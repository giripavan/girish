<section class="cosmic-section" style="padding: 30px 0; background: linear-gradient(135deg, #0f0524 0%, #1a0c33 50%, #eb1111 100%);">
  <div class="container">
    <div class="row">
      <!-- Left Content - Stacked on top for mobile -->
      <div class="col-md-8 col-12 order-md-1 order-2">
        <div class="about_astrology_box" style="margin-bottom: 30px;">
          <div class="about_astrology_content">
            <h1 class="cosmic-gradient-text" style="font-size: 26px; line-height: 1.3; font-family: 'Cinzel'">MASTER SHIVAKUMAR- TRUSTED VEDIC ASTROLOGER IN USA</h1>
            <h3 class="cosmic-glow-text" style="font-size: 18px;">Get Powerful & Authentic Astrology Solutions</h3>
            <p style="color: #eee; font-size: 16px; line-height: 1.6; margin-bottom: 15px;"><strong style="color:yellow;">MASTER SHIVAKUMAR</strong> is a highly respected Vedic astrologer based in New York, known for offering powerful spiritual insights and life-transforming remedies. With deep expertise in traditional astrology and energy healing,<strong style="color:yellow;"> Master Shivakumar</strong> has guided individuals through challenges in love, relationships, business, health, and spiritual blockages. His personalized approach and intuitive guidance have earned him trust from people across all walks of life.</p>
            <p style="color: #eee; font-size: 16px; line-height: 1.6; margin-bottom: 20px;">Using sacred mantras and ancient astrological techniques, <strong style="color:yellow;"> Master Shivakumar</strong> guides individuals toward peace, prosperity, and emotional well-being. Based in New York, he firmly believes that the movements of celestial bodies shape human experiences and offers tailored solutions that help align your life with cosmic energies.</p>
            <a href="contact-us.php" class="cosmic-btn" style="display: inline-block; padding: 10px 20px; font-size: 16px;">Know Your Future</a>
          </div>
          <!-- Astrology Symbols Grid - 2 rows, 3 columns -->
          <div class="astrology-symbols-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); grid-template-rows: repeat(2, 1fr); gap: 15px; margin-top: 30px;">
            <div class="cosmic-symbol" style="width: 100%; max-width: 70px; height: 70px; font-size: 30px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 50%; background: rgba(255,255,255,0.1); box-shadow: 0 0 15px #FF4500; animation: symbolPulse 4s infinite;">♄</div>
            <div class="cosmic-symbol" style="width: 100%; max-width: 70px; height: 70px; font-size: 30px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 50%; background: rgba(255,255,255,0.1); box-shadow: 0 0 15px #1E90FF; animation: symbolPulse 4s infinite 0.2s;">♅</div>
            <div class="cosmic-symbol" style="width: 100%; max-width: 70px; height: 70px; font-size: 30px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 50%; background: rgba(255,255,255,0.1); box-shadow: 0 0 15px #32CD32; animation: symbolPulse 4s infinite 0.4s;">♆</div>
            <div class="cosmic-symbol" style="width: 100%; max-width: 70px; height: 70px; font-size: 30px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 50%; background: rgba(255,255,255,0.1); box-shadow: 0 0 15px #FFD700; animation: symbolPulse 4s infinite 0.6s;">♇</div>
            <div class="cosmic-symbol" style="width: 100%; max-width: 70px; height: 70px; font-size: 30px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 50%; background: rgba(255,255,255,0.1); box-shadow: 0 0 15px #FF69B4; animation: symbolPulse 4s infinite 0.8s;">⚷</div>
            <div class="cosmic-symbol" style="width: 100%; max-width: 70px; height: 70px; font-size: 30px; display: flex; align-items: center; justify-content: center; color: white; border-radius: 50%; background: rgba(255,255,255,0.1); box-shadow: 0 0 15px #00FFFF; animation: symbolPulse 4s infinite 1s;">⚶</div>
          </div>
        </div>
      </div>

      <!-- Right Side - Stats (Moved to top on mobile) -->
      <div class="col-md-4 col-12 order-md-2 order-1">
        <div class="cosmic-stats-wrapper" style="background: rgba(15, 5, 36, 0.6); border-radius: 15px; padding: 20px; margin-bottom: 30px; backdrop-filter: blur(5px);">
          <h3 class="stats-title" style="color: white; font-size: 18px; text-align: center; margin-bottom: 20px;">Celestial Success Metrics</h3>
          
          <!-- Stat Item 1 -->
          <div class="cosmic-stat-card" style="background: rgba(255,255,255,0.05); border-radius: 12px; padding: 15px; margin-bottom: 15px;">
            <div class="stat-visual" style="display: flex; flex-direction: column; align-items: center;">
              <div class="stat-circle" style="position: relative; width: 70px; height: 70px; margin-bottom: 8px;">
                <svg class="progress-ring" width="70" height="70" viewBox="0 0 70 70">
                  <circle class="progress-ring-circle" stroke="#FF4B2B" stroke-width="5" fill="transparent" r="30" cx="35" cy="35" style="stroke-dasharray: 188; stroke-dashoffset: 188;"/>
                </svg>
                <span class="stat-percent" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 18px; color: white;">0%</span>
              </div>
              <div class="stat-stars" style="color: #FF4B2B; font-size: 16px; margin-bottom: 5px;">✧✧✧</div>
            </div>
            <div class="stat-name" style="color: white; text-align: center; font-size: 14px;">Customer Visits</div>
          </div>
          
          <!-- Stat Item 2 -->
          <div class="cosmic-stat-card" style="background: rgba(255,255,255,0.05); border-radius: 12px; padding: 15px; margin-bottom: 15px;">
            <div class="stat-visual" style="display: flex; flex-direction: column; align-items: center;">
              <div class="stat-circle" style="position: relative; width: 70px; height: 70px; margin-bottom: 8px;">
                <svg class="progress-ring" width="70" height="70" viewBox="0 0 70 70">
                  <circle class="progress-ring-circle" stroke="#9C27B0" stroke-width="5" fill="transparent" r="30" cx="35" cy="35" style="stroke-dasharray: 188; stroke-dashoffset: 188;"/>
                </svg>
                <span class="stat-percent" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 18px; color: white;">0%</span>
              </div>
              <div class="stat-stars" style="color: #9C27B0; font-size: 16px; margin-bottom: 5px;">✦✦✦</div>
            </div>
            <div class="stat-name" style="color: white; text-align: center; font-size: 14px;">Satisfaction</div>
          </div>
          
          <!-- Stat Item 3 -->
          <div class="cosmic-stat-card" style="background: rgba(255,255,255,0.05); border-radius: 12px; padding: 15px; margin-bottom: 15px;">
            <div class="stat-visual" style="display: flex; flex-direction: column; align-items: center;">
              <div class="stat-circle" style="position: relative; width: 70px; height: 70px; margin-bottom: 8px;">
                <svg class="progress-ring" width="70" height="70" viewBox="0 0 70 70">
                  <circle class="progress-ring-circle" stroke="#2196F3" stroke-width="5" fill="transparent" r="30" cx="35" cy="35" style="stroke-dasharray: 188; stroke-dashoffset: 188;"/>
                </svg>
                <span class="stat-percent" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 18px; color: white;">0%</span>
              </div>
              <div class="stat-stars" style="color: #2196F3; font-size: 16px; margin-bottom: 5px;">✧✦✧</div>
            </div>
            <div class="stat-name" style="color: white; text-align: center; font-size: 14px;">Problems Solved</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<style>
  /* Mobile-first styles */
  .cosmic-gradient-text {
    background: linear-gradient(90deg, #FF4B2B, #FF416C, #9C27B0);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: 700;
    margin-bottom: 10px;
  }
  
  .cosmic-glow-text {
    color: white;
    text-shadow: 0 0 10px rgba(255, 255, 255, 0.7);
    margin-bottom: 15px;
  }
  
  .cosmic-btn {
    background: linear-gradient(45deg, #FF4B2B, #FF416C);
    color: white;
    border-radius: 25px;
    text-decoration: none;
    font-weight: bold;
    border: none;
    box-shadow: 0 4px 10px rgba(255, 75, 43, 0.4);
    transition: all 0.3s ease;
  }
  
  .cosmic-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(255, 75, 43, 0.6);
  }
  
  @keyframes symbolPulse {
    0% { transform: scale(1); opacity: 0.8; }
    50% { transform: scale(1.1); opacity: 1; box-shadow: 0 0 25px currentColor; }
    100% { transform: scale(1); opacity: 0.8; }
  }
  
  /* Progress Ring Animation */
  @keyframes progressAnimation {
    from { stroke-dashoffset: 188; }
    to { stroke-dashoffset: 0; }
  }
  
  /* Tablet and Desktop */
  @media (min-width: 768px) {
    .cosmic-gradient-text {
      font-size: 32px;
    }
    
    .cosmic-glow-text {
      font-size: 20px;
    }
    
    .cosmic-btn {
      padding: 12px 25px;
      font-size: 16px;
    }
    
    .stats-title {
      font-size: 22px;
    }
    
    .stat-percent {
      font-size: 20px;
    }
    
    .stat-name {
      font-size: 16px;
    }
  }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Animate percentage counters on mobile
  const statCards = document.querySelectorAll('.cosmic-stat-card');
  const targets = [95, 98, 97];
  const colors = ['#FF4B2B', '#9C27B0', '#2196F3'];
  
  statCards.forEach((card, index) => {
    const target = targets[index];
    const percentElement = card.querySelector('.stat-percent');
    const circle = card.querySelector('.progress-ring-circle');
    const circumference = 188; // 2 * π * r (where r=30)
    
    // Set initial state
    circle.style.strokeDashoffset = circumference;
    percentElement.textContent = '0%';
    
    // Start animation after a delay
    setTimeout(() => {
      let current = 0;
      const increment = target / 50;
      
      const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
          current = target;
          clearInterval(timer);
        }
        
        const offset = circumference - (current / 100) * circumference;
        circle.style.strokeDashoffset = offset;
        percentElement.textContent = Math.round(current) + '%';
        
        // Add glow effect when animation completes
        if (current === target) {
          card.style.boxShadow = `0 0 15px ${colors[index]}`;
          setTimeout(() => {
            card.style.boxShadow = 'none';
          }, 500);
        }
      }, 20);
    }, 300 * (index + 1));
  });
});
</script>


<!-- map start -->
<div style="position: relative; display: flex; justify-content: center; align-items: center; height: 500px; background: #f5f5f5; padding: 20px; border-radius: 10px; flex-wrap: wrap;">
    <!-- Address Title -->
    <div style="position: absolute; top: 20px; left: 30px; right: 30px; z-index: 10; background: rgba(30, 15, 50, 0.8); color: #fff; padding: 10px 15px; border-radius: 8px; font-size: 16px; font-weight: 500; text-align: center;">
        📍 8811 Enfield Ct, Laurel, MD 20708
    </div>

    <!-- Google Map -->
    <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.391179017193!2d-76.85376872457335!3d39.16112953801873!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89b7ddc1a3b2f4c1%3A0x3c8a7a8a7c5d3b8f!2s8811%20Enfield%20Ct%2C%20Laurel%2C%20MD%2020708!5e0!3m2!1sen!2sus!4v1712237640137!5m2!1sen!2sus" 
        width="100%" height="100%" style="min-height: 350px; border:5px solid #333; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);" 
        allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
    </iframe>
</div>

<!-- map end -->