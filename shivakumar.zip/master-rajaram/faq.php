<style>
  :root {
    --primary: #6c5ce7;
    --secondary: #a29bfe;
    --dark: #2d3436;
    --light: #f5f6fa;
    --accent: #fd79a8;
    --card-bg: #ffffff;
  }

  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: 'Inter', sans-serif;
    background-color: var(--light);
  }

  .faq-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 60px 20px;
    display: flex;
    gap: 40px;
    align-items: center;
  }

  .faq-image {
    flex: 1;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15);
    transform: rotate(-2deg);
    transition: transform 0.3s ease;
  }

  .faq-image:hover {
    transform: rotate(0deg);
  }

  .faq-image img {
    width: 100%;
    height: auto;
    display: block;
    transition: transform 0.5s ease;
  }

  .faq-image:hover img {
    transform: scale(1.03);
  }

  .faq-content {
    flex: 1;
  }

  .faq-title {
    font-size: 2.5rem;
    color: var(--dark);
    margin-bottom: 30px;
    font-weight: 700;
    line-height: 1.2;
  }

  .faq-title span {
    color: var(--primary);
  }

  .faq-cards {
    display: flex;
    flex-direction: column;
    gap: 16px;
  }

  .faq-card {
    background: var(--card-bg);
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    cursor: pointer;
    transition: all 0.3s ease;
    border-left: 4px solid transparent;
  }

  .faq-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    border-left-color: var(--accent);
  }

  .faq-card.active {
    border-left-color: var(--primary);
  }

  .faq-question {
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--dark);
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .faq-icon {
    width: 24px;
    height: 24px;
    position: relative;
    margin-left: 15px;
    flex-shrink: 0;
  }

  .faq-icon::before,
  .faq-icon::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: var(--primary);
    transition: all 0.3s ease;
  }

  .faq-icon::before {
    width: 16px;
    height: 2px;
  }

  .faq-icon::after {
    width: 2px;
    height: 16px;
  }

  .faq-card.active .faq-icon::after {
    transform: translate(-50%, -50%) rotate(90deg);
    opacity: 0;
  }

  .faq-answer {
    max-height: 0;
    overflow: hidden;
    color: #64748b;
    line-height: 1.6;
    transition: max-height 0.5s cubic-bezier(0.4, 0, 0.2, 1);
    padding-top: 0;
  }

  .faq-card.active .faq-answer {
    max-height: 300px;
    padding-top: 15px;
  }

  @media (max-width: 992px) {
    .faq-container {
      flex-direction: column;
    }

    .faq-image {
      width: 100%;
      max-width: 500px;
      margin-bottom: 40px;
    }

    .faq-title {
      text-align: center;
    }
  }

  @media (max-width: 576px) {
    .faq-container {
      padding: 40px 15px;
    }

    .faq-title {
      font-size: 2rem;
    }

    .faq-card {
      padding: 16px;
    }
  }
</style>

<div class="faq-container">
  <div class="faq-image">
    <img src="https://images.unsplash.com/photo-1534447677768-be436bb09401?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" alt="Astrology Illustration">
  </div>
  
  <div class="faq-content">
    <h2 class="faq-title">Astrology <span>FAQs</span></h2>
    
    <div class="faq-cards">
      <div class="faq-card active">
        <div class="faq-question">
          What is astrology and how does it work?
          <div class="faq-icon"></div>
        </div>
        <div class="faq-answer" style="max-height: 300px; padding-top: 15px;">
          Astrology is the study of celestial bodies and their influence on human lives. It works by analyzing the positions of planets at specific moments (like your birth) to provide insights about personality and life patterns.
        </div>
      </div>
      
      <div class="faq-card">
        <div class="faq-question">
          Can astrology help with relationships?
          <div class="faq-icon"></div>
        </div>
        <div class="faq-answer">
          Yes! Astrology can reveal compatibility through synastry (chart comparison) and composite charts. It helps understand emotional needs, communication styles, and potential challenges in partnerships.
        </div>
      </div>
      
      <div class="faq-card">
        <div class="faq-question">
          What exactly is a birth chart?
          <div class="faq-icon"></div>
        </div>
        <div class="faq-answer">
          Your birth chart is a snapshot of the sky at your exact moment of birth. It maps planets across zodiac signs and twelve houses to create your unique cosmic blueprint.
        </div>
      </div>
      
      <div class="faq-card">
        <div class="faq-question">
          How accurate are astrology predictions?
          <div class="faq-icon"></div>
        </div>
        <div class="faq-answer">
          Astrology reveals tendencies rather than fixed outcomes. Accuracy improves with precise birth data and skilled interpretation, but your free will always plays the decisive role.
        </div>
      </div>
      
      <div class="faq-card">
        <div class="faq-question">
          What's the difference between sun and moon signs?
          <div class="faq-icon"></div>
        </div>
        <div class="faq-answer">
          Your sun sign represents your core identity, while your moon sign governs your emotional nature. The sun shows how you shine, the moon reveals how you feel.
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    const faqCards = document.querySelectorAll('.faq-card');
    
    // Open first card by default
    faqCards[0].classList.add('active');
    
    faqCards.forEach(card => {
      card.addEventListener('click', () => {
        // Close all other cards
        faqCards.forEach(otherCard => {
          if (otherCard !== card) {
            otherCard.classList.remove('active');
            otherCard.querySelector('.faq-answer').style.maxHeight = '0';
            otherCard.querySelector('.faq-answer').style.paddingTop = '0';
          }
        });
        
        // Toggle current card
        card.classList.toggle('active');
        const answer = card.querySelector('.faq-answer');
        
        if (card.classList.contains('active')) {
          answer.style.maxHeight = '300px';
          answer.style.paddingTop = '15px';
        } else {
          answer.style.maxHeight = '0';
          answer.style.paddingTop = '0';
        }
      });
    });
  });
</script>