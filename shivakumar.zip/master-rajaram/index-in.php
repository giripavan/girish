<section class="cosmic-astrologer" style="background: #000 url('https://images.unsplash.com/photo-1464802686167-b939a6910659?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2150&q=80') no-repeat center center/cover; padding: 80px 0; position: relative; overflow: hidden;">
    <!-- Dark overlay -->
    <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.7);"></div>
    
    <div class="container" style="position: relative; z-index: 2;">
        <div class="row">
            
            
            <!-- Content Column -->
            <div class="col-md-7">
                <div style="background: rgba(20, 20, 20, 0.8); border: 1px solid #4d3a1f; border-radius: 10px; padding: 30px; box-shadow: 0 5px 15px rgba(0,0,0,0.3);">
                    <!-- Title -->
                    <div class="text-center mb-4">
                        <h2 style="color: #e4c590; font-family: 'Cinzel', serif; position: relative; display: inline-block;">
                            <span style="position: relative; z-index: 2; padding: 0 20px; background: rgba(20, 20, 20, 0.8);">The Astrologer Guide</span>
                            <span style="position: absolute; top: 50%; left: 0; width: 100%; height: 1px; background: linear-gradient(90deg, transparent, #9c7c4d, transparent); z-index: 1;"></span>
                        </h2>
                    </div>
                    
                    <!-- Introduction -->
                    <p style="color: white ; line-height: 1.8; margin-bottom: 25px; font-size: 16px; text-align: center; font-style: italic;">
                        "Renowned across continents for his extraordinary gifts,<strong style="color:yellow;">  Master Shiva Kumar </strong> brings ancient wisdom to modern lives"
                    </p>
                    
                    <!-- Services Accordion -->
                    <div class="mystic-services">
                        <!-- Service 1 -->
                        <div class="service-item" style="margin-bottom: 15px; border-bottom: 1px dashed #4d3a1f; padding-bottom: 15px;">
                            <div class="service-title" style="color: #e4c590; font-weight: 600; cursor: pointer; position: relative; padding-left: 25px;">
                                <span style="position: absolute; left: 0; top: 2px;">✧</span> Remove Bad Luck in 48 Hours
                            </div>
                            <div class="service-content" style="color: #b5b5b5; padding-top: 10px; line-height: 1.7;">
                                <p style="color: white;">Specializing in negative energy removal,<strong style="color:yellow;">  Master Shiva Kumar </strong>  provides solutions when others impose black magic to harm your life. His mastery over both white and black magic offers complete protection.</p>
                            </div>
                        </div>
                        
                        <!-- Service 2 -->
                        <div class="service-item" style="margin-bottom: 15px; border-bottom: 1px dashed #4d3a1f; padding-bottom: 15px;">
                            <div class="service-title" style="color: #e4c590; font-weight: 600; cursor: pointer; position: relative; padding-left: 25px;">
                                <span style="position: absolute; left: 0; top: 2px;">✧</span> Love Return in 9 Days
                            </div>
                            <div class="service-content" style="color: #b5b5b5; padding-top: 10px; line-height: 1.7;">
                                <p style="color: white;">When love separation disrupts your life, his ancient astrological techniques can reunite lost loves and resolve relationship conflicts with remarkable effectiveness.</p>
                            </div>
                        </div>
                        
                        <!-- Service 3 -->
                        <div class="service-item" style="margin-bottom: 15px;">
                            <div class="service-title" style="color: #e4c590; font-weight: 600; cursor: pointer; position: relative; padding-left: 25px;">
                                <span style="position: absolute; left: 0; top: 2px;">✧</span> Win Back Your Partner
                            </div>
                            <div class="service-content" style="color: #b5b5b5; padding-top: 10px; line-height: 1.7;">
                                <p style="color: white;">No need for begging or crying. His spiritual methods can rekindle lost connections and heal broken relationships through cosmic alignment.</p>
                                <a href="contact-us.php" style="color: #e4c590; text-decoration: none; font-weight: 600; display: inline-block; margin-top: 10px; border-bottom: 1px dotted #e4c590;">Begin Your Journey →</a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Call to Action -->
                <div class="text-center mt-4">
                    <div style="background: linear-gradient(90deg, transparent, #9c7c4d, transparent); height: 1px; margin: 20px 0;"></div>
                    <p style="color: #b5b5b5; font-size: 14px; letter-spacing: 1px;">
                       
                    </p>
                </div>
            </div>
			<!-- Psychic Image Column -->
            <div class="col-md-5 mb-4 mb-md-0">
                <div style="border: 5px solid #9c7c4d; border-radius: 10px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.5);">
                    <img src="./images/shiva.jpg" alt="Psychic Sanju" style="width: 100%; display: block;">
                </div>
                <div class="text-center mt-3">
                    <div style="display: inline-block; background: linear-gradient(90deg, transparent, #9c7c4d, transparent); height: 2px; width: 80%;"></div>
                    <h3 class="mt-3" style="color: #e4c590; font-family: 'Playfair Display', serif; letter-spacing: 1px;">MASTER SHIVA KUMAR</h3>
                    <p style="color: White; letter-spacing: 2px; font-size: 14px;">Master Astrologer • Love  Problem</p>
                </div>
            </div>
        </div>
    </div>
</section>