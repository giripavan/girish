<!DOCTYPE HTML>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="de">  <!--<![endif]-->
<head>
<!-- Event snippet for Submit lead form conversion page -->


	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
 <title>Astrologer in New York</title>
    
<?php
	include('header.php');
	?>
	
 <div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:980px;height:510px;overflow:hidden;visibility:hidden;">
        <!-- Loading Screen -->
        <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
            <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="../svg/loading/static-svg/spin.svg" alt="Astrologer in " />
        </div>
        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:510px;overflow:hidden;">
           
<div>
                <img data-u="image" src="./images/msb.jpg" alt="Palm Reading"/>
            </div>
		   <div>
                <img data-u="image" src="./images/msb1.jpg" alt="Black magic removal"/>
            </div>
            <div>
                <img data-u="image" src="./images/msb2.jpg" alt="Get ex-love back"/>
            </div>
            
		
     
        </div>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb053" style="position:absolute;bottom:12px;right:12px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
            <div data-u="prototype" class="i" style="width:16px;height:16px;">
                <svg viewBox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <path class="b" d="M11400,13800H4600c-1320,0-2400-1080-2400-2400V4600c0-1320,1080-2400,2400-2400h6800 c1320,0,2400,1080,2400,2400v6800C13800,12720,12720,13800,11400,13800z"></path>
                </svg>
            </div>
        </div>
        <!-- Arrow Navigator -->
        <div data-u="arrowleft" class="jssora093" style="width:50px;height:50px;top:0px;left:30px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
            <svg viewBox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <circle class="c" cx="8000" cy="8000" r="5920"></circle>
                <polyline class="a" points="7777.8,6080 5857.8,8000 7777.8,9920 "></polyline>
                <line class="a" x1="10142.2" y1="8000" x2="5857.8" y2="8000"></line>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora093" style="width:50px;height:50px;top:0px;right:30px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
            <svg viewBox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <circle class="c" cx="8000" cy="8000" r="5920"></circle>
                <polyline class="a" points="8222.2,6080 10142.2,8000 8222.2,9920 "></polyline>
                <line class="a" x1="5857.8" y1="8000" x2="10142.2" y2="8000"></line>
            </svg>
        </div>
    </div>
	<!-- about section start -->

	
	<?php
	include('index-in.php');
	?>
	
	<?php
	include('services.php');
	?>
	
    <?php
	include('poojaservices.php');
	?>
	<?php 
    include('one.php');
    ?>
		
	<?php
	include('testimonials.php');
	?>
	<div style="position: relative; display: flex; justify-content: center; align-items: center; height: 500px; background: #f5f5f5; padding: 20px; border-radius: 10px; flex-wrap: wrap;">
    <!-- Address Title -->
    <div style="position: absolute; top: 20px; left: 30px; right: 30px; z-index: 10; background: rgba(30, 15, 50, 0.8); color: #fff; padding: 10px 15px; border-radius: 8px; font-size: 16px; font-weight: 500; text-align: center;">
        📍 8811 Enfield Ct, Laurel, MD 20708
    </div>

    <!-- Google Map -->
    <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3093.391179017193!2d-76.85376872457335!3d39.16112953801873!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89b7ddc1a3b2f4c1%3A0x3c8a7a8a7c5d3b8f!2s8811%20Enfield%20Ct%2C%20Laurel%2C%20MD%2020708!5e0!3m2!1sen!2sus!4v1712237640137!5m2!1sen!2sus" 
        width="100%" height="100%" style="min-height: 350px; border:5px solid #333; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);" 
        allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
    </iframe>
</div>
	
<section style="padding: 100px 0; background: linear-gradient(to bottom, #FFA725 0%,rgb(76, 102, 141) 100%);">
    <div class="container">
        <!-- Section Header -->
        <div class="text-center mb-6" style="margin-bottom: 60px;">
            <h2 style="font-size: 3rem; font-weight: 700; color: #690B22; margin-bottom: 15px; position: relative; display: inline-block; font-family: 'Cinzel'">
                Your Questions Answered
                <span style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%); width: 80px; height: 4px; background: linear-gradient(90deg, #6a11cb 0%, #2575fc 100%); border-radius: 2px;"></span>
            </h2>
            <p style="font-size: 1.3rem; color: black; max-width: 700px; margin: 0 auto;">Quick answers to the most common astrology queries from our clients</p>
        </div>

        <!-- FAQ Grid with Vertical Gaps -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; margin-bottom: 3rem;">
            <!-- FAQ Card 1 -->
            <div class="faq-card" style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: all 0.3s ease; border-left: 4px solid #6a11cb;"
                 onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 15px 35px rgba(0,0,0,0.1)';"
                 onmouseout="this.style.transform=''; this.style.boxShadow='0 10px 30px rgba(0,0,0,0.05)'">
                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%); border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 15px; flex-shrink: 0;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M9.09 9C9.3251 8.33167 9.78915 7.76811 10.4 7.40913C11.0108 7.05016 11.7289 6.91894 12.4272 7.03871C13.1255 7.15849 13.7588 7.52152 14.2151 8.06353C14.6713 8.60553 14.9211 9.29152 14.92 10C14.92 12 11.92 13 11.92 13" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M12 17H12.01" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <h3 style="font-size: 1.45rem; font-weight: 600; color: #1a1a1a; margin: 0;">How accurate are astrology predictions?</h3>
                </div>
                <p style="color: #4b5563; line-height: 1.6; margin-bottom: 0;">Astrology provides insightful guidance rather than absolute predictions. Accuracy depends on the astrologer's skill, the clarity of your birth chart, and how you apply the insights to your life circumstances.</p>
            </div>

            <!-- FAQ Card 2 -->
            <div class="faq-card" style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: all 0.3s ease; border-left: 4px solid #ec4899;"
                 onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 15px 35px rgba(0,0,0,0.1)';"
                 onmouseout="this.style.transform=''; this.style.boxShadow='0 10px 30px rgba(0,0,0,0.05)'">
                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #ec4899 0%, #f43f5e 100%); border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 15px; flex-shrink: 0;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M17 21V19C17 17.9391 16.5786 16.9217 15.8284 16.1716C15.0783 15.4214 14.0609 15 13 15H5C3.93913 15 2.92172 15.4214 2.17157 16.1716C1.42143 16.9217 1 17.9391 1 19V21" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M9 11C11.2091 11 13 9.20914 13 7C13 4.79086 11.2091 3 9 3C6.79086 3 5 4.79086 5 7C5 9.20914 6.79086 11 9 11Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M23 21V19C22.9993 18.1137 22.7044 17.2528 22.1614 16.5523C21.6184 15.8519 20.8581 15.3516 20 15.13" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M16 3.13C16.8604 3.3503 17.623 3.8507 18.1676 4.55231C18.7122 5.25392 19.0078 6.11683 19.0078 7.005C19.0078 7.89317 18.7122 8.75608 18.1676 9.45769C17.623 10.1593 16.8604 10.6597 16 10.88" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <h3 style="font-size: 1.45rem; font-weight: 600; color: #1a1a1a; margin: 0;">Can astrology help with relationships?</h3>
                </div>
                <p style="color: #4b5563; line-height: 1.6; margin-bottom: 0;">Absolutely. Synastry (relationship astrology) compares two birth charts to reveal compatibility, communication styles, and potential challenges. Many couples find it helps deepen understanding and navigate conflicts.</p>
            </div>

            <!-- FAQ Card 3 -->
            <div class="faq-card" style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: all 0.3s ease; border-left: 4px solid #10b981;"
                 onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 15px 35px rgba(0,0,0,0.1)';"
                 onmouseout="this.style.transform=''; this.style.boxShadow='0 10px 30px rgba(0,0,0,0.05)'">
                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #10b981 0%, #059669 100%); border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 15px; flex-shrink: 0;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M19 21V5C19 3.89543 18.1046 3 17 3H7C5.89543 3 5 3.89543 5 5V21M19 21L21 21M19 21H14M5 21L3 21M5 21H10M9 7H10M9 11H10M9 15H10M14 7H15M14 11H15M14 15H15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <h3 style="font-size: 1.45rem; font-weight: 600; color: #1a1a1a; margin: 0;">What's included in a birth chart reading?</h3>
                </div>
                <p style="color: #4b5563; line-height: 1.6; margin-bottom: 0;">A comprehensive reading analyzes your Sun, Moon, and Rising signs, planetary placements, aspects between planets, houses, and major life themes. We focus on both your strengths and areas for growth.</p>
            </div>

            <!-- FAQ Card 4 -->
            <div class="faq-card" style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: all 0.3s ease; border-left: 4px solid #f59e0b;"
                 onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 15px 35px rgba(0,0,0,0.1)';"
                 onmouseout="this.style.transform=''; this.style.boxShadow='0 10px 30px rgba(0,0,0,0.05)'">
                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 15px; flex-shrink: 0;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 3V5M3 12H5M6.2 6.2L7.5 7.5M17.8 6.2L16.5 7.5M6.2 17.8L7.5 16.5M17.8 17.8L16.5 16.5M21 12H19M12 19V21M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <h3 style="font-size: 1.45rem; font-weight: 600; color: #1a1a1a; margin: 0;">How do planetary retrogrades affect me?</h3>
                </div>
                <p style="color: #4b5563; line-height: 1.6; margin-bottom: 0;">Retrogrades (especially Mercury) often bring delays, reconsiderations, or revisiting past issues. Their effects vary based on which houses/planets they activate in your chart. We'll identify specifically how they impact you.</p>
            </div>

            <!-- FAQ Card 5 -->
            <div class="faq-card" style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: all 0.3s ease; border-left: 4px solid #3b82f6;"
                 onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 15px 35px rgba(0,0,0,0.1)';"
                 onmouseout="this.style.transform=''; this.style.boxShadow='0 10px 30px rgba(0,0,0,0.05)'">
                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 15px; flex-shrink: 0;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15M9 5C9 6.10457 9.89543 7 11 7H13C14.1046 7 15 6.10457 15 5M9 5C9 3.89543 9.89543 3 11 3H13C14.1046 3 15 3.89543 15 5M12 12H15M12 16H15M9 12H9.01M9 16H9.01" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <h3 style="font-size: 1.45rem; font-weight: 600; color: #1a1a1a; margin: 0;">Do you provide written reports?</h3>
                </div>
                <p style="color: #4b5563; line-height: 1.6; margin-bottom: 0;">Yes! All consultations include a digital recording and summary notes. Full written reports (15-20 pages) are available as an add-on service with detailed interpretations of your chart components.</p>
            </div>

            <!-- FAQ Card 6 -->
            <div class="faq-card" style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: all 0.3s ease; border-left: 4px solid #8b5cf6;"
                 onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 15px 35px rgba(0,0,0,0.1)';"
                 onmouseout="this.style.transform=''; this.style.boxShadow='0 10px 30px rgba(0,0,0,0.05)'">
                <div style="display: flex; align-items: center; margin-bottom: 20px;">
                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 15px; flex-shrink: 0;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM12 20C7.59 20 4 16.41 4 12C4 7.59 7.59 4 12 4C16.41 4 20 7.59 20 12C20 16.41 16.41 20 12 20ZM11 16H13V18H11V16ZM12 6C9.79 6 8 7.79 8 10H10C10 8.9 10.9 8 12 8C13.1 8 14 8.9 14 10C14 12 11 11.75 11 15H13C13 12.75 16 12.5 16 10C16 7.79 14.21 6 12 6Z" fill="white"/>
                        </svg>
                    </div>
                    <h3 style="font-size: 1.45rem; font-weight: 600; color: #1a1a1a; margin: 0;">What if I don't know my birth time?</h3>
                </div>
                <p style="color: #4b5563; line-height: 1.6; margin-bottom: 0;">While exact time is ideal, we can work with approximate times or noon charts. The Moon moves about 12° daily, so without a time, we estimate its position. Rectification services are available to help determine your likely birth time.</p>
            </div>
        </div>

        
    </div>
</section>
	
	
	
		
	<?php
	include('footer.php');
	?>