<section class="circle-pooja-section">
  <h2> Select Sacred Pooja Services</h2>
  <div class="circle-card-grid">

    <!-- Ganesha Pooja -->
    <div class="circle-card">
      <img src="images/msp.jpg" alt="Ganapathi Pooja">
      <div class="circle-overlay">
        <h3>Ganapathi Pooja</h3>
        <p>Removes obstacles and ensures success in new ventures.</p>
        <a href="ganesha-pooja.php">Read More</a>
      </div>
    </div>

    <!-- Lakshmi Pooja -->
    <div class="circle-card">
      <img src="images/msp2.jpg" alt="Lakshmi Pooja">
      <div class="circle-overlay">
        <h3>Lakshmi Pooja</h3>
        <p>Brings wealth, prosperity, and divine abundance to your home.</p>
        <a href="lakshmi-pooja.php">Read More</a>
      </div>
    </div>

    <!-- Kali Mata Pooja -->
    <div class="circle-card">
      <img src="images/msp3.jpg" alt="Kalimata Pooja">
      <div class="circle-overlay">
        <h3>Kali Mata Pooja</h3>
        <p>Destroys negative energies and protects from evil forces.</p>
        <a href="kalimata-pooja.php">Read More</a>
      </div>
    </div>

    <!-- Shiva Pooja -->
    <div class="circle-card">
      <img src="images/msp4.jpg" alt="Shiva Pooja">
      <div class="circle-overlay">
        <h3>Shiva Pooja</h3>
        <p>Ensures peace, liberation, and spiritual awakening.</p>
        <a href="shiva-pooja.php">Read More</a>
      </div>
    </div>

    <!-- Hanuman Pooja -->
    <div class="circle-card">
      <img src="images/msp5.jpg" alt="Hanuman Pooja">
      <div class="circle-overlay">
        <h3>Hanuman Pooja</h3>
        <p>Grants strength, protection, and success in life’s battles.</p>
        <a href="hanuman-pooja.php">Read More</a>
      </div>
    </div>

    <!-- Shani Pooja -->
    <div class="circle-card">
      <img src="images/msp6.jpg" alt="Shani Pooja">
      <div class="circle-overlay">
        <h3>Shani Pooja</h3>
        <p>Reduces Saturn's malefic effects and brings karmic balance.</p>
        <a href="shani-pooja.php">Read More</a>
      </div>
    </div>

  </div>
</section>

<style>
.circle-pooja-section {
  background: linear-gradient(to right, #0a0a0a, #1a1a1a);
  padding: 60px 20px;
  text-align: center;
  font-family: 'Poppins', sans-serif;
  color: #fff;
}
.circle-pooja-section h2 {
  color: #ffc107;
  font-size: 36px;
  margin-bottom: 50px;
}
.circle-card-grid {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 40px;
}
.circle-card {
  width: 280px;
  height: 280px;
  position: relative;
  border-radius: 50%;
  overflow: hidden;
  cursor: pointer;
  transition: transform 0.4s;
}
.circle-card img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 50%;
  display: block;
  transition: transform 0.4s ease;
}
.circle-card:hover img {
  transform: scale(1.08);
  filter: brightness(0.3);
}
.circle-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border-radius: 50%;
  background: rgba(0, 0, 0, 0.75);
  color: #fff;
  opacity: 0;
  padding: 30px 20px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: center;
  transition: opacity 0.4s ease;
}
.circle-card:hover .circle-overlay {
  opacity: 1;
}
.circle-overlay h3 {
  font-size: 20px;
  margin-bottom: 12px;
  color: #ffcc00;
}
.circle-overlay p {
  font-size: 15px;
  margin-bottom: 15px;
  line-height: 1.4;
  color:white;
}
.circle-overlay a {
  padding: 8px 18px;
  background: #ffc107;
  color: #000;
  border-radius: 20px;
  text-decoration: none;
  font-weight: bold;
  font-size: 14px;
  transition: background 0.3s ease;
}
.circle-overlay a:hover {
  background: #ffffff;
}
/* Responsive Design */
@media (max-width: 768px) {
  .circle-card {
    width: 200px;
    height: 200px;
  }
  .circle-overlay h3 {
    font-size: 16px;
  }
  .circle-overlay p {
    font-size: 13px;
  }
}
</style>
