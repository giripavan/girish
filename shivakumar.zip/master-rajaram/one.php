<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
<style>
  body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background-color: #390d3b;
    color: #fff;
  }

  .why-choose-us {
    padding: 60px 20px;
    text-align: center;
  }

  .why-choose-us h2 {
    font-size: 2.5rem;
    margin-bottom: 20px;
    color: white;
  }

  .why-choose-us h2 .highlight {
    color: #ff6a00;
  }

  .why-choose-us .description {
    
    max-width: 800px;
    margin: 0 auto 40px;
    line-height: 1.6;
    padding: 0 10px;
    color:orange;
  }

  .features-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 20px;
  }

  .feature-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    background-color: transparent;
    border-radius: 10px;
    padding: 10px;
  }

  .feature-item .icon {
    background-color: #ff6a00;
    color: white;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    margin-bottom: 10px;
  }

  .feature-item p {
    font-size: 1.1rem;
    color: white;
    margin: 0;
  }

  /* Tablet and up */
  @media (min-width: 768px) {
    .why-choose-us {
      padding: 80px 60px;
    }

    .why-choose-us h2 {
      font-size: 3rem;
    }

    .why-choose-us .description {
      font-size: 1.2rem;
    }

    .features-grid {
      grid-template-columns: 1fr 1fr;
      gap: 30px 40px;
    }

    .feature-item {
      flex-direction: row;
      text-align: left;
      align-items: center;
    }

    .feature-item .icon {
      margin-bottom: 0;
      margin-right: 15px;
      width: 70px;
      height: 70px;
      font-size: 28px;
    }

    .feature-item p {
      font-size: 1.2rem;
    }
  }

  /* Desktop */
  @media (min-width: 1024px) {
    .why-choose-us {
      padding: 100px 150px;
    }

    .why-choose-us .description {
      font-size: 1.3rem;
    }
  }
</style>

<section class="why-choose-us">
  <h2><span class="highlight">Why</span> Choose Us</h2>
  <p class="description" style="font-size: 1.9rem;">
    <strong style="color:white;">Master Shiva Kumar</strong> has more than 25 years of experience in the field of astrology and has a
    successful practice running globally with clients from individuals to industrialists and like.
  </p>
  <div class="features-grid">
    <div class="feature-item">
      <div class="icon"><i class="fas fa-user-tie"></i></div>
      <p  style="font-size: 1.9rem;">Renowned Expert Astrologer</p>
    </div>
    <div class="feature-item">
      <div class="icon"><i class="fas fa-phone-alt"></i></div>
      <p  style="font-size: 1.9rem;">24x7, 365 Days Availability</p>
    </div>
    <div class="feature-item">
      <div class="icon"><i class="fas fa-users"></i></div>
      <p  style="font-size: 1.9rem;">Instant Access Worldwide</p>
    </div>
    <div class="feature-item">
      <div class="icon"><i class="fas fa-handshake-angle"></i></div>
      <p  style="font-size: 1.9rem;">Accurate Remedial Solutions</p>
    </div>
    <div class="feature-item">
      <div class="icon"><i class="fas fa-user-lock"></i></div>
      <p  style="font-size: 1.9rem;">Privacy Guaranteed</p>
    </div>
    <div class="feature-item">
      <div class="icon"><i class="fas fa-user-friends"></i></div>
      <p  style="font-size: 1.9rem;">Trusted by Million Clients</p>
    </div>
  </div>
</section>
