<!DOCTYPE HTML>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Witchcraft Reading & Protection - Master Shivakumar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <?php include('header.php'); ?>
  <style>
    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background-color: #0b0711;
      color: #fff;
    }

    .witchcraft-section {
      position: relative;
      background: linear-gradient(to right, #1a001f, #32003c);
      padding: 100px 20px;
      overflow: hidden;
    }

    .container {
      max-width: 1200px;
      margin: auto;
      position: relative;
      z-index: 2;
    }

    .witch-grid {
      display: flex;
      flex-wrap: wrap;
      gap: 60px;
      align-items: center;
      justify-content: space-between;
    }

    .witch-text {
      flex: 1 1 500px;
    }

    .witch-text h2 {
      font-size: 3.5rem;
      color: #ff85c1;
      margin-bottom: 20px;
    }

    .witch-text p {
      font-size: 1.6rem;
      color: #ffdff1;
      line-height: 1.7;
      margin-bottom: 30px;
    }

    .witch-features {
      list-style: none;
      padding: 0;
      margin-bottom: 40px;
    }

    .witch-features li {
      font-size: 2rem;
      margin-bottom: 14px;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .witch-features li i {
      color: #ff4fcf;
      font-size: 2.4rem;
    }

    .witch-cta {
      display: inline-block;
      background: #ff4fcf;
      padding: 12px 28px;
      border-radius: 30px;
      color: #000;
      font-weight: bold;
      text-decoration: none;
      box-shadow: 0 8px 25px rgba(255, 79, 207, 0.3);
      transition: all 0.3s ease;
    }

    .witch-cta:hover {
      background: #e33fb8;
      box-shadow: 0 10px 30px rgba(227, 63, 184, 0.5);
    }

    .witch-image {
      flex: 1 1 400px;
      position: relative;
    }

    .witch-image img {
      width: 100%;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(255, 255, 255, 0.08);
      transition: transform 0.4s ease;
    }

    .witch-image img:hover {
      transform: scale(1.03);
    }

    .spell-orbs {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1;
      overflow: hidden;
    }

    .orb {
      position: absolute;
      border-radius: 50%;
      background: rgba(255, 79, 207, 0.05);
      animation: floatOrb 25s linear infinite;
    }

    .orb.one {
      width: 320px;
      height: 320px;
      top: -60px;
      left: -100px;
    }

    .orb.two {
      width: 240px;
      height: 240px;
      bottom: 40px;
      right: -60px;
    }

    .orb.three {
      width: 180px;
      height: 180px;
      top: 30%;
      left: 70%;
    }

    @keyframes floatOrb {
      0% { transform: translateY(0); }
      50% { transform: translateY(-25px); }
      100% { transform: translateY(0); }
    }

    @media (max-width: 900px) {
      .witch-grid {
        flex-direction: column;
      }

      .witch-text h2 {
        font-size: 2.5rem;
      }

      .witch-text p {
        font-size: 1.4rem;
      }

      .witch-features li {
        font-size: 1.6rem;
      }

      .witch-cta {
        padding: 10px 20px;
      }
    }
  </style>
</head>
<body>

  <section class="witchcraft-section">
    <div class="spell-orbs">
      <span class="orb one"></span>
      <span class="orb two"></span>
      <span class="orb three"></span>
    </div>

    <div class="container">
      <div class="witch-grid">
        <div class="witch-text">
          <h2>Witchcraft Reading & Removal</h2>
          <p><strong style="color:yellow;">Master Shivakumar</strong> specializes in identifying hidden witchcraft influences affecting your life. Using ancient rituals and spiritual insight, he uncovers negative energies, hexes, or dark spells that may be disturbing your peace, success, and health.</p>
          <p>Through powerful mantras, protective talismans, and divine remedies, Master Shivakumar shields you from black magic and restores your spiritual balance and protection.</p>

          <ul class="witch-features">
            <li><i class="fas fa-hat-wizard"></i> Witchcraft Detection</li>
            <li><i class="fas fa-burn"></i> Curse Removal Rituals</li>
            <li><i class="fas fa-shield-alt"></i> Spiritual Protection</li>
            <li><i class="fas fa-star-of-david"></i> Energy Shield Creation</li>
          </ul>

          <a href="contact-us.php" class="witch-cta">Protect Yourself <i class="fas fa-arrow-circle-right"></i></a>
        </div>

        <div class="witch-image">
          <img src="./images/ms12.jpg" alt="Witchcraft Reading by Master Shivakumar">
        </div>
      </div>
    </div>
  </section>

  <?php include('testimonials.php'); ?>
  <?php include('footer.php'); ?>
</body>
</html>
