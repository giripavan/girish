<section class="services-section">
  <div class="services-header">
    <h2 style="color:red;" ><strong style="color:Blue;">✦</strong>  Astrology Services <strong style="color:Blue;">✦</strong> </h2>
    <p>Master Shivakumar offers powerful spiritual solutions to life's complex challenges.</p>
  </div>

  <div class="services-cards">

    <!-- Love Problem -->
    <div class="service-card" style="background-image: url('images/mss1.jpg');">
      <div class="service-icon">🔗</div>
      <div class="service-info">
        <h3>Love Problem</h3>
        <p>Expert help in resolving relationship and love life challenges with spiritual remedies.</p>
        <div class="card-buttons">
          <a href="tel:+1(443) 851-1838" class="card-btn call">📞 Call</a>
          <a href="https://wa.me/14438511838" target="_blank" class="card-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Black Magic Removal -->
    <div class="service-card" style="background-image: url('images/mss2.jpg');">
      <div class="service-icon">🔗</div>
      <div class="service-info">
        <h3>Black Magic Removal</h3>
        <p>Eliminate dark energies and hexes through ancient protective rituals.</p>
        <div class="card-buttons">
           <a href="tel:+1(443) 851-1838" class="card-btn call">📞 Call</a>
          <a href="https://wa.me/14438511838" target="_blank" class="card-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Business Problem -->
    <div class="service-card" style="background-image: url('images/mss3.jpg');">
      <div class="service-icon">🔗</div>
      <div class="service-info">
        <h3>Business Problem</h3>
        <p>Unlock success and growth with spiritual solutions to business challenges.</p>
        <div class="card-buttons">
           <a href="tel:+1(443) 851-1838" class="card-btn call">📞 Call</a>
          <a href="https://wa.me/14438511838" target="_blank" class="card-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Palm Reading -->
    <div class="service-card" style="background-image: url('images/mss4.jpg');">
      <div class="service-icon">🔗</div>
      <div class="service-info">
        <h3>Palm Reading</h3>
        <p>Reveal your destiny through the lines of the palm interpreted by ancient wisdom.</p>
        <div class="card-buttons">
           <a href="tel:+1(443) 851-1838" class="card-btn call">📞 Call</a>
          <a href="https://wa.me/14438511838" target="_blank" class="card-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Marriage Problem -->
    <div class="service-card" style="background-image: url('images/mss5.jpg');">
      <div class="service-icon">🔗</div>
      <div class="service-info">
        <h3>Marriage Problem</h3>
        <p>Harmonize your marital life through astrological compatibility and remedies.</p>
        <div class="card-buttons">
           <a href="tel:+1(443) 851-1838" class="card-btn call">📞 Call</a>
          <a href="https://wa.me/14438511838" target="_blank" class="card-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Psychic Reading -->
    <div class="service-card" style="background-image: url('images/mss6.jpg');">
      <div class="service-icon">🔗</div>
      <div class="service-info">
        <h3>Psychic Reading</h3>
        <p>Gain insight into your future and unseen energies through psychic vision.</p>
        <div class="card-buttons">
         <a href="tel:+1(443) 851-1838" class="card-btn call">📞 Call</a>
          <a href="https://wa.me/14438511838" target="_blank" class="card-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Career Guidance -->
    <div class="service-card" style="background-image: url('images/mss7.jpg');">
      <div class="service-icon">🔗</div>
      <div class="service-info">
        <h3>Career Guidance</h3>
        <p>Find the right direction in your career using Vedic solutions and intuition.</p>
        <div class="card-buttons">
           <a href="tel:+1(443) 851-1838" class="card-btn call">📞 Call</a>
          <a href="https://wa.me/14438511838" target="_blank" class="card-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Spiritual Healing -->
    <div class="service-card" style="background-image: url('images/mss8.jpg');">
      <div class="service-icon">🔗</div>
      <div class="service-info">
        <h3>Spiritual Healing</h3>
        <p>Cleanse your aura and restore peace through energy balancing rituals.</p>
        <div class="card-buttons">
         <a href="tel:+1(443) 851-1838" class="card-btn call">📞 Call</a>
          <a href="https://wa.me/14438511838" target="_blank" class="card-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Financial Problem -->
    <div class="service-card" style="background-image: url('images/mss9.jpg');">
      <div class="service-icon">🔗</div>
      <div class="service-info">
        <h3>Financial Problem</h3>
        <p>Overcome financial stress and attract abundance through spiritual means.</p>
        <div class="card-buttons">
           <a href="tel:+1(443) 851-1838" class="card-btn call">📞 Call</a>
          <a href="https://wa.me/14438511838" target="_blank" class="card-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Voodoo Spell Removal -->
    <div class="service-card" style="background-image: url('images/mss10.jpg');">
      <div class="service-icon">🔗</div>
      <div class="service-info">
        <h3>Voodoo Spell Removal</h3>
        <p>Break free from harmful spells with ancient mantras and divine protection.</p>
        <div class="card-buttons">
           <a href="tel:+1(443) 851-1838" class="card-btn call">📞 Call</a>
          <a href="https://wa.me/14438511838" target="_blank" class="card-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Health Problem -->
    <div class="service-card" style="background-image: url('images/mss11.jpg');">
      <div class="service-icon">🔗</div>
      <div class="service-info">
        <h3>Health Problem</h3>
        <p>Restore well-being by addressing spiritual roots of physical illness.</p>
        <div class="card-buttons">
         <a href="tel:+1(443) 851-1838" class="card-btn call">📞 Call</a>
          <a href="https://wa.me/14438511838" target="_blank" class="card-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Witch Craft Reading -->
    <div class="service-card" style="background-image: url('images/mss12.jpg');">
      <div class="service-icon">🔗</div>
      <div class="service-info">
        <h3>Witch Craft Reading</h3>
        <p>Detect and neutralize witchcraft energies with spiritual diagnosis and rituals.</p>
        <div class="card-buttons">
          <a href="tel:+1(443) 851-1838" class="card-btn call">📞 Call</a>
          <a href="https://wa.me/14438511838" target="_blank" class="card-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

  </div>
</section>

<!-- CSS -->
<style>
.services-section {
  background-color:#EED9C4;
  padding: 80px 30px;
  color: white;
  font-family: 'Poppins', sans-serif;
}

.services-header {
  text-align: center;
  margin-bottom: 50px;
}

.services-header h2 {
  font-size: 5rem;
  margin-bottom: 10px;
  color: #fff;
}

.services-header p {
  max-width: 650px;
  margin: 0 auto;
  color: white;
  font-size:2.5rem;
  color:black;
}

.services-cards {
  display: flex;
  flex-wrap: wrap;
  gap: 30px;
  justify-content: center;
}

.service-card {
  position: relative;
  width: 260px;
  height: 460px;
  background-size: cover;
  background-position: center;
  border-radius: 16px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.6);
  transition: transform 0.3s;
}

.service-card:hover {
  transform: translateY(-10px);
}

.service-icon {
  position: absolute;
  top: 15px;
  right: 15px;
  background-color: #fcbf49;
  color: black;
  font-size: 1.2rem;
  padding: 10px;
  border-radius: 50%;
}

.service-info {
  background: rgba(255, 183, 77, 0.85);
  padding: 20px;
  border-top-left-radius: 40px;
  color: #000;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 50%;
}

.service-info h3 {
  font-size: 2.2rem;
  margin-bottom: 10px;
}

.service-info p {
  font-size: 1.5rem;
  margin-bottom: 10px;
}

.card-buttons {
  display: flex;
  justify-content: space-between;
  gap: 10px;
}

.card-btn {
  flex: 1;
  padding: 8px 12px;
  border-radius: 20px;
  font-size: 0.85rem;
  font-weight: 600;
  text-align: center;
  text-decoration: none;
  color: white;
  transition: background 0.3s;
}

.card-btn.call {
  background-color:rgb(81, 17, 4);
}

.card-btn.call:hover {
  background-color:rgb(77, 4, 4);
}

.card-btn.whatsapp {
  background-color: #25D366;
}

.card-btn.whatsapp:hover {
  background-color: #1ebe5d;
}
</style>
