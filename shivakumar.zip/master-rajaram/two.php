
  <!-- Astrology Section -->
  <section class="astrology-section">
    <div class="astrology-content">
      <div class="astrology-image">
        <img src="./images/ab1.png" alt="Astrology Symbol">
      </div>
      <div class="astrology-text">
        <h2>We Know Everything <br> About Astrology</h2>
        <p>
          At <strong style="color:yellow;"> Master Shivakumar</strong>  Insights, we combine ancient wisdom with modern intuition. With over 25 years of experience, our astrologers have guided thousands across the globe on love, career, spiritual, and personal growth journeys. We believe in clarity, transformation, and purpose-driven living.
        </p>
        <p>
          At <strong style="color:yellow;">Master Shivakumar</strong>, we understand the silent damage caused by <strong style="font-size:2rem ;">black magic</strong>. With powerful <strong >ancient rituals</strong> and personalized <strong >protection mantras</strong>, he removes <strong style="color:yellow;">negative energies</strong> and shields you from further harm. Thousands have regained <strong >peace</strong>, <strong>health</strong>, and <strong >stability</strong> after his <strong style="color:yellow;">black magic healing</strong> sessions.
        </p>

        <p>
          Whether you're facing <strong>heartbreak</strong>, <strong style="color:yellow;">delays in marriage</strong>, or <strong >legal struggles</strong>, <strong style="color:yellow;">Master Shivakumar</strong> provides time-tested <strong >astrological remedies</strong>. His guidance in <strong style="color:yellow;">love reunions</strong> and <strong style="color:yellow;">court case victories</strong> has brought <strong >relief</strong> and <strong>justice</strong> to many. With deep <strong >insight</strong> and <strong >divine blessings</strong>, he paves the way for lasting solutions.
        </p>


        <a href="#" class="read-more-btn">Read More</a>
      </div>
    </div>
  </section>

  <!-- CSS -->
  <style>
    .astrology-section {
    background-color:rgb(75, 2, 2); 
    background-size: cover;
    padding: 80px 20px;
    color: #fff;
    font-family: 'Open Sans', sans-serif;
  }

    .astrology-content {
      display: flex;
      align-items: center;
      justify-content: center;
      max-width: 1200px;
      margin: 0 auto;
      flex-wrap: wrap;
      gap: 40px;
    }

    .astrology-image img {
      max-width: 400px;
      width: 100%;
      height: auto;
    }

    .astrology-text {
      max-width: 500px;
    }

    .astrology-text h2 {
      font-size: 36px;
      margin-bottom: 20px;
      line-height: 1.3;
      font-weight: bold;
      color:yellow;
    }

    .astrology-text p {
      font-size: 16px;
      line-height: 1.6;
      margin-bottom: 30px;
      color:white;  
    }

    .read-more-btn {
      display: inline-block;
      padding: 12px 30px;
      background-color: #f5a84d;
      color: #000;
      text-decoration: none;
      border-radius: 30px;
      font-weight: bold;
      transition: background-color 0.3s ease;
    }

    .read-more-btn:hover {
      background-color: #e68a1f;
    }

    @media (max-width: 768px) {
      .astrology-content {
        flex-direction: column;
        text-align: center;
      }

      .astrology-text h2 {
        font-size: 28px;
      }
    }
  </style>
 <style>
    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background-color::rgba(47, 2, 52, 0.96);
      color: white;
    }

    .benefits-section {
      display: flex;
      flex-wrap: wrap;
      min-height: 100vh;
    }

    .benefits-left {
      flex: 1;
      background-color: #d42e78;
      padding: 60px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .benefits-left h5 {
      text-transform: uppercase;
      font-weight: bold;
      font-size: 16px;
      margin-bottom: 10px;
    }

    .benefits-left h2 {
      font-size: 40px;
      line-height: 1.2;
      margin-bottom: 20px;
    }

    .benefits-left p {
      font-size: 16px;
      max-width: 500px;
    }

    .benefits-right {
      flex: 1;
      background-color: #1e002b;
      background-image: url('magic-background.png'); /* optional: semi-transparent background image */
      background-size: cover;
      background-position: center;
      padding: 60px 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .benefit-item {
      display: flex;
      align-items: flex-start;
      gap: 20px;
      margin-bottom: 30px;
    }

    .benefit-icon {
      font-size: 32px;
    }

    .benefit-text h4 {
      margin: 0;
      font-size: 18px;
      font-weight: bold;
    }

    .benefit-text p {
      margin: 5px 0 0;
      font-size: 14px;
      color: white;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .benefits-section {
        flex-direction: column;
      }

      .benefits-left, .benefits-right {
        padding: 40px 20px;
      }

      .benefits-left h2 {
        font-size: 28px;
      }

      .benefits-left h1 {
        font-size: 32px;
      }

      .benefit-text p {
        font-size: 13px;
        color: white;
      }
    }
  </style>
</head>
<body>

  <section class="benefits-section">
    <div class="benefits-left">
      <h1 style="font-size:48px;">Advantages</h1>
      <h2>Benefits Of<br>Consulting</h2>
    <p>Consulting<strong style="color:yellow;"> Master Shivakumar</strong> offers deep spiritual insight and intuitive guidance to help you navigate life’s most challenging moments. With years of experience and a divine connection to the metaphysical realm, Psychic Venkojirav helps uncover hidden truths, resolve love and family issues, and clear negative energies. Whether you seek clarity in relationships, career, or spiritual direction, his wisdom and foresight provide a path toward peace, healing, and purpose.</p>
    </div>

    <div class="benefits-right">
      <div class="benefit-item">
        <div class="benefit-icon">🔮</div>
        <div class="benefit-text">
          <h4 style="color:yellow;">Helps In Financial Planner</h4>
          <p>Master Shivakumar helps solve money problems and shows ways to attract wealth and remove bad luck.</p>
        </div>
      </div>

      <div class="benefit-item">
        <div class="benefit-icon">🧠</div>
        <div class="benefit-text">
          <h4 style="color:yellow;" >Confused About Life</h4>
          <p>Master Shivakumar helps when you're confused in life and shows the right path with peace and clarity.</p>
        </div>
      </div>

      <div class="benefit-item">
        <div class="benefit-icon">⚖️</div>
        <div class="benefit-text">
          <h4 style="color:yellow;" >Helps in Decision Making</h4>

          <p> Master Shivakumar helps you make the right decisions in life with clear guidance and spiritual support.</p>        </div>
      </div>

      <div class="benefit-item">
        <div class="benefit-icon">💘</div>
        <div class="benefit-text">
          <h4 style="color:yellow;"  >Tells About Your Partner </h4>
         <p>Master Shivakumar reveals your partner's true nature and helps you understand their feelings and intentions.</p>
        </div>
      </div>
    </div>
  </section>

 <link href="https://fonts.googleapis.com/css2?family=Marcellus&display=swap" rel="stylesheet">