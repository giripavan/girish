<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<?php
	include('header.php');
	?>
	
	
	<!-- service section about matter -->
	<!-- Animated Cosmic Couple Disputes Section -->
<section class="animated-astrology" style="
    padding: 100px 0;
    background: #0a0511;
    position: relative;
    overflow: hidden;
">
    <!-- Animated Cosmic Background Elements -->
    <div class="cosmic-star" style="
        position: absolute;
        top: 20%;
        left: 15%;
        width: 3px;
        height: 3px;
        border-radius: 50%;
        background: white;
        box-shadow: 0 0 10px 2px white;
        animation: twinkle 4s infinite ease-in-out;
    "></div>
    <div class="cosmic-star" style="
        position: absolute;
        top: 40%;
        right: 20%;
        width: 4px;
        height: 4px;
        border-radius: 50%;
        background: #ff6b9e;
        box-shadow: 0 0 12px 3px #ff6b9e;
        animation: twinkle 5s infinite 1s ease-in-out;
    "></div>
    <div class="cosmic-star" style="
        position: absolute;
        bottom: 30%;
        left: 25%;
        width: 2px;
        height: 2px;
        border-radius: 50%;
        background: #9c27b0;
        box-shadow: 0 0 8px 1px #9c27b0;
        animation: twinkle 3s infinite 0.5s ease-in-out;
    "></div>

    <!-- Floating Planets -->
    <div class="floating-planet" style="
        position: absolute;
        top: 10%;
        right: 10%;
        width: 100px;
        height: 100px;
        border-radius: 50%;
        background: radial-gradient(circle at 30% 30%, #9c27b0, #0a0511);
        box-shadow: 0 0 30px #9c27b0;
        animation: float 15s infinite ease-in-out;
    "></div>
    <div class="floating-planet" style="
        position: absolute;
        bottom: 15%;
        left: 10%;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: radial-gradient(circle at 30% 30%, #2196f3, #0a0511);
        box-shadow: 0 0 20px #2196f3;
        animation: float 12s infinite 3s ease-in-out;
    "></div>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 text-center">
                <h2 class="magic-title" style="
                    font-size: 6rem;
                    font-weight: 800;
                    color: transparent;
                    background: linear-gradient(45deg, #ff6b9e, #9c27b0, #2196f3);
                    -webkit-background-clip: text;
                    background-clip: text;
                    text-shadow: 0 0 20px rgba(255,107,158,0.3);
                    margin-bottom: 30px;
                    position: relative;
                    display: inline-block;
                    animation: glow 3s infinite alternate;
                    font-family: 'Cinzel';
                ">
                    <span style="
                        position: absolute;
                        bottom: -15px;
                        left: 0;
                        width: 100%;
                        height: 4px;
                        background: linear-gradient(90deg, #ff6b9e, #2196f3);
                        border-radius: 4px;
                        animation: underlinePulse 3s infinite;
                    "></span>
                    Couple Disputes
                </h2>
                <p class="magic-subtitle" style="
                    color: white;
                    font-size: 1.8rem;
                    max-width: 700px;
                    margin: 0 auto 60px;
                    text-shadow: 0 0 10px rgba(179,136,255,0.5);
                    animation: fadeInOut 4s infinite;
                ">
                The celestial forces recognize your struggle. When couples clash, the universe feels the discord. Our cosmic interventions restore balance, dissolve tensions, and rekindle understanding. Through ancient wisdom and energy alignment, we transform disputes into harmonious connections, helping partners rediscover their shared cosmic bond.                </p>
            </div>
        </div>

        <div class="row g-5">
            <!-- Animated Card 1 -->
            <div class="col-md-4">
                <div class="magic-card" style="
                    background: rgba(20,10,40,0.7);
                    border-radius: 25px;
                    padding: 40px 30px;
                    height: 100%;
                    box-shadow: 0 0 40px rgba(255,107,158,0.2);
                    border: 1px solid rgba(255,107,158,0.3);
                    backdrop-filter: blur(8px);
                    transition: all 0.5s ease;
                    position: relative;
                    overflow: hidden;
                    animation: floatCard 6s infinite ease-in-out;
                ">
                    <div class="card-bg-animation" style="
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background: radial-gradient(circle at 20% 30%, rgba(255,107,158,0.1), transparent 70%);
                        animation: bgPulse 8s infinite alternate;
                        z-index: 0;
                    "></div>
                    <div class="card-content" style="position: relative; z-index: 1;">
                        <div class="magic-icon" style="
                            width: 90px;
                            height: 90px;
                            background: linear-gradient(45deg, #ff6b9e, #ff4081);
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin: 0 auto 30px;
                            color: white;
                            font-size: 40px;
                            box-shadow: 0 0 30px rgba(255,107,158,0.5);
                            animation: pulse 3s infinite;
                        ">
                            <i class="fas fa-handshake"></i>
                        </div>
                        <h3 style="
                            color: #ff6b9e;
                            margin-bottom: 25px;
                            text-align: center;
                            font-weight: 700;
                            font-size: 2.4rem;
                            text-shadow: 0 0 10px rgba(255,107,158,0.3);
                        ">Conflict Resolution</h3>
                        <p style="
                            color: #e0c7ff;
                            line-height: 1.8;
                            text-align: center;
                            font-size: 1.7rem;
                        ">
                            Transform arguments into understanding with cosmic mediation techniques that calm emotions and restore rational communication.
                        </p>
                    </div>
                </div>
            </div>
            
            <!-- Animated Card 2 -->
            <div class="col-md-4">
                <div class="magic-card" style="
                    background: rgba(20,10,40,0.7);
                    border-radius: 25px;
                    padding: 40px 30px;
                    height: 100%;
                    box-shadow: 0 0 40px rgba(156,39,176,0.2);
                    border: 1px solid rgba(156,39,176,0.3);
                    backdrop-filter: blur(8px);
                    transition: all 0.5s ease;
                    position: relative;
                    overflow: hidden;
                    animation: floatCard 6s infinite 1s ease-in-out;
                ">
                    <div class="card-bg-animation" style="
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background: radial-gradient(circle at 20% 30%, rgba(156,39,176,0.1), transparent 70%);
                        animation: bgPulse 8s infinite 1s alternate;
                        z-index: 0;
                    "></div>
                    <div class="card-content" style="position: relative; z-index: 1;">
                        <div class="magic-icon" style="
                            width: 90px;
                            height: 90px;
                            background: linear-gradient(45deg, #9c27b0, #7b1fa2);
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin: 0 auto 30px;
                            color: white;
                            font-size: 40px;
                            box-shadow: 0 0 30px rgba(156,39,176,0.5);
                            animation: pulse 3s infinite 0.5s;
                        ">
                            <i class="fas fa-balance-scale"></i>
                        </div>
                        <h3 style="
                            color: #ba68c8;
                            margin-bottom: 25px;
                            text-align: center;
                            font-weight: 700;
                            font-size: 2.4rem;
                            text-shadow: 0 0 10px rgba(186,104,200,0.3);
                        ">Energy Rebalancing</h3>
                        <p style="
                            color: #e0c7ff;
                            line-height: 1.8;
                            text-align: center;
                            font-size: 1.7rem;
                        ">
                            Neutralize negative energy patterns causing recurring arguments and restore harmonious vibrations between partners.
                        </p>
                    </div>
                </div>
            </div>
            
            <!-- Animated Card 3 -->
            <div class="col-md-4">
                <div class="magic-card" style="
                    background: rgba(20,10,40,0.7);
                    border-radius: 25px;
                    padding: 40px 30px;
                    height: 100%;
                    box-shadow: 0 0 40px rgba(33,150,243,0.2);
                    border: 1px solid rgba(33,150,243,0.3);
                    backdrop-filter: blur(8px);
                    transition: all 0.5s ease;
                    position: relative;
                    overflow: hidden;
                    animation: floatCard 6s infinite 2s ease-in-out;
                ">
                    <div class="card-bg-animation" style="
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background: radial-gradient(circle at 20% 30%, rgba(33,150,243,0.1), transparent 70%);
                        animation: bgPulse 8s infinite 2s alternate;
                        z-index: 0;
                    "></div>
                    <div class="card-content" style="position: relative; z-index: 1;">
                        <div class="magic-icon" style="
                            width: 90px;
                            height: 90px;
                            background: linear-gradient(45deg, #2196f3, #1976d2);
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin: 0 auto 30px;
                            color: white;
                            font-size: 40px;
                            box-shadow: 0 0 30px rgba(33,150,243,0.5);
                            animation: pulse 3s infinite 1s;
                        ">
                            <i class="fas fa-heartbeat"></i>
                        </div>
                        <h3 style="
                            color: #64b5f6;
                            margin-bottom: 25px;
                            text-align: center;
                            font-weight: 700;
                            font-size: 2.4rem;
                            text-shadow: 0 0 10px rgba(100,181,246,0.3);
                        ">Emotional Reconnection</h3>
                        <p style="
                            color: #e0c7ff;
                            line-height: 1.8;
                            text-align: center;
                            font-size: 1.7rem;
                        ">
                            Bridge emotional distances and rebuild intimacy through cosmic alignment of heart chakras and energy meridians.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-md-12 text-center">
                <a href="#" class="magic-button" style="
                    display: inline-block;
                    background: linear-gradient(45deg, #ff00cc, #ff0066, #cc00ff);
                    color: white;
                    padding: 20px 50px;
                    border-radius: 50px;
                    text-decoration: none;
                    font-weight: 700;
                    font-size: 1.9rem;
                    box-shadow: 0 0 30px rgba(255,0,204,0.5);
                    position: relative;
                    overflow: hidden;
                    margin-top: 60px;
                    border: none;
                    transition: all 0.3s ease;
                    z-index: 1;
                    animation: pulseGlow 2s infinite;
                ">
                    <span style="position: relative; z-index: 3;">
                        <i class="fas fa-peace" style="margin-right: 10px;"></i> 
                        Restore Your Harmony
                    </span>
                    <span style="
                        position: absolute;
                        top: 0;
                        left: -100%;
                        width: 100%;
                        height: 100%;
                        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
                        transition: 0.6s;
                        z-index: 2;
                    "></span>
                </a>
            </div>
        </div>
    </div>
</section>

<style>
    /* Keyframe Animations */
    @keyframes twinkle {
        0%, 100% { opacity: 0.3; }
        50% { opacity: 1; }
    }
    @keyframes float {
        0%, 100% { transform: translateY(0) rotate(0deg); }
        50% { transform: translateY(-20px) rotate(5deg); }
    }
    @keyframes floatCard {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-15px); }
    }
    @keyframes glow {
        0% { text-shadow: 0 0 20px rgba(255,107,158,0.3); }
        100% { text-shadow: 0 0 30px rgba(255,107,158,0.6); }
    }
    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.1); }
    }
    @keyframes pulseGlow {
        0%, 100% { box-shadow: 0 0 30px rgba(255,0,204,0.5); }
        50% { box-shadow: 0 0 50px rgba(255,0,204,0.8); }
    }
    @keyframes underlinePulse {
        0%, 100% { width: 100%; left: 0; }
        50% { width: 80%; left: 10%; }
    }
    @keyframes fadeInOut {
        0%, 100% { opacity: 0.7; }
        50% { opacity: 1; }
    }
    @keyframes bgPulse {
        0% { opacity: 0.3; transform: scale(1); }
        100% { opacity: 0.6; transform: scale(1.2); }
    }

    /* Hover Effects */
    .magic-card:hover {
        transform: translateY(-10px) scale(1.02) !important;
        box-shadow: 0 0 60px rgba(255,107,158,0.4) !important;
    }
    .magic-button:hover {
        animation: none;
        transform: scale(1.05);
        box-shadow: 0 0 60px rgba(255,0,204,0.8) !important;
    }
    .magic-button:hover span:last-child {
        left: 100%;
    }
    .magic-icon:hover {
        animation: none;
        transform: scale(1.2) rotate(20deg);
    }
</style>
	<?php
	include('testimonials.php');
	?>
	<?php
	include('locations.php');
	?>
	<?php
	include('footer.php');
	?>
	
	