<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <?php include('header.php'); ?>
    
 <section class="dark-celestial-contact" style="
    padding: 80px 0;
    background: #0a0a12 url('https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8MXx8fGVufDB8fHx8fA%3D%3D&w=1000&q=80') no-repeat center/cover;
    position: relative;
    font-family: 'Georgia', serif;
">
    <!-- Overlay -->
    <div style="position: absolute; top:0; left:0; width:100%; height:100%; background: rgba(10, 10, 30, 0.92); z-index: 0;"></div>
    
    <div class="container" style="position: relative; z-index: 1; max-width: 1000px;">
        <div class="row">
            <!-- Left: Form -->
            <div class="col-md-7">
                <div style="background: rgba(20, 20, 40, 0.8); 
                    border-radius: 8px; 
                    padding: 40px;
                    border: 1px solid rgba(200, 180, 255, 0.1);
                    box-shadow: 0 10px 30px rgba(0, 0, 20, 0.5);
                    backdrop-filter: blur(5px);
                    height: 100%;">
                    
                    <h2 style="color: yellow; font-size: 5rem; margin-bottom: 10px; font-weight: 300; font-family:Serif ;">
                        <span style="border-bottom: 2px solid #8a7fff; padding-bottom: 5px;">Contact Inquiry</span>
                    </h2>
                    <p style="color: white; margin-bottom: 30px; font-size: 1.95rem; line-height: 1.6;">
                        Seek guidance from the stars. Fill the form below, and <strong style="color:yellow;font-family:serif ;"> Master Shivakumar Ji</strong> will channel Solve  for you.
                    </p>
                    
                    <form id="celestialForm" style="margin-top: 20px;">
                        <!-- Name -->
                        <div style="margin-bottom: 25px;">
                            <label style="display: block; color: Yellow; margin-bottom: 8px; font-size: 2rem; font-family:Serif ;">Full Name</label>
                            <input type="text" placeholder="Your Name" style="
                                width: 100%; 
                                padding: 12px 15px;
                                background: rgba(30, 30, 60, 0.7);
                                border: 1px solid rgba(138, 127, 255, 0.3);
                                color: white;
                                border-radius: 4px;
                                font-size: 1.95rem;
                            ">
                        </div>
                        
                        <!-- Birth Details -->
                        <div class="row" style="margin-bottom: 25px;">
                            <div class="col-md-6" style="margin-bottom: 15px;">
                                <label style="display: block; color: yellow; margin-bottom: 8px; font-size: 2rem; font-family:Serif ;">Birth Date</label>
                                <input type="date" style="
                                    width: 100%; 
                                    padding: 12px 15px;
                                    background: rgba(30, 30, 60, 0.7);
                                    border: 1px solid rgba(138, 127, 255, 0.3);
                                    color: #f0e6ff;
                                    border-radius: 4px;
                                ">
                            </div>
                            <div class="col-md-6">
                                <label style="display: block; color: yellow; margin-bottom: 8px; font-size: 2rem; font-family:Serif ;">Select Your Problems</label>
                                <select style="
                                    width: 100%; 
                                    padding: 12px 15px;
                                    background: rgba(30, 30, 60, 0.7);
                                    border: 1px solid rgba(138, 127, 255, 0.3);
                                    color: #f0e6ff;
                                    border-radius: 4px;
                                ">
                                    <option value="">Select your Problems</option>
                                    <option value="Aries">love problems</option>
                                    <option value="Taurus">mariage problems</option>
                                    <option value="Gemini">black magic removal</option>
                                    <option value="Cancer">witch craft</option>
                                    <option value="Leo">spiritual healing</option>
                                    <option value="Virgo"> court problems</option>
                                    <option value="Libra">others</option>
                                    
                                </select>
                            </div>
                        </div>
                        
                        <!-- Question -->
                        <div style="margin-bottom: 25px;">
                            <label style="display: block; color: yellow; margin-bottom: 8px;  font-size: 2rem; font-family:Serif ;">Your Question</label>
                            <textarea rows="4" placeholder="What do the stars reveal about your path?" style="
                                width: 100%; 
                                padding: 12px 15px;
                                background: rgba(30, 30, 60, 0.7);
                                border: 1px solid rgba(138, 127, 255, 0.3);
                                color: #f0e6ff;
                                border-radius: 4px;
                                resize: none;
                            "></textarea>
                        </div>
                        
                        <!-- Submit Button -->
                        <button type="submit" style="
                            width: 100%;
                            padding: 14px;
                            background: linear-gradient(135deg, #6a5acd, #8a7fff);
                            border: none;
                            color: white;
                            border-radius: 4px;
                            font-size: 1rem;
                            cursor: pointer;
                            transition: all 0.3s;
                            font-family: 'Georgia', serif;
                            letter-spacing: 0.5px;
                        ">
                            <i class="fas fa-stars" style="margin-right: 8px;  font-family:Serif ;"></i> Request Celestial Reading
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Right: Contact Info -->
            <div class="col-md-5">
                <div style="padding-left: 30px; height: 100%;">
                    <div style="background: rgba(20, 20, 40, 0.8); 
                        border-radius: 8px; 
                        padding: 40px;
                        border: 1px solid rgba(200, 180, 255, 0.1);
                        box-shadow: 0 10px 30px rgba(0, 0, 20, 0.5);
                        backdrop-filter: blur(5px);
                        height: 100%;">
                        
                        <h3 style="color: yellow; font-size: 3rem; margin-bottom: 20px; font-weight: 300; font-family:Georgia;">
                            <span style="border-bottom: 2px solid yellow; padding-bottom: 5px;">MASTER SHIVAKUMAR Ji</span>
                        </h3>
                        <p style="color: white; margin-bottom: 30px; line-height: 1.6; font-size: 1.95rem; font-family:Georgia;">
                            A master astrologer with 25 years of experience in Vedic and Western astrology, tarot, and spiritual counseling.
                        </p>
                        
                        <!-- Contact Details -->
                        <div style="margin-bottom: 30px;">
                            <div style="display: flex; align-items: center; margin-bottom: 20px;">
                                <div style="width: 40px; height: 40px; background: rgba(138, 127, 255, 0.1); 
                                    border-radius: 50%; display: flex; align-items: center; justify-content: center;
                                    margin-right: 15px;">
                                    <i class="fas fa-envelope" style="color: #8a7fff; "></i>
                                </div>
                                <div>
                                    <h4 style="color: white; margin: 0; font-size: 1.5rem; font-weight: 400; font-family:Georgia;">Email</h4>
                                    <p style="color: white; margin: 5px 0 0; font-size: 1.6rem; font-family:Georgia;">mastermaha9468@gmail.com</p>
                                </div>
                            </div>
                            
                            <div style="display: flex; align-items: center; margin-bottom: 20px;">
                                <div style="width: 40px; height: 40px; background: rgba(138, 127, 255, 0.1); 
                                    border-radius: 50%; display: flex; align-items: center; justify-content: center;
                                    margin-right: 15px;">
                                    <i class="fas fa-phone-alt" style="color: #8a7fff;"></i>
                                </div>
                                <div>
                                    <h4 style="color: white; margin: 0; font-size: 1.5rem; font-weight: 400; font-family:Georgia;">Phone</h4>
                                    <p style="color: white; margin: 5px 0 0; font-size: 1.6rem; font-family:Georgia;">+1(443) 851-1838</p>
                                </div>
                            </div>
                            
                            <div style="display: flex; align-items: center; margin-bottom: 20px;">
                                <div style="width: 40px; height: 40px; background: rgba(138, 127, 255, 0.1); 
                                    border-radius: 50%; display: flex; align-items: center; justify-content: center;
                                    margin-right: 15px;">
                                    <i class="fas fa-map-marker-alt" style="color: #8a7fff;"></i>
                                </div>
                                <div>
                                    <h4 style="color: white; margin: 0; font-size: 1.5rem; font-weight: 400; font-family:Georgia;">Location</h4>
                                    <p style="color: white; margin: 5px 0 0; font-size: 1.6rem; font-family:Georgia;">8811 Enfield Ct, Laurel, MD 20708</p>
                                </div>
                            </div>
                        </div>

                        <!-- Google Maps Embed -->
                        <div style="margin-bottom: 25px; border-radius: 6px; overflow: hidden;">
                            <iframe 
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3098.042965724175!2d-76.8493364!3d39.0917027!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89b7e0a1b924c1e5%3A0x6a4e8a1a4f5d0a1!2s8811%20Enfield%20Ct%2C%20Laurel%2C%20MD%2020708!5e0!3m2!1sen!2sus!4v1712345678901!5m2!1sen!2sus" 
                                width="100%" 
                                height="200" 
                                style="border:0;" 
                                allowfullscreen="" 
                                loading="lazy" 
                                referrerpolicy="no-referrer-when-downgrade">
                            </iframe>
                        </div>
                        
                        <!-- Emergency Contact -->
                        <div style="text-align: center;">
                           
                            <p style="color: yellow; font-size: 1.8rem; margin-top: 10px; font-family:Georgia;">
                                Available 24/7 for critical guidance
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Floating Stars -->
    <div style="position: absolute; top: 20%; left: 10%; font-size: 1.5rem; color: rgba(138, 127, 255, 0.3); 
        animation: twinkle 5s infinite;">✧</div>
    <div style="position: absolute; bottom: 15%; right: 12%; font-size: 1.2rem; color: rgba(200, 180, 255, 0.2); 
        animation: twinkle 7s infinite 2s;">✧</div>
</section>

<style>
    @keyframes twinkle {
        0%, 100% { opacity: 0.3; }
        50% { opacity: 0.8; }
    }
    
    #celestialForm input:focus, 
    #celestialForm select:focus, 
    #celestialForm textarea:focus {
        border-color: #8a7fff !important;
        box-shadow: 0 0 10px rgba(138, 127, 255, 0.3) !important;
        outline: none;
    }
    
    button[type="submit"]:hover {
        background: linear-gradient(135deg, #8a7fff, #6a5acd) !important;
        transform: translateY(-2px);
    }
    
    .dark-celestial-contact a:hover {
        background: rgba(138, 127, 255, 0.2) !important;
        color: #f0e6ff !important;
    }
</style>

<script>
    document.getElementById('celestialForm').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Your celestial inquiry has been sent. Hanuman Ji will respond within 48 hours.');
        this.reset();
    });
</script>
        
 <style>
    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background-color::rgba(47, 2, 52, 0.96);
      color: white;
    }

    .benefits-section {
      display: flex;
      flex-wrap: wrap;
      min-height: 100vh;
    }

    .benefits-left {
      flex: 1;
      background-color: #d42e78;
      padding: 60px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .benefits-left h5 {
      text-transform: uppercase;
      font-weight: bold;
      font-size: 16px;
      margin-bottom: 10px;
    }

    .benefits-left h2 {
      font-size: 40px;
      line-height: 1.2;
      margin-bottom: 20px;
    }

    .benefits-left p {
      font-size: 16px;
      max-width: 500px;
    }

    .benefits-right {
      flex: 1;
      background-color: #1e002b;
      background-image: url('magic-background.png'); /* optional: semi-transparent background image */
      background-size: cover;
      background-position: center;
      padding: 60px 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .benefit-item {
      display: flex;
      align-items: flex-start;
      gap: 20px;
      margin-bottom: 30px;
    }

    .benefit-icon {
      font-size: 32px;
    }

    .benefit-text h4 {
      margin: 0;
      font-size: 18px;
      font-weight: bold;
    }

    .benefit-text p {
      margin: 5px 0 0;
      font-size: 14px;
      color: white;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .benefits-section {
        flex-direction: column;
      }

      .benefits-left, .benefits-right {
        padding: 40px 20px;
      }

      .benefits-left h2 {
        font-size: 28px;
      }

      .benefits-left h1 {
        font-size: 32px;
      }

      .benefit-text p {
        font-size: 13px;
        color: white;
      }
    }
  </style>
</head>
<body>

  <section class="benefits-section">
    <div class="benefits-left">
      <h1 style="font-size:48px;">Advantages</h1>
      <h2>Benefits Of<br>Consulting</h2>
    <p>Consulting Psychic Venkojirav offers deep spiritual insight and intuitive guidance to help you navigate life’s most challenging moments. With years of experience and a divine connection to the metaphysical realm, Psychic Venkojirav helps uncover hidden truths, resolve love and family issues, and clear negative energies. Whether you seek clarity in relationships, career, or spiritual direction, his wisdom and foresight provide a path toward peace, healing, and purpose.</p>
    </div>

    <div class="benefits-right">
      <div class="benefit-item">
        <div class="benefit-icon">🔮</div>
        <div class="benefit-text">
          <h4 style="color:yellow;">Helps In Financial Planner</h4>
          <p>Psychic Venkojirav helps solve money problems and shows ways to attract wealth and remove bad luck.</p>
        </div>
      </div>

      <div class="benefit-item">
        <div class="benefit-icon">🧠</div>
        <div class="benefit-text">
          <h4 style="color:yellow;" >Confused About Life</h4>
          <p>Psychic Venkojirav helps when you're confused in life and shows the right path with peace and clarity.</p>
        </div>
      </div>

      <div class="benefit-item">
        <div class="benefit-icon">⚖️</div>
        <div class="benefit-text">
          <h4 style="color:yellow;" >Helps in Decision Making</h4>

          <p> Psychic Venkojirav helps you make the right decisions in life with clear guidance and spiritual support.</p>        </div>
      </div>

      <div class="benefit-item">
        <div class="benefit-icon">💘</div>
        <div class="benefit-text">
          <h4 style="color:yellow;"  >Tells About Your Partner </h4>
         <p>Psychic Venkojirav reveals your partner's true nature and helps you understand their feelings and intentions.</p>
        </div>
      </div>
    </div>
  </section>
  <?php include('one.php')?>

    <?php include('footer.php'); ?>
</body>
</html>