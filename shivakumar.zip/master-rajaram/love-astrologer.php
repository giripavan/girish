<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Love Astrologer</title>
	<?php
	include('header.php');
	?>
	
	
	<!-- service section about matter -->
	<!-- Animated Cosmic Love Astrology Section -->
<!-- Palm Reading Section -->
<section class="love-astrology-elegant">
  <div class="ring-bg">
    <span class="ring one"></span>
    <span class="ring two"></span>
    <span class="ring three"></span>
  </div>

  <div class="container">
    <div class="elegant-grid">
      <div class="elegant-text">
        <h2>Love Problem Specialist</h2>
        <p><strong style="color:yellow;"> Master Shivakumar</strong> offers profound solutions to love problems through his deep understanding of ancient astrology and spiritual practices. Whether you're facing misunderstandings, emotional distance, parental opposition, or the pain of a breakup, his guidance helps you reconnect with love's true essence. With a compassionate heart and intuitive insight, he works to restore harmony in relationships and reunite lost lovers.</p>
         <p>Using powerful rituals, personalized mantras, and astrological remedies, <strong style="color:yellow;"> Master Shivakumar</strong> clears negative energies and removes obstacles standing between you and your happiness. His love problem solutions are tailored to each unique situation, ensuring that every step is aligned with your destiny. Many have found lasting peace and joy in their relationships through his time-tested guidance and unwavering support.</p>

        <ul class="elegant-features">
          <li><i class="fas fa-hand-holding-heart"></i> Twin Flame Readings</li>
          <li><i class="fas fa-balance-scale"></i> Relationship Balance</li>
          <li><i class="fas fa-seedling"></i> Karmic Cleanse Guidance</li>
          <li><i class="fas fa-magic"></i> Energy Alignment</li>
        </ul>

        <a href="contact-us.php" class="elegant-cta">Book a Session <i class="fas fa-arrow-circle-right"></i></a>
      </div>

      <div class="elegant-image">
        <img src="./images/ms1.jpg" alt="Astrologer Shivakumar">
      </div>
    </div>
  </div>
</section>



<style>
       .love-astrology-elegant {
  position: relative;
  background: linear-gradient(to right, #2c003e, #100021);
  color: #fff;
  padding: 100px 20px;
  overflow: hidden;
  font-family: 'Poppins', sans-serif;
}

.container {
  max-width: 1200px;
  margin: auto;
  position: relative;
  z-index: 2;
}

.elegant-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 60px;
  align-items: center;
  justify-content: space-between;
}

.elegant-text {
  flex: 1 1 500px;
}
.elegant-text h2 {
  font-size:4rem;
  color: #ff9ec9;
  margin-bottom: 20px;
}
.elegant-text p {
  font-size: 1.6rem;
  color: #e0cbe8;
  line-height: 1.7;
  margin-bottom: 30px;
}
.elegant-features {
  list-style: none;
  padding: 0;
  margin-bottom: 40px;
}
.elegant-features li {
  font-size: 2rem;
  margin-bottom: 14px;
  display: flex;
  align-items: center;
  gap: 10px;
}
.elegant-features li i {
  color: #fdd835;
  font-size: 2.9rem;
}

.elegant-cta {
  display: inline-block;
  background: #ff4b8e;
  padding: 12px 28px;
  border-radius: 30px;
  color: #fff;
  font-weight: bold;
  text-decoration: none;
  box-shadow: 0 8px 25px rgba(255, 75, 142, 0.4);
  transition: all 0.3s ease;
}
.elegant-cta:hover {
  background: #ff2e76;
  box-shadow: 0 10px 30px rgba(255, 46, 118, 0.6);
}

.elegant-image {
  flex: 1 1 400px;
  position: relative;
}
.elegant-image img {
  width: 100%;
  border-radius: 20px;
  box-shadow: 0 10px 30px rgba(255, 255, 255, 0.1);
  transition: transform 0.4s ease;
}
.elegant-image img:hover {
  transform: scale(1.03);
}

.ring-bg {
  position: absolute;
  top: 0; left: 0;
  width: 100%; height: 100%;
  z-index: 1;
  overflow: hidden;
}
.ring {
  position: absolute;
  border: 2px solid rgba(255, 255, 255, 0.07);
  border-radius: 50%;
  animation: spinRing 30s linear infinite;
}
.ring.one {
  width: 400px; height: 400px;
  top: -50px; left: -100px;
}
.ring.two {
  width: 250px; height: 250px;
  bottom: 20px; right: -80px;
}
.ring.three {
  width: 300px; height: 300px;
  top: 30%; left: 70%;
}
@keyframes spinRing {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

@media (max-width: 900px) {
  .elegant-grid {
    flex-direction: column;
  }
  .elegant-text, .elegant-image {
    width: 100%;
  }
}

</style>
	<?php
	include('testimonials.php');
	?>
 <style>
    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background-color::rgba(47, 2, 52, 0.96);
      color: white;
    }

    .benefits-section {
      display: flex;
      flex-wrap: wrap;
      min-height: 100vh;
    }

    .benefits-left {
      flex: 1;
      background-color: #d42e78;
      padding: 60px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .benefits-left h5 {
      text-transform: uppercase;
      font-weight: bold;
      font-size: 16px;
      margin-bottom: 10px;
    }

    .benefits-left h2 {
      font-size: 40px;
      line-height: 1.2;
      margin-bottom: 20px;
    }

    .benefits-left p {
      font-size: 16px;
      max-width: 500px;
    }

    .benefits-right {
      flex: 1;
      background-color: #1e002b;
      background-image: url('magic-background.png'); /* optional: semi-transparent background image */
      background-size: cover;
      background-position: center;
      padding: 60px 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .benefit-item {
      display: flex;
      align-items: flex-start;
      gap: 20px;
      margin-bottom: 30px;
    }

    .benefit-icon {
      font-size: 32px;
    }

    .benefit-text h4 {
      margin: 0;
      font-size: 18px;
      font-weight: bold;
    }

    .benefit-text p {
      margin: 5px 0 0;
      font-size: 14px;
      color: white;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .benefits-section {
        flex-direction: column;
      }

      .benefits-left, .benefits-right {
        padding: 40px 20px;
      }

      .benefits-left h2 {
        font-size: 28px;
      }

      .benefits-left h1 {
        font-size: 32px;
      }

      .benefit-text p {
        font-size: 13px;
        color: white;
      }
    }
  </style>
</head>
<body>
 <?php include('one.php')?>
  <section class="benefits-section">
    <div class="benefits-left">
      <h1 style="font-size:48px;">Advantages</h1>
      <h2>Benefits Of<br>Consulting</h2>
    <p>Consulting<strong style="color:yellow;"> Master Shivakumar</strong> offers deep spiritual insight and intuitive guidance to help you navigate life’s most challenging moments. With years of experience and a divine connection to the metaphysical realm, Psychic Venkojirav helps uncover hidden truths, resolve love and family issues, and clear negative energies. Whether you seek clarity in relationships, career, or spiritual direction, his wisdom and foresight provide a path toward peace, healing, and purpose.</p>
    </div>

    <div class="benefits-right">
      <div class="benefit-item">
        <div class="benefit-icon">🔮</div>
        <div class="benefit-text">
          <h4 style="color:yellow;">Helps In Financial Planner</h4>
          <p>Master Shivakumar helps solve money problems and shows ways to attract wealth and remove bad luck.</p>
        </div>
      </div>

      <div class="benefit-item">
        <div class="benefit-icon">🧠</div>
        <div class="benefit-text">
          <h4 style="color:yellow;" >Confused About Life</h4>
          <p>Master Shivakumar helps when you're confused in life and shows the right path with peace and clarity.</p>
        </div>
      </div>

      <div class="benefit-item">
        <div class="benefit-icon">⚖️</div>
        <div class="benefit-text">
          <h4 style="color:yellow;" >Helps in Decision Making</h4>

          <p> Master Shivakumar helps you make the right decisions in life with clear guidance and spiritual support.</p>        </div>
      </div>

      <div class="benefit-item">
        <div class="benefit-icon">💘</div>
        <div class="benefit-text">
          <h4 style="color:yellow;"  >Tells About Your Partner </h4>
         <p>Master Shivakumar reveals your partner's true nature and helps you understand their feelings and intentions.</p>
        </div>
      </div>
    </div>
  </section>
	
	<?php
	include('footer.php');
	?>
	
	