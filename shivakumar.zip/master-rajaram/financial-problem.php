<!DOCTYPE HTML>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Financial Problem Solutions - Master Shivakumar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Font Awesome for icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <?php include('header.php'); ?>
  <style>
    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background-color: #0a0a23;
      color: #fff;
    }

    .financial-problem-section {
      position: relative;
      background: linear-gradient(to right, #22002c, #002e2e);
      color: #fff;
      padding: 100px 20px;
      overflow: hidden;
    }

    .container {
      max-width: 1200px;
      margin: auto;
      position: relative;
      z-index: 2;
    }

    .financial-grid {
      display: flex;
      flex-wrap: wrap;
      gap: 60px;
      align-items: center;
      justify-content: space-between;
    }

    .financial-text {
      flex: 1 1 500px;
    }

    .financial-text h2 {
      font-size: 3.5rem;
      color: #ffd66e;
      margin-bottom: 20px;
    }

    .financial-text p {
      font-size: 1.6rem;
      color: #f3e3c3;
      line-height: 1.7;
      margin-bottom: 30px;
    }

    .financial-features {
      list-style: none;
      padding: 0;
      margin-bottom: 40px;
    }

    .financial-features li {
      font-size: 2rem;
      margin-bottom: 14px;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .financial-features li i {
      color: #ffe600;
      font-size: 2.4rem;
    }

    .financial-cta {
      display: inline-block;
      background: #ffc400;
      padding: 12px 28px;
      border-radius: 30px;
      color: #000;
      font-weight: bold;
      text-decoration: none;
      box-shadow: 0 8px 25px rgba(255, 196, 0, 0.3);
      transition: all 0.3s ease;
    }

    .financial-cta:hover {
      background: #e0ad00;
      box-shadow: 0 10px 30px rgba(255, 204, 0, 0.5);
    }

    .financial-image {
      flex: 1 1 400px;
      position: relative;
    }

    .financial-image img {
      width: 100%;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(255, 255, 255, 0.1);
      transition: transform 0.4s ease;
    }

    .financial-image img:hover {
      transform: scale(1.03);
    }

    .orb-bg {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1;
      overflow: hidden;
    }

    .orb {
      position: absolute;
      border-radius: 50%;
      background: rgba(255, 255, 0, 0.07);
      animation: floatOrb 20s linear infinite;
    }

    .orb.one {
      width: 400px;
      height: 400px;
      top: -50px;
      left: -100px;
    }

    .orb.two {
      width: 300px;
      height: 300px;
      bottom: 50px;
      right: -80px;
    }

    .orb.three {
      width: 200px;
      height: 200px;
      top: 30%;
      left: 75%;
    }

    @keyframes floatOrb {
      0% { transform: translateY(0); }
      50% { transform: translateY(-30px); }
      100% { transform: translateY(0); }
    }

    @media (max-width: 900px) {
      .financial-grid {
        flex-direction: column;
      }

      .financial-text h2 {
        font-size: 2.5rem;
      }

      .financial-text p {
        font-size: 1.4rem;
      }

      .financial-features li {
        font-size: 1.6rem;
      }

      .financial-cta {
        padding: 10px 20px;
      }
    }
  </style>
</head>
<body>

  <section class="financial-problem-section">
    <div class="orb-bg">
      <span class="orb one"></span>
      <span class="orb two"></span>
      <span class="orb three"></span>
    </div>

    <div class="container">
      <div class="financial-grid">
        <div class="financial-text">
          <h2>Financial Problem Solutions by Master Shivakumar</h2>
          <p><strong style="color:yellow;">Master Shivakumar</strong> offers divine insight and ancient rituals to help resolve your financial struggles. Whether it's debts, career instability, or business losses, his astrological guidance can help unlock your path to abundance and prosperity.</p>
          <p>Through personalized remedies, planetary alignment corrections, and spiritual energy balancing, he clears the blockages that hinder your wealth flow. Discover the astrological key to long-term financial stability and success.</p>

          <ul class="financial-features">
            <li><i class="fas fa-rupee-sign"></i> Remove Money Blockages</li>
            <li><i class="fas fa-briefcase"></i> Job & Business Stability</li>
            <li><i class="fas fa-coins"></i> Increase Wealth & Prosperity</li>
            <li><i class="fas fa-chart-line"></i> Growth in Career & Investments</li>
          </ul>

          <a href="contact-us.php" class="financial-cta">Solve My Financial Issue <i class="fas fa-arrow-circle-right"></i></a>
        </div>

        <div class="financial-image">
          <img src="./images/ms9.jpg" alt="Financial Problem Astrology by Master Shivakumar">
        </div>
      </div>
    </div>
  </section>

  <?php include('testimonials.php'); ?>
  <?php include('footer.php'); ?>
</body>
</html>
