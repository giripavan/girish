<!DOCTYPE HTML>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="de">  <!--<![endif]-->
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <<title>About us</title>
	<?php
	include('header.php');
	?>
	<!-- service indicator banner -->
    <!--	<div class="auto-container">
        	<h1>About Astrologer</h1>
            <ul class="page-breadcrumb">
            	<li><a href="index.php">Home</a></li>
                <li>About us</li>
            </ul>
        </div>
        -->
    </section>
	<?php
	include('two.php');
	?>
	<!-- service section about matter -->
	<?php
	include('about-in.php');
	?>

	<?php
	include('locations.php');
	?>
	<?php
	include('footer.php');
	?>
	
	