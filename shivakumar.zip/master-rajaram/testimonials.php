<!-- testimonials start -->
<div class="testimonials-v2" style="padding: 80px 0; background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);">
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
        <div class="section-header" style="text-align: center; margin-bottom: 50px;">
            <span style="display: inline-block; color:rgb(88, 68, 234); font-size:5rem; font-weight: 600; letter-spacing: 0px; margin-bottom: 15px;">OUR CLIENT EXPERIENCE</span>
            <h2 style="font-size: 2.5rem; margin: 0; color: #2d3436; font-weight: 700; line-height: 1.3;">Trusted by Astrology Seekers </h2>
        </div>
        
        <div class="testimonial-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
            <!-- Testimonial 1 -->
            <div class="testimonial-card" style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); position: relative; overflow: hidden; transition: transform 0.3s ease;">
                <div class="card-bg" style="position: absolute; top: 0; right: 0; width: 100px; height: 100px; background: rgba(108, 92, 231, 0.08); border-radius: 0 0 0 100%;"></div>
                <div class="client-meta" style="display: flex; align-items: center; margin-bottom: 20px;">
                    <div class="client-avatar" style="width: 100px; height: 100px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 2px solid #f1f1f1;">
                        <img src="./images/rrt1.jpg" alt="Scarlet" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                    <div>
                        <h4 style="margin: 0 0 5px 0; color: #2d3436; font-size: 1.9rem;">Scarlet</h4>
                        <p style="margin: 0; color: #636e72; font-size: 1.5rem; font-weight: 500;">Marry Land, USA</p>
                    </div>
                </div>
                <div class="testimonial-content" style="position: relative;">
                    <svg style="position: absolute; top: -15px; left: -10px; opacity: 0.1; width: 40px; height: 40px; color: #6c5ce7;" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/>
                    </svg>
                    <p style="color: #2d3436; line-height: 1.7; font-size: 1.95rem; padding-left: 20px;">"Master Shivakumar reading revealed career opportunities I never would have considered. Within months, I found my true calling."</p>
                </div>
                <div class="rating-date" style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
                    <div class="stars" style="color: #ffb400; font-size: 1.9rem;">
                        ★ ★ ★ ★ ★
                    </div>
                    <span style="font-size: 0.8rem; color: #b2bec3;">June 2024</span>
                </div>
            </div>
            
            <!-- Testimonial 2 -->
            <div class="testimonial-card" style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); position: relative; overflow: hidden; transition: transform 0.3s ease;">
                <div class="card-bg" style="position: absolute; top: 0; right: 0; width: 100px; height: 100px; background: rgba(108, 92, 231, 0.08); border-radius: 0 0 0 100%;"></div>
                <div class="client-meta" style="display: flex; align-items: center; margin-bottom: 20px;">
                    <div class="client-avatar" style="width: 100px; height: 100px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 2px solid #f1f1f1;">
                        <img src="./images/rrt2.0.jpg" alt="Oliver" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                    <div>
                        <h4 style="margin: 0 0 5px 0; color: #2d3436; font-size: 1.9rem;">Oliver</h4>
                        <p style="margin: 0; color: #636e72; font-size: 1.5rem; font-weight: 500;">New York, USA</p>
                    </div>
                </div>
                <div class="testimonial-content" style="position: relative;">
                    <svg style="position: absolute; top: -15px; left: -10px; opacity: 0.1; width: 40px; height: 40px; color: #6c5ce7;" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/>
                    </svg>
                    <p style="color: #2d3436; line-height: 1.7; font-size: 1.95rem; padding-left: 20px;">"The relationship analysis helped me understand karmic patterns I've been repeating for lifetimes. Profound healing followed."</p>
                </div>
                <div class="rating-date" style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
                    <div class="stars" style="color: #ffb400; font-size: 1.9rem;">
                        ★ ★ ★ ★ ★
                    </div>
                    <span style="font-size: 0.8rem; color: #b2bec3;">May 2024</span>
                </div>
            </div>
            
            <!-- Testimonial 3 -->
            <div class="testimonial-card" style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); position: relative; overflow: hidden; transition: transform 0.3s ease;">
                <div class="card-bg" style="position: absolute; top: 0; right: 0; width: 100px; height: 100px; background: rgba(108, 92, 231, 0.08); border-radius: 0 0 0 100%;"></div>
                <div class="client-meta" style="display: flex; align-items: center; margin-bottom: 20px;">
                    <div class="client-avatar" style="width: 100px; height: 100px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 2px solid #f1f1f1;">
                        <img src="./images/rrt3.jpg" alt="Rachel" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                    <div>
                        <h4 style="margin: 0 0 5px 0; color: #2d3436; font-size: 1.9rem;">Rachel</h4>
                        <p style="margin: 0; color: #636e72; font-size: 1.5rem; font-weight: 500;">New York, USA</p>
                    </div>
                </div>
                <div class="testimonial-content" style="position: relative;">
                    <svg style="position: absolute; top: -15px; left: -10px; opacity: 0.1; width: 40px; height: 40px; color: #6c5ce7;" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/>
                    </svg>
                    <p style="color: #2d3436; line-height: 1.7; font-size: 1.95rem; padding-left: 20px;">"Master Shivakumar prediction about my financial situation came true to the month. The remedies he suggested made all the difference."</p>
                </div>
                <div class="rating-date" style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
                    <div class="stars" style="color: #ffb400; font-size: 1.9rem;">
                        ★ ★ ★ ★ ★
                    </div>
                    <span style="font-size: 0.8rem; color: #b2bec3;">April 2024</span>
                </div>
            </div>

            <!-- Testimonial 4 -->
             <div class="testimonial-card" style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); position: relative; overflow: hidden; transition: transform 0.3s ease;">
                <div class="card-bg" style="position: absolute; top: 0; right: 0; width: 100px; height: 100px; background: rgba(108, 92, 231, 0.08); border-radius: 0 0 0 100%;"></div>
                <div class="client-meta" style="display: flex; align-items: center; margin-bottom: 20px;">
                    <div class="client-avatar" style="width: 100px; height: 100px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 2px solid #f1f1f1;">
                        <img src="./images/mst1.jpg" alt="Rachel" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                    <div>
                        <h4 style="margin: 0 0 5px 0; color: #2d3436; font-size: 1.9rem;">Chase</h4>
                        <p style="margin: 0; color: #636e72; font-size: 1.5rem; font-weight: 500;">New York, USA</p>
                    </div>
                </div>
                <div class="testimonial-content" style="position: relative;">
                    <svg style="position: absolute; top: -15px; left: -10px; opacity: 0.1; width: 40px; height: 40px; color: #6c5ce7;" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/>
                    </svg>
                    <p style="color: #2d3436; line-height: 1.7; font-size: 1.95rem; padding-left: 20px;">"Master Shivakumar's black magic removal changed my life. I was facing unexplained problems for months, but after his powerful remedies, everything began to clear up—just as he predicted. His guidance brought peace and protection back into my life."</p>
                </div>
                <div class="rating-date" style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
                    <div class="stars" style="color: #ffb400; font-size: 1.9rem;">
                        ★ ★ ★ ★ ★
                    </div>
                    <span style="font-size: 0.8rem; color: #b2bec3;">April 2024</span>
                </div>
            </div>
 
            <!-- Testimonial 5 -->
            <div class="testimonial-card" style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); position: relative; overflow: hidden; transition: transform 0.3s ease;">
                <div class="card-bg" style="position: absolute; top: 0; right: 0; width: 100px; height: 100px; background: rgba(108, 92, 231, 0.08); border-radius: 0 0 0 100%;"></div>
                <div class="client-meta" style="display: flex; align-items: center; margin-bottom: 20px;">
                    <div class="client-avatar" style="width: 100px; height: 100px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 2px solid #f1f1f1;">
                        <img src="./images/mst.jpg" alt="Rachel" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                    <div>
                        <h4 style="margin: 0 0 5px 0; color: #2d3436; font-size: 1.9rem;">Lisa</h4>
                        <p style="margin: 0; color: #636e72; font-size: 1.5rem; font-weight: 500;">New York, USA</p>
                    </div>
                </div>
                <div class="testimonial-content" style="position: relative;">
                    <svg style="position: absolute; top: -15px; left: -10px; opacity: 0.1; width: 40px; height: 40px; color: #6c5ce7;" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/>
                    </svg>
                    <p style="color: #2d3436; line-height: 1.7; font-size: 1.95rem; padding-left: 20px;">"I had almost given up hope of getting married due to constant delays and family obstacles. Master Shivakumar’s guidance and astrological remedies worked wonders—within months, everything aligned, and my marriage was fixed smoothly."</p>
                </div>
                <div class="rating-date" style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
                    <div class="stars" style="color: #ffb400; font-size: 1.9rem;">
                        ★ ★ ★ ★ ★
                    </div>
                    <span style="font-size: 0.8rem; color: #b2bec3;">April 2024</span>
                </div>
            </div>

            <!-- Testimonial 6 -->
 
            <div class="testimonial-card" style="background: white; border-radius: 12px; padding: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); position: relative; overflow: hidden; transition: transform 0.3s ease;">
                <div class="card-bg" style="position: absolute; top: 0; right: 0; width: 100px; height: 100px; background: rgba(108, 92, 231, 0.08); border-radius: 0 0 0 100%;"></div>
                <div class="client-meta" style="display: flex; align-items: center; margin-bottom: 20px;">
                    <div class="client-avatar" style="width: 100px; height: 100px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 2px solid #f1f1f1;">
                        <img src="./images/mst2.jpg" alt="Rachel" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                    <div>
                        <h4 style="margin: 0 0 5px 0; color: #2d3436; font-size: 1.9rem;">Steve</h4>
                        <p style="margin: 0; color: #636e72; font-size: 1.5rem; font-weight: 500;">New York, USA</p>
                    </div>
                </div>
                <div class="testimonial-content" style="position: relative;">
                    <svg style="position: absolute; top: -15px; left: -10px; opacity: 0.1; width: 40px; height: 40px; color: #6c5ce7;" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/>
                    </svg>
                    <p style="color: #2d3436; line-height: 1.7; font-size: 1.95rem; padding-left: 20px;">"Master Shivakumar's spiritual healing brought me inner peace during the darkest phase of my life. His sessions helped me reconnect with my energy, clear negativity, and feel truly balanced for the first time in years."</p>
                </div>
                <div class="rating-date" style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px;">
                    <div class="stars" style="color: #ffb400; font-size: 1.9rem;">
                        ★ ★ ★ ★ ★
                    </div>
                    <span style="font-size: 0.8rem; color: #b2bec3;">April 2024</span>
                </div>
            </div>
        </div>
        
       
    </div>
</div>

<style>
.testimonial-card:hover {
    transform: translateY(-5px) !important;
    box-shadow: 0 15px 35px rgba(0,0,0,0.1) !important;
}

@media (max-width: 768px) {
    .testimonial-grid {
        grid-template-columns: 1fr !important;
    }
    
    .section-header h2 {
        font-size: 2rem !important;
    }
}

@media (max-width: 480px) {
    .testimonials-v2 {
        padding: 60px 0 !important;
    }
    
    .testimonial-card {
        padding: 25px !important;
    }
}
</style>
<!-- testimonials end -->