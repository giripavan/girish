<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Career Guidance</title>
  <?php include('header.php'); ?>

  <!-- Career Guidance Section -->
  <section class="career-guidance-section">
    <div class="ring-bg">
      <span class="ring one"></span>
      <span class="ring two"></span>
      <span class="ring three"></span>
    </div>

    <div class="container">
      <div class="elegant-grid">
        <div class="elegant-text">
          <h2>Career Guidance by Master Shivakumar</h2>
          <p><strong style="color:#ffe56a;">Master Shivakumar</strong> helps individuals navigate career uncertainty with clarity and confidence. Through astrological insights and spiritual intuition, he identifies your strengths, hidden opportunities, and obstacles holding you back from professional success.</p>
          <p>Whether you're a student unsure about your next steps, or a professional seeking a career shift, <strong style="color:#ffe56a;">Master Shivakumar</strong> provides personalized solutions that align with your soul path and cosmic timing.</p>

          <ul class="elegant-features">
            <li><i class="fas fa-briefcase"></i> Personalized Career Charts</li>
            <li><i class="fas fa-lightbulb"></i> Talent & Strength Analysis</li>
            <li><i class="fas fa-crosshairs"></i> Goal Alignment Techniques</li>
            <li><i class="fas fa-mountain"></i> Obstacle Removal Remedies</li>
          </ul>

          <a href="contact-us.php" class="elegant-cta">Book Career Session <i class="fas fa-arrow-circle-right"></i></a>
        </div>

        <div class="elegant-image">
          <img src="./images/ms7.jpg" alt="Career Guidance by Master Shivakumar">
        </div>
      </div>
    </div>
  </section>

  <style>
    .career-guidance-section {
      position: relative;
      background: linear-gradient(to right, #281943, #113247);
      color: #fff;
      padding: 100px 20px;
      overflow: hidden;
      font-family: 'Poppins', sans-serif;
    }

    .container {
      max-width: 1200px;
      margin: auto;
      position: relative;
      z-index: 2;
    }

    .elegant-grid {
      display: flex;
      flex-wrap: wrap;
      gap: 60px;
      align-items: center;
      justify-content: space-between;
    }

    .elegant-text {
      flex: 1 1 500px;
    }

    .elegant-text h2 {
      font-size: 3.5rem;
      color: #ffe56a;
      margin-bottom: 20px;
    }

    .elegant-text p {
      font-size: 1.6rem;
      color: #e5f3ff;
      line-height: 1.7;
      margin-bottom: 30px;
    }

    .elegant-features {
      list-style: none;
      padding: 0;
      margin-bottom: 40px;
    }

    .elegant-features li {
      font-size: 2rem;
      margin-bottom: 14px;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .elegant-features li i {
      color: #ffe56a;
      font-size: 2.5rem;
    }

    .elegant-cta {
      display: inline-block;
      background: #ffc107;
      padding: 12px 28px;
      border-radius: 30px;
      color: #000;
      font-weight: bold;
      text-decoration: none;
      box-shadow: 0 8px 25px rgba(255, 193, 7, 0.3);
      transition: all 0.3s ease;
    }

    .elegant-cta:hover {
      background: #ffb300;
      box-shadow: 0 10px 30px rgba(255, 179, 0, 0.5);
    }

    .elegant-image {
      flex: 1 1 400px;
      position: relative;
    }

    .elegant-image img {
      width: 100%;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(255, 255, 255, 0.1);
      transition: transform 0.4s ease;
    }

    .elegant-image img:hover {
      transform: scale(1.03);
    }

    .ring-bg {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1;
      overflow: hidden;
    }

    .ring {
      position: absolute;
      border: 2px solid rgba(255, 255, 255, 0.05);
      border-radius: 50%;
      animation: spinRing 30s linear infinite;
    }

    .ring.one {
      width: 400px;
      height: 400px;
      top: -50px;
      left: -100px;
    }

    .ring.two {
      width: 250px;
      height: 250px;
      bottom: 20px;
      right: -80px;
    }

    .ring.three {
      width: 300px;
      height: 300px;
      top: 30%;
      left: 70%;
    }

    @keyframes spinRing {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    @media (max-width: 900px) {
      .elegant-grid {
        flex-direction: column;
      }

      .elegant-text,
      .elegant-image {
        width: 100%;
      }
    }
  </style>

  <?php include('testimonials.php'); ?>
  <?php include('footer.php'); ?>
</head>
<body>
</body>
</html>
