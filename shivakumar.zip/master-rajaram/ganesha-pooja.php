<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ganesha Pooja</title>
    <?php include('header.php'); ?>
    <link rel="stylesheet" href="styles.css">
   <section class="ganapathi-section">
  <!-- Divine Light Elements -->
  <div class="divine-lights">
    <div class="light-ray ray-1"></div>
    <div class="light-ray ray-2"></div>
    <div class="light-ray ray-3"></div>
    <div class="light-particle particle-1"></div>
    <div class="light-particle particle-2"></div>
    <div class="light-particle particle-3"></div>
  </div>

  <div class="container">
    <div class="sacred-card">
      <!-- Sacred Symbol Overlay -->
      <div class="om-symbol">
        <svg viewBox="0 0 24 24">
          <path d="M12,3C17.5,3 22,6.58 22,11C22,15.42 17.5,19 12,19C6.5,19 2,15.42 2,11C2,6.58 6.5,3 12,3M12,5C7.58,5 4,7.69 4,11C4,14.31 7.58,17 12,17C16.42,17 20,14.31 20,11C20,7.69 16.42,5 12,5Z" />
        </svg>
      </div>
      
      <div class="card-content">
        <!-- Left Side - Sacred Text -->
        <div class="sacred-text">
         
          
          <h2 class="sacred-title">
            <span>Ganapathi</span>
            <span>Pooja</span>
            <span>Services</span>
          </h2>
          
          <div class="sacred-divider">
            <div class="divider-line"></div>
            <div class="divider-dot"></div>
            <div class="divider-line"></div>
          </div>
          
          <p class="sacred-description" style="font-size:1.8rem;">
            <strong style="color:yellow">Master Shiva Kumar</strong> performs Ganesha Pooja with deep devotion and strict adherence to Vedic rituals. With sacred chants, offerings, and precise mantras, he invokes the divine presence of Lord Ganesha to remove negativity, energize your surroundings, and bring harmony into your life. Every step is guided by spiritual discipline and decades of experience.
          </p>

          <p class="sacred-description" style="font-size:1.8rem;">
            Ganesha Pooja is known for eliminating obstacles, attracting prosperity, and ensuring success in new ventures. Whether you're beginning a new journey, facing challenges, or seeking divine grace, this ritual brings clarity, protection, and blessings from the remover of all hurdles—Lord Ganesha.
          </p>

<!-- 100-character summary -->
          <p class="sacred-description" style="font-size:1.8rem;">
            Ganesha Pooja clears obstacles, brings peace, success, and prosperity to every step of your life.
          </p>
          
          <ul class="sacred-benefits">
            <li>
              <div class="benefit-icon">
                <svg viewBox="0 0 24 24">
                  <path d="M12,2L15.09,8.26L22,9.27L17,14.14L18.18,21.02L12,17.77L5.82,21.02L7,14.14L2,9.27L8.91,8.26L12,2Z" />
                </svg>
              </div>
              <span style="font-size:1.8rem;">Obstacle removal for new ventures</span>
            </li>
            <li>
              <div class="benefit-icon">
                <svg viewBox="0 0 24 24">
                  <path d="M17,18C15.89,18 15,18.89 15,20A2,2 0 0,0 17,22A2,2 0 0,0 19,20C19,18.89 18.1,18 17,18M1,2V4H3L6.6,11.59L5.24,14.04C5.09,14.32 5,14.65 5,15A2,2 0 0,0 7,17H19V15H7.42A0.25,0.25 0 0,1 7.17,14.75C7.17,14.7 7.18,14.66 7.2,14.63L8.1,13H15.55C16.3,13 16.96,12.58 17.3,11.97L20.88,5.5C20.95,5.34 21,5.17 21,5A1,1 0 0,0 20,4H5.21L4.27,2M7,18C5.89,18 5,18.89 5,20A2,2 0 0,0 7,22A2,2 0 0,0 9,20C9,18.89 8.1,18 7,18Z" />
                </svg>
              </div>
              <span style="font-size:1.8rem;">Attract prosperity & abundance</span>
            </li>
            <li>
              <div class="benefit-icon">
                <svg viewBox="0 0 24 24">
                  <path d="M12,3L2,12H5V20H19V12H22L12,3M12,7.7L16,11.2V18H14V14H10V18H8V11.2L12,7.7Z" />
                </svg>
              </div>
              <span style="font-size:1.8rem;">Divine protection for your home</span>
            </li>
          </ul>
          
          <a href="#" class="sacred-cta">
            <span>Book Your Pooja</span>
            <svg viewBox="0 0 24 24">
              <path d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z" />
            </svg>
          </a>
        </div>
        
        <!-- Right Side - Sacred Image -->
        <div class="sacred-image">
          <div class="image-frame">
            <img src="./images/mp.jpg" alt="Ganapathi Pooja Ceremony">
            <div class="image-overlay"></div>
            <div class="image-badge">
              <span>Vedic</span>
              <span>Tradition</span>
            </div>
          </div>
          
          <div class="ritual-features">
            <div class="feature">
              <svg viewBox="0 0 24 24">
                <path d="M12,1L3,5V11C3,16.55 6.84,21.74 12,23C17.16,21.74 21,16.55 21,11V5L12,1Z" />
              </svg>
              <span style="font-size:1.8rem;">Authentic</span>
            </div>
            <div class="feature">
              <svg viewBox="0 0 24 24">
                <path d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M11,16.5L18,9.5L16.59,8.09L11,13.67L7.91,10.59L6.5,12L11,16.5Z" />
              </svg>
              <span style="font-size:1.8rem;">Blessed</span>
            </div>
            <div class="feature">
              <svg viewBox="0 0 24 24">
                <path d="M12,17.27L18.18,21L16.54,13.97L22,9.24L14.81,8.62L12,2L9.19,8.62L2,9.24L7.45,13.97L5.82,21L12,17.27Z" />
              </svg>
              <span style="font-size:1.8rem;">Powerful</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<style>
  /* Modern Spiritual Design System */
  :root {
    --sacred-gold: #FFD700;
    --deep-saffron: #FF9933;
    --holy-red: #E25822;
    --divine-white: #F5F5F5;
    --sacred-teal: #2E8B57;
    --dark-maroon: #800000;
    --spiritual-purple: #4B0082;
  }
  
  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }
  
  body {
    font-family: 'Poppins', sans-serif;
    background-color: #FAFAFA;
  }
  
  .ganapathi-section {
    position: relative;
    padding: 100px 20px;
    overflow: hidden;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
  }
  
  .divine-lights {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    pointer-events: none;
    z-index: 0;
  }
  
  .light-ray {
    position: absolute;
    background: linear-gradient(90deg, rgba(255,215,0,0.1), transparent);
    height: 1px;
    transform-origin: left center;
    animation: ray-glow 8s infinite ease-in-out;
  }
  
  .ray-1 {
    width: 50%;
    top: 20%;
    left: 0;
    animation-delay: 0s;
  }
  
  .ray-2 {
    width: 70%;
    top: 50%;
    left: 0;
    animation-delay: 2s;
  }
  
  .ray-3 {
    width: 40%;
    top: 80%;
    left: 0;
    animation-delay: 4s;
  }
  
  @keyframes ray-glow {
    0%, 100% { opacity: 0.2; }
    50% { opacity: 0.8; }
  }
  
  .light-particle {
    position: absolute;
    background: var(--sacred-gold);
    border-radius: 50%;
    filter: blur(2px);
    animation: particle-float 12s infinite linear;
  }
  
  .particle-1 {
    width: 8px;
    height: 8px;
    top: 15%;
    right: 10%;
    animation-delay: 0s;
  }
  
  .particle-2 {
    width: 5px;
    height: 5px;
    top: 70%;
    right: 30%;
    animation-delay: 3s;
  }
  
  .particle-3 {
    width: 6px;
    height: 6px;
    top: 40%;
    right: 20%;
    animation-delay: 6s;
  }
  
  @keyframes particle-float {
    0% { transform: translateY(0) translateX(0); opacity: 0; }
    20% { opacity: 0.8; }
    100% { transform: translateY(-100px) translateX(50px); opacity: 0; }
  }
  
  .container {
    max-width: 1200px;
    margin: 0 auto;
    position: relative;
    z-index: 1;
  }
  
  .sacred-card {
    background: rgba(26, 26, 46, 0.8);
    border-radius: 24px;
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
    overflow: hidden;
    position: relative;
    border: 1px solid rgba(255, 215, 0, 0.2);
    backdrop-filter: blur(10px);
  }
  
  .om-symbol {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    opacity: 0.03;
    z-index: 0;
  }
  
  .om-symbol svg {
    width: 400px;
    height: 400px;
    fill: var(--divine-white);
  }
  
  .card-content {
    display: flex;
    flex-wrap: wrap;
    position: relative;
    z-index: 1;
  }
  
  .sacred-text {
    flex: 1 1 50%;
    padding: 60px 40px;
    color: var(--divine-white);
  }
  
  .divine-label {
    display: inline-flex;
    flex-direction: column;
    margin-bottom: 20px;
    position: relative;
  }
  
  .divine-label span {
    font-size: 14px;
    font-weight: 600;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: var(--sacred-gold);
    margin-bottom: 8px;
  }
  
  .label-decoration {
    height: 3px;
    width: 40px;
    background: linear-gradient(90deg, var(--sacred-gold), transparent);
  }
  
  .sacred-title {
    font-family: 'Playfair Display', serif;
    font-weight: 700;
    font-size: 3.5rem;
    line-height: 1.2;
    margin-bottom: 30px;
    display: flex;
    flex-direction: column;
  }
  
  .sacred-title span {
    background: linear-gradient(90deg, var(--divine-white), var(--sacred-gold));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    display: inline-block;
  }
  
  .sacred-title span:nth-child(2) {
    padding-left: 50px;
  }
  
  .sacred-title span:nth-child(3) {
    padding-left: 100px;
  }
  
  .sacred-divider {
    display: flex;
    align-items: center;
    margin: 30px 0;
  }
  
  .divider-line {
    height: 1px;
    flex-grow: 1;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
  }
  
  .divider-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--sacred-gold);
    margin: 0 15px;
  }
  
  .sacred-description {
    font-size: 1.1rem;
    line-height: 1.8;
    margin-bottom: 40px;
    color: rgba(255,255,255,0.9);
    position: relative;
    padding-left: 20px;
    border-left: 2px solid var(--sacred-gold);
  }
  
  .sacred-benefits {
    list-style: none;
    margin-bottom: 50px;
  }
  
  .sacred-benefits li {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
    padding: 15px 20px;
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.05);
    transition: all 0.3s ease;
  }
  
  .sacred-benefits li:hover {
    background: rgba(255, 215, 0, 0.1);
    transform: translateX(5px);
  }
  
  .benefit-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 215, 0, 0.1);
    flex-shrink: 0;
  }
  
  .benefit-icon svg {
    width: 20px;
    height: 20px;
    fill: var(--sacred-gold);
  }
  
  .sacred-benefits li span {
    font-size: 1rem;
    color: var(--divine-white);
  }
  
  .sacred-cta {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 16px 32px;
    background: linear-gradient(135deg, var(--holy-red), var(--dark-maroon));
    color: white;
    font-weight: 600;
    text-decoration: none;
    border-radius: 50px;
    transition: all 0.3s ease;
    box-shadow: 0 10px 20px rgba(226, 88, 34, 0.3);
  }
  
  .sacred-cta:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 30px rgba(226, 88, 34, 0.5);
  }
  
  .sacred-cta svg {
    width: 20px;
    height: 20px;
    fill: white;
    transition: transform 0.3s ease;
  }
  
  .sacred-cta:hover svg {
    transform: translateX(5px);
  }
  
  .sacred-image {
    flex: 1 1 50%;
    padding: 40px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }
  
  .image-frame {
    width: 100%;
    border-radius: 16px;
    overflow: hidden;
    position: relative;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
  }
  
  .image-frame img {
    width: 100%;
    height: auto;
    display: block;
    transition: transform 0.5s ease;
  }
  
  .image-frame:hover img {
    transform: scale(1.05);
  }
  
  .image-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(45deg, rgba(255, 153, 51, 0.2), rgba(226, 88, 34, 0.2));
    mix-blend-mode: overlay;
    pointer-events: none;
  }
  
  .image-badge {
    position: absolute;
    bottom: 20px;
    right: 20px;
    background: rgba(0, 0, 0, 0.7);
    padding: 12px 20px;
    border-radius: 8px;
    display: flex;
    flex-direction: column;
    align-items: center;
    z-index: 1;
  }
  
  .image-badge span {
    font-family: 'Playfair Display', serif;
    color: var(--sacred-gold);
    line-height: 1.2;
    font-size: 1.2rem;
  }
  
  .image-badge span:first-child {
    font-weight: 700;
  }
  
  .ritual-features {
    display: flex;
    gap: 20px;
    margin-top: 30px;
    width: 100%;
    justify-content: center;
  }
  
  .feature {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    background: rgba(255, 255, 255, 0.05);
    padding: 15px;
    border-radius: 12px;
    transition: all 0.3s ease;
    width: 100px;
  }
  
  .feature:hover {
    background: rgba(255, 215, 0, 0.1);
    transform: translateY(-5px);
  }
  
  .feature svg {
    width: 24px;
    height: 24px;
    fill: var(--sacred-gold);
  }
  
  .feature span {
    font-size: 0.9rem;
    color: var(--divine-white);
    text-align: center;
  }
  
  /* Responsive Design */
  @media (max-width: 1024px) {
    .sacred-title {
      font-size: 2.8rem;
    }
    
    .sacred-text, .sacred-image {
      padding: 40px 30px;
    }
  }
  
  @media (max-width: 768px) {
    .ganapathi-section {
      padding: 60px 20px;
    }
    
    .card-content {
      flex-direction: column;
    }
    
    .sacred-title {
      font-size: 2.4rem;
    }
    
    .sacred-title span:nth-child(2),
    .sacred-title span:nth-child(3) {
      padding-left: 0;
    }
    
    .ritual-features {
      justify-content: flex-start;
    }
  }
  
  @media (max-width: 480px) {
    .sacred-text, .sacred-image {
      padding: 30px 20px;
    }
    
    .sacred-title {
      font-size: 2rem;
    }
    
    .sacred-cta {
      width: 100%;
      justify-content: center;
    }
  }
</style>

    <!-- Include Additional Sections -->
    <?php include('testimonials.php'); ?>
    
    <?php include('footer.php'); ?>
</body>
</html>