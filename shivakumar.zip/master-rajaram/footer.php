<!-- footer start -->

<div id="footer">

	<div class="container">
		<div class="row">
		<!--
			<div class="col-md-12 col-sm-12 footer-top">
				<h6 class="animated flash infinite">35 Years Experience Astrologer | Guranteed Result</h6>
				<div class="foot-bottom hidden-xs">
					<ul> 
						<li class="foot-call"> <a href=""><span>Call Support : </span></a><a href="tel:<?php echo $linkphone ?>"><?php echo $phone ?></a> </li>
						<li class="foot-call foot-mail"> <a href="mailto:<?php echo $email ?>"><span>Email Support :<?php echo $email ?> </span></a> </li>
						
					</ul>
				</div>
			</div>
			-->
			<div class="footer-box-section">
			
		
				
						<div class="col-md-3 col-sm-12 footer-box">
					<h6 style="color: gold;">about us </h6>
				<p style="color:white;">
				 When unexplained misfortunes strike—be it in health, relationships, or finances—black magic could be the hidden force. Unlike positive spiritual practices, black magic works in secrecy and shadows. Master Shivakumar uses ancient rituals and divine energy to uncover and neutralize these dark influences, restoring balance and shielding your aura from future attacks.
				</p>
				</div>
				
				
				
						<div class="col-md-3 col-sm-12 footer-box">
					<h6 style="color: gold;">Quick Links </h6>
					
					<ul>
						<li> <a href="index.php">Home </a> </li>
						<li> <a href="about-us.php">About Psychic </a> </li>
					
						<li> <a href="contact-us.php">Contact Us </a> </li>
					</ul>
					
					
			
				</div>
				
		
				
				<div class="col-md-3 col-sm-12 footer-box">
					<h6 style="color: gold;">Contact Us </h6>
					
					<div class="foot-contact">
                    	<img src="images/footer-address-icon.png" alt="footer address">
                        <p><span> Address: </span> 
							 <?php echo $address ?>
						</p>
                    </div>
					
					<div class="foot-contact">
                    	<img src="images/footer-email-icon.png" alt="email-address">
                        <p><span> Email Support:</span> 
							<?php echo $email ?>
						</p>
                    </div>
					
					<div class="foot-contact">
                    	<img src="images/footer-phone-icons.png" alt="phone address">
                        <p><span> Phone No: </span>
							<a href="tel:<?php echo $linkphone ?>"style="color:#ffffff"> 
								<?php echo $phone ?>
							</a>
							<br>
						</p>
                    </div>
					
							
				</div>
				
			
			
			</div>
			
			
			
		</div>
	</div>
</div>



<!-- footer end -->
</body>	
	 <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<!-- slider js -->
	<script src="js/jssor.slider-27.5.0.min.js" type="text/javascript"></script>
    <script type="text/javascript">jssor_1_slider_init();</script>
	<!-- End slider js -->
    <!-- Bootsnavs -->
    <script src="js/bootsnav.js"></script>
	<!-- Testimonial js -->
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
	<script>
		$(document).ready(function() {
		$("#news-slider").owlCarousel({
			items:
			3,
			itemsDesktop:[1199,2],
			itemsDesktopSmall:[980,2],
			itemsMobile:[600,1],
			pagination:false,
			navigationText:false,
			autoPlay:true
		});
	});
	</script>
	<script>
	$(document).ready(function(){
    $("#testimonial-slider").owlCarousel({
        items:3,
        itemsDesktop:[1000,1],
        itemsDesktopSmall:[979,1],
        itemsTablet:[768,1],
        pagination:false,
        navigation:true,
        navigationText:["",""],
        autoPlay:true
    });
});
</script>
<!--Start of Tawk.to Script-->

<!--End of Tawk.to Script-->
</html>