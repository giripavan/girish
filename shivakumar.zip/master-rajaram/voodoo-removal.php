<!DOCTYPE HTML>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Voodoo Spell & Removal - Master Shivakumar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Font Awesome for icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <?php include('header.php'); ?>
  <style>
    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background-color: #0d0018;
      color: #fff;
    }

    .voodoo-section {
      position: relative;
      background: linear-gradient(to right, #1a001f, #3b0044);
      padding: 100px 20px;
      overflow: hidden;
    }

    .container {
      max-width: 1200px;
      margin: auto;
      position: relative;
      z-index: 2;
    }

    .voodoo-grid {
      display: flex;
      flex-wrap: wrap;
      gap: 60px;
      align-items: center;
      justify-content: space-between;
    }

    .voodoo-text {
      flex: 1 1 500px;
    }

    .voodoo-text h2 {
      font-size: 3.5rem;
      color: #e174ff;
      margin-bottom: 20px;
    }

    .voodoo-text p {
      font-size: 1.6rem;
      color: #f3d6ff;
      line-height: 1.7;
      margin-bottom: 30px;
    }

    .voodoo-features {
      list-style: none;
      padding: 0;
      margin-bottom: 40px;
    }

    .voodoo-features li {
      font-size: 2rem;
      margin-bottom: 14px;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .voodoo-features li i {
      color: #e86aff;
      font-size: 2.4rem;
    }

    .voodoo-cta {
      display: inline-block;
      background: #db57ff;
      padding: 12px 28px;
      border-radius: 30px;
      color: #000;
      font-weight: bold;
      text-decoration: none;
      box-shadow: 0 8px 25px rgba(219, 87, 255, 0.3);
      transition: all 0.3s ease;
    }

    .voodoo-cta:hover {
      background: #c846e3;
      box-shadow: 0 10px 30px rgba(200, 70, 227, 0.5);
    }

    .voodoo-image {
      flex: 1 1 400px;
      position: relative;
    }

    .voodoo-image img {
      width: 100%;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(255, 255, 255, 0.08);
      transition: transform 0.4s ease;
    }

    .voodoo-image img:hover {
      transform: scale(1.03);
    }

    .spell-bg {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1;
      overflow: hidden;
    }

    .spell-orb {
      position: absolute;
      border-radius: 50%;
      background: rgba(255, 0, 255, 0.07);
      animation: floatOrb 20s linear infinite;
    }

    .spell-orb.one {
      width: 350px;
      height: 350px;
      top: -50px;
      left: -120px;
    }

    .spell-orb.two {
      width: 280px;
      height: 280px;
      bottom: 40px;
      right: -80px;
    }

    .spell-orb.three {
      width: 200px;
      height: 200px;
      top: 25%;
      left: 70%;
    }

    @keyframes floatOrb {
      0% { transform: translateY(0); }
      50% { transform: translateY(-30px); }
      100% { transform: translateY(0); }
    }

    @media (max-width: 900px) {
      .voodoo-grid {
        flex-direction: column;
      }

      .voodoo-text h2 {
        font-size: 2.5rem;
      }

      .voodoo-text p {
        font-size: 1.4rem;
      }

      .voodoo-features li {
        font-size: 1.6rem;
      }

      .voodoo-cta {
        padding: 10px 20px;
      }
    }
  </style>
</head>
<body>

  <section class="voodoo-section">
    <div class="spell-bg">
      <span class="spell-orb one"></span>
      <span class="spell-orb two"></span>
      <span class="spell-orb three"></span>
    </div>

    <div class="container">
      <div class="voodoo-grid">
        <div class="voodoo-text">
          <h2>Voodoo Spell Removal by Master Shivakumar</h2>
          <p><strong style="color:yellow;">Master Shivakumar</strong> specializes in removing the dark effects of voodoo, black magic, and unknown spiritual attacks. Using sacred mantras, divine fire rituals, and astrological corrections, he shields your energy and breaks negative influences.</p>
          <p>If you're facing sudden misfortune, mental confusion, or unexplained obstacles, it may be caused by hidden spiritual harm. Master Shivakumar provides powerful protection and complete voodoo removal solutions to restore your life’s flow.</p>

          <ul class="voodoo-features">
            <li><i class="fas fa-skull-crossbones"></i> Voodoo Curse Removal</li>
            <li><i class="fas fa-shield-alt"></i> Spiritual Protection Shields</li>
            <li><i class="fas fa-fire"></i> Sacred Fire Healing Rituals</li>
            <li><i class="fas fa-eye-slash"></i> Evil Eye & Hex Elimination</li>
          </ul>

          <a href="contact-us.php" class="voodoo-cta">Protect Me Now <i class="fas fa-arrow-circle-right"></i></a>
        </div>

        <div class="voodoo-image">
          <img src="./images/1ms.jpg" alt="Voodoo Spell Removal by Master Shivakumar">
        </div>
      </div>
    </div>
  </section>

  <?php include('testimonials.php'); ?>
  <?php include('footer.php'); ?>
</body>
</html>
