<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Black Magic Removal</title>
  <?php include('header.php'); ?>

  <!-- Black Magic Removal Section -->
  <section class="love-astrology-elegant">
    <div class="ring-bg">
      <span class="ring one"></span>
      <span class="ring two"></span>
      <span class="ring three"></span>
    </div>

    <div class="container">
      <div class="elegant-grid">
        <div class="elegant-text">
          <h2>Black Magic Removal</h2>
          <p><strong style="color:yellow;">Master Shivakumar</strong> specializes in identifying and removing the harmful effects of black magic through ancient spiritual wisdom and protective rituals. If you're facing sudden failures, bad luck, strained relationships, or unexplained health issues, his expertise can uncover the hidden negative energies affecting your life. His remedies are rooted in Vedic traditions and divine intuition to ensure safe and effective results.</p>
          <p>With powerful mantras, energy cleansing, and astrological insights, <strong style="color:yellow;">Master Shivakumar</strong> eliminates dark forces and shields your life from future attacks. Each session is customized to your unique spiritual needs, aiming to bring peace, prosperity, and balance back into your life. Many have experienced relief and freedom from long-term suffering through his trusted guidance.</p>

          <ul class="elegant-features">
            <li><i class="fas fa-shield-alt"></i> Evil Eye Protection</li>
            <li><i class="fas fa-burn"></i> Curse & Spell Removal</li>
            <li><i class="fas fa-star"></i> Aura Cleansing</li>
            <li><i class="fas fa-crosshairs"></i> Psychic Energy Defense</li>
          </ul>

          <a href="contact-us.php" class="elegant-cta">Book a Session <i class="fas fa-arrow-circle-right"></i></a>
        </div>

        <div class="elegant-image">
          <img src="./images/ms2.jpg" alt="Astrologer Shivakumar">
        </div>
      </div>
    </div>
  </section>

  <style>
    .love-astrology-elegant {
      position: relative;
      background: linear-gradient(to right, #2c003e, #100021);
      color: #fff;
      padding: 100px 20px;
      overflow: hidden;
      font-family: 'Poppins', sans-serif;
    }

    .container {
      max-width: 1200px;
      margin: auto;
      position: relative;
      z-index: 2;
    }

    .elegant-grid {
      display: flex;
      flex-wrap: wrap;
      gap: 60px;
      align-items: center;
      justify-content: space-between;
    }

    .elegant-text {
      flex: 1 1 500px;
    }
    .elegant-text h2 {
      font-size: 4rem;
      color: #ff9ec9;
      margin-bottom: 20px;
    }
    .elegant-text p {
      font-size: 1.6rem;
      color: #e0cbe8;
      line-height: 1.7;
      margin-bottom: 30px;
    }
    .elegant-features {
      list-style: none;
      padding: 0;
      margin-bottom: 40px;
    }
    .elegant-features li {
      font-size: 2rem;
      margin-bottom: 14px;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .elegant-features li i {
      color: #fdd835;
      font-size: 2.9rem;
    }

    .elegant-cta {
      display: inline-block;
      background: #ff4b8e;
      padding: 12px 28px;
      border-radius: 30px;
      color: #fff;
      font-weight: bold;
      text-decoration: none;
      box-shadow: 0 8px 25px rgba(255, 75, 142, 0.4);
      transition: all 0.3s ease;
    }
    .elegant-cta:hover {
      background: #ff2e76;
      box-shadow: 0 10px 30px rgba(255, 46, 118, 0.6);
    }

    .elegant-image {
      flex: 1 1 400px;
      position: relative;
    }
    .elegant-image img {
      width: 100%;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(255, 255, 255, 0.1);
      transition: transform 0.4s ease;
    }
    .elegant-image img:hover {
      transform: scale(1.03);
    }

    .ring-bg {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1;
      overflow: hidden;
    }

    .ring {
      position: absolute;
      border: 2px solid rgba(255, 255, 255, 0.07);
      border-radius: 50%;
      animation: spinRing 30s linear infinite;
    }

    .ring.one {
      width: 400px;
      height: 400px;
      top: -50px;
      left: -100px;
    }

    .ring.two {
      width: 250px;
      height: 250px;
      bottom: 20px;
      right: -80px;
    }

    .ring.three {
      width: 300px;
      height: 300px;
      top: 30%;
      left: 70%;
    }

    @keyframes spinRing {
      0% {
        transform: rotate(0deg);
      }
      100% {
        transform: rotate(360deg);
      }
    }

    @media (max-width: 900px) {
      .elegant-grid {
        flex-direction: column;
      }
      .elegant-text,
      .elegant-image {
        width: 100%;
      }
    }
  </style>

  <?php include('testimonials.php'); ?>
  <?php include('footer.php'); ?>
</head>
<body>
</body>
</html>
