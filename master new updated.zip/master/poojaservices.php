<section class="astro-pooja-services">
  <div class="astro-header">
    <h2 style="color:red;"><strong style="color:blue;">✦</strong> Astrology Pooja Services <strong style="color:blue;">✦</strong></h2>
    <p>Master offers powerful spiritual solutions to life's complex challenges.</p>
  </div>

  <div class="astro-cards-wrapper">

    <!-- Shani Pooja -->
    <div class="astro-card" style="background-image: url('images/mps.jpg');">
      <div class="astro-icon">🔗</div>
      <div class="astro-info">
        <h3>Shani Pooja</h3>
        <p>Seek protection from Saturn's influence and reduce life obstacles.</p>
         <div class="astro-buttons">
          <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Rahu Ketu Pooja -->
    <div class="astro-card" style="background-image: url('images/mps1.jpg');">
      <div class="astro-icon">🔗</div>
      <div class="astro-info">
        <h3>Rahu Ketu Pooja</h3>
        <p>Balance karmic energies and remove planetary doshas affecting your life.</p>
       <div class="astro-buttons">
        <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Shiva Pooja -->
    <div class="astro-card" style="background-image: url('images/mps2.jpg');">
      <div class="astro-icon">🔗</div>
      <div class="astro-info">
        <h3>Shiva Pooja</h3>
        <p>Invoke Lord Shiva's blessings for peace, success, and spiritual growth.</p>
         <div class="astro-buttons">
         <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Durga Pooja -->
    <div class="astro-card" style="background-image: url('images/mps3.jpg');">
      <div class="astro-icon">🔗</div>
      <div class="astro-info">
        <h3>Durga Pooja</h3>
        <p>Gain protection from evil forces and empower your inner strength.</p>
         <div class="astro-buttons">
         <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Kali Mata Pooja -->
    <div class="astro-card" style="background-image: url('images/mps4.jpg');">
      <div class="astro-icon">🔗</div>
      <div class="astro-info">
        <h3>Kali Mata Pooja</h3>
        <p>Destroy negative energies and attain liberation through divine power.</p>
         <div class="astro-buttons">
          <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Radha Krishna Pooja -->
    <div class="astro-card" style="background-image: url('images/mps5.jpg');">
      <div class="astro-icon">🔗</div>
      <div class="astro-info">
        <h3>Radha Krishna Pooja</h3>
        <p>Enhance love, harmony, and divine connection with this sacred ritual.</p>
         <div class="astro-buttons">
         <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Hanuman Pooja -->
    <div class="astro-card" style="background-image: url('images/mps6.jpg');">
      <div class="astro-icon">🔗</div>
      <div class="astro-info">
        <h3>Hanuman Pooja</h3>
        <p>Receive strength, courage, and protection from evil spirits and negativity.</p>
        <div class="astro-buttons">
         <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

    <!-- Ganesha Pooja -->
    <div class="astro-card" style="background-image: url('images/mps7.jpg');">
      <div class="astro-icon">🔗</div>
      <div class="astro-info">
        <h3>Ganesha Pooja</h3>
        <p>Remove all obstacles and start new ventures with divine blessings of Lord Ganesha.</p>
         <div class="astro-buttons">
       <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
        </div>
      </div>
    </div>

  </div>
</section>

<style>
.astro-pooja-services {
  background-color: #EED9C4;
  padding: 80px 30px;
  font-family: 'Poppins', sans-serif;
}

.astro-header {
  text-align: center;
  margin-bottom: 50px;
}

.astro-header h2 {
  font-size: 5rem;
  margin-bottom: 10px;
  color: #fff;
}

.astro-header p {
  max-width: 650px;
  margin: 0 auto;
  font-size: 2.5rem;
  color: black;
}

.astro-cards-wrapper {
  display: flex;
  flex-wrap: wrap;
  gap: 30px;
  justify-content: center;
}

.astro-card {
  position: relative;
  width: 260px;
  height: 460px;
  background-size: cover;
  background-position: center;
  border-radius: 16px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.6);
  transition: transform 0.3s;
}

.astro-card:hover {
  transform: translateY(-10px);
}

.astro-icon {
  position: absolute;
  top: 15px;
  right: 15px;
  background-color: #fcbf49;
  color: black;
  font-size: 1.2rem;
  padding: 10px;
  border-radius: 50%;
}

.astro-info {
  background: rgba(255, 183, 77, 0.85);
  padding: 20px;
  border-top-left-radius: 40px;
  color: #000;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 50%;
}

.astro-info h3 {
  font-size: 2.2rem;
  margin-bottom: 10px;
}

.astro-info p {
  font-size: 1.5rem;
  margin-bottom: 10px;
}

.astro-buttons {
  display: flex;
  justify-content: space-between;
  gap: 10px;
}

.astro-btn {
  flex: 1;
  padding: 8px 12px;
  border-radius: 20px;
  font-size: 0.85rem;
  font-weight: 600;
  text-align: center;
  text-decoration: none;
  color: white;
  transition: background 0.3s;
}

.astro-btn.call {
  background-color: rgb(81, 17, 4);
}

.astro-btn.call:hover {
  background-color: rgb(77, 4, 4);
}

.astro-btn.whatsapp {
  background-color: #25D366;
}

.astro-btn.whatsapp:hover {
  background-color: #1ebe5d;
}
</style>
