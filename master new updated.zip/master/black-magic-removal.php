<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Black Magic Removal</title>
	<?php include('header.php'); ?>
</head>
<body>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>

<style>
  body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #1a0007, #2e0f0f);
    color: white;
  }

  .section-wrapper {
    max-width: 1200px;
    margin: auto;
    padding: 80px 20px;
    display: flex;
    flex-wrap: wrap;
    gap: 40px;
  }

  .left-image {
    flex: 1 1 400px;
  }

  .left-image img {
    width: 100%;
    height: 100%;
    max-height: 500px;
    object-fit: cover;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(255, 0, 0, 0.2);
  }

  .right-content {
    flex: 1 1 600px;
  }

  .right-content h1 {
    font-size: 4.5rem;
    color: #ff4444;
    margin-bottom: 20px;
  }

  .right-content p {
    font-size: 2.1rem;
    line-height: 1.7;
    color: #f4dcdc;
    margin-bottom: 30px;
  }

  .card-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
  }

  .info-card {
    flex: 1 1 260px;
    background: rgba(255, 255, 255, 0.07);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 15px;
    padding: 20px;
    cursor: pointer;
    transition: 0.3s ease;
    display: flex;
    flex-direction: column;
  }

  .info-card:hover {
    background: rgba(255, 255, 255, 0.15);
  }

  .info-card-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 10px;
  }

  .info-card i {
    font-size: 1.8rem;
    color: #ff4444;
  }

  .info-card h3 {
    font-size: 1.9rem;
    color: yellow;
    margin: 0;
  }

 .info-card .card-detail {
    margin-top: 10px;
    font-size: 1.95rem;
    line-height: 1.5;
    color: white;
    display: none;
  }

  .info-card.active .card-detail {
    display: block;
    animation: fadeIn 0.4s ease;
  }

  .contact-btn {
    margin-top: 40px;
    display: inline-block;
    background: linear-gradient(135deg, #ff4444, #ff6a00);
    color: black;
    padding: 14px 30px;
    border-radius: 40px;
    font-weight: bold;
    font-size: 1rem;
    text-decoration: none;
    transition: background 0.3s ease;
  }

  .contact-btn:hover {
    background: linear-gradient(135deg, #ff6666, #ffa94d);
    color: #000;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @media (max-width: 768px) {
    .section-wrapper {
      flex-direction: column;
    }

    .right-content {
      order: 1;
    }

    .left-image {
      order: 2;
      margin-top: 30px;
    }

    .card-grid {
      order: 3;
    }

    .right-content h1 {
      font-size: 2.5rem;
    }

    .info-card {
      flex: 1 1 100%;
    }
  }
</style>

<section class="section-wrapper">

  <!-- Left Image -->
  <div class="left-image">
    <img src="./images/msse1.jpg" alt="Black Magic Removal" />
  </div>

  <!-- Right Content -->
  <div class="right-content">
    <h1><i class="fas fa-skull-crossbones"></i> Black Magic</h1>
    <p>
      Do you feel cursed, stuck, or affected by unseen forces? Black magic, evil eye, and negative energies can disrupt your peace, relationships, and success. Protect yourself with time-tested spiritual practices.
    </p>
    <p>
      Through rituals, yantras, and divine intervention, black magic can be neutralized. Regain balance, health, and positivity by removing harmful energies and fortifying your aura.
    </p>

    <!-- Cards -->
    <div class="card-grid">
      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-eye-slash"></i>
          <h3>Evil Eye Symptoms</h3>
        </div>
        <div class="card-detail">
          Unexplained illness, financial loss, fear, and anxiety may signal an evil eye or black magic. Learn the signs and act early.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-cross"></i>
          <h3>Spiritual Protection</h3>
        </div>
        <div class="card-detail">
          Mantras, Hanuman Chalisa, and protective amulets (raksha yantras) build divine shields around your aura and environment.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-burn"></i>
          <h3>Black Magic Removal</h3>
        </div>
        <div class="card-detail">
          Rituals like Sudarshana Homa, Kali Pooja, and Nava Graha Shanti help eliminate deep-rooted black magic and dark energies.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-shield-alt"></i>
          <h3>After Effects Cleansing</h3>
        </div>
        <div class="card-detail">
          Post-removal spiritual cleansing brings clarity, success, and peace back into your life by realigning your spiritual flow.
        </div>
      </div>
    </div>

    <!-- Contact Button -->
    <a href="contact-us.php" class="contact-btn">Get Protection Now</a>
  </div>
</section>

<script>
  function toggleCard(card) {
    card.classList.toggle('active');
  }
</script>

<?php include('testimonials.php'); ?>
<?php include('faq.php'); ?>
<?php include('footer.php'); ?>

</body>
</html>
