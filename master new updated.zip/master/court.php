<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Court Case Problem Solution</title>
  <?php include('header.php'); ?>
</head>
<body>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>

<style>
  body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #1e3c72, #2a5298);
    color: white;
  }

  .section-wrapper {
    max-width: 1200px;
    margin: auto;
    padding: 80px 20px;
    display: flex;
    flex-wrap: wrap;
    gap: 40px;
  }

  .left-image {
    flex: 1 1 400px;
  }

  .left-image img {
    width: 100%;
    height: 100%;
    max-height: 500px;
    object-fit: cover;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  }

  .right-content {
    flex: 1 1 600px;
  }

  .right-content h1 {
    font-size: 4.5rem;
    color: #ffe066;
    margin-bottom: 20px;
  }

  .right-content p {
    font-size: 2.1rem;
    line-height: 1.7;
    color: #f6f9ff;
    margin-bottom: 30px;
  }

  .card-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
  }

  .info-card {
    flex: 1 1 260px;
    background: rgba(255, 255, 255, 0.07);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 15px;
    padding: 20px;
    cursor: pointer;
    transition: 0.3s ease;
    display: flex;
    flex-direction: column;
  }

  .info-card:hover {
    background: rgba(255, 255, 255, 0.15);
  }

  .info-card-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 10px;
  }

  .info-card i {
    font-size: 1.8rem;
    color: #ffe066;
  }

  .info-card h3 {
    font-size: 1.9rem;
    color: yellow;
    margin: 0;
  }

  .info-card .card-detail {
    margin-top: 10px;
    font-size: 1.95rem;
    line-height: 1.5;
    color: white;
    display: none;
  }

  .info-card.active .card-detail {
    display: block;
    animation: fadeIn 0.4s ease;
  }

  .contact-btn {
    margin-top: 40px;
    display: inline-block;
    background: linear-gradient(135deg, #ffe066, #f5c518);
    color: black;
    padding: 14px 30px;
    border-radius: 40px;
    font-weight: bold;
    font-size: 1rem;
    text-decoration: none;
    transition: background 0.3s ease;
  }

  .contact-btn:hover {
    background: linear-gradient(135deg, #f5cd00, #fff275);
    color: #000;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @media (max-width: 768px) {
    .section-wrapper {
      flex-direction: column;
    }

    .right-content {
      order: 1;
    }

    .left-image {
      order: 2;
      margin-top: 30px;
    }

    .card-grid {
      order: 3;
    }

    .right-content h1 {
      font-size: 2.5rem;
    }

    .info-card {
      flex: 1 1 100%;
    }
  }
</style>

<section class="section-wrapper">

  <!-- Left Image -->
  <div class="left-image">
    <img src="./images/msse10.jpg" alt="Court Case Solution" />
  </div>

  <!-- Right Content -->
  <div class="right-content">
    <h1><i class="fas fa-gavel"></i> Court Case Help</h1>
    <p>
      Facing delays in legal matters? Whether it's civil disputes, false accusations, or property conflicts, astrology offers remedies for smoother court victories.
    </p>
    <p>
      With the right poojas, mantra sadhanas, and planetary correction, justice can be attained faster and obstacles removed.
    </p>

    <!-- Cards -->
    <div class="card-grid">
      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-balance-scale-left"></i>
          <h3>Legal Delays</h3>
        </div>
        <div class="card-detail">
          Saturn and Rahu effects can cause judgment delays. Specific rituals like Shani Shanti help remove blocks.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-user-secret"></i>
          <h3>Enemy Troubles</h3>
        </div>
        <div class="card-detail">
          Hidden enemies and false allegations may be the result of negative energy. Baglamukhi pooja gives legal dominance.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-scroll"></i>
          <h3>Property Disputes</h3>
        </div>
        <div class="card-detail">
          Horoscope analysis and dosha nivaran can ease resolution of inheritance or real estate disputes.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-praying-hands"></i>
          <h3>Victory Rituals</h3>
        </div>
        <div class="card-detail">
          Perform Durga Saptashati, Hanuman puja, and Navagraha homa to overcome legal obstacles and attain favorable verdicts.
        </div>
      </div>
    </div>

    <!-- Contact Button -->
    <a href="contact-us.php" class="contact-btn">Solve Court Case Issues</a>
  </div>
</section>

<script>
  function toggleCard(card) {
    card.classList.toggle('active');
  }
</script>

<?php include('testimonials.php'); ?>
<?php include('faq.php'); ?>
<?php include('footer.php'); ?>

</body>
</html>
