<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Financial Problem Solution</title>
  <?php include('header.php'); ?>
</head>
<body>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>

<style>
  body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg,rgb(21, 17, 30), #4361ee);
    color: white;
  }

  .section-wrapper {
    max-width: 1200px;
    margin: auto;
    padding: 80px 20px;
    display: flex;
    flex-wrap: wrap;
    gap: 40px;
  }

  .left-image {
    flex: 1 1 400px;
  }

  .left-image img {
    width: 100%;
    height: 100%;
    max-height: 500px;
    object-fit: cover;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  }

  .right-content {
    flex: 1 1 600px;
  }

  .right-content h1 {
    font-size: 4.5rem;
    color: #ffcf00;
    margin-bottom: 20px;
  }

  .right-content p {
    font-size: 2.1rem;
    line-height: 1.7;
    color: #fefae0;
    margin-bottom: 30px;
  }

  .card-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
  }

  .info-card {
    flex: 1 1 260px;
    background: rgba(255, 255, 255, 0.07);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 15px;
    padding: 20px;
    cursor: pointer;
    transition: 0.3s ease;
    display: flex;
    flex-direction: column;
  }

  .info-card:hover {
    background: rgba(255, 255, 255, 0.15);
  }

  .info-card-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 10px;
  }

  .info-card i {
    font-size: 1.8rem;
    color: #ffcf00;
  }

  .info-card h3 {
    font-size: 1.9rem;
    color: yellow;
    margin: 0;
  }

  .info-card .card-detail {
    margin-top: 10px;
    font-size: 1.95rem;
    line-height: 1.5;
    color: white;
    display: none;
  }
  .info-card.active .card-detail {
    display: block;
    animation: fadeIn 0.4s ease;
  }

  .contact-btn {
    margin-top: 40px;
    display: inline-block;
    background: linear-gradient(135deg, #ffcf00, #ffd700);
    color: black;
    padding: 14px 30px;
    border-radius: 40px;
    font-weight: bold;
    font-size: 1rem;
    text-decoration: none;
    transition: background 0.3s ease;
  }

  .contact-btn:hover {
    background: linear-gradient(135deg, #ffc107, #ffe066);
    color: #000;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @media (max-width: 768px) {
    .section-wrapper {
      flex-direction: column;
    }

    .right-content {
      order: 1;
    }

    .left-image {
      order: 2;
      margin-top: 30px;
    }

    .card-grid {
      order: 3;
    }

    .right-content h1 {
      font-size: 2.5rem;
    }

    .info-card {
      flex: 1 1 100%;
    }
  }
</style>

<section class="section-wrapper">

  <!-- Left Image -->
  <div class="left-image">
    <img src="./images/msse5.jpg" alt="Financial Problem Solution" />
  </div>

  <!-- Right Content -->
  <div class="right-content">
    <h1><i class="fas fa-hand-holding-usd"></i> Financial Problems</h1>
    <p>
      Struggling to manage finances or facing constant money issues? Financial instability often has roots in astrological imbalances or doshas. Let us guide you to prosperity.
    </p>
    <p>
      Remedies like Lakshmi Pooja, Kubera Yantra, or removing past life karmic blockages can restore your wealth flow and bring abundance into your life.
    </p>

    <!-- Cards -->
    <div class="card-grid">
      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-funnel-dollar"></i>
          <h3>Money Flow Issues</h3>
        </div>
        <div class="card-detail">
          Delay in payments, unending debts, or unexpected losses may be due to Dhana Bhava afflictions in your chart.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-user-slash"></i>
          <h3>Blocked Income Sources</h3>
        </div>
        <div class="card-detail">
          Karmic debts and planetary misalignment can silently block potential income streams and professional success.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-gem"></i>
          <h3>Wealth Remedies</h3>
        </div>
        <div class="card-detail">
          Through Lakshmi Kubera Homa, energizing money yantras, and Vastu correction, wealth and savings can flourish again.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-sun"></i>
          <h3>Pooja & Astrology</h3>
        </div>
        <div class="card-detail">
          Specialized poojas and astrological consultation can help turn your financial fate towards abundance and growth.
        </div>
      </div>
    </div>

    <!-- Contact Button -->
    <a href="contact-us.php" class="contact-btn">Fix Financial Problems</a>
  </div>
</section>

<script>
  function toggleCard(card) {
    card.classList.toggle('active');
  }
</script>

<?php include('testimonials.php'); ?>
<?php include('faq.php'); ?>
<?php include('footer.php'); ?>

</body>
</html>
