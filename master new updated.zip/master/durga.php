<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Durga Pooja | Divine Feminine Power</title>
  <?php include('header.php'); ?>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Marcellus&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root {
      --gold: #D4AF37;
      --durga-red: #9B1C31;
      --peach: #FFF3F0;
      --dark: #1A1A1A;
    }

    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background-color: var(--peach);
      color: var(--dark);
      line-height: 1.8;
      overflow-x: hidden;
    }

    .luxury-section {
      position: relative;
      max-width: 1400px;
      margin: 0 auto;
      padding: 100px 40px;
      overflow: hidden;
    }

    .ornament {
      position: absolute;
      opacity: 0.05;
      z-index: 0;
    }

    .ornament-1 {
      top: -100px;
      right: -100px;
      font-size: 30rem;
      color: var(--gold);
    }

    .ornament-2 {
      bottom: -150px;
      left: -100px;
      font-size: 25rem;
      color: var(--durga-red);
    }

    .section-content { position: relative; z-index: 2; }
    .section-header {
      text-align: center;
      margin-bottom: 80px;
    }

    .section-subtitle {
      display: block;
      font-size: 7rem;
      letter-spacing: 4px;
      color: var(--gold);
      text-transform: uppercase;
      margin-bottom: 20px;
    }

    .section-title {
      font-family: 'Marcellus', serif;
      font-size: 4rem;
      color: var(--durga-red);
      margin-bottom: 20px;
      line-height: 1.2;
    }

    .section-divider {
      width: 100px;
      height: 2px;
      background: linear-gradient(to right, transparent, var(--gold), transparent);
      margin: 0 auto;
    }

    .content-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 60px;
      align-items: center;
    }

    .sacred-image {
      position: relative;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 30px 60px rgba(0,0,0,0.15);
      transform: perspective(1000px) rotateY(-5deg);
      transition: all 0.6s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .sacred-image:hover {
      transform: perspective(1000px) rotateY(0deg);
      box-shadow: 0 40px 80px rgba(0,0,0,0.2);
    }

    .sacred-image img {
      width: 100%;
      height: 600px;
      display: block;
    }

    .sacred-image:before {
      content: '';
      position: absolute;
      top: 20px;
      left: 20px;
      right: 20px;
      bottom: 20px;
      border: 1px solid rgba(212, 175, 55, 0.4);
      z-index: 2;
      pointer-events: none;
    }

    .service-details h2 {
      font-family: 'Marcellus', serif;
      font-size: 2.5rem;
      color: var(--durga-red);
      margin-bottom: 30px;
      position: relative;
    }

    .service-details h2:after {
      content: '';
      position: absolute;
      bottom: -15px;
      left: 0;
      width: 60px;
      height: 2px;
      background: var(--gold);
    }

    .service-description {
      font-size: 1.9rem;
      margin-bottom: 30px;
      color: #444;
    }

    .highlight-box {
      background: rgba(255, 255, 255, 0.7);
      border-left: 4px solid var(--gold);
      padding: 30px;
      margin: 40px 0;
      position: relative;
      backdrop-filter: blur(5px);
    }

    .highlight-box p {
      font-style: italic;
      font-size: 1.9rem;
      color: var(--durga-red);
      margin: 0;
    }

    .highlight-box:before {
      content: '"';
      position: absolute;
      top: 10px;
      left: 15px;
      font-family: 'Marcellus', serif;
      font-size: 5rem;
      color: var(--gold);
      opacity: 0.2;
      line-height: 1;
    }

    .benefits-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 25px;
      margin-top: 40px;
    }

    .benefit-card {
      background: white;
      border-radius: 8px;
      padding: 30px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.05);
      transition: all 0.4s ease;
      position: relative;
      overflow: hidden;
      border-top: 3px solid var(--gold);
    }

    .benefit-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 40px rgba(0,0,0,0.1);
    }

    .benefit-icon {
      font-size: 2.5rem;
      color: var(--gold);
      margin-bottom: 20px;
      transition: transform 0.4s ease;
    }

    .benefit-card:hover .benefit-icon {
      transform: scale(1.1);
    }

    .benefit-title {
      font-family: 'Marcellus', serif;
      font-size: 2.3rem;
      color: var(--durga-red);
      margin-bottom: 15px;
    }

    .benefit-description {
      font-size: 1.95rem;
      color: #666;
    }

    .cta-button {
      display: inline-flex;
      align-items: center;
      margin-top: 50px;
      padding: 18px 40px;
      background: linear-gradient(135deg, var(--durga-red), #6B0B1F);
      color: white;
      font-weight: 600;
      font-size: 1.1rem;
      border-radius: 8px;
      text-decoration: none;
      transition: all 0.4s ease;
      box-shadow: 0 10px 30px rgba(155, 28, 49, 0.3);
    }

    .cta-button:hover {
      background: linear-gradient(135deg, var(--gold), #E6C200);
      color: var(--durga-red);
      transform: translateY(-5px);
      box-shadow: 0 15px 40px rgba(212, 175, 55, 0.4);
    }

    .cta-button i {
      margin-left: 10px;
      transition: transform 0.3s ease;
    }

    .cta-button:hover i {
      transform: translateX(5px);
    }

    @media (max-width: 768px) {
      .content-grid { grid-template-columns: 1fr; }
      .sacred-image { margin-bottom: 40px; }
      .ornament-1, .ornament-2 { font-size: 15rem; }
    }
     .section-subtitle {
        font-size: 3.2rem;
      }

    @media (max-width: 480px) {
      .luxury-section { padding: 80px 20px; }
      .section-title { font-size: 2rem; }
      .benefits-grid { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <section class="luxury-section">
    <div class="ornament ornament-1">ॐ</div>
    <div class="ornament ornament-2">दुर्गा</div>

    <div class="section-content">
      <div class="section-header">
     <span class="section-subtitle">MASTER Rituals</span>
        <h1 class="section-title">Divine Durga Pooja</h1>
        <div class="section-divider"></div>
        <p>Invoke Maa Durga’s divine energy to remove negativity, empower inner strength, and bless your life with victory and peace.</p>
      </div>

      <div class="content-grid">
        <div class="sacred-image">
          <img src="images/mpss3.jpg" alt="Goddess Durga">
        </div>

        <div class="service-details">
          <h2>Victory Over Darkness</h2>
          <p class="service-description">Durga Pooja is a powerful remedy to overcome fear, enemies, black magic, and evil influences. Conducted with complete devotion and Vedic rituals, this pooja strengthens your aura and confidence.</p>

          <div class="highlight-box">
            <p>Maa Durga embodies power, wisdom, and protection. Her blessings destroy all evil and restore spiritual order.</p>
          </div>

          <p class="service-description">Highly beneficial during Navratri, challenging planetary periods, or emotional turmoil.</p>

          <div class="benefits-grid">
            <div class="benefit-card">
              <div class="benefit-icon"><i class="fas fa-shield-alt"></i></div>
              <h3 class="benefit-title">Protection</h3>
              <p class="benefit-description">Safeguards from negativity, black magic, and evil eyes</p>
            </div>
            <div class="benefit-card">
              <div class="benefit-icon"><i class="fas fa-bolt"></i></div>
              <h3 class="benefit-title">Empowerment</h3>
              <p class="benefit-description">Boosts confidence, energy, and inner courage</p>
            </div>
            <div class="benefit-card">
              <div class="benefit-icon"><i class="fas fa-heart"></i></div>
              <h3 class="benefit-title">Emotional Balance</h3>
              <p class="benefit-description">Calms anxiety, mood swings, and fear</p>
            </div>
            <div class="benefit-card">
              <div class="benefit-icon"><i class="fas fa-gem"></i></div>
              <h3 class="benefit-title">Spiritual Strength</h3>
              <p class="benefit-description">Strengthens devotion, discipline, and divine connection</p>
            </div>
          </div>

          <a href="contact-us.php" class="cta-button">
            Book Durga Pooja <i class="fas fa-arrow-right"></i>
          </a>
        </div>
      </div>
    </div>
  </section>
</body>
</html>
<?php include('three.php'); ?>
<?php include('testimonials.php'); ?>
<?php include('faq.php'); ?>
<?php include('footer.php'); ?>
