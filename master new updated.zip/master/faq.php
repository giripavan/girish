<section style="position: relative; background: radial-gradient(circle, rgb(101, 47, 2), rgb(236, 11, 11)); padding: 80px 20px; font-family: 'Poppins', sans-serif; color: white; overflow: hidden;">
  <!-- Right-side Background Image -->

  <div style="position: relative; z-index: 1; max-width: 1200px; margin: auto;">
    <h1 style="font-family: 'Marcellus', serif; font-size: 42px; color: #ffd700; text-align: center; margin-bottom: 20px;">
      Benefits of Consulting Master
    </h1>
    <p style="color: #ccc; max-width: 800px; margin: 0 auto 50px; text-align: center;">
      Discover how astrology can guide and protect you across various aspects of life — from love to protection against negative energies.
    </p>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 30px; padding: 0 20px;">
      <!-- FAQ Cards -->
      <div style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px; padding: 30px 20px; text-align: left;">
        <div style="font-size: 32px; margin-bottom: 15px; color: #ffd700;">🔮</div>
        <div style="font-size: 18px; color: #ffcc00; margin-bottom: 10px; font-weight: 600;">How can astrology help me understand my life better?</div>
        <div style="font-size: 15px; color: #ddd; line-height: 1.6;">
          Astrology reveals the unique blueprint of your life by analyzing planetary positions at your birth. Master helps uncover your strengths, challenges, and spiritual path for better decision-making.
        </div>
      </div>

      <div style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px; padding: 30px 20px; text-align: left;">
        <div style="font-size: 32px; margin-bottom: 15px; color: #ffd700;">🧭</div>
        <div style="font-size: 18px; color: #ffcc00; margin-bottom: 10px; font-weight: 600;">Can astrology provide clarity about my life direction?</div>
        <div style="font-size: 15px; color: #ddd; line-height: 1.6;">
          Yes. By reading your birth chart, Master helps you understand your life’s purpose, career direction, and karmic lessons — bringing clarity and spiritual alignment.
        </div>
      </div>

      <div style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px; padding: 30px 20px; text-align: left;">
        <div style="font-size: 32px; margin-bottom: 15px; color: #ffd700;">💘</div>
        <div style="font-size: 18px; color: #ffcc00; margin-bottom: 10px; font-weight: 600;">How can astrology help me with love and relationships?</div>
        <div style="font-size: 15px; color: #ddd; line-height: 1.6;">
          Astrology analyzes compatibility between you and your partner. Master can reveal emotional patterns, help resolve issues, and guide you toward stronger, balanced relationships.
        </div>
      </div>

      <div style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px; padding: 30px 20px; text-align: left;">
        <div style="font-size: 32px; margin-bottom: 15px; color: #ffd700;">🌑</div>
        <div style="font-size: 18px; color: #ffcc00; margin-bottom: 10px; font-weight: 600;">Can astrology help me overcome black magic or evil eye problems?</div>
        <div style="font-size: 15px; color: #ddd; line-height: 1.6;">
          Yes. Astrology detects black magic, negative energies, or evil eye through planetary signs. Master performs rituals, chants, and spiritual remedies to protect and cleanse your aura.
        </div>
      </div>

      <div style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px; padding: 30px 20px; text-align: left;">
        <div style="font-size: 32px; margin-bottom: 15px; color: #ffd700;">⚖️</div>
        <div style="font-size: 18px; color: #ffcc00; margin-bottom: 10px; font-weight: 600;">Can astrology help me make better decisions?</div>
        <div style="font-size: 15px; color: #ddd; line-height: 1.6;">
          Absolutely. Astrology reveals the most favorable time to make life decisions — whether in career, finance, or personal matters. Master Shivakumar provides guidance that aligns your actions with planetary support.
        </div>
      </div>

      <div style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 16px; padding: 30px 20px; text-align: left;">
        <div style="font-size: 32px; margin-bottom: 15px; color: #ffd700;">🌟</div>
        <div style="font-size: 18px; color: #ffcc00; margin-bottom: 10px; font-weight: 600;">Is astrology useful for business or career growth?</div>
        <div style="font-size: 15px; color: #ddd; line-height: 1.6;">
          Yes. By analyzing your birth chart and current planetary transits, Master can help you choose the right career path, launch a business at the right time, and avoid setbacks caused by negative alignments.
        </div>
      </div>
    </div>
  </div>
</section>
