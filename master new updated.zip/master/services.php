<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Astrology Services</title>
  <link href="https://fonts.googleapis.com/css2?family=Segoe+UI:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #0c0e2c;
      color: #fff;
      overflow-x: hidden;
    }

    .magic-section {
      padding: 40px 16px;
      background-color: #1a1a3d;
    }

    .magic-content {
      text-align: center;
      margin-bottom: 30px;
    }

    .magic-content h2 {
      color: #f6549a;
      font-size: 32px;
      margin-bottom: 10px;
    }

    .magic-content p {
      color: #ccc;
      font-size: 16px;
      margin-bottom: 16px;
    }

    .btn-book {
      background-color: #f6549a;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 20px;
      cursor: pointer;
    }

    .magic-body {
      display: flex;
      gap: 16px;
    }

    .magic-left {
      flex: 0 0 30%;
      max-width: 30%;
    }

    .magic-left img {
      width: 100%;
      height: 100%;
      max-height: 500px;
      object-fit: cover;
      border-radius: 12px;
      box-shadow: 0 0 20px rgba(255, 255, 255, 0.1);
    }

    .magic-right {
      flex: 1;
      overflow: hidden;
      position: relative;
    }

    .card-wrapper {
      display: flex;
      transition: transform 0.4s ease-in-out;
    }

    .service-card {
      min-width: 250px;
      max-width: 250px;
      background-color: #1a1a3d;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 0 10px rgba(0,0,0,0.4);
      margin-right: 16px;
      flex-shrink: 0;
      text-align: center;
    }

    .service-card img {
      width: 100%;
      height: 160px;
      object-fit: cover;
    }

    .card-content {
      padding: 12px;
    }

    .card-content h4 {
      color: #4da6ff;
      margin: 0 0 8px;
      font-size: 16px;
    }

    .card-content p {
      font-size: 14px;
      color: #ccc;
      margin: 0 0 8px;
    }

    .card-actions {
      margin-top: 8px;
      display: flex;
      justify-content: center;
      gap: 8px;
      flex-wrap: wrap;
    }

    .card-actions a {
      text-decoration: none;
      font-size: 13px;
      padding: 6px 10px;
      border-radius: 20px;
      display: inline-block;
    }

    .call-btn {
      background-color: #4da6ff;
      color: white;
    }

    .whatsapp-btn {
      background-color: #25D366;
      color: white;
    }

    .nav-buttons {
      display: none;
      justify-content: center;
      gap: 12px;
      margin-top: 16px;
    }

    .nav-buttons button {
      background: #f6549a;
      color: white;
      border: none;
      padding: 8px 14px;
      border-radius: 6px;
      font-size: 14px;
      cursor: pointer;
    }

    @media (min-width: 769px) {
      .card-wrapper {
        animation: scroll-desktop 40s linear infinite;
      }

      @keyframes scroll-desktop {
        0% { transform: translateX(0); }
        100% { transform: translateX(-100%); }
      }

      .nav-buttons {
        display: none !important;
      }
    }

    @media (max-width: 768px) {
  .magic-body {
    display: block;
  }

  .magic-left {
    display: none;
  }

  .magic-right {
    max-width: 100%;
  }

  .card-wrapper {
    flex-direction: column;
    align-items: center;
    transform: none !important;
  }

  .service-card {
    width: 250px;
    height: 250px;
    margin: 50px auto;
    transform: rotate(45deg);
    position: relative;
    overflow: hidden;
    border-radius: 12px;
    box-shadow: 0 0 10px rgba(255,255,255,0.2);
  }

  .service-card img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transform: rotate(-45deg) scale(1.41);
  }

  .card-content {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 80%;
    padding: 10px;
    background: rgba(0, 0, 0, 0.6);
    color: #fff;
    text-align: center;
    transform: translate(-50%, -50%) rotate(-45deg);
    border-radius: 10px;
    opacity: 0;
    transition: opacity 0.3s ease;
    pointer-events: none;
  }

  .service-card:hover .card-content {
    opacity: 1;
    pointer-events: auto;
  }

  .card-actions {
    flex-direction: column;
    gap: 6px;
    margin-top: 6px;
  }

  .card-actions a {
    width: 100%;
    text-align: center;
  }
}

  </style>
</head>
<body>

<section class="magic-section">
  <div class="magic-content">
    <h2>Let’s Make Some Magic</h2>
    <p>They will provide the best free horoscope astrology to you by analysing your sign.</p>
    <button class="btn-book">Book Reading Now</button>
  </div>

  <div class="magic-body">
    <div class="magic-left">
      <img src="images/a.jpg" alt="Astrology Image" loading="lazy">
    </div>

    <div class="magic-right">
     <div class="card-wrapper" id="cardWrapper">

  <!-- 1. Love & Relationship Problem -->
  <div class="service-card">
    <img src="images/mss.jpg" alt="Love">
    <div class="card-content">
      <h4>Get Love Back</h4>
      <p>Resolve heartbreak, misunderstandings & attract true love with astrology.</p>
      <div class="card-actions">
        <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- 2. Black Magic Removal -->
  <div class="service-card">
    <img src="images/mse1.jpg" alt="Black Magic">
    <div class="card-content">
      <h4>Black Magic Removal</h4>
      <p>Eliminate dark energies and spiritual attacks affecting your peace.</p>
    <div class="card-actions">
     <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- 3. Marriage Problem -->
  <div class="service-card">
    <img src="images/mssse.jpg" alt="Marriage">
    <div class="card-content">
      <h4>Marriage Problem</h4>
      <p>Overcome delays, disputes & gain harmony in your married life.</p>
      <div class="card-actions">
       <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- 4. Career and Business Problem -->
  <div class="service-card">
    <img src="images/mse3.jpg" alt="Career">
    <div class="card-content">
      <h4>Career & Business Problem</h4>
      <p>Boost your career and overcome business losses using astrology.</p>
      <div class="card-actions">
      <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- 5. Spiritual Healing -->
  <div class="service-card">
    <img src="images/mse4.jpg" alt="Spiritual">
    <div class="card-content">
      <h4>Spiritual Healing</h4>
      <p>Cleanse your aura and restore inner peace through spiritual energy work.</p>
      <div class="card-actions">
       <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- 6. Financial and Property Problem -->
  <div class="service-card">
    <img src="images/mse5.jpg" alt="Financial">
    <div class="card-content">
      <h4>Financial & Property Problem</h4>
      <p>Resolve money matters and legal property issues through astrology.</p>
      <div class="card-actions">
    <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- 7. Palm and Face Reading -->
  <div class="service-card">
    <img src="images/mse6.jpg" alt="Palmistry">
    <div class="card-content">
      <h4>Palm & Face Reading</h4>
      <p>Reveal secrets of your destiny through palmistry and face analysis.</p>
      <div class="card-actions">
       <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- 8. Negative Energy Removal -->
  <div class="service-card">
    <img src="images/mse7.jpg" alt="Negative Energy">
    <div class="card-content">
      <h4>Negative Energy Removal</h4>
      <p>Cleanse spaces and people from evil eye, bad luck, and dark forces.</p>
      <div class="card-actions">
     <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- 9. Childless Couple -->
  <div class="service-card">
    <img src="images/mse8.jpg" alt="Childless Couple">
    <div class="card-content">
      <h4>Childless Couple</h4>
      <p>Astrological remedies for infertility and childbearing blessings.</p>
      <div class="card-actions">
       <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- 10. Witch Craft Reading -->
  <div class="service-card">
    <img src="images/mse9.jpg" alt="Witch Craft">
    <div class="card-content">
      <h4>Witch Craft Reading</h4>
      <p>Protect yourself from witchcraft and spiritual intrusions with rituals.</p>
     <div class="card-actions">
   <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
      </div>
    </div>
  </div>

  <!-- 11. Court Problem -->
  <div class="service-card">
    <img src="images/mse10.jpg" alt="Court Problem">
    <div class="card-content">
      <h4>Court Problem</h4>
      <p>Get astrological support for favorable outcomes in legal issues.</p>
      <div class="card-actions">
    <a href="tel:+1 647-523-1499" class="astro-btn call">📞 Call</a>
          <a href="https://wa.me/16475231499" class="astro-btn whatsapp">💬 WhatsApp</a>
      </div>
    </div>
  </div>

</div>


        <!-- Add remaining service cards here the same way -->

      </div>
    </div>
  </div>

  <div class="nav-buttons">
    <button onclick="slideCards(-1)">← Prev</button>
    <button onclick="slideCards(1)">Next →</button>
  </div>
</section>

<script>
  let currentSlide = 0;
  function slideCards(dir) {
    const wrapper = document.getElementById("cardWrapper");
    const cards = wrapper.children;
    const cardWidth = cards[0].offsetWidth;
    const totalSlides = cards.length;

    currentSlide += dir;
    if (currentSlide < 0) currentSlide = 0;
    if (currentSlide > totalSlides - 1) currentSlide = totalSlides - 1;

    wrapper.style.transform = `translateX(-${currentSlide * cardWidth}px)`;
  }
</script>

</body>
</html>
