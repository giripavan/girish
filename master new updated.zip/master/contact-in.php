<form class="hm_contact_form astro-margin-top" id="contactus" name="contact-us-form" action="form.php" method="post">
								<!--<form class="hm_contact_form astro-margin-top" id="contactus" name="contact-us-form" action="contact-action.php" method="post">-->
								<h2 class="title1 light_color"><i class="ico-envelope3"></i>Book <strong>appointment</strong></h2>
								<div id="error_message"></div>
								<div class="form_row clearfix">
								  <input class="form_fill_fields hm_input_text" type="text" name="first_name" id="name" placeholder="Name" required="required">
								</div>
								<div class="form_row clearfix">
								  <input class="form_fill_fields hm_input_text" type="text" name="email" id="email" placeholder="Email" required="required">
								</div>
								<div class="form_row clearfix">
								  <input class="form_fill_fields hm_input_text" type="text" name="contact" placeholder="Phone" id="phone" required="required">
								</div>
							
								
								<div class="form_row clearfix">
								  <input class="form_fill_fields hm_input_text" type="time" name="time" id="time" placeholder="select date" required="required">
								</div>
								
								<div class="form_row clearfix">
								  <input class="form_fill_fields hm_input_text" type="text" name="place" id="place" placeholder="Enter your place" required="required">
								</div>
								<div class="form_row clearfix">
								  <textarea class="form_fill_fields hm_textarea" name="comments" placeholder="Message" id="message" rows="3" cols="3" required="required"></textarea>
								</div>
								<div class="form_row clearfix">
								  <button type="submit" class="send_button full_button" name="submit" value="submit"><i class="ico-check3"></i><span>Send  Message</span> </button>
								</div>
								<div class="form_row clearfix">
								  <div id="form-messages">  </div>
								</div>
								<div class="form_loader"></div>
							</form>