<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dark Arts Master</title>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&display=swap" rel="stylesheet">
    <style>
        /* === Cosmic Theme === */
        :root {
          --void: #0a0a12;
          --eldritch-purple: #5e2d8c;
          --mystic-gold: #d4af37;
          --spirit-blue: #4d8bff;
          --blood-crimson: #8a0303;
          --ghost-white: rgba(255,255,255,0.9);
        }

        /* === Background Magic === */
        .mystic-background {
          background: 
            radial-gradient(ellipse at 30% 40%, var(--eldritch-purple) 0%, transparent 60%),
            radial-gradient(ellipse at 70% 60%, var(--blood-crimson) 0%, transparent 60%),
            linear-gradient(var(--void), #000);
          min-height: 100vh;
          display: flex;
          justify-content: center;
          align-items: center;
          position: relative;
          overflow: hidden;
          font-family: 'Cinzel', serif;
          padding: 20px;
          box-sizing: border-box;
        }

        .star-particles {
          position: absolute;
          width: 100%;
          height: 100%;
          background: 
            url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><circle cx="50" cy="50" r="0.5" fill="white" opacity="0.5"/></svg>') repeat;
          opacity: 0.3;
        }

        .energy-sphere {
          position: absolute;
          width: 400px;
          height: 400px;
          background: radial-gradient(circle, var(--spirit-blue), transparent 70%);
          filter: blur(60px);
          opacity: 0.1;
          top: 20%;
          right: 10%;
        }

        .ancient-symbol {
          position: absolute;
          font-size: 18rem;
          opacity: 0.03;
          bottom: -5%;
          left: 5%;
          font-weight: 700;
          letter-spacing: 20px;
          transform: rotate(-15deg);
          z-index: 0;
        }

        /* === Portal Structure === */
        .main-container {
          display: flex;
          max-width: 1100px;
          width: 100%;
          padding: 2rem;
          gap: 2rem;
          align-items: center;
          position: relative;
          z-index: 2;
          margin-top: 80px; /* Added this line to create gap below title */
        }

        /* === Left Side Image === */
        .portrait-wrapper {
          flex: 0 0 auto;
          position: relative;
          perspective: 1000px;
        }

        .portrait-frame {
          width: 500px;
          height: 600px;
          border: 3px solid rgba(212, 175, 55, 0.3);
          border-radius: 10px;
          overflow: hidden;
          transform-style: preserve-3d;
          transition: all 0.5s ease;
          box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }

        .portrait-image {
          width: 100%;
          height: 100%;
          object-fit: cover;
          filter: sepia(0.3) contrast(1.1);
          transition: all 0.5s ease;
        }

        .portrait-halo {
          position: absolute;
          width: calc(100% + 20px);
          height: calc(100% + 20px);
          top: -10px;
          left: -10px;
          border: 2px solid var(--mystic-gold);
          border-radius: 15px;
          opacity: 0.3;
          pointer-events: none;
        }

        .portrait-wrapper:hover .portrait-frame {
          transform: rotateY(-10deg) translateY(-10px);
          border-color: var(--mystic-gold);
        }

        .portrait-wrapper:hover .portrait-image {
          filter: sepia(0) contrast(1.2);
        }

        /* === 3D Sigil === */
        .symbol-holder {
          flex: 0 0 150px;
          height: 150px;
          position: relative;
          perspective: 1000px;
        }

        .rotating-symbol {
          width: 100%;
          height: 100%;
          font-size: 5rem;
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--mystic-gold);
          transform-style: preserve-3d;
          animation: symbol-spin 20s infinite linear;
          text-shadow: 0 0 20px var(--mystic-gold);
        }

        .symbol-radiance {
          position: absolute;
          width: 100%;
          height: 100%;
          border-radius: 50%;
          background: radial-gradient(circle, var(--mystic-gold), transparent 70%);
          filter: blur(20px);
          opacity: 0.2;
          top: 0;
        }

        /* === Occult Card === */
        .mystic-panel {
          flex: 1;
          min-width: 0;
          background: rgba(10, 10, 18, 0.7);
          backdrop-filter: blur(12px);
          border-radius: 20px;
          padding: 20px;
          position: relative;
          box-shadow: 0 0 40px rgba(94, 45, 140, 0.3);
          width: 500px;
        }

        .panel-outline {
          position: absolute;
          inset: 0;
          border-radius: 20px;
          padding: 2px;
          background: linear-gradient(135deg, var(--mystic-gold), var(--spirit-blue), var(--blood-crimson));
          -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          -webkit-mask-composite: xor;
          mask-composite: exclude;
        }

        .outline-tracer {
          position: absolute;
          width: 50%;
          height: 2px;
          background: var(--mystic-gold);
          top: 0;
          left: 0;
          animation: tracer-move 6s infinite linear;
        }

        .panel-content {
          background: rgba(10, 10, 18, 0.9);
          border-radius: 18px;
          padding: 2rem;
          height: 100%;
          position: relative;
          overflow: hidden;
        }

        /* === Profile Header === */
        .profile-heading {
          margin-bottom: 2rem;
          position: relative;
        }

        .title-badge {
          background: linear-gradient(90deg, transparent, var(--blood-crimson), transparent);
          background-size: 200% 100%;
          color: var(--ghost-white);
          padding: 0.5rem 1.5rem;
          display: inline-block;
          font-size: 0.8rem;
          letter-spacing: 3px;
          text-transform: uppercase;
          margin-bottom: 1rem;
          position: relative;
          animation: badge-glow 3s infinite linear;
        }

        .shimmer-title {
          font-size: 2.8rem;
          font-weight: 700;
          color: transparent;
          background: linear-gradient(135deg, var(--mystic-gold), var(--ghost-white));
          -webkit-background-clip: text;
          background-clip: text;
          margin: 0;
          line-height: 1;
          display: flex;
          flex-wrap: wrap;
        }

        .title-letter {
          display: inline-block;
          transition: all 0.3s ease;
          text-shadow: 0 0 10px rgba(212, 175, 55, 0.3);
        }

        .title-letter:hover {
          transform: translateY(-5px);
          color: var(--mystic-gold);
        }

        .profile-subtitle {
          font-size: 1.9rem;
          color: var(--ghost-white);
          margin: 0.5rem 0 0;
          font-weight: 400;
          letter-spacing: 2px;
        }

        /* === Avatar === */
        .profile-thumbnail {
          width: 120px;
          height: 160px;
          position: absolute;
          top: 2rem;
          right: 2rem;
          perspective: 1000px;
        }

        .thumbnail-frame {
          width: 100%;
          height: 100%;
          border: 3px solid rgba(212, 175, 55, 0.3);
          border-radius: 10px;
          overflow: hidden;
          transform-style: preserve-3d;
          transition: all 0.5s ease;
          box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }

        .thumbnail-image {
          width: 100%;
          height: 100%;
          object-fit: cover;
          filter: sepia(0.3) contrast(1.1);
          transition: all 0.5s ease;
        }

        .thumbnail-halo {
          position: absolute;
          width: calc(100% + 20px);
          height: calc(100% + 20px);
          top: -10px;
          left: -10px;
          border: 2px solid var(--mystic-gold);
          border-radius: 15px;
          opacity: 0.3;
          pointer-events: none;
        }

        .profile-thumbnail:hover .thumbnail-frame {
          transform: rotateY(10deg) translateY(-10px);
          border-color: var(--mystic-gold);
        }

        .profile-thumbnail:hover .thumbnail-image {
          filter: sepia(0) contrast(1.2);
        }

        /* === Divider === */
        .section-divider {
          margin: 1.5rem 0;
          display: flex;
          justify-content: center;
        }

        .divider-line {
          width: 60px;
          height: 2px;
          background: linear-gradient(90deg, transparent, var(--mystic-gold), transparent);
          position: relative;
        }

        .divider-line::before {
          content: '';
          position: absolute;
          width: 10px;
          height: 10px;
          background: var(--mystic-gold);
          border-radius: 50%;
          top: -4px;
          left: 50%;
          transform: translateX(-50%);
        }

        /* === Experience Badge === */
        .experience-display {
          display: inline-flex;
          flex-direction: column;
          align-items: center;
          margin: 1.5rem 0;
          position: relative;
        }

        .display-base {
          width: 80px;
          height: 8px;
          background: linear-gradient(90deg, var(--mystic-gold), var(--spirit-blue));
          border-radius: 5px;
        }

        .years-display {
          background: rgba(212, 175, 55, 0.1);
          color: var(--mystic-gold);
          padding: 0.8rem 1.5rem;
          font-size: 1.4rem;
          font-weight: 700;
          border: 1px solid var(--mystic-gold);
          border-radius: 5px;
          transform: translateY(-5px);
          position: relative;
        }

        .display-radiance {
          position: absolute;
          width: 100%;
          height: 100%;
          background: radial-gradient(ellipse at center, var(--mystic-gold), transparent 70%);
          opacity: 0.1;
          top: 0;
          left: 0;
          z-index: -1;
        }

        /* === Services === */
        .service-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1.2rem;
          margin: 1.5rem 0;
        }

        .service-item {
          background: rgba(77, 139, 255, 0.05);
          border: 1px solid rgba(77, 139, 255, 0.1);
          border-radius: 10px;
          padding: 1.2rem;
          position: relative;
          overflow: hidden;
          transition: all 0.3s ease;
        }

        .service-item:hover {
          background: rgba(77, 139, 255, 0.1);
          transform: translateY(-5px);
          box-shadow: 0 10px 20px rgba(77, 139, 255, 0.1);
          border-color: var(--spirit-blue);
        }

        .service-icon {
          font-size: 1.3rem;
          color: var(--mystic-gold);
          margin-bottom: 0.6rem;
          display: inline-block;
        }

        .service-item h3 {
          font-size: 1.9rem;
          color: yellow;
          margin: 0 0 0.6rem;
        }

        .service-item p {
          font-size: 1.5rem;
          color: white;
          margin: 0;
          line-height: 1.5;
        }

        .service-effect {
          position: absolute;
          width: 100%;
          height: 100%;
          top: 0;
          left: 0;
          background: radial-gradient(circle at center, transparent 90%, var(--mystic-gold) 100%);
          opacity: 0;
          transition: opacity 0.3s ease;
          pointer-events: none;
        }

        .service-item:hover .service-effect {
          opacity: 0.1;
        }

        /* === Contact Portal === */
        .contact-button {
          background: linear-gradient(135deg, rgba(212, 175, 55, 0.1), rgba(77, 139, 255, 0.1));
          border: 1px solid var(--mystic-gold);
          border-radius: 50px;
          padding: 1px;
          cursor: pointer;
          transition: all 0.3s ease;
          max-width: 300px;
          margin-top: 1.5rem;
          position: relative;
          overflow: hidden;
        }

        .button-ring {
          position: absolute;
          width: 100%;
          height: 100%;
          border: 1px solid transparent;
          border-radius: 50px;
          top: 0;
          left: 0;
        }

        .button-core {
          background: rgba(10, 10, 18, 0.8);
          padding: 1rem 1.2rem;
          border-radius: 50px;
          display: flex;
          flex-direction: column;
          align-items: center;
        }

        .call-text {
          font-size: 1.75rem;
          color: var(--mystic-gold);
          letter-spacing: 2px;
          text-transform: uppercase;
          margin-bottom: 0.3rem;
        }

        .phone-number {
          font-size: 3.1rem;
          font-weight: 700;
          color: var(--ghost-white);
        }

        .contact-button:hover {
          box-shadow: 0 0 30px rgba(212, 175, 55, 0.3);
          transform: translateY(-3px);
        }

        /* === Animations === */
        @keyframes symbol-spin {
          100% { transform: rotateY(360deg); }
        }

        @keyframes tracer-move {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(200%); }
        }

        @keyframes badge-glow {
          0% { background-position: 200% 50%; }
          100% { background-position: -100% 50%; }
        }

        /* === Responsive Design === */
        @media (max-width: 992px) {
          .main-container {
            flex-direction: column;
            gap: 2rem;
          }
          
          .symbol-holder {
            display: none;
          }
          
          .portrait-wrapper {
            margin-bottom: 1rem;
          }
          
          .shimmer-title {
            font-size: 2.3rem;
          }
          
          .mystic-panel {
            width: 100%;
          }
        }

        @media (max-width: 768px) {
          .profile-thumbnail {
            position: relative;
            top: auto;
            right: auto;
            margin: 1.9rem auto;
          }
          
          .shimmer-title {
            font-size: 3rem;
          }
          .title-letter {
            font-size: 2.1rem;
          }
          
          .profile-subtitle {
            font-size: 1.4rem;
          }
          
          .portrait-frame {
            width: 350px;
            height: 500px;
          }
        }

        @media (max-width: 480px) {
          .main-container {
            padding: 1rem;
          }
          
          
          
          .shimmer-title {
            font-size: 1.6rem;
          }
          
          .years-display {
            font-size: 1.1rem;
          }
          
          .phone-number {
            font-size: 0.95rem;
          }
          
          .service-grid {
            grid-template-columns: 1fr;
          }
        }
    </style>
</head>
<body>
    <section class="mystic-background">
        <!-- Cosmic Background Elements -->
        <div class="star-particles"></div>
        <div class="energy-sphere"></div>
        
        <div class="main-container">
            <!-- Left Side Image -->
            <div class="portrait-wrapper">
                <div class="portrait-frame">
                    <img src="images/ab.jpg" alt="Mystical Portrait" class="portrait-image">
                </div>
                <div class="portrait-halo"></div>
            </div>
            
            <!-- Main Profile Card -->
            <div class="mystic-panel">
                <!-- Animated Border -->
                <div class="panel-outline">
                    <div class="outline-tracer"></div>
                </div>
                
                <div class="panel-content">
                    <!-- Profile Header with Floating Effect -->
                    <div class="profile-heading">
                        
                        <h1 class="shimmer-title">
                            <span class="title-letter">MASTER</span>
                        </h1>
                        <h2 class="profile-subtitle">Remove Black Magic  Curses</h2>
                    </div>
                    
                    <!-- Floating Profile Image -->
                    <div class="profile-thumbnail">
                        <div class="thumbnail-frame">
                            <img src="images/b.jpg" alt="Psychic Venkoji Rav" class="thumbnail-image">
                        </div>
                        <div class="thumbnail-halo"></div>
                    </div>
                    
                    <!-- Animated Divider -->
                    <div class="section-divider">
                        <div class="divider-line"></div>
                    </div>
                    
                    <!-- Mystical Experience Badge -->
                    <div class="experience-display">
                        <div class="display-base"></div>
                        <div class="years-display">25+ Years</div>
                        <div class="display-radiance"></div>
                    </div>
                    
                    <!-- Services with Hover Magic -->
                    <div class="service-grid">
                        <div class="service-item">
                            <div class="service-icon">✧</div>
                            <h3>Black Magic Purge</h3>
                            <p>Complete eradication of dark spells and negative attachments</p>
                            <div class="service-effect"></div>
                        </div>
                        
                        <div class="service-item">
                            <div class="service-icon">✧</div>
                            <h3>Soul Protection</h3>
                            <p>Impenetrable spiritual armor against future attacks</p>
                            <div class="service-effect"></div>
                        </div>
                    </div>
                    
                    <!-- Animated Contact Portal -->
                    <div class="contact-button" onclick="window.location.href='tel:+16785307311'">
                        <div class="button-ring"></div>
                        <div class="button-core">
                            <span class="call-text">CALL NOW</span>
                            <span class="phone-number">+1 647-523-1499</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
</html>