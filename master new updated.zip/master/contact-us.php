<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact Section</title>
  <?php include('header.php'); ?>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
  <style>
    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background-color: #f7f3ec;
      color: #2a2a2a;
    }

    .contact-section {
      padding: 0;
    }

    .map-embed iframe {
      width: 100%;
      height: 300px;
      border: none;
    }

    .contact-info-boxes {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      background-color: #f7f3ec;
      text-align: center;
      padding: 40px 20px;
    }

    .contact-box {
      flex: 1 1 250px;
      margin: 20px;
    }

    .contact-box i {
      font-size: 28px;
      color: #000;
      margin-bottom: 10px;
    }

    .contact-box h4 {
      margin: 10px 0 5px;
      font-weight: 600;
    }

    .contact-box p {
      margin: 0;
      color: #555;
      font-size: 14px;
    }

    .message-section {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: center;
      padding: 60px 20px;
      background-image: url('images/contact-ab.jpg');
    }

    .palm-image {
      flex: 1 1 300px;
      text-align: center;
    }

    .palm-image img {
      max-width: 420px;
      height:500px;
      opacity: 0.8;
    }

    .message-form {
      flex: 1 1 350px;
      padding: 20px 30px;
    }

    .message-form h3 {
      font-family: 'Playfair Display', serif;
      font-size: 24px;
      margin-bottom: 10px;
    }

    .message-form p {
      color: #555;
      font-size: 14px;
      margin-bottom: 20px;
    }

    .message-form input,
    .message-form textarea {
      width: 100%;
      padding: 12px 15px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 4px;
      font-size: 14px;
      font-family: 'Poppins', sans-serif;
    }

    .message-form button {
      background-color: #a6844b;
      color: #fff;
      border: none;
      padding: 12px 30px;
      font-size: 14px;
      font-weight: 600;
      border-radius: 4px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .message-form button:hover {
      background-color: #8c6b3c;
    }

    @media (max-width: 768px) {
      .message-section {
        flex-direction: column;
        text-align: center;
      }

      .message-form {
        padding: 20px 10px;
      }

      .palm-image img {
        height: 300px;
        max-width: 220px;
      }
    }
  </style>
</head>
<body>

<section class="contact-section">

  <!-- Map -->
 <div class="map-embed">
  <iframe 
    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2886.6974895325253!2d-79.18198292412998!3d43.77011164406336!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d4d3f49645c155%3A0xf6a5a5e5f91a0ef2!2s4510%20Kingston%20Rd%2C%20Scarborough%2C%20ON%20M1E%202N8%2C%20Canada!5e0!3m2!1sen!2sin!4v1718886789011!5m2!1sen!2sin" 
    width="100%" 
    height="300" 
    style="border:0;" 
    allowfullscreen="" 
    loading="lazy" 
    referrerpolicy="no-referrer-when-downgrade">
  </iframe>
</div>


  <!-- Info Boxes -->
  <div class="contact-info-boxes">
   
    <div class="contact-box">
      <i class="fas fa-phone-alt"></i>
      <h4>Contact Info</h4>
      <p>+1 647-523-1499</p>
      <p>astromahakali6999@gmail.com</p>
    </div>
    <div class="contact-box">
      <i class="fas fa-clock"></i>
      <h4>Working Hours</h4>
      <p>Open: 8:00AM – Close: 22:00PM</p>
    </div>
  </div>

  <!-- Message Form Section -->
  <div class="message-section">
    <!-- Left Palm Image -->
    <div class="palm-image">
      <img src="images/contact.png" alt="Palmistry" />
    </div>

    <!-- Right Form -->
    <div class="message-form">
      <h3>Send A Message</h3>
       <p>If you have questions, need guidance, or want to book an appointment for astrology services, we’re here to help. Reach out to us for personal consultations, spiritual solutions, or to learn more about how we can assist with your love life, career, health, or family matters. You can contact us by phone, WhatsApp, email, or by filling out the form below. We respond promptly and ensure your information is kept confidential. Let us guide you toward peace, success, and clarity.</p>
      <form>
        <input type="text" placeholder="Name" required />
        <input type="email" placeholder="Email" required />
        <textarea placeholder="Message" required></textarea>
        <button type="submit">Contact Us</button>
      </form>
    </div>
  </div>

</section>

</body>
</html>


	<?php
	include('footer.php');
	?>
	
	
	