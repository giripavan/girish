<!DOCTYPE HTML>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Footer Example</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <!-- Background Image Section -->
 

  <!-- Your full footer content -->
  <div id="footer">
    <div class="container">
      <div class="row">
        <div class="footer-box-section">
          <div class="col-md-3 col-sm-12 footer-box">
            <h6>about us</h6>
            <p style="color:white;">
              However, all those who can not tolerate your highness and bravery or for some other reasons...
            </p>
          </div>
          <div class="col-md-3 col-sm-12 footer-box">
            <h6>Psychic Services</h6>
               <ul >
                            <li><a href="palm reading.php">Palm reading</a></li>
                            <li><a href="get-love-back.php">Get Love Back</a></li>
                            <li><a href="marriage-problem.php">Marriage problem</a></li>
                            <li><a href="black-magic-removal.php">Black magic Removal</a></li>
                            <li><a href="spiritual-healing.php">Spiritual healing</a></li>
                            <li><a href="negative-energy.php">Negitive energy</a></li>
                            <li><a href="tarot-reading.php">Tarot reading</a></li>

                        </ul>
          </div>
          <div class="col-md-3 col-sm-12 footer-box">
            <h6>Quick Links</h6>
            <ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="about-us.php">About Psychic</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
          </div>
          <div class="col-md-3 col-sm-12 footer-box">
            <h6>Contact Us</h6>
           
            <div class="foot-contact">
              <img src="images/footer-email-icon.png" alt="email-address">
              <p><span>Email Support:</span> <?php echo $email ?></p>
            </div>
            <div class="foot-contact">
              <img src="images/footer-phone-icons.png" alt="phone address">
              <p><span>Phone No:</span>
                <a href="tel:<?php echo $linkphone ?>" style="color:#ffffff"><?php echo $phone ?></a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <!-- Scripts -->
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jssor.slider-27.5.0.min.js" type="text/javascript"></script>
  <script type="text/javascript">jssor_1_slider_init();</script>
  <script src="js/bootsnav.js"></script>
  <script>
    $(document).ready(function() {
      $("#news-slider").owlCarousel({
        items: 3,
        itemsDesktop:[1199,2],
        itemsDesktopSmall:[980,2],
        itemsMobile:[600,1],
        pagination:false,
        navigationText:false,
        autoPlay:true
      });
    });
  </script>
  <script>
    $(document).ready(function(){
      $("#testimonial-slider").owlCarousel({
        items:3,
        itemsDesktop:[1000,1],
        itemsDesktopSmall:[979,1],
        itemsTablet:[768,1],
        pagination:false,
        navigation:true,
        navigationText:["",""],
        autoPlay:true
      });
    });
  </script>
</body>
</html>
