<style>
  body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background-color: #0c0e2c;
    color: #fff;
  }

  .about-section {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 80px 10px;
    background-color: #0c0e2c;
    gap: 100px;
    flex-wrap: wrap;
  }

  .image-stack {
    position: relative;
    width: 400px;
    height: 500px;
  }

  .diamond {
    position: absolute;
    width: 300px;
    height: 300px;
    overflow: hidden;
    transform: rotate(45deg);
    border: 4px solid #130b2b;
    background-color: #000;
  }

  .diamond img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .diamond.main {
    top: 0;
    left: 50px;
    z-index: 2;
  }

  .diamond.second {
    width: 200px;
    height: 200px;
    bottom: 50px;
    left: -40px;
    filter: grayscale(100%);
    opacity: 1.2;
    z-index: 1;
  }

  .diamond.third {
    width: 200px;
    height: 200px;
    bottom: 50px;
    right: -40px;
    filter: grayscale(100%);
    opacity: 1.2;
    z-index: 1;
  }

  .about-content {
    max-width: 550px;
  }

  .about-content h1 {
    color: White ;
    font-size: 36px;
    letter-spacing: 2px;
    position: relative;
    display: inline-block;
    margin-bottom: 10px;
  }

  .about-content h4::after {
    content: '';
    display: inline-block;
    width: 60px;
    height: 2px;
    background-color: #fff;
    margin-left: 10px;
    vertical-align: middle;
  }

  .about-content h2 {
    font-size: 48px;
    color: #c94c7b;
    margin: 0;
    margin-bottom: 25px;
  }

  .about-content p {
    color: white;
    line-height: 1.8;
    font-size: 15px;
    margin-bottom: 25px;
  }

  .about-content .experience {
    font-size: 50px;
    font-weight: 700;
    color: #3b9df5;
  }

  .about-content .years {
    font-size: 22px;
    color: #999;
    display: inline-block;
    margin-left: 10px;
  }

  .about-content .years strong {
    color: #fff;
  }

  .about-content .btn {
    margin-top: 30px;
    padding: 12px 30px;
    border: 2px solid #c94c7b;
    background: transparent;
    color: #fff;
    border-radius: 50px;
    font-weight: 500;
    cursor: pointer;
    text-decoration: none;
    transition: 0.3s;
  }

  .about-content .btn:hover {
    background-color: #c94c7b;
  }

  /* Responsive styles */
  @media (max-width: 768px) {
    .about-section {
      flex-direction: column;
      gap: 40px;
      padding: 50px 20px;
    }

    .image-stack {
      width: 250px;
      height: 320px;
    }

    .diamond.main {
      width: 200px;
      height: 200px;
      left: 25px;
    }

    .diamond.second,
    .diamond.third {
      width: 130px;
      height: 130px;
      bottom: 20px;
    }

    .diamond.second {
      left: -20px;
    }

    .diamond.third {
      right: -20px;
    }

    .about-content h2 {
      font-size: 32px;
    }

    .about-content .experience {
      font-size: 40px;
    }

    .about-content .years {
      font-size: 18px;
    }
  }
</style>

<section class="about-section">
  <div class="image-stack">
    <div class="diamond second">
      <img src="images/b2.jpg" alt="Woman Background 1">
    </div>
    <div class="diamond third">
      <img src="images/b2.jpg" alt="Woman Background 2">
    </div>
    <div class="diamond main">
      <img src="images/b5.jpg" alt="Main Astrologer">
    </div>
  </div>

  <div class="about-content">
    <h1>About  <strong style="color:yellow;">MASTER</strong></h1>
    <h2>We Are Welcome</h2>
    <p>We have the World Famous Astrologers on the Best Astrology Website in India, practising both Indian Astrology and Western Astrology for astrology today.</p>
    <p>They will provide the best free horoscope astrology to you by analysing your birth chart and your astrology sign.</p>
    <div>
      <span class="experience">25</span>
      <span class="years">Years Of <strong>Experience</strong></span>
    </div>
    <a href="contact-us.php" class="btn">Book Reading Now</a>
  </div>
</section>

<?php include('black.php');?>