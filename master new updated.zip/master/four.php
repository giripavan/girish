<section style="background: linear-gradient(to right, #0b061f, #1b1240); padding: 60px 0; font-family: 'Georgia', serif; color: white;"> 
  <style>
    @media (max-width: 768px) {
      .right-content-mobile-gap {
        margin-top: 20px; /* Adjust the space here */
      }
    }
  </style>

  <div style="display: flex; flex-wrap: wrap; max-width: 1200px; margin: auto; align-items: center;">
    
    <!-- Left Side: Image -->
    <div style="flex: 1 1 500px; position: relative; min-height: 400px;">
      <img src="images/bbss1.jpg" alt="Astrology Setup" style="width: 100%; height: 400px; object-fit: cover; border-radius: 8px;">
    </div>

    <!-- Right Side: Content -->
    <div class="right-content-mobile-gap" style="flex: 1 1 500px; padding: 30px;">
     <h5 style="color: rgb(227, 66, 112); font-size: 36px; line-height: 1.5;">
  Why Choose <strong style="color: yellow;">MASTER</strong>
</h5>

     
      <p style="font-size: 20px; color: White; margin: 20px 0;">
        Master is a renowned Vedic astrologer with over 25 years of experience in decoding the language of the stars.
        His profound wisdom and intuitive guidance have transformed lives across the globe through accurate predictions and divine counsel.
      </p>

      <!-- Progress Bars with Counters -->
      <div style="margin: 20px 0;">
        <div style="margin-bottom: 16px;">
          <div style="display: flex; justify-content: space-between;">
            <strong style="color:yellow;">Accurate Horoscopes</strong>
            <span class="counter" data-target="90">0%</span>
          </div>
          <div style="background: #302b4f; height: 4px; width: 100%; margin-top: 4px;">
            <div style="background: #b0a4f3; width: 90%; height: 100%;"></div>
          </div>
        </div>
        <div style="margin-bottom: 16px;">
          <div style="display: flex; justify-content: space-between;">
            <strong style="color:yellow;">Astrology Reading</strong>
            <span class="counter" data-target="95">0%</span>
          </div>
          <div style="background: #302b4f; height: 4px; width: 100%; margin-top: 4px;">
            <div style="background: #b0a4f3; width: 95%; height: 100%;"></div>
          </div>
        </div>
        <div style="margin-bottom: 16px;">
        <div style="display: flex; justify-content: space-between;">
            <strong style="color:yellow;">Relationship Reading</strong>
            <span class="counter" data-target="100">0%</span>
        </div>
        <div style="background: #302b4f; height: 4px; width: 100%; margin-top: 4px;">
            <div style="background: #b0a4f3; width: 100%; height: 100%;"></div>
        </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- JavaScript for Number Counting -->
<script>
  const counters = document.querySelectorAll('.counter');

  counters.forEach(counter => {
    const target = +counter.getAttribute('data-target');
    let count = 0;

    const updateCounter = () => {
      if (count < target) {
        count++;
        counter.innerText = count + '%';
        setTimeout(updateCounter, 25); // speed
      } else {
        counter.innerText = target + '%';
      }
    };

    updateCounter();
  });
</script>
