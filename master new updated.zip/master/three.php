<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Our Working Process - Astrology Master</title>
  <link href="https://fonts.googleapis.com/css2?family=Marcellus&family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background: #0e0a2d;
      color: #fff;
    }

    .process-section {
      padding: 80px 20px;
      text-align: center;
      background: radial-gradient(circle at top, #1a103d 0%, #0e0a2d 100%);
    }

    .process-section h4 {
      color: #c49fff;
      font-size: 16px;
      margin-bottom: 10px;
      letter-spacing: 1px;
    }

    .process-section h2 {
      font-family: 'Marcellus', serif;
      font-size: 40px;
      margin: 10px 0 20px;
      color: #ffffff;
    }

    .process-section p {
      color: #ccc;
      font-size: 14px;
      max-width: 700px;
      margin: 0 auto 50px;
    }

    .steps-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 30px;
      padding: 0 20px;
    }

    .step-card {
      background: #1b133a;
      border-radius: 14px;
      padding: 30px 20px;
      position: relative;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    }

    .step-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 6px 25px rgba(0,0,0,0.4);
    }

    .step-number {
      position: absolute;
      top: -15px;
      left: 20px;
      background: linear-gradient(45deg, #ae75ff, #6b21a8);
      color: #fff;
      font-weight: bold;
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 13px;
    }

    .step-icon {
      font-size: 42px;
      margin-bottom: 20px;
      color: #d7b3ff;
    }

    .step-title {
      font-family: 'Marcellus', serif;
      font-size: 20px;
      margin-bottom: 10px;
      color: #fff;
    }

    .step-desc {
      font-size: 14px;
      color: #bdbdbd;
    }

    /* Astrology Icon Placeholder */
    .icon-horoscope::before { content: "🔮"; }
    .icon-appointment::before { content: "📆"; }
    .icon-remedy::before { content: "🪔"; }
    .icon-results::before { content: "🌟"; }

    @media (max-width: 600px) {
      .step-card {
        padding: 25px 15px;
      }
    }
  </style>
</head>
<body>

  <section class="process-section">
    <h1 style="color:white;">How Astrology <strong style="color: yellow;">Master</strong> Helps</h1>
    <h2>Our Working Process</h2>
    <p>We follow a precise and spiritual process to understand your stars, guide you through your challenges, and provide divine solutions for a peaceful life.</p>

    <div class="steps-container">
      <div class="step-card">
        <div class="step-number">01</div>
        <div class="step-icon icon-horoscope"></div>
        <div class="step-title">Share Birth Details</div>
        <div class="step-desc">Provide your date, time, and place of birth to generate an accurate horoscope.</div>
      </div>

      <div class="step-card">
        <div class="step-number">02</div>
        <div class="step-icon icon-appointment"></div>
        <div class="step-title">Get Consultation</div>
        <div class="step-desc">Book a session with our astrology master to discuss your concerns in detail.</div>
      </div>

      <div class="step-card">
        <div class="step-number">03</div>
        <div class="step-icon icon-remedy"></div>
        <div class="step-title">Receive Remedies</div>
        <div class="step-desc">Get powerful pooja, mantra, and gemstone remedies tailored to your chart.</div>
      </div>

      <div class="step-card">
        <div class="step-number">04</div>
        <div class="step-icon icon-results"></div>
        <div class="step-title">Transform Your Life</div>
        <div class="step-desc">Experience peace, success, and harmony with divine guidance and blessings.</div>
      </div>
    </div>
  </section>

</body>
</html>
