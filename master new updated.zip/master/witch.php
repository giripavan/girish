<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Witchcraft Removal</title>
  <?php include('header.php'); ?>
</head>
<body>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>

<style>
  body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #1e130c, #9a031e);
    color: white;
  }

  .section-wrapper {
    max-width: 1200px;
    margin: auto;
    padding: 80px 20px;
    display: flex;
    flex-wrap: wrap;
    gap: 40px;
  }

  .left-image {
    flex: 1 1 400px;
  }

  .left-image img {
    width: 100%;
    height: 100%;
    max-height: 500px;
    object-fit: cover;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  }

  .right-content {
    flex: 1 1 600px;
  }

  .right-content h1 {
    font-size: 4.5rem;
    color: #ff6666;
    margin-bottom: 20px;
  }

  .right-content p {
    font-size: 2.1rem;
    line-height: 1.7;
    color: #ffe3e3;
    margin-bottom: 30px;
  }

  .card-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
  }

  .info-card {
    flex: 1 1 260px;
    background: rgba(255, 255, 255, 0.07);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 15px;
    padding: 20px;
    cursor: pointer;
    transition: 0.3s ease;
    display: flex;
    flex-direction: column;
  }

  .info-card:hover {
    background: rgba(255, 255, 255, 0.15);
  }

  .info-card-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 10px;
  }

  .info-card i {
    font-size: 1.8rem;
    color: #ff6666;
  }

   .info-card h3 {
    font-size: 1.9rem;
    color: yellow;
    margin: 0;
  }

  .info-card .card-detail {
    margin-top: 10px;
    font-size: 1.95rem;
    line-height: 1.5;
    color: white;
    display: none;
  }

  .info-card.active .card-detail {
    display: block;
    animation: fadeIn 0.4s ease;
  }

  .contact-btn {
    margin-top: 40px;
    display: inline-block;
    background: linear-gradient(135deg, #ff4e50, #f9d423);
    color: black;
    padding: 14px 30px;
    border-radius: 40px;
    font-weight: bold;
    font-size: 1rem;
    text-decoration: none;
    transition: background 0.3s ease;
  }

  .contact-btn:hover {
    background: linear-gradient(135deg, #d72638, #ff8c42);
    color: #000;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @media (max-width: 768px) {
    .section-wrapper {
      flex-direction: column;
    }

    .right-content {
      order: 1;
    }

    .left-image {
      order: 2;
      margin-top: 30px;
    }

    .card-grid {
      order: 3;
    }

    .right-content h1 {
      font-size: 2.5rem;
    }

    .info-card {
      flex: 1 1 100%;
    }
  }
</style>

<section class="section-wrapper">

  <!-- Left Image -->
  <div class="left-image">
    <img src="./images/msse9.jpg" alt="Witchcraft Removal" />
  </div>

  <!-- Right Content -->
  <div class="right-content">
    <h1><i class="fas fa-magic"></i> Witchcraft Removal</h1>
    <p>
      Are you facing sudden fear, mental disturbance, or physical illness without a cause? Witchcraft and dark rituals may be draining your energy and peace of mind.
    </p>
    <p>
      Our spiritual remedies remove black spells and protect your aura using powerful tantric rituals, mantras, and divine blessings.
    </p>

    <!-- Cards -->
    <div class="card-grid">
      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-user-injured"></i>
          <h3>Signs of Witchcraft</h3>
        </div>
        <div class="card-detail">
          Unexplained health issues, nightmares, or anxiety may be signs of negative rituals performed against you.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-tools"></i>
          <h3>Tantric Healing</h3>
        </div>
        <div class="card-detail">
          Ancient tantric methods are used to neutralize spells, curses, and hexes causing harm to your spirit and body.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-shield-virus"></i>
          <h3>Protection Rituals</h3>
        </div>
        <div class="card-detail">
          We create protective shields using yantras, homas, and divine energy invocations for long-term safety from future attacks.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-fire-alt"></i>
          <h3>Poojas to Break Spells</h3>
        </div>
        <div class="card-detail">
          Perform rituals like Baglamukhi Homa, Kali Pooja, and Sudarshan Yagna to burn the roots of black magic and regain balance.
        </div>
      </div>
    </div>

    <!-- Contact Button -->
    <a href="contact-us.php" class="contact-btn">Remove Witchcraft Now</a>
  </div>
</section>

<script>
  function toggleCard(card) {
    card.classList.toggle('active');
  }
</script>

<?php include('testimonials.php'); ?>
<?php include('faq.php'); ?>
<?php include('footer.php'); ?>

</body>
</html>
