
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta name="geo.region" content="FR-75" />
<meta name="ICBM" content="48.885298, 2.360289" />
<link rel="publisher" href="" />
<meta name="web_author" content="" />
<meta name= "content-language" content="english" />  
<meta name="audience" content="all" />  
<meta name= "revisit-after" content="14 days" />  
<meta name="copyright" content="Copyright 2018" />
<meta name="robots" content="index, follow" />
<meta name="country" content="Perth" />

<meta property="og:type" content="astrology" />
<meta property="og:image" content="images/logo.png" alt="Astrologer in Australia" />
<meta property="og:locale" content="en_US" />

<meta name="twitter:url" content="https://dev.twitter.com/cards/markup" />
<meta name="mobile-web-app-capable" content="yes" />
<meta name="web-app-capable" content="yes" />

<meta name="viewport" content="width=device-width,initial-scale=1.0" />

<?php
$name="JaiHanuman ";
$phone="+1 647-523-1499";
$linkphone="+1 647-523-1499";
$whatsapp="+1 647-523-1499";
$email="astromahakali6999@gmail.com";
?>

<meta name="msvalidate.01" content="" /> 

<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="HandheldFriendly" content="True" />
<meta name="apple-touch-fullscreen" content="yes" />
<meta name="MobileOptimized" content="320" />

    <!-- CSS -->
	<!-- font awesome css-->
	<link rel="shortcut icon" type="image/png" href="images/short.png">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">
	 <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
	<!-- Testimonial css links-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
	<link href="testimonials.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
	<!-- stylesheet css -->
	<link href="stylesheet.css" rel="stylesheet"/>
	<!-- bootsnav css -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootsnav.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<!-- news slider css -->
	<link href="newsslider.css" rel="stylesheet">
			<!-- animate css -->
	<link href="css/animate.css" rel="stylesheet">
	<!-- hovering effects -->
	<link href="css/ihover.css" rel="stylesheet">
	<link href="hover.css" rel="stylesheet">
	<!-- testimonial css -->
	<!-- google fonts -->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=PT+Sans:700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Arimo" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=ZCOOL+QingKe+HuangYou" rel="stylesheet">
    
	<!-- <style>
		.nav-back{background:linear-gradient( 90deg, rgb(166,0,49) 0%, rgb(209,0,61) 100%);!important;border-top:1px solid #ff0000!important}
	.nav-back {
    background: linear-gradient(90deg, rgb(166, 0, 49) 0%, rgb(209, 0, 61) 100%);
    border-top: 1px solid #ff0000 !important;
    background: #bc4e9c;
    background: -webkit-linear-gradient(to left, #f80759, #bc4e9c);
    background: linear-gradient(to left, #f80759, #bc4e9c);
}
	
	.nav-back {
    background: linear-gradient(90deg, rgb(166, 0, 49) 0%, rgb(209, 0, 61) 100%);
    border-top: 1px solid #ff0000 !important;
    background: #bc4e9c;
    background: -webkit-linear-gradient(to left, #f80759, #bc4e9c);
    background: linear-gradient(to left, #ffffff, #f3f3f3);
}
.nav-back {
    background: linear-gradient(90deg, rgb(166, 0, 49) 0%, rgb(209, 0, 61) 100%);
    border-top: 1px solid #483009 !important;
    background: #bc4e9c;
    background: -webkit-linear-gradient(to left, #f80759, #bc4e9c);
    background: linear-gradient(to left, #ffffff, #f3f3f3);
}
	</style>
	<!-- Global site tag (gtag.js) - Google Ads: 392344226 -->









<!--



@use "sass:math";:root {
    --theme-color: #bd3015;
    --theme-color2: #df722b;
    --title-color: #0E121D;
    --body-color: #4D5765;
    --smoke-color: #F8F8F8;
    --black-color: #000000;
    --white-color: #ffffff;
    --light-color: #72849B;
    --yellow-color: #FFB539;
    --success-color: #28a745;
    --error-color: #dc3545;
    --border-color: #E4E4E4;
    --title-font: 'Exo', sans-serif;
    --body-font: 'Public Sans', sans-serif;
    --icon-font: "Font Awesome 6 Pro";
    --main-container: 1220px;
    --container-gutters: 24px;
    --section-space: 120px;
    --section-space-mobile: 80px;
    --section-title-space: 60px;
    --ripple-ani-duration: 5s
}

html,body {
    scroll-behavior: auto !important
}

body {
    font-family: var(--body-font);
    font-size: 16px;
    font-weight: 400;
    color: var(--body-color);
    line-height: 26px;
    overflow-x: hidden;
    -webkit-font-smoothing: antialiased
}

body::-webkit-scrollbar {
    width: 10px;
    height: 10px;
    border-radius: 20px
}

body::-webkit-scrollbar-track {
    background: rgba(252,0,18,0.1);
    box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    border-radius: 20px
}

body::-webkit-scrollbar-thumb {
    background-color: var(--theme-color);
    background-image: -webkit-linear-gradient(45deg, rgba(255,255,255,0.3) 25%, transparent 20%, transparent 50%, rgba(255,255,255,0.3) 50%, rgba(255,255,255,0.3) 75%, transparent 75%, transparent);
    border-radius: 20px
}

.theme-green {
    --theme-color: #bd3015;
    --theme-color2: #FF5E14
}

.theme-green .bg-theme2 {
    background-color: var(--theme-color2) !important
}

.theme-green .th-btn {
    border-radius: 5px
}

.theme-green .th-btn.style-new {
    box-shadow: 0px 8px 19px rgba(223,114,43,1)
}

.theme-green .slick-arrow:hover {
    box-shadow: 0px 8px 19px rgba(82,195,6,0.3);
    -webkit-filter: none;
    filter: none
}

.theme-yellow {
    --theme-color: #F0A538;
    --theme-color2: #FF5E14
}

.theme-yellow .slick-arrow:hover {
    box-shadow: none;
    -webkit-filter: none;
    filter: none
}

iframe {
    border: none;
    width: 100%
}

.slick-slide:focus,button:focus,a:focus,a:active,input,input:hover,input:focus,input:active,textarea,textarea:hover,textarea:focus,textarea:active {
    outline: none
}

input:focus {
    outline: none;
    box-shadow: none
}

img:not([draggable]),embed,object,video {
    max-width: 100%;
    height: auto
}

ul {
    list-style-type: disc
}

ol {
    list-style-type: decimal
}

table {
    margin: 0 0 1.5em;
    width: 100%;
    border-collapse: collapse;
    border-spacing: 0;
    border: 1px solid var(--border-color)
}

th {
    font-weight: 700;
    color: var(--title-color)
}

td,th {
    border: 1px solid var(--border-color);
    padding: 9px 12px
}

a {
    color: var(--theme-color);
    text-decoration: none;
    outline: 0;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s
}

a:hover {
    color: var(--title-color)
}

a:active,a:focus,a:hover,a:visited {
    text-decoration: none;
    outline: 0
}

button {
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s
}

img {
    border: none;
    max-width: 100%
}

ins {
    text-decoration: none
}

pre {
    font-family: var(--body-font);
    background: #f5f5f5;
    color: #666;
    font-size: 14px;
    margin: 20px 0;
    overflow: auto;
    padding: 20px;
    white-space: pre-wrap;
    word-wrap: break-word
}

span.ajax-loader:empty,p:empty {
    display: none
}

p {
    font-family: var(--body-font);
    margin: 0 0 18px 0;
    color: #1e1e1e;
    line-height: 1.75
}

h1 a,h2 a,h3 a,h4 a,h5 a,h6 a,p a,span a {
    font-size: inherit;
    font-family: inherit;
    font-weight: inherit;
    line-height: inherit
}

.h1,h1,.h2,h2,.h3,h3,.h4,h4,.h5,h5,.h6,h6 {
    font-family: var(--title-font);
    color: var(--title-color);
    text-transform: none;
    font-weight: 700;
    line-height: 1.4;
    margin: 0 0 15px 0
}

.h1,h1 {
    font-size: 64px;
    line-height: 1.167
}

.h2,h2 {
    font-size: 48px;
    line-height: 1.208
}

.h3,h3 {
    font-size: 32px;
    line-height: 1.278
}

.h4,h4 {
    font-size: 30px;
    line-height: 1.333;
    font-weight: 600
}

.h5,h5 {
    font-size: 24px;
    line-height: 1.417;
    font-weight: 600
}

.h6,h6 {
    font-size: 20px;
    line-height: 1.5;
    font-weight: 600
}

@media (max-width: 1399px) {
    .h1,h1 {
        font-size:48px
    }

    .h2,h2 {
        font-size: 40px
    }
}

@media (max-width: 1199px) {
    .h1,h1 {
        font-size:38px
    }

    .h2,h2 {
        font-size: 36px
    }

    .h3,h3 {
        font-size: 30px
    }

    .h4,h4 {
        font-size: 24px
    }

    .h5,h5 {
        font-size: 20px
    }

    .h6,h6 {
        font-size: 16px
    }
}

@media (max-width: 767px) {
    .h1,h1 {
        font-size:40px
    }

    .h2,h2 {
        font-size: 18px
    }

    .h3,h3 {
        font-size: 22px
    }

    .h4,h4 {
        font-size: 22px
    }

    .h5,h5 {
        font-size: 18px
    }

    .h6,h6 {
        font-size: 16px
    }
}

@media (max-width: 575px) {
    .h1,h1 {
        font-size:34px;
        line-height: 1.3
    }
}

@media (max-width: 375px) {
    .h1,h1 {
        font-size:32px
    }
}

.admin-bar .th-header .sticky-wrapper.sticky {
    top: 32px
}

p.has-drop-cap {
    margin-bottom: 20px
}

.page--item p:last-child .alignright {
    clear: right
}

.blog-title,.pagi-title,.breadcumb-title {
    word-break: break-word
}

.blocks-gallery-caption,.wp-block-embed figcaption,.wp-block-image figcaption {
    color: var(--body-color)
}

.bypostauthor,.gallery-caption {
    display: block
}

.page-links,.clearfix {
    clear: both
}

.page--item {
    margin-bottom: 30px
}

.page--item p {
    line-height: 1.8
}

.content-none-search {
    margin-top: 30px;
    margin-bottom: -10px
}

.nof-title {
    margin-top: -0.2em
}

.wp-block-button.aligncenter {
    text-align: center
}

.alignleft {
    display: inline;
    float: left;
    margin-bottom: 10px;
    margin-right: 1.5em
}

.alignright {
    display: inline;
    float: right;
    margin-bottom: 10px;
    margin-left: 1.5em;
    margin-right: 1em
}

.aligncenter {
    clear: both;
    display: block;
    margin-left: auto;
    margin-right: auto;
    max-width: 100%
}

.gallery {
    margin-bottom: 1.5em;
    width: 100%
}

.gallery-item {
    display: inline-block;
    text-align: center;
    vertical-align: top;
    width: 100%;
    padding: 0 5px
}

.wp-block-columns {
    margin-bottom: 1em
}

figure.gallery-item {
    margin-bottom: 10px;
    display: inline-block
}

figure.wp-block-gallery {
    margin-bottom: 14px
}

.gallery-columns-2 .gallery-item {
    max-width: 50%
}

.gallery-columns-3 .gallery-item {
    max-width: 33.33%
}

.gallery-columns-4 .gallery-item {
    max-width: 25%
}

.gallery-columns-5 .gallery-item {
    max-width: 20%
}

.gallery-columns-6 .gallery-item {
    max-width: 16.66%
}

.gallery-columns-7 .gallery-item {
    max-width: 14.28%
}

.gallery-columns-8 .gallery-item {
    max-width: 12.5%
}

.gallery-columns-9 .gallery-item {
    max-width: 11.11%
}

.gallery-caption {
    display: block;
    font-size: 12px;
    color: var(--body-color);
    line-height: 1.5;
    padding: .5em 0
}

.wp-block-cover p:not(.has-text-color),.wp-block-cover-image-text,.wp-block-cover-text {
    color: var(--white-color)
}

.wp-block-cover {
    margin-bottom: 15px
}

.wp-caption-text {
    text-align: center
}

.wp-caption {
    margin-bottom: 1.5em;
    max-width: 100%
}

.wp-caption .wp-caption-text {
    margin: .5em 0;
    font-size: 14px
}

.wp-block-media-text,.wp-block-media-text.alignwide,figure.wp-block-gallery {
    margin-bottom: 30px
}

.wp-block-media-text.alignwide {
    background-color: var(--smoke-color)
}

.editor-styles-wrapper .has-large-font-size,.has-large-font-size {
    line-height: 1.4
}

.wp-block-latest-comments a {
    color: inherit
}

.wp-block-button {
    margin-bottom: 10px
}

.wp-block-button:last-child {
    margin-bottom: 0
}

.wp-block-button .wp-block-button__link {
    color: #fff
}

.wp-block-button .wp-block-button__link:hover {
    color: #fff;
    background-color: var(--theme-color)
}

.wp-block-button.is-style-outline .wp-block-button__link {
    background-color: transparent;
    border-color: var(--title-color);
    color: var(--title-color)
}

.wp-block-button.is-style-outline .wp-block-button__link:hover {
    color: #fff;
    background-color: var(--theme-color);
    border-color: var(--theme-color)
}

.wp-block-button.is-style-squared .wp-block-button__link {
    border-radius: 0
}

ol.wp-block-latest-comments li {
    margin: 15px 0
}

ul.wp-block-latest-posts {
    padding: 0;
    margin: 0;
    margin-bottom: 15px
}

ul.wp-block-latest-posts a {
    color: inherit
}

ul.wp-block-latest-posts a:hover {
    color: var(--theme-color)
}

ul.wp-block-latest-posts li {
    margin: 15px 0
}

.wp-block-search {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-bottom: 30px
}

.wp-block-search .wp-block-search__input {
    width: 100%;
    max-width: 100%;
    border: 1px solid rgba(0,0,0,0.1);
    padding-left: 20px;
    border-radius: 0px
}

.wp-block-search .wp-block-search__button {
    margin: 0;
    min-width: 110px;
    border: none;
    color: #fff;
    background-color: var(--theme-color);
    border-radius: 0
}

.wp-block-search .wp-block-search__button.has-icon {
    min-width: 55px
}

.wp-block-search .wp-block-search__button:hover {
    background-color: var(--title-color);
    opacity: 0.8
}

.wp-block-search.wp-block-search__button-inside .wp-block-search__inside-wrapper {
    padding: 0;
    border: none
}

.wp-block-search.wp-block-search__button-inside .wp-block-search__inside-wrapper .wp-block-search__input {
    padding: 0 8px 0 25px;
    border-radius: 0px
}

ul.wp-block-rss a {
    color: inherit
}

.wp-block-group.has-background {
    padding: 15px 15px 1px;
    margin-bottom: 30px
}

.wp-block-table td,.wp-block-table th {
    border-color: rgba(0,0,0,0.1)
}

.wp-block-table.is-style-stripes {
    border: 1px solid rgba(0,0,0,0.1);
    margin-bottom: 30px
}

.wp-block-table.is-style-stripes {
    border: 0;
    margin-bottom: 30px;
    border-bottom: 0
}

.wp-block-table.is-style-stripes th,.wp-block-table.is-style-stripes td {
    border-color: var(--border-color)
}

.logged-in .will-sticky .sticky-active.active,.logged-in .preloader .th-btn {
    top: 32px
}

@media (max-width: 782px) {
    .logged-in .will-sticky .sticky-active.active,.logged-in .preloader .th-btn {
        top:46px
    }
}

@media (max-width: 600px) {
    .logged-in .will-sticky .sticky-active.active,.logged-in .preloader .th-btn {
        top:0
    }
}

.post-password-form {
    margin-bottom: 30px;
    margin-top: 20px
}

.post-password-form p {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    position: relative;
    gap: 15px
}

@media (max-width: 575px) {
    .post-password-form p {
        -webkit-flex-wrap:wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }
}

.post-password-form label {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-flex: 1;
    -webkit-flex: auto;
    -ms-flex: auto;
    flex: auto;
    margin-bottom: 0;
    line-height: 1;
    margin-top: 0;
    gap: 15px
}

@media (max-width: 575px) {
    .post-password-form label {
        -webkit-flex-wrap:wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }
}

.post-password-form input {
    width: 100%;
    border: none;
    height: 55px;
    padding-left: 25px;
    color: var(--body-color);
    border: 1px solid var(--border-color)
}

.post-password-form input[type="submit"] {
    padding-left: 0;
    padding-right: 0;
    margin: 0;
    width: 140px;
    border: none;
    color: #fff;
    background-color: var(--theme-color);
    text-align: center
}

.post-password-form input[type="submit"]:hover {
    background-color: var(--title-color)
}

.page-links {
    clear: both;
    margin: 0 0 1.5em;
    padding-top: 1em
}

.page-links>.page-links-title {
    margin-right: 10px
}

.page-links>span:not(.page-links-title):not(.screen-reader-text),.page-links>a {
    display: inline-block;
    padding: 5px 13px;
    background-color: var(--white-color);
    color: var(--title-color);
    border: 1px solid rgba(0,0,0,0.08);
    margin-right: 10px;
    border-radius: 5px
}

.page-links>span:not(.page-links-title):not(.screen-reader-text):hover,.page-links>a:hover {
    opacity: 0.8;
    color: var(--white-color);
    background-color: var(--theme-color);
    border-color: transparent
}

.page-links>span:not(.page-links-title):not(.screen-reader-text).current,.page-links>a.current {
    background-color: var(--theme-color);
    color: var(--white-color);
    border-color: transparent
}

.page-links span.screen-reader-text {
    display: none
}

.blog-single .wp-block-archives-dropdown {
    margin-bottom: 30px
}

.blog-single.format-quote,.blog-single.format-link,.blog-single.tag-sticky-2,.blog-single.sticky {
    position: relative
}

.blog-single.format-quote .blog-content:before,.blog-single.format-link .blog-content:before,.blog-single.tag-sticky-2 .blog-content:before,.blog-single.sticky .blog-content:before {
    display: none
}

.blog-single.format-quote:before,.blog-single.format-link:before,.blog-single.tag-sticky-2:before,.blog-single.sticky:before {
    content: '\f08d';
    position: absolute;
    font-family: var(--icon-font);
    font-size: 14px;
    font-weight: 500;
    opacity: 1;
    right: 0;
    top: 0;
    color: var(--white-color);
    background-color: var(--theme-color);
    z-index: 1;
    height: 40px;
    width: 40px;
    line-height: 40px;
    text-align: center;
    border-radius: 0 8px 0 8px
}

.blog-single.format-quote:before {
    content: "\f10e"
}

.blog-single.format-link:before {
    content: "\f0c1"
}

.blog-single .blog-content .wp-block-categories-dropdown.wp-block-categories,.blog-single .blog-content .wp-block-archives-dropdown {
    display: block;
    margin-bottom: 30px
}

.blog-details .blog-single:before {
    display: none
}

.blog-details .blog-single .blog-content {
    background-color: transparent;
    overflow: hidden
}

.blog-details .blog-single.format-chat .blog-meta {
    margin-bottom: 20px
}

.blog-details .blog-single.format-chat .blog-content>p:nth-child(2n) {
    background: var(--smoke-color);
    padding: 5px 20px
}

.blog-details .blog-single.tag-sticky-2:before,.blog-details .blog-single.sticky:before,.blog-details .blog-single.format-quote:before,.blog-details .blog-single.format-link:before {
    display: none
}

.th-search {
    background-color: var(--smoke-color);
    margin-bottom: 30px;
    border: 1px solid #f3f3f3
}

.th-search .search-grid-content {
    padding: 30px
}

@media (max-width: 767px) {
    .th-search .search-grid-content {
        padding:20px
    }
}

.th-search .search-grid-title {
    font-size: 20px;
    margin-bottom: 5px;
    margin-top: 0
}

.th-search .search-grid-title a {
    color: inherit
}

.th-search .search-grid-title a:hover {
    color: var(--theme-color)
}

.th-search .search-grid-meta>* {
    display: inline-block;
    margin-right: 15px;
    font-size: 16px;
    font-weight: 500
}

.th-search .search-grid-meta>*:last-child {
    margin-right: 0
}

.th-search .search-grid-meta a,.th-search .search-grid-meta span {
    color: var(--body-color)
}

@media (max-width: 768px) {
    .wp-block-latest-comments {
        padding-left:10px
    }

    .page--content.clearfix+.th-comment-form {
        margin-top: 24px
    }
}

@media (max-width: 575px) {
    .blog-single.format-quote .blog-content:before,.blog-single.format-link .blog-content:before,.blog-single.tag-sticky-2 .blog-content:before,.blog-single.sticky .blog-content:before {
        display:none
    }

    .blog-single.format-quote:before,.blog-single.format-link:before,.blog-single.tag-sticky-2:before,.blog-single.sticky:before {
        font-size: 13px;
        height: 32px;
        width: 32px;
        line-height: 32px
    }
}

.service-sidebar .widget_categories h5 {
    position: relative;
    font-size: 24px;
    font-weight: 600;
    font-family: var(--title-font);
    line-height: 1em;
    margin: -0.1em 0 29px 0;
    padding-bottom: 16px;
    text-transform: uppercase;
    border-bottom: 3px solid var(--border-color)
}

.service-sidebar .widget_categories h5:before {
    content: '';
    height: 3px;
    width: 50px;
    background-color: var(--theme-color);
    position: absolute;
    bottom: -3px;
    left: 0;
    z-index: 1;
    -webkit-animation: lineMove 10s linear infinite;
    animation: lineMove 10s linear infinite
}

@media (max-width: 1399px) {
    :root {
        --main-container: 1220px
    }
}

@media only screen and (min-width: 1300px) {
    .container-xxl,.container-xl,.container-lg,.container-md,.container-sm,.container {
        max-width:calc(var(--main-container) + var(--container-gutters));
        padding-left: calc(var(--container-gutters) / 2);
        padding-right: calc(var(--container-gutters) / 2)
    }
}

@media (min-width: 1700px) {
    .th-container {
        --main-container: 1420px
    }

    .th-container3 {
        --main-container: 1710px
    }
}

@media (min-width: 1600px) {
    .th-container {
        --main-container: 1420px
    }

    .th-container2 {
        --main-container: 1380px
    }
}

@media only screen and (max-width: 1600px) {
    .container-fluid.px-0 {
        padding-left:15px !important;
        padding-right: 15px !important
    }

    .container-fluid.px-0 .row {
        margin-left: 0 !important;
        margin-right: 0 !important
    }

    .th-container3 {
        --main-container: 1500px
    }
}

.th-container4 {
    max-width: 1562px;
    padding-left: 0;
    padding-right: 0;
    margin-right: auto;
    margin-left: unset
}

.th-container4 .container {
    margin-left: auto;
    margin-right: 0
}

@media (max-width: 1700px) {
    .th-container4 {
        margin-left:auto
    }

    .th-container4 .container {
        margin-right: auto
    }
}

@media (min-width: 1922px) {
    .th-container4 {
        margin-left:auto
    }

    .th-container4 .container {
        margin-right: auto
    }
}

.th-container5 {
    max-width: 1562px;
    padding-left: 0;
    padding-right: 0;
    margin-right: unset;
    margin-left: auto
}

.th-container5 .container {
    margin-left: 0;
    margin-right: auto
}

@media (max-width: 1700px) {
    .th-container5 {
        margin-right:auto
    }

    .th-container5 .container {
        margin-left: auto
    }
}

@media (max-width: 1300px) {
    .th-container5 {
        padding-left:12px;
        padding-right: 12px
    }
}

@media (min-width: 1922px) {
    .th-container5 {
        margin-right:auto
    }

    .th-container5 .container {
        margin-left: auto
    }
}

@media (min-width: 1560px) {
    .th-container6 {
        max-width:1620px;
        margin-left: auto;
        margin-right: auto;
        padding-left: 0;
        padding-right: 0
    }

    .th-container6 .container {
        --main-container: 1220px
    }
}

.slick-track>[class*=col] {
    -webkit-flex-shrink: 0;
    -ms-flex-negative: 0;
    flex-shrink: 0;
    width: 100%;
    max-width: 100%;
    padding-right: calc(var(--bs-gutter-x)/ 2);
    padding-left: calc(var(--bs-gutter-x)/ 2);
    margin-top: var(--bs-gutter-y)
}

.gy-30 {
    --bs-gutter-y: 30px
}

.gy-40 {
    --bs-gutter-y: 40px
}

.gy-50 {
    --bs-gutter-y: 50px
}

.gx-10 {
    --bs-gutter-x: 10px
}

.gx-70 {
    --bs-gutter-x: 70px
}

@media (max-width: 1500px) {
    .gx-70 {
        --bs-gutter-x: 30px
    }
}

@media (max-width: 991px) {
    .gx-70 {
        --bs-gutter-x: 24px
    }
}

@media (min-width: 1299px) {
    .gx-60 {
        --bs-gutter-x: 60px
    }
}

@media (min-width: 1399px) {
    .gx-30 {
        --bs-gutter-x: 30px
    }

    .gx-25 {
        --bs-gutter-x: 25px
    }

    .gx-40 {
        --bs-gutter-x: 40px
    }
}

@media (max-width: 991px) {
    .gy-50 {
        --bs-gutter-y: 40px
    }
}

select,.form-control,.form-select,textarea,input {
    height: 55px;
    padding: 0 25px 0 25px;
    padding-right: 45px;
    border: 1px solid #100101e0;
    color: var(--body-color);
    background-color: var(--smoke-color);
    border-radius: 0px;
    font-size: 16px;
    width: 100%;
    font-family: var(--body-font);
    -webkit-transition: 0.3s ease-in-out;
    transition: 0.3s ease-in-out
}

select:focus,.form-control:focus,.form-select:focus,textarea:focus,input:focus {
    outline: 0;
    box-shadow: none;
    border-color: var(--theme-color);
    background-color: var(--smoke-color)
}

select::-moz-placeholder,.form-control::-moz-placeholder,.form-select::-moz-placeholder,textarea::-moz-placeholder,input::-moz-placeholder {
    color: var(--body-color)
}

select::-webkit-input-placeholder,.form-control::-webkit-input-placeholder,.form-select::-webkit-input-placeholder,textarea::-webkit-input-placeholder,input::-webkit-input-placeholder {
    color: var(--body-color)
}

select:-ms-input-placeholder,.form-control:-ms-input-placeholder,.form-select:-ms-input-placeholder,textarea:-ms-input-placeholder,input:-ms-input-placeholder {
    color: var(--body-color)
}

select::-webkit-input-placeholder, .form-control::-webkit-input-placeholder, .form-select::-webkit-input-placeholder, textarea::-webkit-input-placeholder, input::-webkit-input-placeholder {
    color: var(--body-color)
}

select::-moz-placeholder, .form-control::-moz-placeholder, .form-select::-moz-placeholder, textarea::-moz-placeholder, input::-moz-placeholder {
    color: var(--body-color)
}

select:-ms-input-placeholder, .form-control:-ms-input-placeholder, .form-select:-ms-input-placeholder, textarea:-ms-input-placeholder, input:-ms-input-placeholder {
    color: var(--body-color)
}

select::-ms-input-placeholder, .form-control::-ms-input-placeholder, .form-select::-ms-input-placeholder, textarea::-ms-input-placeholder, input::-ms-input-placeholder {
    color: var(--body-color)
}

select::placeholder,.form-control::placeholder,.form-select::placeholder,textarea::placeholder,input::placeholder {
    color: var(--body-color)
}

select.style2,.form-control.style2,.form-select.style2,textarea.style2,input.style2 {
    border: 1px solid transparent;
    padding-left: 52px;
    background-image: none
}

select.style2 ~ i,.form-control.style2 ~ i,.form-select.style2 ~ i,textarea.style2 ~ i,input.style2 ~ i {
    color: var(--theme-color);
    font-weight: 400;
    left: 25px;
    max-width: 16px
}

select.style-white,.form-control.style-white,.form-select.style-white,textarea.style-white,input.style-white {
    background-color: var(--white-color);
    border: none
}

input[type=date] {
    padding: 0 25px 0 25px;
    position: relative
}

input[type=date]:after {
    content: "\f073";
    position: relative;
    font-family: var(--icon-font);
    top: 0px;
    font-weight: 300
}

input[type=date]::-webkit-calendar-picker-indicator {
    background: transparent;
    position: absolute;
    right: 20px;
    z-index: 1;
    cursor: pointer
}

.form-select,select {
    display: block;
    width: 100%;
    line-height: 1.5;
    vertical-align: middle;
    background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3E%3C/svg%3E");
    background-position: right 26px center;
    background-repeat: no-repeat;
    background-size: 16px 12px;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    cursor: pointer
}

.form-select.nice-select,select.nice-select {
    border: none;
    padding: 15px 25px;
    background-color: var(--smoke-color);
    background-image: none;
    z-index: 11;
    margin-bottom: -10px
}

.form-select.nice-select .list,select.nice-select .list {
    width: 100%
}

.form-select.nice-select:after,select.nice-select:after {
    border-bottom: 1px solid #93a5be;
    border-right: 1px solid #93a5be;
    height: 8px;
    right: 25px;
    width: 8px
}

.form-select.style-white,select.style-white {
    background: var(--white-color)
}

textarea.form-control,textarea {
    min-height: 150px;
    padding-top: 16px;
    padding-bottom: 17px;
    border-radius: 0px
}

.form-group {
    margin-bottom: var(--bs-gutter-x);
    position: relative;
    display: inline-block;
    width: 100%
}

.form-group>i {
    display: inline-block;
    position: absolute;
    right: 25px;
    top: 19px;
    font-size: 16px;
    color: #93a5be
}

.form-group>i.fa-envelope {
    padding-top: 1px
}

.form-group>i.fa-comment {
    margin-top: -2px
}

.form-group>i.fa-chevron-down {
    width: 17px;
    background-color: var(--white-color)
}

.form-group.has-label>i {
    top: 50px
}

[class*="col-"].form-group>i {
    right: calc((var(--bs-gutter-x) / 2) + 25px)
}

[class*="col-"].form-group .style2 ~ i {
    left: calc((var(--bs-gutter-x) / 2) + 25px)
}

option:checked,option:focus,option:hover {
    background-color: var(--theme-color);
    color: var(--white-color)
}

input::-webkit-outer-spin-button,input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0
}

input[type="number"] {
    -moz-appearance: textfield
}

input[type="checkbox"] {
    visibility: hidden;
    opacity: 0;
    display: inline-block;
    vertical-align: middle;
    width: 0;
    height: 0;
    display: none
}

input[type="checkbox"]:checked ~ label:before {
    content: "\f00c";
    color: var(--white-color);
    background-color: var(--theme-color);
    border-color: var(--theme-color)
}

input[type="checkbox"] ~ label {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
    display: block
}

input[type="checkbox"] ~ label:before {
    content: "";
    font-family: var(--icon-font);
    font-weight: 700;
    position: absolute;
    left: 0px;
    top: 3.5px;
    background-color: var(--white-color);
    border: 1px solid var(--border-color);
    height: 18px;
    width: 18px;
    line-height: 18px;
    text-align: center;
    font-size: 12px
}

input[type="radio"] {
    visibility: hidden;
    opacity: 0;
    display: inline-block;
    vertical-align: middle;
    width: 0;
    height: 0;
    display: none
}

input[type="radio"] ~ label {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
    line-height: 1;
    display: inline-block;
    font-weight: 600;
    margin-bottom: 0
}

input[type="radio"] ~ label::before {
    content: "\f111";
    position: absolute;
    font-family: var(--icon-font);
    left: 0;
    top: -2px;
    width: 20px;
    height: 20px;
    padding-left: 0;
    font-size: 0.6em;
    line-height: 19px;
    text-align: center;
    border: 1px solid var(--theme-color);
    border-radius: 100%;
    font-weight: 700;
    background: var(--white-color);
    color: transparent;
    -webkit-transition: all 0.2s ease;
    transition: all 0.2s ease
}

input[type="radio"]:checked ~ label::before {
    border-color: var(--theme-color);
    background-color: var(--theme-color);
    color: var(--white-color)
}

label {
    margin-bottom: 0.5em;
    margin-top: -0.3em;
    display: block;
    color: var(--title-color);
    font-family: var(--body-font);
    font-size: 16px
}

textarea.is-invalid,select.is-invalid,input.is-invalid,.was-validated input:invalid {
    border: 1px solid var(--error-color) !important;
    background-position: right calc(0.375em + 0.8875rem) center;
    background-image: none
}

textarea.is-invalid:focus,select.is-invalid:focus,input.is-invalid:focus,.was-validated input:invalid:focus {
    outline: 0;
    box-shadow: none
}

textarea.is-invalid {
    background-position: top calc(0.375em + 0.5875rem) right calc(0.375em + 0.8875rem)
}

.row.no-gutters>.form-group {
    margin-bottom: 0
}

.form-messages {
    display: none
}

.form-messages.mb-0 * {
    margin-bottom: 0
}

.form-messages.success {
    color: var(--success-color);
    display: block
}

.form-messages.error {
    color: var(--error-color);
    display: block
}

.form-messages pre {
    padding: 0;
    background-color: transparent;
    color: inherit
}

.slick-track>[class*=col] {
    -webkit-flex-shrink: 0;
    -ms-flex-negative: 0;
    flex-shrink: 0;
    width: 100%;
    max-width: 100%;
    padding-right: calc(var(--bs-gutter-x) / 2);
    padding-left: calc(var(--bs-gutter-x) / 2);
    margin-top: var(--bs-gutter-y)
}

.slick-list {
    padding-left: 0;
    padding-right: 0
}

.slick-track {
    min-width: 100%
}

.slick-slide img {
    display: inline-block
}

.slick-dots {
    list-style-type: none;
    padding: 2px 0;
    margin: 60px 0 0 0;
    line-height: 0;
    text-align: center;
    height: -webkit-max-content;
    height: -moz-max-content;
    height: max-content
}

.slick-dots li {
    display: inline-block;
    margin-right: 20px
}

.slick-dots li:last-child {
    margin-right: 0
}

.slick-dots button {
    font-size: 0;
    padding: 0;
    background-color: var(--theme-color);
    width: 12px;
    height: 12px;
    line-height: 0;
    border-radius: 9999px;
    border: none;
    border: 0;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s;
    position: relative
}

.slick-dots button:hover {
    border-color: var(--theme-color)
}

.slick-dots button:before {
    content: "";
    position: absolute;
    left: 50%;
    top: 50%;
    width: 30px;
    height: 30px;
    border: 1px solid var(--theme-color);
    background-color: transparent;
    border-radius: 50%;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s;
    visibility: hidden;
    opacity: 1;
    -webkit-transform: translate(-50%, -50%) scale(0);
    -ms-transform: translate(-50%, -50%) scale(0);
    transform: translate(-50%, -50%) scale(0)
}

.slick-dots .slick-active button::before {
    visibility: visible;
    opacity: 1;
    -webkit-transform: translate(-50%, -50%) scale(1);
    -ms-transform: translate(-50%, -50%) scale(1);
    transform: translate(-50%, -50%) scale(1)
}

.dot-style2 .slick-dots {
    list-style-type: none;
    padding: 2px 0;
    margin: 60px 0 0 0;
    line-height: 0;
    text-align: center;
    height: -webkit-max-content;
    height: -moz-max-content;
    height: max-content
}

.dot-style2 .slick-dots li {
    display: inline-block;
    margin-right: 10px
}

.dot-style2 .slick-dots li:last-child {
    margin-right: 0
}

.dot-style2 .slick-dots button {
    font-size: 0;
    padding: 0;
    background-color: transparent;
    width: 20px;
    height: 20px;
    line-height: 0;
    border-radius: 9999px;
    border: none;
    background-color: transparent;
    border: 2px solid #cedce9;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s;
    position: relative
}

.dot-style2 .slick-dots button:hover {
    border-color: var(--theme-color)
}

.dot-style2 .slick-dots button:before {
    content: "";
    position: absolute;
    left: 50%;
    top: 50%;
    width: 8px;
    height: 8px;
    border: none;
    background-color: transparent;
    border-radius: 50%;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s;
    visibility: hidden;
    opacity: 1
}

.dot-style2 .slick-dots .slick-active button {
    border-color: var(--theme-color)
}

.dot-style2 .slick-dots .slick-active button::before {
    background-color: var(--theme-color);
    visibility: visible;
    opacity: 1
}

.dot-style3 .slick-dots {
    list-style-type: none;
    padding: 0 0;
    margin: 40px 0 0 0;
    line-height: 0;
    text-align: center;
    height: -webkit-max-content;
    height: -moz-max-content;
    height: max-content
}

.dot-style3 .slick-dots li {
    display: inline-block;
    margin-right: 8px
}

.dot-style3 .slick-dots li:last-child {
    margin-right: 0
}

.dot-style3 .slick-dots button {
    font-size: 0;
    padding: 0;
    background-color: transparent;
    width: 20px;
    height: 6px;
    line-height: 0;
    border-radius: 9999px;
    border: none;
    background-color: rgba(0,15,87,0.3);
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s
}

.dot-style3 .slick-dots button:before {
    display: none
}

.dot-style3 .slick-dots button:hover {
    border-color: var(--theme-color)
}

.dot-style3 .slick-dots .slick-active button {
    width: 40px;
    -webkit-transform: scale(1);
    -ms-transform: scale(1);
    transform: scale(1);
    background-color: var(--theme-color)
}

.slick-arrow {
    display: inline-block;
    padding: 0;
    background-color: var(--white-color);
    -webkit-filter: drop-shadow(0px 4px 20px rgba(7,36,95,0.1));
    filter: drop-shadow(0px 4px 20px rgba(7,36,95,0.1));
    position: absolute;
    top: 50%;
    border: 1px solid #f2f2f2;
    left: var(--pos-x, -100px);
    width: var(--icon-size, 56px);
    height: var(--icon-size, 56px);
    font-size: var(--icon-font-size, 20px);
    font-weight: 600;
    margin-top: calc(var(--icon-size, 56px) / -2);
    z-index: 2;
    border-radius: 999px;
    color: var(--theme-color)
}

.slick-arrow.default {
    position: relative;
    --pos-x: 0;
    margin-top: 0
}

.slick-arrow.slick-next {
    right: var(--pos-x, -100px);
    left: auto
}

.slick-arrow:hover {
    background-color: var(--theme-color);
    color: var(--white-color);
    border-color: transparent;
    -webkit-filter: drop-shadow(0px 8px 19px rgba(255,76,19,0.3));
    filter: drop-shadow(0px 8px 19px rgba(255,76,19,0.3))
}

.icon-box.style2 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 10px
}

.icon-box.style2 .slick-arrow {
    margin: 0
}

.arrow-style2 .slick-arrow {
    background-color: transparent;
    border: 1px solid var(--body-color);
    box-shadow: none
}

.arrow-style2 .slick-arrow:hover {
    background: var(--theme-color);
    border-color: var(--theme-color)
}

.arrow-style3 .slick-arrow {
    border-radius: 0
}

.arrow-style3 .slick-arrow:hover {
    background: var(--theme-color);
    border-color: var(--theme-color)
}

.arrow-style4 .slick-arrow {
    border-radius: 0;
    background: #1D212D;
    border-color: #1D212D;
    color: var(--white-color)
}

.arrow-style4 .slick-arrow:hover {
    background: var(--theme-color);
    border-color: var(--theme-color)
}

.arrow-style5 .slick-arrow {
    background-color: transparent;
    border: 1px solid var(--border-color);
    box-shadow: none
}

.arrow-style5 .slick-arrow:hover {
    background: var(--theme-color);
    border-color: var(--theme-color)
}

.arrow-style6 .slick-arrow {
    background-color: var(--title-color);
    box-shadow: none;
    color: var(--white-color)
}

.arrow-style6 .slick-arrow:hover {
    background: var(--theme-color);
    border-color: var(--theme-color)
}

.arrow-style7 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 15px
}

.arrow-style7 .slick-arrow {
    background-color: transparent;
    border-radius: 0;
    box-shadow: none;
    color: var(--theme-color);
    border-color: var(--border-color);
    margin: 0
}

.arrow-style7 .slick-arrow:hover {
    background: var(--theme-color);
    border-color: var(--theme-color);
    color: var(--white-color)
}

.arrow-style8 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 15px
}

.arrow-style8 .slick-arrow {
    background-color: var(--theme-color);
    border-radius: 0;
    box-shadow: none;
    color: var(--white-color);
    border-color: var(--theme-color);
    margin: 0
}

.arrow-style8 .slick-arrow:hover {
    background: var(--white-color);
    border-color: var(--theme-color);
    color: var(--theme-color)
}

.arrow-margin .slick-arrow {
    top: calc(50% - 30px)
}

.arrow-wrap .slick-arrow {
    opacity: 0;
    visibility: hidden
}

.arrow-wrap:hover .slick-arrow {
    opacity: 1;
    visibility: visible
}

@media (max-width: 1299px) {
    .slick-arrow {
        --arrow-horizontal: -20px;
        --pos-x: -70px
    }
}

@media (max-width: 1399px) {
    .slick-arrow {
        --arrow-horizontal: 40px;
        --pos-x: -17px
    }
}

@media (max-width: 991px) {
    .slick-arrow {
        --icon-size: 40px;
        margin-right: 40px
    }

    .slick-arrow.slick-next {
        margin-right: 0;
        margin-left: 40px
    }

    .slick-dots {
        margin: 40px 0 0 0
    }
}

.th-menu-wrapper {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    background-color: rgba(0,0,0,0.6);
    z-index: 999999;
    width: 0;
    width: 100%;
    height: 100%;
    -webkit-transition: all ease 0.8s;
    transition: all ease 0.8s;
    opacity: 0;
    visibility: hidden
}

.th-menu-wrapper .mobile-logo {
    padding-bottom: 30px;
    padding-top: 40px;
    display: block;
    text-align: center;
}

.th-menu-wrapper .mobile-logo svg {
    max-width: 185px
}

.th-menu-wrapper .th-menu-toggle {
    border: none;
    font-size: 22px;
    position: absolute;
    right: -16.5px;
    top: 25px;
    padding: 0;
    line-height: 1;
    width: 33px;
    height: 33px;
    line-height: 35px;
    font-size: 18px;
    z-index: 1;
    color: var(--white-color);
    background-color: var(--theme-color);
    border-radius: 50%
}

.th-menu-wrapper .th-menu-toggle:hover {
    background-color: var(--title-color);
    color: var(--white-color)
}

.th-menu-wrapper .th-menu-area {
    width: 100%;
    max-width: 310px;
    background-color: #fff;
    border-right: 3px solid var(--theme-color);
    height: 100%;
    position: relative;
    left: -110%;
    opacity: 0;
    visibility: hidden;
    -webkit-transition: all ease 1s;
    transition: all ease 1s;
    z-index: 1
}

.th-menu-wrapper.th-body-visible {
    opacity: 1;
    visibility: visible
}

.th-menu-wrapper.th-body-visible .th-menu-area {
    left: 0;
    opacity: 1;
    visibility: visible
}

.th-mobile-menu {
    overflow-y: scroll;
    max-height: calc(100vh - 200px);
    padding-bottom: 40px;
    margin-top: 33px;
    text-align: left
}

.th-mobile-menu .new-label {
    font-size: 13px;
    background-color: var(--theme-color);
    color: var(--white-color);
    padding: 2px 5px;
    border-radius: 4px;
    position: relative;
    top: -1px
}

.th-mobile-menu ul {
    margin: 0;
    padding: 0 0
}

.th-mobile-menu ul li {
    border-bottom: 1px solid #fdedf1;
    list-style-type: none
}

.th-mobile-menu ul li li:first-child {
    border-top: 1px solid #fdedf1
}

.th-mobile-menu ul li a {
    display: block;
    position: relative;
    padding: 12px 0;
    line-height: 1.4;
    font-size: 16px;
    text-transform: capitalize;
    color: var(--title-color);
    padding-left: 18px
}

.th-mobile-menu ul li a:before {
    content: '\f105';
    font-family: var(--icon-font);
    position: absolute;
    left: 0;
    top: 12px;
    margin-right: 10px;
    display: inline-block
}

.th-mobile-menu ul li.th-active>a {
    color: var(--theme-color)
}

.th-mobile-menu ul li.th-active>a:before {
    -webkit-transform: rotate(90deg);
    -ms-transform: rotate(90deg);
    transform: rotate(90deg)
}

.th-mobile-menu ul li ul li {
    padding-left: 20px
}

.th-mobile-menu ul li ul li:last-child {
    border-bottom: none
}

.th-mobile-menu ul .th-item-has-children>a .th-mean-expand {
    position: absolute;
    right: 0;
    top: 50%;
    font-weight: 400;
    font-size: 12px;
    width: 25px;
    height: 25px;
    line-height: 25px;
    margin-top: -12.5px;
    display: inline-block;
    text-align: center;
    background-color: var(--smoke-color);
    color: var(--title-color);
    box-shadow: 0 0 20px -8px rgba(173,136,88,0.5);
    border-radius: 50%
}

.th-mobile-menu ul .th-item-has-children>a .th-mean-expand:before {
    content: '\f067';
    font-family: var(--icon-font)
}

.th-mobile-menu ul .th-item-has-children>a:after {
    content: "\f067";
    font-family: var(--icon-font);
    width: 22px;
    height: 22px;
    line-height: 22px;
    display: inline-block;
    text-align: center;
    font-size: 12px;
    border-radius: 50px;
    background-color: var(--smoke-color);
    float: right;
    margin-top: 1px
}

.th-mobile-menu ul .th-item-has-children.th-active>a .th-mean-expand:before {
    content: '\f068'
}

.th-mobile-menu ul .th-item-has-children.th-active>a:after {
    content: "\f068"
}

.th-mobile-menu>ul {
    padding: 0 40px
}

.th-mobile-menu>ul>li:last-child {
    border-bottom: none
}

.th-menu-toggle {
    width: 50px;
    height: 50px;
    padding: 0;
    font-size: 20px;
    border: none;
    background-color: var(--theme-color);
    color: var(--white-color);
    display: inline-block;
    border-radius: 5px
}

.th-menu-toggle:hover {
    background-color: var(--title-color)
}

.th-menu-toggle.style-text,.th-menu-toggle.style-text-white {
    width: auto;
    height: auto;
    background-color: transparent;
    color: var(--title-color);
    font-size: 20px
}

.th-menu-toggle.style-text i,.th-menu-toggle.style-text-white i {
    margin-right: 10px
}

.th-menu-toggle.style-text-white {
    color: var(--white-color)
}

@media (max-width: 400px) {
    .th-menu-wrapper .th-menu-area {
        width:100%;
        max-width: 270px
    }

    .th-mobile-menu>ul {
        padding: 0 20px
    }
}

.preloader {
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    z-index: 999;
    background-color: var(--title-color)
}

.preloader .as-btn {
    padding: 15px 20px;
    border-radius: 0;
    font-size: 14px
}

.preloader-inner {
    text-align: center;
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    text-align: center;
    line-height: 1
}

.preloader-inner img {
    display: block;
    margin: 0 auto 10px auto
}

.loader {
    width: 48px;
    height: 48px;
    display: inline-block;
    position: relative;
    background: var(--theme-color);
    box-sizing: border-box;
    -webkit-animation: flipX 1s linear infinite;
    animation: flipX 1s linear infinite
}

@-webkit-keyframes flipX {
    0% {
        -webkit-transform: perspective(200px) rotateX(0deg) rotateY(0deg);
        transform: perspective(200px) rotateX(0deg) rotateY(0deg)
    }

    50% {
        -webkit-transform: perspective(200px) rotateX(-180deg) rotateY(0deg);
        transform: perspective(200px) rotateX(-180deg) rotateY(0deg)
    }

    100% {
        -webkit-transform: perspective(200px) rotateX(-180deg) rotateY(-180deg);
        transform: perspective(200px) rotateX(-180deg) rotateY(-180deg)
    }
}

@keyframes flipX {
    0% {
        -webkit-transform: perspective(200px) rotateX(0deg) rotateY(0deg);
        transform: perspective(200px) rotateX(0deg) rotateY(0deg)
    }

    50% {
        -webkit-transform: perspective(200px) rotateX(-180deg) rotateY(0deg);
        transform: perspective(200px) rotateX(-180deg) rotateY(0deg)
    }

    100% {
        -webkit-transform: perspective(200px) rotateX(-180deg) rotateY(-180deg);
        transform: perspective(200px) rotateX(-180deg) rotateY(-180deg)
    }
}

.th-btn {
    position: relative;
    z-index: 2;
    overflow: hidden;
    vertical-align: middle;
    display: inline-block;
    border: none;
    text-transform: uppercase;
    text-align: center;
    background-color: var(--theme-color);
    color: var(--white-color);
    font-family: var(--body-font);
    font-size: 14px;
    font-weight: 700;
    line-height: 1;
    padding: 20.5px 29px;
    border-radius: 0
}

.th-btn:before,.th-btn:after {
    content: "";
    position: absolute;
    height: 100%;
    top: 0;
    width: 0%;
    background-color: var(--title-color);
    z-index: -1;
    -webkit-transition: all 0.4s ease-out;
    transition: all 0.4s ease-out
}

.th-btn:before {
    left: 0;
    border-radius: 0 20px 20px 0
}

.th-btn:after {
    right: 0;
    border-radius: 20px 0 0 20px
}

.th-btn:hover,.th-btn.active {
    color: var(--white-color)
}

.th-btn:hover::before,.th-btn:hover:after,.th-btn.active::before,.th-btn.active:after {
    width: 50%;
    border-radius: 0
}

.th-btn.style2 {
    background-color: transparent;
    color: var(--white-color);
    border: 1px solid var(--white-color);
    padding: 19.5px 27px;
    box-shadow: none
}

.th-btn.style2:hover {
    color: var(--title-color)
}

.th-btn.style2:hover:before,.th-btn.style2:hover:after {
    background-color: var(--white-color)
}

.th-btn.style3:hover {
    color: var(--title-color)
}

.th-btn.style3:hover:before,.th-btn.style3:hover:after {
    background-color: var(--white-color)
}

.th-btn.style4 {
    background-color: var(--white-color);
    color: var(--theme-color)
}

.th-btn.style4:hover {
    color: var(--white-color)
}

.th-btn.style4:hover:before,.th-btn.style4:hover:after {
    background-color: var(--theme-color)
}

.th-btn.style5 {
    background-color: var(--title-color);
    color: var(--white-color)
}

.th-btn.style5:hover {
    color: var(--title-color)
}

.th-btn.style5:hover:before,.th-btn.style5:hover:after {
    background-color: var(--white-color)
}

.th-btn.style6 {
    background-color: var(--white-color);
    color: var(--theme-color)
}

.th-btn.style6:hover {
    color: var(--white-color)
}

.th-btn.style6:hover:before,.th-btn.style6:hover:after {
    background-color: var(--title-color)
}

.th-btn.style7 {
    background-color: transparent;
    color: var(--white-color);
    border: 1px solid var(--theme-color);
    padding: 19.5px 27px;
    box-shadow: none
}

.th-btn.style7:hover {
    color: var(--white-color)
}

.th-btn.style7:hover:before,.th-btn.style7:hover:after {
    background-color: var(--theme-color)
}

.th-btn.style8 {
    background-color: var(--white-color);
    color: var(--theme-color)
}

.th-btn.style8:hover:before,.th-btn.style8:hover:after {
    background-color: transparent
}

.th-btn.style9 {
    background-color: transparent;
    color: var(--title-color);
    border: 1px solid var(--border-color)
}

.th-btn.style9:hover {
    color: var(--theme-color);
    border-color: var(--white-color)
}

.th-btn.style9:hover:before,.th-btn.style9:hover:after {
    background-color: var(--white-color)
}

.th-btn.style10 {
    background-color: transparent;
    color: var(--body-color);
    border: 1px solid var(--border-color)
}

.th-btn.style10:hover {
    color: var(--white-color);
    border-color: var(--theme-color)
}

.th-btn.style10:hover:before,.th-btn.style10:hover:after {
    background-color: var(--theme-color)
}

.th-btn.style-new {
    border-radius: 3px;
    box-shadow: 0px 8px 19px rgba(255,76,19,0.3)
}

.icon-btn {
    display: inline-block;
    width: var(--btn-size, 50px);
    height: var(--btn-size, 50px);
    line-height: var(--btn-size, 50px);
    font-size: var(--btn-font-size, 16px);
    background-color: var(--icon-bg, #fff);
    color: var(--title-color);
    text-align: center;
    border-radius: 50%;
    border: none
}

.icon-btn:hover {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.icon-btn.style2 {
    border: 2px solid var(--white-color);
    background: transparent;
    color: var(--white-color)
}

.icon-btn.style2:hover {
    background: var(--white-color);
    color: var(--theme-color)
}

.play-btn {
    display: inline-block;
    position: relative;
    z-index: 1
}

.play-btn>i {
    display: inline-block;
    width: var(--icon-size, 100px);
    height: var(--icon-size, 100px);
    line-height: var(--icon-size, 100px);
    text-align: center;
    background-color: var(--white-color);
    color: var(--theme-color);
    font-size: var(--icon-font-size, 1.2em);
    border-radius: 50%;
    z-index: 1;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s
}

.play-btn:after,.play-btn:before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    background-color: var(--title-color);
    z-index: -1;
    border-radius: 50%;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s
}

.play-btn:after {
    -webkit-animation-delay: 2s;
    animation-delay: 2s
}

.play-btn:hover:after,.play-btn:hover::before,.play-btn:hover i {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.play-btn.style2>i {
    --icon-size: 40px;
    background: transparent;
    border: 1px solid var(--white-color);
    color: var(--white-color)
}

.play-btn.style2:after,.play-btn.style2:before {
    background: var(--white-color);
    opacity: 0.2;
    width: 80px;
    height: 80px;
    margin-top: -20px;
    margin-left: -20px
}

.play-btn.style3>i {
    --icon-size: 80px;
    background: var(--theme-color);
    color: var(--white-color);
    font-size: var(--icon-font-size, 24px)
}

.play-btn.style3:after,.play-btn.style3:before {
    background: var(--theme-color)
}

.play-btn.style3:hover>i {
    background: var(--white-color);
    color: var(--theme-color)
}

.play-btn.style3:hover:after,.play-btn.style3:hover:before {
    background: var(--white-color)
}

.play-btn.style4>i {
    --icon-size: 70px;
    background: var(--white-color);
    color: var(--theme-color);
    font-size: var(--icon-font-size, 24px)
}

.play-btn.style4:after,.play-btn.style4:before {
    background: var(--white-color)
}

.play-btn.style4:hover>i {
    background: var(--white-color);
    color: var(--theme-color)
}

.play-btn.style4:hover:after,.play-btn.style4:hover:before {
    background: var(--white-color)
}

.play-btn.style5>i {
    --icon-size: 60px;
    background: var(--white-color);
    color: var(--theme-color);
    font-size: var(--icon-font-size, 20px)
}

.play-btn.style5:after,.play-btn.style5:before {
    background: var(--theme-color)
}

.play-btn.style5:hover>i {
    background: var(--white-color);
    color: var(--theme-color)
}

.play-btn.style5:hover:after,.play-btn.style5:hover:before {
    background: var(--white-color)
}

.link-btn {
    font-weight: 500;
    font-size: 14px;
    display: inline-block;
    line-height: 0.8;
    position: relative;
    padding-bottom: 2px;
    margin-bottom: -2px;
    text-transform: uppercase;
    color: var(--theme-color)
}

.link-btn i {
    margin-left: 5px;
    font-size: 0.9rem
}

.link-btn:before {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    width: 0;
    height: 2px;
    background-color: var(--theme-color);
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s
}

.link-btn:hover {
    color: var(--theme-color)
}

.link-btn:hover::before {
    width: 100%
}

.link-btn.style2::before {
    width: 100%;
    height: 1px
}

.link-btn.style2:hover::before {
    width: 50%
}

.link-btn.style3 {
    padding-bottom: 4px;
    margin-bottom: -1px;
    color: var(--body-color)
}

.link-btn.style3:before {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    width: 51px;
    height: 1px;
    background-color: var(--body-color);
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s
}

.link-btn.style3:hover {
    color: var(--theme-color)
}

.link-btn.style3:hover::before {
    background-color: var(--theme-color);
    width: 100%
}

.scroll-top {
    position: fixed;
    right: 30px;
    bottom: 30px;
    height: 50px;
    width: 50px;
    cursor: pointer;
    display: block;
    border-radius: 50px;
    z-index: 10000;
    opacity: 1;
    visibility: hidden;
    -webkit-transform: translateY(45px);
    -ms-transform: translateY(45px);
    transform: translateY(45px);
    -webkit-transition: all 300ms linear;
    transition: all 300ms linear
}

.scroll-top:after {
    content: "\f062";
    font-family: var(--icon-font);
    position: absolute;
    text-align: center;
    line-height: 50px;
    font-size: 20px;
    color: var(--theme-color);
    left: 0;
    top: 0;
    height: 50px;
    width: 50px;
    cursor: pointer;
    display: block;
    z-index: 1;
    border: 2px solid var(--theme-color);
    box-shadow: none;
    border-radius: 50%
}

.scroll-top svg {
    color: var(--theme-color);
    border-radius: 50%;
    background: var(--white-color)
}

.scroll-top svg path {
    fill: none
}

.scroll-top .progress-circle path {
    stroke: var(--theme-color);
    stroke-width: 20px;
    box-sizing: border-box;
    -webkit-transition: all 400ms linear;
    transition: all 400ms linear
}

.scroll-top.show {
    opacity: 1;
    visibility: visible;
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0)
}

@media (max-width: 767px) {
    .play-btn {
        --icon-size: 60px
    }
}

.sec-title {
    margin-bottom: calc(var(--section-title-space) - 12px);
    margin-top: -0.23em
}

.sub-title {
    font-size: 18px;
    font-weight: 600;
    color: var(--theme-color);
    font-family: var(--title-font);
    text-transform: uppercase;
    margin-top: 20px;
    margin-bottom: 27px;
    display: block
}

.sub-title img {
    margin-right: -15px;
    margin-top: -21px
}

.sub-title.text-white img {
    -webkit-filter: brightness(999);
    filter: brightness(999)
}

.sub-title2 {
    font-size: 18px;
    font-weight: 600;
    font-family: var(--title-font);
    color: var(--theme-color);
    text-transform: capitalize;
    margin-bottom: 30px;
    display: inline-block;
    position: relative
}

.sub-title3 {
    font-size: 16px;
    font-weight: 600;
    text-transform: uppercase;
    color: var(--theme-color);
    letter-spacing: 4.8px;
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    margin-bottom: 20px;
    gap: 6px
}

.sub-title4 {
    font-size: 16px;
    font-weight: 600;
    color: var(--theme-color);
    padding-left: 15px;
    display: inline-block;
    margin-bottom: 33px;
    position: relative;
    line-height: 30px
}

.sub-title4:after {
    content: '';
    position: absolute;
    left: 0;
    height: 100%;
    width: 50%;
    background: #FFEAE1;
    z-index: -1
}

.sub-title5 {
    font-size: 16px;
    font-weight: 600;
    color: var(--theme-color);
    letter-spacing: 1.6px;
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    margin-bottom: 32px;
    gap: 0px;
    line-height: initial;
    padding-top: 7px
}

.sub-title5 img {
    margin-right: -24px;
    margin-top: -7px
}

.sub-title6 {
    font-size: 16px;
    font-weight: 600;
    color: var(--title-color);
    font-family: var(--title-font);
    text-transform: uppercase;
    margin-top: -0.41em;
    margin-bottom: 25px;
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 5px
}

.sub-title6 .dots {
    display: inline-block;
    width: 3px;
    height: 3px;
    background-color: inherit;
    border-radius: 99px;
    position: absolute;
    top: 0
}

.sub-title6 .dots:before,.sub-title6 .dots:after {
    content: '';
    height: inherit;
    width: inherit;
    background-color: inherit;
    border-radius: inherit;
    display: inline-block;
    position: absolute;
    top: 0
}

.sub-title6 .shape {
    display: inline-block;
    height: 3px;
    width: 40px;
    background-color: var(--theme-color);
    border-radius: 99px;
    position: relative
}

.sub-title6 .shape.left .dots {
    left: -6px
}

.sub-title6 .shape.left .dots:before {
    left: -6px
}

.sub-title6 .shape.left .dots:after {
    left: -12px
}

.sub-title6 .shape.right .dots {
    right: -6px
}

.sub-title6 .shape.right .dots:before {
    right: -6px
}

.sub-title6 .shape.right .dots:after {
    right: -12px
}

.sub-title7 {
    display: block;
    font-size: 16px;
    font-weight: 600;
    color: var(--theme-color);
    font-family: var(--title-font);
    text-transform: uppercase;
    letter-spacing: 0.2em;
    margin-top: -0.41em;
    margin-bottom: 25px;
    position: relative
}

.sub-title7 .box {
    display: inline-block;
    width: 24px;
    height: 24px;
    position: relative;
    top: 7px;
    margin-right: 4px
}

.sub-title7 .box:before,.sub-title7 .box:after {
    content: "";
    height: 16px;
    width: 16px;
    background-color: var(--theme-color);
    border-radius: 3px;
    display: inline-block;
    position: absolute
}

.sub-title7 .box:before {
    top: 0;
    left: 0;
    background-color: transparent;
    border: 2px solid var(--theme-color)
}

.sub-title7 .box:after {
    bottom: 0;
    right: 0
}

@media (max-width: 1199px) {
    .sub-title7 {
        margin-bottom:20px
    }
}

@media (max-width: 575px) {
    .sub-title7 {
        letter-spacing:0.14em
    }
}

.title-area {
    margin-bottom: calc(var(--section-title-space) - 12px);
    position: relative;
    z-index: 2
}

.title-area .sec-title {
    margin-bottom: 15px
}

.title-area.mb-0 .sec-title {
    margin-bottom: -0.31em
}

.sec-text {
    max-width: 670px
}

.shadow-title {
    font-size: 160px;
    font-weight: 900;
    color: transparent;
    line-height: 0.89;
    -webkit-text-stroke: 1px var(--title-color);
    opacity: 0.08;
    margin-top: -0.08em;
    margin-bottom: -100px;
    width: 100%;
    z-index: -1
}

.shadow-title.border-white {
    -webkit-text-stroke: 1px var(--white-color)
}

@media (max-width: 1399px) {
    .shadow-title {
        font-size:140px;
        margin-bottom: -90px
    }
}

@media (max-width: 1199px) {
    .shadow-title {
        font-size:120px;
        margin-bottom: -82px
    }
}

@media (max-width: 991px) {
    .shadow-title {
        font-size:100px
    }
}

@media (max-width: 767px) {
    .shadow-title {
        font-size:80px;
        margin-top: -3px;
        margin-bottom: -75px
    }
}

@media (max-width: 575px) {
    .shadow-title {
        font-size:70px;
        margin-top: 6px
    }
}

@media (max-width: 375px) {
    .shadow-title {
        font-size:60px;
        margin-top: 15px
    }
}

.title-area.text-center .sec-text {
    margin-left: auto;
    margin-right: auto
}

.box-title {
    font-size: 24px;
    line-height: 1.417;
    font-weight: 600;
    margin-top: -0.32em
}

.box-title a {
    color: inherit
}

.box-title a:hover {
    color: var(--theme-color)
}

.sec-btn {
    margin-bottom: var(--section-title-space)
}

@media (max-width: 1199px) {
    .title-area,.sec-title {
        --section-title-space: 60px
    }

    .title-area.mb-30,.sec-title.mb-30 {
        margin-bottom: 25px
    }

    .title-area.mb-40,.sec-title.mb-40 {
        margin-bottom: 28px
    }

    .title-area.mb-45,.sec-title.mb-45 {
        margin-bottom: 32px
    }

    .title-area.mb-50,.sec-title.mb-50 {
        margin-bottom: 35px
    }

    .title-area.mb-25,.sec-title.mb-25 {
        margin-bottom: 15px
    }

    .title-area.mb-35,.sec-title.mb-35 {
        margin-bottom: 25px
    }

    .sec-btn {
        --section-title-space: 65px
    }
}

@media (max-width: 991px) {
    .title-area,.sec-title {
        --section-title-space: 45px
    }

    .title-area.mb-45,.sec-title.mb-45 {
        margin-bottom: 27px
    }

    .title-area.mb-50,.sec-title.mb-50 {
        margin-bottom: 28px
    }

    .sec-btn {
        --section-title-space: 45px
    }
}

.image-scale-hover {
    overflow: hidden
}

.image-scale-hover img {
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s;
    -webkit-transform: scale(1.001);
    -ms-transform: scale(1.001);
    transform: scale(1.001)
}

.image-scale-hover:hover img {
    -webkit-transform: scale(1.2);
    -ms-transform: scale(1.2);
    transform: scale(1.2)
}

.rounded-20 {
    border-radius: 20px !important
}

.rounded-20 img {
    border-radius: inherit
}

@media (max-width: 767px) {
    .rounded-20 {
        border-radius:10px !important
    }
}

.z-index-step1 {
    position: relative;
    z-index: 4 !important
}

.z-index-common {
    position: relative;
    z-index: 3
}

.z-index-n1 {
    z-index: -1
}

.media-body {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1
}

.badge {
    position: absolute;
    width: -webkit-fit-content;
    width: -moz-fit-content;
    width: fit-content;
    display: inline-block;
    text-align: center;
    background-color: var(--theme-color2);
    color: var(--white-color);
    padding: 0.35em 0.55em;
    border-radius: 50%;
    top: -5px;
    right: -5px;
    font-weight: 400
}

.th-social {
    display: inline-block
}

.th-social a {
    display: inline-block;
    width: var(--icon-size, 46px);
    height: var(--icon-size, 46px);
    line-height: var(--icon-size, 46px);
    background-color: var(--white-color);
    color: var(--body-color);
    font-size: 16px;
    text-align: center;
    margin-right: 10px;
    border-radius: 50%
}

.th-social a:last-child {
    margin-right: 0
}

.th-social a:hover {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.th-social.style2 a {
    border-radius: 3px;
    border: 1px solid #DBE3EE;
    background: var(--white-color);
    color: #4D5765
}

.th-social.style2 a:hover {
    background: var(--theme-color);
    color: var(--white-color)
}

.th-social.style3 a {
    display: inline-block;
    width: var(--icon-size, 38px);
    height: var(--icon-size, 38px);
    line-height: var(--icon-size, 38px);
    background: rgba(14,18,29,0.08);
    color: #4D5765;
    border-radius: 50%
}

.th-social.style3 a:hover {
    background: var(--theme-color);
    color: var(--white-color)
}

.th-social.style4 a {
    display: inline-block;
    background: rgba(14,18,29,0.08);
    color: #4D5765
}

.th-social.style4 a:hover {
    background: var(--theme-color);
    color: var(--white-color)
}

.slider-shadow .slick-list {
    padding-top: 30px;
    padding-bottom: 30px;
    margin-bottom: -30px;
    margin-top: -30px
}

.btn-group {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 20px
}

.btn-group:has(.about-profile) {
    gap: 40px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.btn-group.style2 {
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 15px 30px
}

.video-box {
    position: relative;
    border-radius: 10px;
    overflow: hidden
}

@media (max-width: 991px) {
    .video-box {
        min-height:400px
    }

    .video-box img {
        height: 400px;
        object-fit: cover
    }
}

.video-box .overlay {
    width: 100%;
    height: 100%;
    background-color: var(--black-color);
    opacity: 0.6;
    position: absolute;
    inset: 0
}

.video-box .play-btn {
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    z-index: 2
}

.video-box .video-content {
    position: absolute;
    top: 50%;
    left: 0;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    text-align: center;
    width: 100%;
    padding: 30px 15px
}

.video-box .video-title {
    color: var(--white-color);
    margin: 0 auto 40px auto;
    font-weight: 500;
    max-width: 760px
}

@media (max-width: 1199px) {
    .video-box .video-title {
        margin:0 auto 30px auto
    }
}

.video-box .video-text {
    font-size: 14px;
    text-transform: uppercase;
    color: var(--white-color);
    display: block;
    margin-top: 20px
}

.video-box .icon-btn {
    background-color: transparent;
    border: 1px solid;
    color: var(--white-color);
    --btn-size: 80px;
    font-size: 20px
}

.video-box .icon-btn:hover {
    color: var(--theme-color)
}

.shape-mockup-wrap {
    z-index: 2;
    position: relative
}

.shape-mockup {
    position: absolute;
    z-index: -1
}

.shape-mockup.z-index3 {
    z-index: 3
}

.radius-10 {
    border-radius: 10px !important
}

.mfp-zoom-in .mfp-content {
    opacity: 0;
    -webkit-transition: all 0.4s ease;
    transition: all 0.4s ease;
    -webkit-transform: scale(0.7);
    -ms-transform: scale(0.7);
    transform: scale(0.7)
}

.mfp-zoom-in.mfp-bg {
    opacity: 0;
    -webkit-transition: all 0.4s ease;
    transition: all 0.4s ease
}

.mfp-zoom-in.mfp-ready .mfp-content {
    opacity: 1;
    -webkit-transform: scale(1);
    -ms-transform: scale(1);
    transform: scale(1)
}

.mfp-zoom-in.mfp-ready.mfp-bg {
    opacity: 0.7
}

.mfp-zoom-in.mfp-removing .mfp-content {
    -webkit-transform: scale(0.7);
    -ms-transform: scale(0.7);
    transform: scale(0.7);
    opacity: 0
}

.mfp-zoom-in.mfp-removing.mfp-bg {
    opacity: 0
}

.font-icon {
    font-family: var(--icon-font)
}

.font-title {
    font-family: var(--title-font)
}

.font-body {
    font-family: var(--body-font)
}

.fw-extralight {
    font-weight: 100
}

.fw-light {
    font-weight: 300
}

.fw-normal {
    font-weight: 400
}

.fw-medium {
    font-weight: 500
}

.fw-semibold {
    font-weight: 600
}

.fw-bold {
    font-weight: 700
}

.fw-extrabold {
    font-weight: 800
}

.fs-md {
    font-size: 18px
}

.fs-xs {
    font-size: 14px
}

.fs-40 {
    font-size: 40px
}

@media (max-width: 1199px) {
    .fs-40 {
        font-size:34px
    }
}

@media (max-width: 991px) {
    .fs-40 {
        font-size:30px
    }

    .fs-40.mt-n3 {
        margin-top: -0.6rem
    }

    .fs-40.mt-n2 {
        margin-top: -0.2rem
    }
}

.bg-theme {
    background-color: var(--theme-color) !important
}

.bg-theme2 {
    background-color: var(--theme-color2) !important
}

.bg-smoke {
    background-color: var(--smoke-color) !important
}

.bg-white {
    background-color: var(--white-color) !important
}

.bg-black {
    background-color: var(--black-color) !important
}

.bg-title {
    background-color: var(--title-color) !important
}

.gr-bg1 {
    background-image: -webkit-linear-gradient(194.6deg, rgba(146,184,253,0.15) 5.09%, var(--smoke-color) 63%);
    background-image: linear-gradient(255.4deg, rgba(146,184,253,0.15) 5.09%, var(--smoke-color) 63%)
}

.gr-bg2 {
    background-image: -webkit-linear-gradient(right, #EDF2FB 0%, #fff 100%);
    background-image: linear-gradient(270deg, #EDF2FB 0%, #fff 100%)
}

.background-image,[data-bg-src] {
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center
}

.bg-fluid {
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-position: center center
}

.bg-auto {
    background-size: auto auto
}

.bg-bottom-right {
    background-size: auto;
    background-position: bottom right
}

.bg-top-center {
    background-size: auto;
    background-position: top center
}

.bg-top-left {
    background-size: auto;
    background-position: top left
}

.bg-repeat {
    background-size: auto;
    background-repeat: repeat
}

.bg-top-right {
    background-size: auto;
    background-position: top right
}

.bg-contain-repeat {
    background-size: contain;
    background-repeat: repeat;
    background-position: center left
}

.half-bg-overlay {
    position: absolute;
    background: -webkit-linear-gradient(left, #0E121D 0%, rgba(14,18,29,0.932558) 17.6%, rgba(14,18,29,0.840787) 33.13%, rgba(14,18,29,0.772531) 42.4%, rgba(14,18,29,0.670209) 49.9%, rgba(14,18,29,0) 89.58%);
    background: linear-gradient(90deg, #0E121D 0%, rgba(14,18,29,0.932558) 17.6%, rgba(14,18,29,0.840787) 33.13%, rgba(14,18,29,0.772531) 42.4%, rgba(14,18,29,0.670209) 49.9%, rgba(14,18,29,0) 89.58%);
    height: 100%;
    width: 100%;
    top: 0;
    left: 0
}

.text-theme {
    color: var(--theme-color) !important
}

.text-theme2 {
    color: var(--theme-color2) !important
}

.text-title {
    color: var(--title-color) !important
}

.text-body {
    color: var(--body-color) !important
}

.text-white {
    color: var(--white-color) !important
}

.text-light {
    color: var(--light-color) !important
}

.text-yellow {
    color: var(--yellow-color) !important
}

.text-success {
    color: var(--success-color) !important
}

.text-error {
    color: var(--error-color) !important
}

.text-inherit {
    color: inherit
}

.text-inherit:hover {
    color: var(--theme-color)
}

a.text-theme:hover,.text-reset:hover {
    text-decoration: underline
}

.overlay {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%
}

.position-center {
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%)
}

[data-overlay] {
    position: relative;
    z-index: 2
}

[data-overlay] [class^="col-"],[data-overlay] [class*="col-"] {
    z-index: 1
}

[data-overlay]:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    z-index: 1
}

[data-overlay="theme"]:before {
    background-color: var(--theme-color)
}

[data-overlay="smoke"]:before {
    background-color: var(--smoke-color)
}

[data-overlay="title"]:before .header-layout8 .menu-bar-wrapper {
    background: #86003a !important;
    padding: 0 30px;
    border-radius: 20px;
    position: relative;
}

{
    background-color: #f1d8959e;
}

[data-overlay="white"]:before {
    background-color: var(--white-color)
}

[data-overlay="black"]:before {
    background-color: var(--black-color)
}

[data-overlay="overlay1"]:before {
    background-color: #041122
}

[data-overlay="overlay2"]:before {
    background-color: #EDEEF2
}

[data-opacity="1"]:before {
    opacity: .1
}

[data-opacity="2"]:before {
    opacity: .2
}

[data-opacity="3"]:before {
    opacity: .3
}

[data-opacity="4"]:before {
    opacity: .4
}

[data-opacity="5"]:before {
    opacity: .5
}

[data-opacity="6"]:before {
    opacity: .6
}

[data-opacity="7"]:before {
    opacity: .7
}

[data-opacity="8"]:before {
    opacity: .8
}

[data-opacity="9"]:before {
    opacity: .9
}

[data-opacity="10"]:before {
    opacity: 1
}

.ripple-animation,.play-btn:after,.play-btn:before,.cta-link-icon:after,.cta-link-icon:before {
    -webkit-animation-duration: var(--ripple-ani-duration);
    animation-duration: var(--ripple-ani-duration);
    -webkit-animation-timing-function: ease-in-out;
    animation-timing-function: ease-in-out;
    -webkit-animation-iteration-count: infinite;
    animation-iteration-count: infinite;
    -webkit-animation-name: ripple;
    animation-name: ripple
}

@-webkit-keyframes ripple {
    0% {
        -webkit-transform: scale(1);
        transform: scale(1);
        opacity: 0
    }

    30% {
        opacity: 0.4
    }

    100% {
        -webkit-transform: scale(1.5);
        transform: scale(1.5);
        opacity: 0
    }
}

@keyframes ripple {
    0% {
        -webkit-transform: scale(1);
        transform: scale(1);
        opacity: 0
    }

    30% {
        opacity: 0.4
    }

    100% {
        -webkit-transform: scale(1.5);
        transform: scale(1.5);
        opacity: 0
    }
}

.movingX {
    -webkit-animation: movingX 8s linear infinite;
    animation: movingX 8s linear infinite
}

@-webkit-keyframes movingX {
    0% {
        -webkit-transform: translateX(0);
        transform: translateX(0)
    }

    50% {
        -webkit-transform: translateX(50px);
        transform: translateX(50px)
    }

    100% {
        -webkit-transform: translateX(0);
        transform: translateX(0)
    }
}

@keyframes movingX {
    0% {
        -webkit-transform: translateX(0);
        transform: translateX(0)
    }

    50% {
        -webkit-transform: translateX(50px);
        transform: translateX(50px)
    }

    100% {
        -webkit-transform: translateX(0);
        transform: translateX(0)
    }
}

.moving {
    -webkit-animation: moving 8s linear infinite;
    animation: moving 8s linear infinite
}

@-webkit-keyframes moving {
    0% {
        -webkit-transform: translateX(0);
        transform: translateX(0)
    }

    50% {
        -webkit-transform: translateX(-50px);
        transform: translateX(-50px)
    }

    100% {
        -webkit-transform: translateX(0);
        transform: translateX(0)
    }
}

@keyframes moving {
    0% {
        -webkit-transform: translateX(0);
        transform: translateX(0)
    }

    50% {
        -webkit-transform: translateX(-50px);
        transform: translateX(-50px)
    }

    100% {
        -webkit-transform: translateX(0);
        transform: translateX(0)
    }
}

.jump {
    -webkit-animation: jumpAni 7s linear infinite;
    animation: jumpAni 7s linear infinite
}

@-webkit-keyframes jumpAni {
    0% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }

    40% {
        -webkit-transform: translateY(-30px);
        transform: translateY(-30px)
    }

    100% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }
}

@keyframes jumpAni {
    0% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }

    40% {
        -webkit-transform: translateY(-30px);
        transform: translateY(-30px)
    }

    100% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }
}

.jump-reverse {
    -webkit-animation: jumpReverseAni 7s linear infinite;
    animation: jumpReverseAni 7s linear infinite
}

@-webkit-keyframes jumpReverseAni {
    0% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }

    50% {
        -webkit-transform: translateY(30px);
        transform: translateY(30px)
    }

    100% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }
}

@keyframes jumpReverseAni {
    0% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }

    50% {
        -webkit-transform: translateY(30px);
        transform: translateY(30px)
    }

    100% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }
}

.spin {
    -webkit-animation: spin 15s linear infinite;
    animation: spin 15s linear infinite
}

@-webkit-keyframes spin {
    0% {
        -webkit-transform: rotate(0);
        transform: rotate(0)
    }

    100% {
        -webkit-transform: rotate(360deg);
        transform: rotate(360deg)
    }
}

@keyframes spin {
    0% {
        -webkit-transform: rotate(0);
        transform: rotate(0)
    }

    100% {
        -webkit-transform: rotate(360deg);
        transform: rotate(360deg)
    }
}

@-webkit-keyframes scrollMove {
    0% {
        opacity: 0
    }

    50% {
        opacity: 1
    }

    100% {
        opacity: 0;
        -webkit-transform: translateY(10px);
        transform: translateY(10px)
    }
}

@keyframes scrollMove {
    0% {
        opacity: 0
    }

    50% {
        opacity: 1
    }

    100% {
        opacity: 0;
        -webkit-transform: translateY(10px);
        transform: translateY(10px)
    }
}

.bounce {
    -webkit-animation: bounce 2s infinite;
    animation: bounce 2s infinite
}

@-webkit-keyframes bounce {
    0%,20%,50%,80%,100% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }

    40% {
        -webkit-transform: translateY(15px);
        transform: translateY(15px)
    }

    60% {
        -webkit-transform: translateY(5px);
        transform: translateY(5px)
    }
}

@keyframes bounce {
    0%,20%,50%,80%,100% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }

    40% {
        -webkit-transform: translateY(15px);
        transform: translateY(15px)
    }

    60% {
        -webkit-transform: translateY(5px);
        transform: translateY(5px)
    }
}

@-webkit-keyframes rotate {
    0% {
        -webkit-transform: rotate(0);
        transform: rotate(0)
    }

    50% {
        -webkit-transform: rotate(40deg);
        transform: rotate(40deg)
    }

    100% {
        -webkit-transform: rotate(0);
        transform: rotate(0)
    }
}

@keyframes rotate {
    0% {
        -webkit-transform: rotate(0);
        transform: rotate(0)
    }

    50% {
        -webkit-transform: rotate(40deg);
        transform: rotate(40deg)
    }

    100% {
        -webkit-transform: rotate(0);
        transform: rotate(0)
    }
}

@-webkit-keyframes animate-positive {
    0% {
        width: 0
    }
}

@keyframes animate-positive {
    0% {
        width: 0
    }
}

.scalein.th-animated {
    --animation-name: scalein
}

.slidetopleft.th-animated {
    --animation-name: slidetopleft
}

.slidebottomright.th-animated {
    --animation-name: slidebottomright
}

.slideinleft.th-animated {
    --animation-name: slideinleft
}

.slideinright.th-animated {
    --animation-name: slideinright
}

.slideinup.th-animated {
    --animation-name: slideinup
}

.slideindown.th-animated {
    --animation-name: slideindown
}

.rollinleft.th-animated {
    --animation-name: rollinleft
}

.rollinright.th-animated {
    --animation-name: rollinright
}

.slidetopleft,.slidebottomright,.slideinleft,.slideinright,.slideindown,.slideinup,.rollinleft,.rollinright {
    opacity: 0;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
    -webkit-animation-iteration-count: 1;
    animation-iteration-count: 1;
    -webkit-animation-duration: 1s;
    animation-duration: 1s;
    -webkit-animation-delay: 0.3s;
    animation-delay: 0.3s;
    -webkit-animation-name: var(--animation-name);
    animation-name: var(--animation-name)
}

.th-animated {
    opacity: 1
}

@-webkit-keyframes slideinup {
    0% {
        opacity: 0;
        -webkit-transform: translateY(70px);
        transform: translateY(70px)
    }

    100% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }
}

@keyframes slideinup {
    0% {
        opacity: 0;
        -webkit-transform: translateY(70px);
        transform: translateY(70px)
    }

    100% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }
}

@-webkit-keyframes slideinright {
    0% {
        opacity: 0;
        -webkit-transform: translateX(70px);
        transform: translateX(70px)
    }

    100% {
        -webkit-transform: translateX(0);
        transform: translateX(0)
    }
}

@keyframes slideinright {
    0% {
        opacity: 0;
        -webkit-transform: translateX(70px);
        transform: translateX(70px)
    }

    100% {
        -webkit-transform: translateX(0);
        transform: translateX(0)
    }
}

@-webkit-keyframes slideindown {
    0% {
        opacity: 0;
        -webkit-transform: translateY(-70px);
        transform: translateY(-70px)
    }

    100% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }
}

@keyframes slideindown {
    0% {
        opacity: 0;
        -webkit-transform: translateY(-70px);
        transform: translateY(-70px)
    }

    100% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }
}

@-webkit-keyframes slideinleft {
    0% {
        opacity: 0;
        -webkit-transform: translateX(-70px);
        transform: translateX(-70px)
    }

    100% {
        -webkit-transform: translateX(0);
        transform: translateX(0)
    }
}

@keyframes slideinleft {
    0% {
        opacity: 0;
        -webkit-transform: translateX(-70px);
        transform: translateX(-70px)
    }

    100% {
        -webkit-transform: translateX(0);
        transform: translateX(0)
    }
}

@-webkit-keyframes slidebottomright {
    0% {
        opacity: 0;
        -webkit-transform: translateX(100px) translateY(100px);
        transform: translateX(100px) translateY(100px)
    }

    100% {
        -webkit-transform: translateX(0) translateY(0);
        transform: translateX(0) translateY(0)
    }
}

@keyframes slidebottomright {
    0% {
        opacity: 0;
        -webkit-transform: translateX(100px) translateY(100px);
        transform: translateX(100px) translateY(100px)
    }

    100% {
        -webkit-transform: translateX(0) translateY(0);
        transform: translateX(0) translateY(0)
    }
}

@-webkit-keyframes slidetopleft {
    0% {
        opacity: 0;
        -webkit-transform: translateX(-100px) translateY(-100px);
        transform: translateX(-100px) translateY(-100px)
    }

    100% {
        -webkit-transform: translateX(0) translateY(0);
        transform: translateX(0) translateY(0)
    }
}

@keyframes slidetopleft {
    0% {
        opacity: 0;
        -webkit-transform: translateX(-100px) translateY(-100px);
        transform: translateX(-100px) translateY(-100px)
    }

    100% {
        -webkit-transform: translateX(0) translateY(0);
        transform: translateX(0) translateY(0)
    }
}

.scalein {
    -webkit-animation: scalein 7s linear infinite;
    animation: scalein 7s linear infinite
}

@-webkit-keyframes scalein {
    0% {
        opacity: 0;
        -webkit-transform: scale(0.3);
        transform: scale(0.3)
    }

    100% {
        -webkit-transform: scale(1);
        transform: scale(1)
    }
}

@keyframes scalein {
    0% {
        opacity: 0;
        -webkit-transform: scale(0.3);
        transform: scale(0.3)
    }

    100% {
        -webkit-transform: scale(1);
        transform: scale(1)
    }
}

@-webkit-keyframes rollinleft {
    0% {
        opacity: 0;
        -webkit-transform: translateX(-100%) rotate(-120deg);
        transform: translateX(-100%) rotate(-120deg)
    }

    to {
        -webkit-transform: translateX(0) rotate(0deg);
        transform: translateX(0) rotate(0deg)
    }
}

@keyframes rollinleft {
    0% {
        opacity: 0;
        -webkit-transform: translateX(-100%) rotate(-120deg);
        transform: translateX(-100%) rotate(-120deg)
    }

    to {
        -webkit-transform: translateX(0) rotate(0deg);
        transform: translateX(0) rotate(0deg)
    }
}

@-webkit-keyframes rollinright {
    0% {
        opacity: 0;
        -webkit-transform: translateX(100%) rotate(120deg);
        transform: translateX(100%) rotate(120deg)
    }

    to {
        -webkit-transform: translateX(0) rotate(0deg);
        transform: translateX(0) rotate(0deg)
    }
}

@keyframes rollinright {
    0% {
        opacity: 0;
        -webkit-transform: translateX(100%) rotate(120deg);
        transform: translateX(100%) rotate(120deg)
    }

    to {
        -webkit-transform: translateX(0) rotate(0deg);
        transform: translateX(0) rotate(0deg)
    }
}

.widget_nav_menu ul,.widget_meta ul,.widget_pages ul,.widget_archive ul,.widget_price_filter ul,.widget_time_duration ul,.widget_instructor ul,.widget_categories ul {
    list-style: none;
    padding: 0;
    margin: 0 0 0 0
}

.widget_nav_menu .menu,.widget_nav_menu .wp-block-categories,.widget_nav_menu>ul,.widget_meta .menu,.widget_meta .wp-block-categories,.widget_meta>ul,.widget_pages .menu,.widget_pages .wp-block-categories,.widget_pages>ul,.widget_archive .menu,.widget_archive .wp-block-categories,.widget_archive>ul,.widget_price_filter .menu,.widget_price_filter .wp-block-categories,.widget_price_filter>ul,.widget_time_duration .menu,.widget_time_duration .wp-block-categories,.widget_time_duration>ul,.widget_instructor .menu,.widget_instructor .wp-block-categories,.widget_instructor>ul,.widget_categories .menu,.widget_categories .wp-block-categories,.widget_categories>ul {
    margin: 0 0 -20px 0
}

.widget_nav_menu a,.widget_meta a,.widget_pages a,.widget_archive a,.widget_price_filter a,.widget_time_duration a,.widget_instructor a,.widget_categories a {
    display: block;
    margin: 0 0 20px 0;
    padding: 0 35px 20px 24px;
    border-bottom: 1px solid var(--border-color);
    font-size: 16px;
    font-weight: 400;
    line-height: 1.18;
    color: var(--body-color)
}

.widget_nav_menu a::before,.widget_meta a::before,.widget_pages a::before,.widget_archive a::before,.widget_price_filter a::before,.widget_time_duration a::before,.widget_instructor a::before,.widget_categories a::before {
    content: '\f101';
    width: 18px;
    height: 18px;
    border-radius: 4px;
    line-height: 18px;
    font-size: 0.8em;
    text-align: center;
    position: absolute;
    left: 0;
    top: 0;
    font-family: var(--icon-font);
    font-weight: 700;
    color: var(--theme-color);
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s
}

.widget_nav_menu a:hover,.widget_meta a:hover,.widget_pages a:hover,.widget_archive a:hover,.widget_price_filter a:hover,.widget_time_duration a:hover,.widget_instructor a:hover,.widget_categories a:hover {
    color: var(--theme-color)
}

.widget_nav_menu a:hover ~ span,.widget_meta a:hover ~ span,.widget_pages a:hover ~ span,.widget_archive a:hover ~ span,.widget_price_filter a:hover ~ span,.widget_time_duration a:hover ~ span,.widget_instructor a:hover ~ span,.widget_categories a:hover ~ span {
    color: var(--theme-color)
}

.widget_nav_menu li,.widget_meta li,.widget_pages li,.widget_archive li,.widget_price_filter li,.widget_time_duration li,.widget_instructor li,.widget_categories li {
    display: block;
    position: relative
}

.widget_nav_menu li>span,.widget_meta li>span,.widget_pages li>span,.widget_archive li>span,.widget_price_filter li>span,.widget_time_duration li>span,.widget_instructor li>span,.widget_categories li>span {
    text-align: center;
    position: absolute;
    right: 0;
    top: 0;
    font-size: 16px;
    line-height: 1.18;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s;
    color: var(--body-color);
    font-weight: 400
}

.widget_nav_menu .children,.widget_meta .children,.widget_pages .children,.widget_archive .children,.widget_price_filter .children,.widget_time_duration .children,.widget_instructor .children,.widget_categories .children {
    margin-left: 10px
}

.widget_nav_menu .sub-cat,.widget_meta .sub-cat,.widget_pages .sub-cat,.widget_archive .sub-cat,.widget_price_filter .sub-cat,.widget_time_duration .sub-cat,.widget_instructor .sub-cat,.widget_categories .sub-cat {
    margin-left: 30px
}

.widget_nav_menu input[type="checkbox"]:checked ~ label:before,.widget_meta input[type="checkbox"]:checked ~ label:before,.widget_pages input[type="checkbox"]:checked ~ label:before,.widget_archive input[type="checkbox"]:checked ~ label:before,.widget_price_filter input[type="checkbox"]:checked ~ label:before,.widget_time_duration input[type="checkbox"]:checked ~ label:before,.widget_instructor input[type="checkbox"]:checked ~ label:before,.widget_categories input[type="checkbox"]:checked ~ label:before {
    border-radius: 4px
}

.widget_nav_menu.style2 li,.widget_meta.style2 li,.widget_pages.style2 li,.widget_archive.style2 li,.widget_price_filter.style2 li,.widget_time_duration.style2 li,.widget_instructor.style2 li,.widget_categories.style2 li {
    margin-top: 18px
}

.widget_nav_menu>ul>li:last-child a,.widget_meta>ul>li:last-child a,.widget_pages>ul>li:last-child a,.widget_archive>ul>li:last-child a,.widget_price_filter>ul>li:last-child a,.widget_time_duration>ul>li:last-child a,.widget_instructor>ul>li:last-child a,.widget_categories>ul>li:last-child a {
    border-bottom: none;
    padding-bottom: 0
}

.widget_nav_menu a,.widget_meta a,.widget_pages a {
    padding-right: 20px
}

.widget_nav_menu .sub-menu {
    margin-left: 10px
}

.wp-block-archives {
    list-style: none;
    margin: 0;
    padding: 0;
    margin-bottom: 20px
}

.wp-block-archives a:not(:hover) {
    color: inherit
}

.th-blog ul.wp-block-archives li {
    margin: 5px 0
}

.widget {
    padding: var(--blog-space-y, 40px) var(--blog-space-x, 40px);
    border-radius: 0px;
    margin-bottom: 40px;
    position: relative;
    background-color: var(--smoke-color)
}

.widget select,.widget input {
    height: 55px;
    border-radius: 0px;
    border: none !important;
    background-color: var(--white-color)
}

.widget.blog-widget-cta {
    padding: 0;
    margin: 0;
    border: 0;
    box-shadow: none
}

.wp-block-search__label,.widget_title {
    position: relative;
    font-size: 24px;
    font-weight: 600;
    font-family: var(--title-font);
    line-height: 1em;
    margin: -0.1em 0 29px 0;
    padding-bottom: 16px;
    text-transform: uppercase;
    border-bottom: 3px solid var(--border-color)
}

.wp-block-search__label a,.widget_title a {
    color: inherit
}

.widget .search-form {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    border-radius: 0px;
    background: var(--white-color);
    box-shadow: 0px 13px 25px 0px rgba(0,0,0,0.04);
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.widget .search-form input {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    padding-right: 8px;
    font-size: 14px;
    background: transparent
}

.widget .search-form button {
    border: none;
    width: 55px;
    height: 55px;
    line-height: 55px;
    background-color: var(--theme-color);
    color: var(--white-color);
    display: inline-block;
    border-radius: 0;
    position: relative
}

.widget .search-form button:hover {
    background: var(--title-color)
}

.wp-block-tag-cloud a,.tagcloud a {
    display: inline-block;
    border: none;
    line-height: 1;
    padding: 13px 17px;
    margin-right: 5px;
    margin-bottom: 10px;
    text-transform: capitalize;
    color: var(--body-color);
    font-size: 14px;
    background-color: var(--white-color);
    box-shadow: 0px 4px 20px 0px rgba(0,0,0,0.05);
    border-radius: 0px
}

.wp-block-tag-cloud a:hover,.tagcloud a:hover {
    background-color: var(--theme-color);
    color: var(--white-color) !important
}

.tagcloud,.wp-block-tag-cloud {
    margin-right: -10px;
    margin-bottom: -10px
}

.recent-post {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    margin-bottom: 25px;
    line-height: 20px
}

.recent-post:last-child {
    margin-bottom: 0
}

.recent-post .media-img {
    margin-right: 20px;
    width: 80px;
    border-radius: 0px;
    overflow: hidden
}

.recent-post .media-img img {
    width: 100%;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.recent-post .post-title {
    font-weight: 600;
    font-size: 20px;
    line-height: 28px;
    margin: 0 0 -0.1em 0;
    font-family: var(--title-font)
}

@media (max-width: 1299px) {
    .recent-post .post-title {
        font-size:17px
    }
}

.recent-post .recent-post-meta {
    margin-bottom: 10px;
    font-size: 14px
}

.recent-post .recent-post-meta a {
    text-transform: capitalize;
    color: var(--body-color)
}

.recent-post .recent-post-meta a:hover {
    color: var(--theme-color)
}

.recent-post .recent-post-meta a i {
    margin-right: 8px;
    color: var(--theme-color)
}

.recent-post:hover .media-img img {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1)
}

.sidebar-gallery {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px
}

.sidebar-gallery .gallery-thumb {
    overflow: hidden;
    border-radius: 6px
}

.sidebar-gallery .gallery-thumb img {
    width: 100%
}

figure.wp-block-gallery-1.wp-block-gallery.has-nested-images.columns-default.is-cropped {
    margin-bottom: 0 !important
}

.wp-block-gallery.columns-default {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px
}

.wp-block-gallery.columns-default figure.wp-block-image:not(#individual-image) {
    width: 100% !important;
    overflow: hidden;
    border-radius: 6px
}

.wp-block-gallery.columns-default figure.wp-block-image:not(#individual-image) img {
    width: 100%
}

.th-video-widget .video-thumb {
    position: relative
}

.th-video-widget .play-btn {
    --icon-size: 60px;
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%)
}

.th-video-widget .play-btn i {
    font-size: 16px
}

.th-video-widget .video-thumb-title {
    font-size: 20px;
    font-weight: 600;
    line-height: 1.4;
    margin-top: 10px;
    margin-bottom: -0.3em
}

.widget_recent_entries ul {
    margin: -0.3em 0 0 0;
    padding: 0;
    list-style: none
}

.widget_recent_entries ul li>a {
    color: var(--body-color);
    font-weight: 500;
    display: inline-block
}

.widget_recent_entries ul li>a:hover {
    color: var(--theme-color)
}

.widget_recent_entries ul li span.post-date {
    font-size: 14px
}

.widget_recent_entries ul li:not(:last-child) {
    border-bottom: 1px solid #dadada;
    padding-bottom: 12px;
    margin-bottom: 12px
}

.widget_recent_comments ul,.wp-block-latest-comments ul {
    list-style-type: none;
    padding-left: 0
}

ul.widget_recent_comments,ol.widget_recent_comments,.wp-block-latest-comments {
    margin-top: -0.11em;
    padding-left: 0
}

.widget_recent_comments ol,.widget_recent_comments ul,.wp-block-latest-comments ol,.wp-block-latest-comments ul {
    margin-bottom: 0
}

.widget_recent_comments li,.wp-block-latest-comments li {
    margin-bottom: 0;
    color: var(--body-color);
    padding-left: 30px;
    position: relative
}

.widget_recent_comments li:before,.wp-block-latest-comments li:before {
    content: "\f086";
    position: absolute;
    left: 0;
    top: -1px;
    color: var(--theme-color);
    font-family: var(--icon-font)
}

.widget_recent_comments.has-avatars li,.wp-block-latest-comments.has-avatars li {
    padding-left: 0;
    padding-bottom: 0 !important
}

.widget_recent_comments.has-avatars li:before,.wp-block-latest-comments.has-avatars li:before {
    display: none
}

.widget_recent_comments .avatar,.wp-block-latest-comments .avatar {
    margin-top: 0.4em
}

.widget_recent_comments li:not(:last-child),.wp-block-latest-comments li:not(:last-child) {
    padding-bottom: 12px
}

.widget_recent_comments article,.wp-block-latest-comments article {
    line-height: 1.5
}

.widget_recent_comments a,.wp-block-latest-comments a {
    color: inherit
}

.widget_recent_comments a:hover,.wp-block-latest-comments a:hover {
    color: var(--theme-color)
}

.wp-block-latest-comments__comment {
    line-height: 1.6
}

.wp-block-latest-comments__comment a {
    color: var(--body-color)
}

.wp-block-latest-comments__comment a:hover {
    color: var(--theme-color)
}

.wp-block-latest-comments__comment:last-child {
    margin-bottom: 0
}

.wp-block-calendar tbody td,.wp-block-calendar th {
    padding: 10px
}

.wp-block-calendar,.calendar_wrap {
    position: relative;
    background-color: #fff;
    padding-bottom: 0;
    border: none
}

.wp-block-calendar span[class*="wp-calendar-nav"],.calendar_wrap span[class*="wp-calendar-nav"] {
    position: absolute;
    top: 9px;
    left: 20px;
    font-size: 14px;
    color: var(--white-color);
    font-weight: 400;
    z-index: 1;
    line-height: 1.7
}

.wp-block-calendar span[class*="wp-calendar-nav"] a,.calendar_wrap span[class*="wp-calendar-nav"] a {
    color: inherit
}

.wp-block-calendar span.wp-calendar-nav-next,.calendar_wrap span.wp-calendar-nav-next {
    left: auto;
    right: 20px
}

.wp-block-calendar caption,.calendar_wrap caption {
    caption-side: top;
    text-align: center;
    color: var(--white-color);
    background-color: var(--theme-color)
}

.wp-block-calendar th,.calendar_wrap th {
    font-size: 14px;
    padding: 5px 5px;
    border: none;
    text-align: center;
    border-right: 1px solid #fff;
    color: var(--title-color);
    font-weight: 500
}

.wp-block-calendar th:first-child,.calendar_wrap th:first-child {
    border-left: 1px solid #eee
}

.wp-block-calendar th:last-child,.calendar_wrap th:last-child {
    border-right: 1px solid #eee
}

.wp-block-calendar table th,.calendar_wrap table th {
    font-weight: 500
}

.wp-block-calendar td,.calendar_wrap td {
    font-size: 14px;
    padding: 5px 5px;
    color: #01133c;
    border: 1px solid #eee;
    text-align: center;
    background-color: transparent;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s
}

.wp-block-calendar #today,.calendar_wrap #today {
    color: var(--theme-color);
    background-color: var(--white-color);
    border-color: #ededed
}

.wp-block-calendar thead,.calendar_wrap thead {
    background-color: #eee
}

.wp-block-calendar .wp-calendar-table,.calendar_wrap .wp-calendar-table {
    margin-bottom: 0
}

.wp-block-calendar .wp-calendar-nav .pad,.calendar_wrap .wp-calendar-nav .pad {
    display: none
}

.wp-block-calendar a,.calendar_wrap a {
    color: inherit;
    text-decoration: none
}

.wp-block-calendar a:hover,.calendar_wrap a:hover {
    color: var(--title-color)
}

.wp-block-calendar {
    margin-bottom: 30px;
    border: none;
    padding-bottom: 0
}

.wp-block-calendar table caption {
    color: var(--white-color)
}

ul.widget_rss,ul.wp-block-rss,ol.widget_rss,ol.wp-block-rss {
    padding-left: 0
}

.widget_rss,.wp-block-rss {
    list-style-type: none
}

.widget_rss ul,.wp-block-rss ul {
    margin: -0.2em 0 -0.5em 0;
    padding: 0;
    list-style: none
}

.widget_rss ul .rsswidget,.wp-block-rss ul .rsswidget {
    color: var(--title-color);
    font-family: var(--theme-font);
    font-size: 18px;
    display: block;
    margin-bottom: 10px
}

.widget_rss ul .rssSummary,.wp-block-rss ul .rssSummary {
    font-size: 14px;
    margin-bottom: 7px;
    line-height: 1.5
}

.widget_rss ul a,.wp-block-rss ul a {
    display: block;
    font-weight: 600;
    color: inherit
}

.widget_rss ul a:hover,.wp-block-rss ul a:hover {
    color: var(--theme-color)
}

.widget_rss ul .rss-date,.wp-block-rss ul .rss-date {
    font-size: 14px;
    display: inline-block;
    margin-bottom: 5px;
    font-weight: 400;
    color: var(--title-color)
}

.widget_rss ul .rss-date:before,.wp-block-rss ul .rss-date:before {
    content: "\f073";
    font-family: var(--icon-font);
    margin-right: 10px;
    font-weight: 300;
    color: var(--theme-color)
}

.widget_rss ul cite,.wp-block-rss ul cite {
    font-weight: 500;
    color: var(--title-color);
    font-family: var(--body-font);
    font-size: 14px
}

.widget_rss ul cite:before,.wp-block-rss ul cite:before {
    content: "";
    position: relative;
    top: -1px;
    left: 0;
    width: 20px;
    height: 2px;
    display: inline-block;
    vertical-align: middle;
    margin-right: 8px;
    background-color: var(--theme-color)
}

.widget_rss li:not(:last-child),.wp-block-rss li:not(:last-child) {
    margin-bottom: 16px;
    border-bottom: 1px solid rgba(0,0,0,0.1);
    padding-bottom: 16px
}

.widget_rss a:hover,.wp-block-rss a:hover {
    color: var(--theme-color)
}

.textwidget {
    margin-top: -0.1em
}

.widget_shopping_cart .widget_title {
    margin-bottom: 15px;
    border-bottom: none
}

.widget_shopping_cart ul {
    margin: 0;
    padding: 0
}

.widget_shopping_cart ul li {
    list-style-type: none
}

.widget_shopping_cart .mini_cart_item {
    position: relative;
    padding: 30px 10px 30px 90px;
    border-bottom: 1px solid rgba(0,0,0,0.1);
    margin-bottom: 0;
    text-align: left
}

.widget_shopping_cart .mini_cart_item:first-child {
    border-top: 1px solid rgba(0,0,0,0.1)
}

.widget_shopping_cart .cart_list a:not(.remove) {
    display: block;
    color: var(--body-color);
    font-size: 16px;
    font-weight: 500;
    font-family: var(--title-font);
    font-weight: 600;
    color: var(--title-color)
}

.widget_shopping_cart .cart_list a:not(.remove):hover {
    color: var(--theme-color)
}

.widget_shopping_cart .cart_list a.remove {
    position: absolute;
    top: 50%;
    left: 95%;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    color: var(--body-color)
}

.widget_shopping_cart .cart_list a.remove:hover {
    color: var(--theme-color)
}

.widget_shopping_cart .cart_list img {
    width: 75px;
    height: 75px;
    position: absolute;
    left: 0;
    top: 20px;
    border: 1px solid var(--border-color)
}

.widget_shopping_cart .quantity {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    white-space: nowrap;
    vertical-align: top;
    margin-right: 20px;
    font-size: 14px;
    color: var(--theme-color)
}

.widget_shopping_cart .total {
    margin-top: 20px;
    font-size: 18px;
    color: var(--title-color)
}

.widget_shopping_cart .amount {
    padding-left: 5px;
    font-weight: 600;
    font-family: var(--title-font)
}

.widget_shopping_cart .th-btn {
    margin-right: 15px
}

.widget_shopping_cart .th-btn:last-child {
    margin-right: 0
}

.sidemenu-area .widget_title,.sidebar-area .widget_title {
    position: relative
}

.sidemenu-area .widget_title:before,.sidebar-area .widget_title:before {
    content: '';
    height: 3px;
    width: 50px;
    background-color: var(--theme-color);
    position: absolute;
    bottom: -3px;
    left: 0;
    z-index: 1;
    -webkit-animation: lineMove 10s linear infinite;
    animation: lineMove 10s linear infinite
}

.sidemenu-area .widget_shopping_cart .th-btn,.sidebar-area .widget_shopping_cart .th-btn {
    margin-right: 10px;
    padding: 8px 22px;
    font-size: 14px
}

@-webkit-keyframes lineMove {
    0% {
        left: 0px
    }

    50% {
        left: calc(100% - 50px)
    }

    100% {
        left: 0px
    }
}

@keyframes lineMove {
    0% {
        left: 0px
    }

    50% {
        left: calc(100% - 50px)
    }

    100% {
        left: 0px
    }
}

.sidebar-area .widget_shopping_cart .th-btn {
    margin-right: 10px;
    padding: 8px 22px;
    font-size: 14px
}

.sidebar-area {
    margin-bottom: -10px
}

.sidebar-area .th-video {
    padding: 0;
    box-shadow: none;
    border-radius: 5px
}

.sidebar-area .th-video .play-btn {
    --icon-size: 50px;
    font-size: 15px
}

.sidebar-area .th-video .play-btn>i {
    background-color: var(--white-color);
    color: var(--theme-color)
}

.sidebar-area .th-video .play-btn:after,.sidebar-area .th-video .play-btn:before {
    background-color: var(--white-color)
}

.sidebar-area ul.wp-block-latest-posts {
    margin-bottom: 0
}

.sidebar-area ul.wp-block-latest-posts li:last-child {
    margin-bottom: 0
}

.sidebar-area .wp-block-tag-cloud a,.sidebar-area .tagcloud a {
    border: none
}

.sidebar-area .newsletter-form button {
    width: 100%;
    text-transform: capitalize;
    font-size: 16px;
    font-weight: 400;
    height: 60px;
    margin-top: 10px
}

.sidebar-area .widget .wp-block-search {
    margin-bottom: 0
}

.sidebar-area .wp-block-group__inner-container h2 {
    font-size: 20px;
    line-height: 1em;
    margin-bottom: 20px;
    margin-top: -0.07em
}

.sidebar-area ol.wp-block-latest-comments {
    padding: 0;
    margin: 0
}

.sidebar-area ol.wp-block-latest-comments li {
    line-height: 1.5;
    margin: 0 0 20px 0;
    border-bottom: 1px solid rgba(0,0,0,0.1);
    padding-bottom: 20px
}

.sidebar-area ol.wp-block-latest-comments li:last-child {
    margin-bottom: 0;
    padding-bottom: 0;
    border-bottom: none
}

.recent-product {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex
}

.recent-product .product-title {
    font-size: 16px
}

.price_slider_wrapper {
    margin-top: -0.5em
}

.price_slider_wrapper .price_label span {
    display: inline-block;
    color: var(--body-color)
}

.price_slider_wrapper .ui-slider {
    height: 4px;
    position: relative;
    width: 100%;
    background-color: #e0e0e0;
    border: none;
    margin-top: 10px;
    margin-bottom: 20px;
    cursor: pointer;
    border-radius: 0
}

.price_slider_wrapper .ui-slider-range {
    border: none;
    cursor: pointer;
    position: absolute;
    top: 0;
    height: 100%;
    z-index: 1;
    display: block;
    background-color: var(--theme-color)
}

.price_slider_wrapper .ui-slider-handle {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    text-align: center;
    line-height: 10.5px;
    padding: 0;
    border: none;
    cursor: pointer;
    position: absolute;
    margin-top: -3px;
    z-index: 2;
    box-shadow: 0px 8px 13px 0px rgba(255,79,38,0.21);
    background-color: var(--theme-color);
    -webkit-transform: translateX(-1px);
    -ms-transform: translateX(-1px);
    transform: translateX(-1px)
}

.price_slider_wrapper .ui-slider-handle:focus {
    outline: none;
    box-shadow: 1.5px 2.598px 10px 0px rgba(0,0,0,0.15)
}

.price_slider_wrapper .ui-slider-handle:last-child {
    -webkit-transform: translateX(-9px);
    -ms-transform: translateX(-9px);
    transform: translateX(-9px)
}

.price_slider_wrapper button,.price_slider_wrapper .button {
    background-color: var(--theme-color);
    color: var(--white-color);
    font-weight: 500;
    line-height: 1.6;
    text-transform: capitalize;
    text-align: center;
    border-radius: 50px;
    border: none;
    display: inline-block;
    overflow: hidden;
    position: relative;
    z-index: 2;
    padding: 7px 20px;
    min-width: 100px;
    font-size: 16px;
    -webkit-transition: 0.4s ease-in;
    transition: 0.4s ease-in
}

.price_slider_wrapper button:hover,.price_slider_wrapper .button:hover {
    background-color: var(--title-color)
}

.product_list_widget {
    list-style: none;
    padding-left: 0;
    margin-bottom: 0
}

.product_list_widget .recent-post {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 0;
    border-bottom: none
}

.product_list_widget .recent-post:last-child {
    margin-bottom: 0
}

.product_list_widget .recent-post .media-img {
    width: 70px;
    margin-right: 20px;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none
}

.product_list_widget .recent-post-title {
    font-size: 20px;
    margin-bottom: 7px
}

.product_list_widget .recent-post-title a {
    color: inherit
}

.product_list_widget .recent-post-title a:hover {
    color: var(--theme-color)
}

.product_list_widget .star-rating {
    font-size: 12px;
    margin-bottom: 3px
}

.widget_info {
    border-top: 4px solid var(--theme-color);
    margin-top: -113px;
    margin-bottom: 0
}

@media (max-width: 1299px) {
    .widget_info {
        margin-top:-195px
    }
}

@media (max-width: 1199px) {
    .widget_info {
        margin-top:-275px
    }

    .widget_info .widget_title {
        font-size: 22px
    }
}

@media (max-width: 991px) {
    .widget_info {
        margin-top:0;
        margin-bottom: 20px
    }
}

.widget_info .service-info-list {
    margin: 0 0 -0.4em 0;
    padding: 0;
    border: 0
}

.widget_info .service-info-list strong {
    font-family: var(--title-font);
    font-size: 18px;
    font-weight: 600;
    color: var(--title-color)
}

.widget_info .service-info-list li:not(:last-child) {
    border-bottom: 1px solid var(--border-color);
    margin-bottom: 14px;
    padding-bottom: 14px
}

.widget_info .th-btn {
    width: 100%;
    margin-bottom: 10px;
    display: block
}

.widget_info .th-video {
    margin-bottom: 20px
}

.widget_info .course-price {
    display: block;
    font-weight: bold;
    margin-bottom: 19px
}

.widget_info .course-price .tag {
    display: inline-block;
    background-color: var(--theme-color2);
    font-size: 12px;
    font-weight: 500;
    text-transform: uppercase;
    color: var(--white-color);
    border-radius: 99px;
    padding: 2px 13px;
    vertical-align: middle;
    margin-bottom: 5px
}

.info-list ul {
    list-style: none;
    padding: 0;
    margin: 0
}

.info-list i {
    color: var(--theme-color);
    width: 16px;
    margin-right: 2px;
    font-size: 16px
}

.info-list strong {
    font-weight: 500;
    color: var(--title-color)
}

.info-list li {
    border-bottom: 1px dashed #d3dbeb;
    padding: 12px 0
}

.info-list li:last-child {
    border-bottom: none;
    padding-bottom: 0;
    margin-bottom: -0.45em
}

.widget_banner {
    border: none;
    overflow: hidden;
    padding: 50px
}

.widget_banner:before {
    z-index: -1
}

.widget_banner .title {
    color: var(--white-color);
    font-weight: 600;
    margin-top: -0.25em;
    font-size: 24px;
    line-height: 34px
}

.widget_banner .link {
    font-size: 18px;
    display: block;
    color: var(--white-color);
    font-weight: 600;
    margin-bottom: 175px
}

@media (max-width: 375px) {
    .widget_banner .th-btn {
        line-height:inherit;
        padding: 14px
    }
}

@media (max-width: 767px) {
    .widget_banner {
        padding:40px 40px 65px
    }
}

@media (max-width: 575px) {
    .widget_banner {
        padding:30px 30px 55px
    }
}

.widget-map {
    line-height: 1px;
    border-radius: 10px
}

.widget-map iframe {
    border-radius: 10px;
    height: 327px
}

@media (max-width: 1199px) {
    .recent-post .post-title {
        font-size:18px;
        line-height: 24px
    }

    .widget_offer {
        padding-top: 40px;
        padding-bottom: 40px
    }

    .col-lg-4 .sidebar-area .widget {
        --blog-space-y: 40px;
        --blog-space-x: 20px
    }
}

@media (max-width: 991px) {
    .sidebar-area {
        padding-top:30px
    }

    .wp-block-tag-cloud a,.tagcloud a {
        padding: 10.5px 18px
    }

    .col-lg-4 .sidebar-area .widget {
        --blog-space-y: 40px;
        --blog-space-x: 40px
    }
}

@media (max-width: 767px) {
    .widget {
        --blog-space-y: 40px;
        --blog-space-x: 20px
    }

    .col-lg-4 .sidebar-area .widget {
        --blog-space-y: 40px;
        --blog-space-x: 20px
    }
}

.donwload-media-wrap {
    margin-top: -4px;
    margin-bottom: -4px
}

.donwload-media-wrap .download-media {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 1px solid #E7E7E7
}

.donwload-media-wrap .download-media:last-child {
    margin-bottom: 0;
    padding-bottom: 0;
    border-bottom: none
}

.donwload-media-wrap .download-media_icon {
    margin-right: 15px
}

.donwload-media-wrap .download-media_icon i {
    font-size: 30px;
    color: var(--theme-color)
}

.donwload-media-wrap .download-media_title {
    color: var(--title-color);
    font-size: 18px;
    font-weight: 600;
    margin-bottom: -4px
}

.donwload-media-wrap .download-media_text {
    color: var(--body-color);
    font-size: 14px
}

.donwload-media-wrap .download-media_btn {
    margin-left: auto;
    width: 40px;
    height: 40px;
    line-height: 40px;
    background-color: var(--theme-color);
    color: var(--white-color);
    text-align: center
}

.donwload-media-wrap .download-media_btn:hover {
    background: var(--title-color)
}

.footer-widget {
    margin-bottom: 40px
}

.footer-widget,.footer-widget .widget {
    padding: 0;
    border: none;
    padding-bottom: 0;
    background-color: transparent;
    box-shadow: none
}

.footer-widget input,.footer-widget select {
    height: 55px;
    background-color: transparent;
    border: 1px solid #283752 !important
}

.footer-widget input:focus,.footer-widget select:focus {
    border-color: var(--theme-color);
    background-color: transparent
}

.footer-widget .form-group>i {
    color: var(--theme-color);
    top: 18px
}

.footer-widget .widget_title {
    position: relative;
    border: none;
    font-family: var(--title-font);
    color: var(--white-color);
    line-height: 1;
    border-bottom: 0;
    padding: 0 0 18px 0;
    margin: -0.1em 0 35px 0;
    max-width: 275px;
    text-transform: capitalize
}

.footer-widget .widget_title:before,.footer-widget .widget_title:after {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    width: 61px;
    height: 2px;
    background-color: var(--theme-color)
}

.footer-widget .widget_title:after {
    width: 16px;
    border-left: 4px dashed #0E121D;
    border-right: 4px dashed #0E121D;
    height: 2px;
    background-color: transparent;
    bottom: 0px;
    left: 40px;
    -webkit-animation: footerLine 7s linear infinite;
    animation: footerLine 7s linear infinite
}

.footer-widget.widget_meta,.footer-widget.widget_pages,.footer-widget.widget_archive,.footer-widget.widget_categories,.footer-widget.widget_nav_menu {
    margin-bottom: 40px
}

.footer-widget.widget_meta ul,.footer-widget.widget_pages ul,.footer-widget.widget_archive ul,.footer-widget.widget_categories ul,.footer-widget.widget_nav_menu ul {
    margin-top: -2px
}

.footer-widget.widget_meta .menu,.footer-widget.widget_meta>ul,.footer-widget.widget_pages .menu,.footer-widget.widget_pages>ul,.footer-widget.widget_archive .menu,.footer-widget.widget_archive>ul,.footer-widget.widget_categories .menu,.footer-widget.widget_categories>ul,.footer-widget.widget_nav_menu .menu,.footer-widget.widget_nav_menu>ul {
    margin-bottom: -5px
}

.footer-widget.widget_meta a,.footer-widget.widget_pages a,.footer-widget.widget_archive a,.footer-widget.widget_categories a,.footer-widget.widget_nav_menu a {
    font-size: 16px;
    font-weight: 400;
    padding: 0 0 0 25px;
    margin-bottom: 20px;
    font-family: var(--body-font);
    display: block;
    max-width: 100%;
    width: -webkit-max-content;
    width: -moz-max-content;
    width: max-content;
    padding-right: 0;
    background-color: transparent;
    position: relative;
    border: 0
}

.footer-widget.widget_meta a:before,.footer-widget.widget_pages a:before,.footer-widget.widget_archive a:before,.footer-widget.widget_categories a:before,.footer-widget.widget_nav_menu a:before {
    content: "\f061";
    font-weight: 900;
    left: 0;
    top: 50%;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    color: inherit;
    width: unset;
    background-color: transparent;
    border: none;
    color: var(--body-color);
    line-height: 0;
    height: 5px
}

.footer-widget.widget_meta a:hover,.footer-widget.widget_pages a:hover,.footer-widget.widget_archive a:hover,.footer-widget.widget_categories a:hover,.footer-widget.widget_nav_menu a:hover {
    background-color: transparent;
    color: var(--theme-color)
}

.footer-widget.widget_meta a:hover:before,.footer-widget.widget_pages a:hover:before,.footer-widget.widget_archive a:hover:before,.footer-widget.widget_categories a:hover:before,.footer-widget.widget_nav_menu a:hover:before {
    color: var(--theme-color);
    left: 5px
}

.footer-widget.widget_meta li>span,.footer-widget.widget_pages li>span,.footer-widget.widget_archive li>span,.footer-widget.widget_categories li>span,.footer-widget.widget_nav_menu li>span {
    width: auto;
    height: auto;
    position: relative;
    background-color: transparent;
    color: var(--body-color);
    line-height: 1
}

.footer-widget.widget_meta li:last-child a,.footer-widget.widget_pages li:last-child a,.footer-widget.widget_archive li:last-child a,.footer-widget.widget_categories li:last-child a,.footer-widget.widget_nav_menu li:last-child a {
    margin-bottom: 0
}

.footer-widget .recent-post {
    max-width: 310px;
    border-bottom: none
}

.footer-widget .recent-post .media-img {
    width: 100px
}

.footer-widget .recent-post .post-title {
    color: var(--white-color);
    font-size: 18px;
    line-height: 28px
}

.footer-widget .recent-post:last-child {
    margin-bottom: 0;
    padding-bottom: 0;
    border-bottom: 0
}

.footer-widget .footer-logo {
    margin-bottom: 15px
}

@-webkit-keyframes footerLine {
    0% {
        left: 40px
    }

    50% {
        left: 0
    }

    100% {
        left: 40px
    }
}

@keyframes footerLine {
    0% {
        left: 40px
    }

    50% {
        left: 0
    }

    100% {
        left: 40px
    }
}

.th-widget-about .about-logo {
    margin-bottom: 30px
}

.th-widget-about .about-text {
    margin-bottom: 31px;
    margin-top: -0.46em
}

.th-widget-about.style2 .title {
    font-size: 18px
}

.th-widget-about.style2 .about-text {
    margin-bottom: 26px
}

.th-widget-about.style2 .footer-info-grid {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 24px;
    margin-bottom: 35px
}

.th-widget-about.style2 .footer-info-title {
    font-size: 18px;
    font-weight: 600;
    font-family: var(--title-font);
    margin-bottom: 4px
}

.th-widget-about.style2 .footer-info i {
    border-radius: 5px
}

.th-widget-about.style2 .newsletter-form {
    gap: 10px;
    -webkit-box-pack: start;
    -webkit-justify-content: start;
    -ms-flex-pack: start;
    justify-content: start
}

.th-widget-about.style2 .newsletter-form input {
    border-radius: 5px;
    background: #272B37;
    height: 45px
}

.th-widget-about.style2 .newsletter-form .th-btn {
    height: 45px;
    line-height: 45px;
    font-size: 14px;
    font-weight: 600;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    padding: 0 19px;
    width: auto
}

.th-widget-about.style3 {
    max-width: 341px
}

.th-widget-about.style3 .footer-info-grid {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 32px 24px;
    margin-bottom: 35px
}

.th-widget-about.style3 .footer-info-title {
    font-size: 18px;
    font-weight: 600;
    font-family: var(--title-font);
    margin-bottom: 4px
}

.th-widget-about.style3 .footer-info {
    max-width: none
}

.widget_contact .contact-text {
    margin-bottom: 25px;
    margin-top: -0.46em
}

.footer-text {
    margin-top: -0.46em;
    margin-bottom: 25px
}

.widget-gallery {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    max-width: 320px
}

.widget-gallery .gallery-btn {
    position: absolute;
    top: 50%;
    left: 50%;
    color: var(--white-color);
    visibility: hidden;
    opacity: 0;
    -webkit-transform: translate(-50%, 20px);
    -ms-transform: translate(-50%, 20px);
    transform: translate(-50%, 20px);
    background: transparent
}

.widget-gallery .gallery-btn:hover {
    color: var(--theme-color);
    background: transparent
}

.widget-gallery .gallery-thumb {
    overflow: hidden;
    position: relative;
    border-radius: 0px
}

.widget-gallery .gallery-thumb:before {
    content: '';
    height: calc(100% - 14px);
    width: calc(100% - 14px);
    background-color: var(--title-color);
    opacity: 0.8;
    position: absolute;
    top: 7px;
    left: 7px;
    -webkit-transform: scaleX(0);
    -ms-transform: scaleX(0);
    transform: scaleX(0);
    border-radius: inherit;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.widget-gallery .gallery-thumb img {
    width: 100%
}

.widget-gallery .gallery-thumb:hover:before {
    -webkit-transform: scaleX(1);
    -ms-transform: scaleX(1);
    transform: scaleX(1)
}

.widget-gallery .gallery-thumb:hover .gallery-btn {
    visibility: visible;
    opacity: 1;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%)
}

.th-widget-schedule {
    margin-top: -0.25em
}

.th-widget-schedule .footer-info {
    padding-left: 0
}

.footer-table {
    margin-top: -15px;
    border: none;
    margin-bottom: 0
}

.footer-table th,.footer-table td {
    border: none;
    padding: 8px 0;
    font-size: 16px
}

.footer-table td {
    padding-left: 50px
}

.footer-table th {
    padding-right: 13px;
    font-weight: 500;
    color: var(--white-color)
}

.footer-info-title {
    font-size: 20px;
    font-family: var(--body-font);
    font-weight: 600;
    color: var(--white-color);
    margin-bottom: 15px;
    margin-top: -0.27em
}

.footer-info {
    position: relative;
    margin: 0 0 25px 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    padding: 0 0 0 35px;
    max-width: 300px
}

.footer-info:last-child {
    margin-bottom: 0
}

.footer-info i {
    display: inline-block;
    width: 25px;
    height: 25px;
    line-height: 25px;
    text-align: center;
    background-color: var(--theme-color);
    color: var(--white-color);
    position: absolute;
    left: 0;
    font-size: 10px
}

.footer-info:nth-child(2) i {
    background-color: var(--theme-color)
}

.footer-info:nth-child(3) i {
    background-color: var(--title-color)
}

@media (max-width: 1199px) {
    .footer-widget .widget_title {
        margin:-0.1em 0 30px 0
    }

    .footer-widget.widget_meta a,.footer-widget.widget_pages a,.footer-widget.widget_archive a,.footer-widget.widget_categories a,.footer-widget.widget_nav_menu a {
        margin-bottom: 16px
    }
}

.footer-widget.style2 .widget_title {
    font-size: 18px;
    text-transform: uppercase;
    padding: 0 0 20px 0;
    font-weight: 500
}

.footer-widget.style2 .widget_title:before {
    height: 2px;
    width: 60px;
    background-color: var(--white-color)
}

.footer-widget.style2 .widget_title:after {
    display: none
}

.footer-widget.style2.widget_meta a,.footer-widget.style2.widget_pages a,.footer-widget.style2.widget_archive a,.footer-widget.style2.widget_categories a,.footer-widget.style2.widget_nav_menu a {
    padding: 0 0 0 25px;
    margin-bottom: 23px
}

.footer-widget.style2.widget_meta a:before,.footer-widget.style2.widget_pages a:before,.footer-widget.style2.widget_archive a:before,.footer-widget.style2.widget_categories a:before,.footer-widget.style2.widget_nav_menu a:before {
    content: "\f061";
    font-weight: 500;
    top: 50%;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    width: unset;
    font-size: 1em;
    height: unset
}

@media (max-width: 767px) {
    .footer-widget.style2 .widget_title {
        padding:0 0 16px 0
    }

    .footer-widget.style2.widget_meta a,.footer-widget.style2.widget_pages a,.footer-widget.style2.widget_archive a,.footer-widget.style2.widget_categories a,.footer-widget.style2.widget_nav_menu a {
        margin-bottom: 18px
    }
}

@media (max-width: 350px) {
    .footer-widget .recent-post .media-img {
        margin-right:15px;
        width: 100px
    }
}

.th-header {
    position: relative;
    z-index: 41
}

.th-header .icon-btn {
    --btn-size: 45px;
    line-height: 43px;
    border: 1px solid #d0dbe9;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.th-header .icon-btn:hover {
    border-color: var(--theme-color)
}

.th-header .th-btn {
    padding: 19px 29px
}

.sticky-wrapper {
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.sticky-wrapper.sticky {
    position: fixed;
    top: 0;
    right: 0;
    left: 0;
    background-color: var(--white-color);
    box-shadow: 0 0 10px 0 rgba(0,0,0,0.07);
    -webkit-animation: stickyAni 0.4s ease-in-out;
    animation: stickyAni 0.4s ease-in-out
}

@-webkit-keyframes stickyAni {
    0% {
        -webkit-transform: translate3d(0, -40px, 0) scaleY(0.8);
        transform: translate3d(0, -40px, 0) scaleY(0.8);
        opacity: 0.7
    }

    100% {
        -webkit-transform: translate3d(0, 0, 0) scaleY(1);
        transform: translate3d(0, 0, 0) scaleY(1);
        opacity: 1
    }
}

@keyframes stickyAni {
    0% {
        -webkit-transform: translate3d(0, -40px, 0) scaleY(0.8);
        transform: translate3d(0, -40px, 0) scaleY(0.8);
        opacity: 0.7
    }

    100% {
        -webkit-transform: translate3d(0, 0, 0) scaleY(1);
        transform: translate3d(0, 0, 0) scaleY(1);
        opacity: 1
    }
}

.main-menu a {
    display: block;
    position: relative;
    font-weight: 600;
    font-size: 16px;
    color: var(--title-color);
    text-transform: uppercase;
    font-family: var(--body-font)
}

.main-menu a:hover {
    color: var(--theme-color)
}

.main-menu a .new-label {
    font-size: 13px;
    background-color: var(--theme-color);
    color: var(--white-color);
    padding: 2px 5px;
    border-radius: 4px;
    position: relative;
    top: -1px;
    margin-left: 5px
}

.main-menu>ul>li {
    margin: 0 13px
}

.main-menu>ul>li>a {
    padding: 28.5px 0
}

.main-menu ul {
    margin: 0;
    padding: 0
}

.main-menu ul li {
    list-style-type: none;
    display: inline-block;
    position: relative
}

.main-menu ul li.menu-item-has-children>a:after {
    content: "\2b";
    position: relative;
    font-family: var(--icon-font);
    margin-left: 5px;
    top: 0px;
    font-size: 14px;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    -webkit-transform: rotate(0deg);
    -ms-transform: rotate(0deg);
    transform: rotate(0deg);
    display: inline-block
}

.main-menu ul li.menu-item-has-children>a:hover:after {
    content: "\f068";
    -webkit-transform: rotate(180deg);
    -ms-transform: rotate(180deg);
    transform: rotate(180deg)
}

.main-menu ul li:last-child {
    margin-right: 0 !important
}

.main-menu ul li:first-child {
    margin-left: 0 !important
}

.main-menu ul li:hover>ul.sub-menu {
    visibility: visible;
    opacity: 1;
    -webkit-transform: scaleY(1);
    -ms-transform: scaleY(1);
    transform: scaleY(1);
    z-index: 9
}

.main-menu ul li:hover ul.mega-menu {
    visibility: visible;
    opacity: 1;
    -webkit-transform: scaleY(1) translateX(-50%);
    -ms-transform: scaleY(1) translateX(-50%);
    transform: scaleY(1) translateX(-50%);
    z-index: 9
}

.main-menu ul.sub-menu,.main-menu ul.mega-menu {
    position: absolute;
    text-align: left;
    top: 100%;
    left: 0;
    background-color: var(--white-color);
    visibility: hidden;
    min-width: 190px;
    width: -webkit-max-content;
    width: -moz-max-content;
    width: max-content;
    padding: 7px;
    left: -14px;
    opacity: 0;
    z-index: -1;
    border: 1px solid var(--border-color);
    border-radius: 0px;
    -webkit-transform: scaleY(0);
    -ms-transform: scaleY(0);
    transform: scaleY(0);
    -webkit-transform-origin: top center;
    -ms-transform-origin: top center;
    transform-origin: top center;
    -webkit-transition: all 0.4s ease 0s;
    transition: all 0.4s ease 0s
}

.main-menu ul.sub-menu a,.main-menu ul.mega-menu a {
    font-size: 16px;
    line-height: 30px
}

.main-menu ul.sub-menu {
    padding: 18px 20px;
    left: -27px
}

.main-menu ul.sub-menu li {
    display: block;
    margin: 0 0;
    padding: 0px 9px
}

.main-menu ul.sub-menu li.menu-item-has-children>a:after {
    content: "\f105";
    float: right;
    top: 1px
}

.main-menu ul.sub-menu li a {
    position: relative;
    padding-left: 23px;
    text-transform: capitalize
}

.main-menu ul.sub-menu li a:before {
    content: "\f7d9";
    position: absolute;
    top: 8px;
    left: 0;
    font-family: var(--icon-font);
    width: 11px;
    height: 11px;
    text-align: center;
    border-radius: 50%;
    display: inline-block;
    font-size: 0.9em;
    line-height: 1;
    color: var(--theme-color);
    font-weight: 700
}

.main-menu ul.sub-menu li ul.sub-menu {
    left: 100%;
    right: auto;
    top: 0;
    margin: 0 0;
    margin-left: 20px
}

.main-menu ul.sub-menu li ul.sub-menu li ul {
    left: 100%;
    right: auto
}

.main-menu .mega-menu-wrap {
    position: static
}

.main-menu ul.mega-menu {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    gap: 40px;
    text-align: left;
    width: 100%;
    max-width: var(--main-container);
    min-width: -webkit-fit-content;
    min-width: -moz-fit-content;
    min-width: fit-content;
    padding: 20px 15px 23px 15px;
    left: 50%;
    -webkit-transform: scaleY(0) translateX(-50%);
    -ms-transform: scaleY(0) translateX(-50%);
    transform: scaleY(0) translateX(-50%)
}

.main-menu ul.mega-menu li {
    display: block;
    width: 100%;
    padding: 0 15px;
    min-width: -webkit-max-content;
    min-width: -moz-max-content;
    min-width: max-content
}

.main-menu ul.mega-menu li li {
    padding: 2px 0
}

.main-menu ul.mega-menu li a {
    display: inline-block;
    text-transform: capitalize
}

.main-menu ul.mega-menu>li>a {
    display: block;
    padding: 0;
    padding-bottom: 15px;
    margin-bottom: 10px;
    text-transform: capitalize;
    letter-spacing: 1px;
    font-weight: 700;
    color: var(--title-color);
    border-color: var(--theme-color)
}

.main-menu ul.mega-menu>li>a::after,.main-menu ul.mega-menu>li>a::before {
    content: "";
    position: absolute;
    bottom: 0;
    left: 0;
    width: 15px;
    height: 1px;
    background-color: var(--theme-color)
}

.main-menu ul.mega-menu>li>a::after {
    width: calc(100% - 20px);
    left: 20px
}

.main-menu ul.mega-menu>li>a:hover {
    padding-left: 0
}

.main-menu.hide-icon ul.sub-menu li a {
    padding-left: 0
}

.main-menu.hide-icon ul.sub-menu li a:before {
    display: none
}

.category-menu {
    position: absolute;
    text-align: left;
    top: 100%;
    left: 0;
    background-color: var(--white-color);
    visibility: hidden;
    min-width: 190px;
    width: -webkit-max-content;
    width: -moz-max-content;
    width: max-content;
    padding: 25px 30px;
    left: 0;
    margin-top: -10px;
    opacity: 0;
    z-index: -1;
    border: 1px solid var(--border-color);
    border-radius: 10px;
    -webkit-transform-origin: top center;
    -ms-transform-origin: top center;
    transform-origin: top center;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    -webkit-transition: margin-top 0.4s ease-in-out 0s, visibility 0.4s ease-in-out 0s, opacity 0.4s ease-in-out 0s, z-index 0s;
    transition: margin-top 0.4s ease-in-out 0s, visibility 0.4s ease-in-out 0s, opacity 0.4s ease-in-out 0s, z-index 0s
}

.category-menu ul {
    padding: 0;
    margin-bottom: 0
}

.category-menu li {
    list-style: none;
    margin-bottom: 6px
}

.category-menu li:last-child {
    margin-bottom: 0
}

.category-menu a {
    text-transform: capitalize;
    color: var(--title-color);
    position: relative;
    padding-left: 23px
}

.category-menu a:before {
    content: "\f07c";
    position: absolute;
    top: 4px;
    left: 0;
    font-family: var(--icon-font);
    width: 11px;
    height: 11px;
    text-align: center;
    border-radius: 50%;
    display: inline-block;
    font-size: 0.9em;
    line-height: 1;
    color: var(--theme-color);
    font-weight: 400
}

.category-menu a:hover {
    color: var(--theme-color)
}

.category-menu-wrap {
    position: relative;
    height: 100%;
    padding: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    border: 1px solid #D0DBE9;
    border-radius: 5px
}

.category-menu-wrap:hover .category-menu {
    visibility: visible;
    opacity: 1;
    margin-top: 0;
    z-index: 9
}

.category-menu-wrap .search-form {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex
}

.category-menu-wrap .search-form input {
    background: transparent;
    border: 0;
    padding-right: 10px;
    padding-left: 15px;
    height: 48px
}

.category-menu-wrap .search-form input:hover,.category-menu-wrap .search-form input:focus,.category-menu-wrap .search-form input:active {
    border: 0
}

.category-menu-wrap .search-form input::-webkit-input-placeholder {
    color: #9FAAB7
}

.category-menu-wrap .search-form input::-moz-placeholder {
    color: #9FAAB7
}

.category-menu-wrap .search-form input:-ms-input-placeholder {
    color: #9FAAB7
}

.category-menu-wrap .search-form input::-ms-input-placeholder {
    color: #9FAAB7
}

.category-menu-wrap .search-form input::placeholder {
    color: #9FAAB7
}

.category-menu-wrap .search-form button {
    border: none;
    width: auto;
    height: 48px;
    line-height: 48px;
    background-color: transparent;
    color: var(--title-color);
    padding-right: 15px;
    display: inline-block;
    border-radius: 0
}

.menu-expand {
    font-size: 16px;
    font-weight: 400;
    color: var(--title-color);
    background-color: transparent;
    padding: 10.5px 16px;
    border-radius: 0;
    border-right: 1px solid #D0DBE9;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    min-width: 160px;
    line-height: initial
}

.simple-icon {
    border: none;
    background-color: transparent;
    padding: 0;
    color: var(--body-color)
}

.simple-icon:hover {
    color: var(--theme-color)
}

.header-button {
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 15px;
    margin-left: 15px
}

.header-button .icon-btn {
    position: relative
}

.header-links ul {
    margin: 0;
    padding: 0;
    list-style-type: none
}

.header-links li {
    display: inline-block;
    position: relative;
    font-size: 16px;
    font-weight: 400
}

.header-links li:not(:last-child) {
    padding: 0 20px 0 0;
    margin: 0 17px 0 0
}

.header-links li:not(:last-child):before {
    content: "";
    position: absolute;
    right: 0;
    top: 50%;
    background-color: #fff;
    width: 1px;
    height: 16px;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%)
}

.header-links li>i {
    margin-right: 10px
}

.header-links li,.header-links span,.header-links p,.header-links a {
    font-family: var(--body-font);
    color: var(--body-color)
}

.header-links i {
    color: var(--body-color);
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.header-links b,.header-links strong {
    font-weight: 600
}

.header-social .social-title {
    font-weight: 400;
    font-size: 16px;
    display: inline-block;
    margin: 0 10px 0 0
}

.header-social a {
    font-size: 14px;
    display: inline-block;
    color: var(--body-color);
    margin: 0 15px 0 0
}

.header-social a:last-child {
    margin-right: 0
}

.header-social a:hover {
    color: var(--theme-color)
}

.header-social a:hover i {
    color: var(--theme-color)
}

.header-logo {
    padding-top: 17px;
    padding-bottom: 17px
}

.header-notice {
    margin-bottom: 0;
    display: inline-block
}

.counter-list {
    padding: 0;
    margin: 0;
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    gap: 18px;
    background-color: var(--theme-color2);
    padding: 2px 20px;
    border-radius: 999px;
    margin-left: 15px;
    color: var(--white-color)
}

.counter-list li {
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    gap: 4px;
    position: relative;
    color: var(--white-color)
}

.counter-list li:after {
    content: ":";
    position: absolute;
    top: 50%;
    right: -11.5px;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    color: var(--white-color);
    font-weight: 600
}

.counter-list li:last-child::after {
    display: none
}

.counter-list .count-number,.counter-list .count-name {
    color: var(--white-color);
    font-weight: 500
}

.dropdown-link {
    position: relative;
    display: inline-block
}

.dropdown-link>a {
    color: var(--white-color)
}

.dropdown-link>a i {
    margin-right: 3px;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.dropdown-link>a:hover i {
    color: var(--white-color) !important
}

.dropdown-toggle::after {
    content: "\f107";
    border: none;
    font-family: var(--icon-font);
    vertical-align: middle;
    font-weight: 400;
    margin-left: 6px
}

.dropdown-menu {
    width: -webkit-fit-content;
    width: -moz-fit-content;
    width: fit-content;
    min-width: auto;
    top: calc(100% + 10px) !important;
    left: 50% !important;
    -webkit-transform: translateX(-50%) !important;
    -ms-transform: translateX(-50%) !important;
    transform: translateX(-50%) !important;
    padding: 8px 20px !important;
    border-color: var(--border-color)
}

.dropdown-menu li {
    padding-right: 0;
    margin-right: 0
}

.dropdown-menu li:after {
    display: none
}

.dropdown-menu li a {
    display: block
}

.dropdown-menu a {
    color: var(--title-color) !important
}

.dropdown-menu a:hover {
    color: var(--theme-color) !important
}

.dropdown-menu:before {
    content: "";
    position: absolute;
    left: 50%;
    top: -7px;
    width: 14px;
    height: 14px;
    margin-left: -7px;
    background-color: var(--white-color);
    z-index: -1;
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg);
    border-top: 1px solid var(--border-color);
    border-left: 1px solid var(--border-color)
}

.header-layout-default .header-top {
    --body-color: #fff;
    background-color: var(--title-color);
    padding: 12px 0px;
    position: relative;
    z-index: 3
}

.header-layout-default .header-top a:hover {
    color: var(--title-color)
}

.header-layout-default .header-top .header-links a:hover {
    color: var(--theme-color)
}

.header-layout-default .menu-area {
    background-color: var(--white-color);
    position: relative;
    z-index: 2
}

.header-layout-default .menu-area .logo-bg {
    position: absolute;
    height: 100%;
    width: 543px;
    border-radius: 0 0px 0 0;
    background: var(--theme-color);
    bottom: 0;
    left: 0;
    z-index: -1;
    -webkit-clip-path: polygon(0 0, 100% 0%, 90% 100%, 0% 100%);
    clip-path: polygon(0 0, 100% 0%, 90% 100%, 0% 100%)
}

@media (min-width: 1922px) {
    .header-layout-default .menu-area .logo-bg {
        width:880px
    }
}

@media (max-width: 1700px) {
    .header-layout-default .menu-area .logo-bg {
        width:350px
    }
}

@media (max-width: 1399px) {
    .header-layout-default .menu-area .logo-bg {
        width:290px
    }
}

@media (max-width: 1299px) {
    .header-layout-default .menu-area .logo-bg {
        width:270px
    }
}

@media (max-width: 1199px) {
    .header-layout-default .menu-area .logo-bg {
        width:290px
    }
}

@media (max-width: 575px) {
    .header-layout-default .menu-area .logo-bg {
        width:230px
    }
}

.header-layout-default .main-menu>ul>li>a {
    padding: 31.5px 0
}

.header-layout-default .th-btn {
    padding: 21px 29px
}

.header-layout-default .header-button {
    margin-left: 0
}

@media (max-width: 1299px) {
    .header-layout-default .header-button .icon-btn {
        display:none
    }
}

.header-layout1 .header-top {
    --body-color: #fff;
    background-color: var(--title-color);
    padding: 12px 0;
    position: relative;
    z-index: 3
}

.header-layout1 .header-top a:hover {
    color: var(--theme-color)
}

.header-layout1 .menu-area {
    background-color: var(--theme-color);
    position: relative;
    z-index: 0
}

.header-layout1 .menu-area .logo-bg {
    position: absolute;
    height: 100%;
    width: 543px;
    background: var(--white-color);
    bottom: 0;
    left: 0;
    z-index: -1;
    -webkit-clip-path: polygon(100% 0, 88% 45%, 95% 100%, 0 100%, 0 0);
    clip-path: polygon(100% 0, 88% 45%, 95% 100%, 0 100%, 0 0)
}

@media (min-width: 1922px) {
    .header-layout1 .menu-area .logo-bg {
        width:900px;
        -webkit-clip-path: polygon(100% 0, 90% 45%, 100% 100%, 0 100%, 0 0);
        clip-path: polygon(100% 0, 90% 45%, 100% 100%, 0 100%, 0 0)
    }
}

@media (max-width: 1700px) {
    .header-layout1 .menu-area .logo-bg {
        width:450px;
        -webkit-clip-path: polygon(100% 0, 85% 50%, 98% 100%, 0 100%, 0 0);
        clip-path: polygon(100% 0, 85% 50%, 98% 100%, 0 100%, 0 0)
    }
}

@media (max-width: 1399px) {
    .header-layout1 .menu-area .logo-bg {
        width:330px
    }
}

@media (max-width: 1299px) {
    .header-layout1 .menu-area .logo-bg {
        width:290px
    }
}

@media (max-width: 1199px) {
    .header-layout1 .menu-area .logo-bg {
        width:300px
    }
}

@media (max-width: 991px) {
    .header-layout1 .menu-area .logo-bg {
        -webkit-clip-path:polygon(100% 0, 85% 60%, 95% 100%, 0 100%, 0 0);
        clip-path: polygon(100% 0, 85% 60%, 95% 100%, 0 100%, 0 0)
    }
}

@media (max-width: 575px) {
    .header-layout1 .menu-area .logo-bg {
        width:230px
    }
}

.header-layout1 .header-logo {
    padding-top: 15px;
    padding-bottom: 15px
}

.header-layout1 .header-middle .header-link {
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    gap: 15px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    border-left: 1px solid var(--white-color);
    margin-left: 30px;
    padding-left: 30px
}

.header-layout1 .header-middle .header-link:first-child {
    padding-left: 0;
    margin-left: 0;
    border-left: 0
}

.header-layout1 .header-middle .header-link i {
    width: var(--icon-size, 46px);
    height: var(--icon-size, 46px);
    line-height: var(--icon-size, 46px);
    background: var(--white-color);
    border-radius: 50%;
    text-align: center;
    color: var(--theme-color);
    font-size: 18px
}

.header-layout1 .header-middle .header-link p {
    font-size: 14px;
    color: var(--white-color);
    margin-bottom: 5px
}

.header-layout1 .header-middle .header-link .header-single-link {
    font-size: 20px;
    font-weight: 600;
    color: var(--white-color);
    font-family: var(--title-font);
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.header-layout1 .header-middle .header-link .header-single-link:hover {
    color: var(--title-color)
}

@media (max-width: 1299px) {
    .header-layout1 .header-middle .header-link {
        margin-left:20px;
        padding-left: 20px
    }
}

.header-layout1 .main-menu-area {
    background: var(--title-color);
    padding: 0 0 0 30px;
    margin-top: -30px;
    -webkit-transform: translateY(30px);
    -ms-transform: translateY(30px);
    transform: translateY(30px)
}

@media (max-width: 991px) {
    .header-layout1 .main-menu-area {
        display:none
    }
}

.header-layout1 .th-menu-toggle {
    background: var(--title-color)
}

.header-layout1 .main-menu>ul>li>a {
    padding: 17px 0;
    color: var(--white-color)
}

.header-layout1 .main-menu>ul>li>a:hover {
    color: var(--theme-color)
}

.header-layout1 .th-btn {
    padding: 23px 29px
}

.header-layout1 .header-button .icon-btn {
    border: 2px solid var(--white-color)
}

.header-layout1 .header-button .icon-btn .fa-grid {
    font-size: 20px;
    line-height: initial
}

@media (max-width: 1299px) {
    .header-layout1 .header-button .icon-btn {
        display:none
    }
}

.header-layout1 .sticy-d-block {
    display: none
}

.header-layout1 .sticky-wrapper.sticky .sticy-d-none {
    display: none !important
}

.header-layout1 .sticky-wrapper.sticky .sticy-d-block {
    display: block
}

.header-layout1 .sticky-wrapper.sticky .menu-area {
    background: var(--white-color)
}

.header-layout1 .sticky-wrapper.sticky .menu-area:after {
    display: none
}

.header-layout1 .sticky-wrapper.sticky .main-menu-area {
    display: none
}

.header-layout1 .sticky-wrapper.sticky .main-menu>ul>li>a {
    color: var(--title-color)
}

.header-layout1 .sticky-wrapper.sticky .main-menu>ul>li>a:hover {
    color: var(--theme-color)
}

.header-layout2 {
    position: absolute;
    top: 0;
    left: 0;
    right: 0
}

.header-layout2 .sticky-wrapper.sticky {
    background: transparent
}

.header-layout2 .sticky-wrapper.sticky .menu-area:after {
    background: var(--title-color)
}

.header-layout2 .sticky-wrapper.sticky .header-logo {
    padding-top: 0;
    margin-top: 0;
    padding-bottom: 0
}

.header-layout2 .sticky-wrapper.sticky .logo-bg {
    width: 554px
}

@media (min-width: 1922px) {
    .header-layout2 .sticky-wrapper.sticky .logo-bg {
        display:none
    }

    .header-layout2 .sticky-wrapper.sticky .menu-area:after {
        width: 100%
    }

    .header-layout2 .sticky-wrapper.sticky .header-logo {
        padding-top: 15px;
        padding-bottom: 15px
    }
}

@media (max-width: 1500px) {
    .header-layout2 .sticky-wrapper.sticky .logo-bg {
        width:400px
    }
}

@media (max-width: 1299px) {
    .header-layout2 .sticky-wrapper.sticky .logo-bg {
        height:100%;
        width: 300px
    }

    .header-layout2 .sticky-wrapper.sticky .header-logo {
        padding-top: 15px;
        padding-bottom: 15px
    }
}

@media (max-width: 991px) {
    .header-layout2 .sticky-wrapper.sticky .logo-bg {
        width:230px
    }
}

@media (max-width: 575px) {
    .header-layout2 .sticky-wrapper.sticky .logo-bg {
        width:190px
    }
}

.header-layout2 .header-top {
    background: transparent;
    padding: 12px 0;
    padding-left: 450px;
    --body-color: #fff
}

@media (max-width: 1700px) {
    .header-layout2 .header-top {
        padding-left:320px
    }
}

@media (max-width: 1600px) {
    .header-layout2 .header-top {
        padding-left:500px
    }
}

@media (max-width: 1399px) {
    .header-layout2 .header-top {
        padding-left:440px
    }
}

@media (max-width: 1299px) {
    .header-layout2 .header-top {
        padding-left:0px
    }
}

.header-layout2 .header-logo {
    padding-top: 0;
    margin-top: -10px;
    padding-bottom: 20px
}

@media (max-width: 1699px) {
    .header-layout2 .header-logo {
        margin-left:-130px
    }
}

@media (max-width: 1600px) {
    .header-layout2 .header-logo {
        margin-left:0
    }
}

@media (max-width: 1299px) {
    .header-layout2 .header-logo {
        padding:20px 0;
        margin: 0
    }
}

@media (max-width: 991px) {
    .header-layout2 .header-logo img {
        max-width:150px
    }
}

.header-layout2 .logo-bg {
    position: absolute;
    left: 0;
    top: 0;
    z-index: -1;
    height: calc(100% + 53px);
    width: 524px;
    background-position: bottom right
}

@media (min-width: 1922px) {
    .header-layout2 .logo-bg {
        width:600px
    }
}

@media (min-width: 2400px) and (max-width: 2600px) {
    .header-layout2 .logo-bg {
        width:850px;
        background-position: -50px -356px;
        background-size: 170%
    }
}

@media (min-width: 2000px) and (max-width: 2399px) {
    .header-layout2 .logo-bg {
        width:630px
    }
}

@media (max-width: 1500px) {
    .header-layout2 .logo-bg {
        width:450px
    }
}

@media (max-width: 1399px) {
    .header-layout2 .logo-bg {
        width:440px
    }
}

@media (max-width: 1299px) {
    .header-layout2 .logo-bg {
        background:var(--theme-color);
        width: 300px;
        height: calc(100% - 50px);
        bottom: 0;
        top: auto
    }
}

@media (max-width: 991px) {
    .header-layout2 .logo-bg {
        width:230px
    }
}

@media (max-width: 575px) {
    .header-layout2 .logo-bg {
        width:190px
    }
}

.header-layout2 .menu-area {
    position: relative
}

.header-layout2 .menu-area:after {
    content: '';
    position: absolute;
    right: 0;
    top: 0;
    height: 100%;
    width: calc(100% - 50px);
    background: rgba(255,255,255,0.07);
    z-index: -1
}

@media (min-width: 1922px) {
    .header-layout2 .menu-area:after {
        width:calc(100% - 250px)
    }
}

.header-layout2 .main-menu>ul>li>a {
    padding: 37px 0;
    color: var(--white-color)
}

.header-layout2 .main-menu>ul>li>a:hover {
    color: var(--theme-color)
}

.header-layout2 .main-menu {
    margin-left: 165px
}

@media (max-width: 1299px) {
    .header-layout2 .main-menu {
        margin-left:100px
    }
}

@media (max-width: 1399px) {
    .header-layout2 .main-menu a {
        font-size:14px
    }
}

@media (max-width: 1299px) {
    .header-layout2 .header-button .icon-btn:nth-child(1),.header-layout2 .header-button .icon-btn:nth-child(2) {
        display:none
    }
}

@media (min-width: 1501px) and (max-width: 1599px) {
    .header-layout2 .header-button .icon-btn:nth-child(1),.header-layout2 .header-button .icon-btn:nth-child(2) {
        display:none
    }
}

.header-layout2 .dropdown-link>a {
    color: var(--title-color)
}

@media (max-width: 1299px) {
    .header-layout2 .dropdown-link>a .icon-btn {
        display:inline-block
    }
}

.header-layout2 .dropdown-link>a:hover {
    color: var(--theme-color)
}

.header-layout2 .dropdown-link>a:hover .icon-btn {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.header-layout3 {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    --main-container: 1680px
}

.header-layout3 .header-top {
    background: var(--title-color);
    --body-color: #8993A1;
    padding: 12px 22px 12px 160px;
    margin-left: 115px
}

.header-layout3 .header-top .header-links li:not(:last-child):before {
    background: #8993A1
}

.header-layout3 .menu-area {
    position: relative;
    padding: 0 22px 0 0px
}

.header-layout3 .menu-area:after {
    content: '';
    position: absolute;
    inset: 0;
    opacity: 0.1;
    background: var(--white-color);
    z-index: -1
}

.header-layout3 .th-btn {
    padding: 21px 29px
}

.header-layout3 .header-logo {
    padding: 17px 30px;
    background: var(--title-color);
    position: relative
}

.header-layout3 .header-logo:after {
    content: '';
    position: absolute;
    left: 0;
    top: -50px;
    height: 50px;
    width: 100%;
    background: transparent;
    border-left: 115px solid transparent;
    border-right: 115px solid transparent;
    border-bottom: 50px solid var(--theme-color)
}

.header-layout3 .main-menu>ul>li>a {
    padding: 37px 0;
    color: var(--white-color)
}

.header-layout3 .main-menu>ul>li>a:hover {
    color: var(--theme-color)
}

.header-layout3 .main-menu {
    margin-left: 20px
}

.header-layout3 .sticky-wrapper.sticky {
    background: var(--title-color)
}

.header-layout3 .sticky-wrapper.sticky .header-logo {
    padding-left: 0
}

.header-layout3 .header-links a:hover {
    color: var(--theme-color)
}

@media (max-width: 1700px) {
    .header-layout3 {
        --main-container: 1500px
    }
}

@media (max-width: 1500px) {
    .header-layout3 {
        --main-container: 1300px
    }
}

@media (max-width: 1299px) {
    .header-layout3 .header-button .icon-btn {
        display:none
    }

    .header-layout3 .header-links li.d-xl-inline-block {
        display: none !important
    }
}

@media (max-width: 991px) {
    .header-layout3 .header-logo {
        padding:12px 20px
    }

    .header-layout3 .header-logo:after {
        border-left: 105px solid transparent;
        border-right: 105px solid transparent;
        border-bottom: 50px solid var(--theme-color)
    }
}

@media (max-width: 767px) {
    .header-layout3 .header-top {
        padding:12px 22px 12px 150px
    }
}

@media (max-width: 575px) {
    .header-layout3 .header-top {
        padding:12px 22px;
        margin: 0;
        background: transparent
    }

    .header-layout3 .header-logo:after {
        display: none
    }
}

@media (max-width: 375px) {
    .header-layout3 .header-logo {
        padding:12px 15px
    }
}

.header-layout4 {
    position: absolute;
    top: 40px;
    left: 0;
    right: 0
}

.header-layout4 .header-top {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    margin-left: 240px
}

.header-layout4 .header-link {
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    gap: 15px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 12.75px 30px;
    background: #DFDFDF
}

.header-layout4 .header-link:first-child {
    background: #EAEAEA
}

.header-layout4 .header-link:last-child {
    background: #D3D3D3
}

.header-layout4 .header-link i {
    width: var(--icon-size, 46px);
    height: var(--icon-size, 46px);
    line-height: var(--icon-size, 46px);
    background: var(--white-color);
    border-radius: 50%;
    text-align: center;
    color: var(--theme-color);
    font-size: 18px;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none
}

.header-layout4 .header-link p {
    font-size: 14px;
    margin-bottom: 3px
}

.header-layout4 .header-link .header-single-link {
    font-size: 20px;
    font-weight: 600;
    color: var(--title-color);
    font-family: var(--title-font);
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.header-layout4 .header-link .header-single-link:hover {
    color: var(--theme-color)
}

.header-layout4 .header-logo {
    background: var(--title-color);
    padding: 30px;
    margin-top: -80px
}

.header-layout4 .menu-area {
    position: relative;
    background: var(--white-color)
}

.header-layout4 .menu-area .logo-bg {
    position: absolute;
    top: -85px;
    left: 0;
    background: var(--title-color);
    width: 240px;
    height: calc(100% + 85px);
    z-index: -1
}

.header-layout4 .main-menu>ul>li>a {
    padding: 12px 0
}

.header-layout4 .main-menu {
    margin-left: 6px
}

.header-layout4 .main-menu a {
    font-weight: 500;
    font-size: 14px
}

.header-layout4 .header-button {
    gap: 30px
}

.header-layout4 .th-btn {
    padding: 18px 30px
}

.header-layout4 .sticky-wrapper.sticky .header-logo {
    padding: 20px 30px;
    margin-top: 0
}

.header-layout4 .sticky-wrapper.sticky .main-menu>ul>li>a {
    padding: 42px 0
}

@media (max-width: 1199px) {
    .header-layout4 .header-link {
        padding:13.25px 20px
    }

    .header-layout4 .header-link i {
        --icon-size: 40px
    }

    .header-layout4 .header-link .header-single-link {
        font-size: 16px
    }
}

@media (max-width: 991px) {
    .header-layout4 .header-top {
        margin-left:0
    }

    .header-layout4 .header-logo {
        padding: 15px 25px;
        margin-top: 0
    }

    .header-layout4 .menu-area {
        padding: 0 20px 0 0
    }

    .header-layout4 .sticky-wrapper.sticky .menu-area {
        padding: 0
    }
}

@media (max-width: 767px) {
    .header-layout4 .header-top {
        display:none
    }
}

@media (max-width: 575px) {
    .header-layout4 {
        top:15px
    }
}

@media (max-width: 375px) {
    .header-layout4 .sticky-wrapper.sticky .header-logo,.header-layout4 .header-logo {
        padding:15px 11px
    }
}

@media (min-width: 1400px) {
    .header-layout5 {
        --main-container: 1560px
    }
}

.header-layout5 .header-links li>i {
    color: var(--white-color)
}

.header-layout5 .header-links li:not(:last-child):before {
    background-color: var(--body-color);
    opacity: 0.3
}

.header-layout5 .header-top {
    --body-color: #fff;
    background-color: #002e5b;
    padding: 12px 0;
    position: relative
}

.header-layout5 .header-top:before {
    content: '';
    height: 100%;
    width: 54%;
    position: absolute;
    top: 0;
    left: 0;
    background-color: var(--theme-color);
    -webkit-clip-path: polygon(0 0, calc(100% - 40px) 0%, 100% 100%, 0% 100%);
    clip-path: polygon(0 0, calc(100% - 40px) 0%, 100% 100%, 0% 100%)
}

@media (max-width: 1399px) {
    .header-layout5 .header-top:before {
        width:60%
    }
}

@media (max-width: 1199px) {
    .header-layout5 .header-top:before {
        width:67%
    }
}

@media (max-width: 991px) {
    .header-layout5 .header-top:before {
        width:57%
    }
}

.header-layout5 .header-top .container {
    padding-left: 400px
}

.header-layout5 .header-top a,.header-layout5 .header-top li,.header-layout5 .header-top p {
    color: var(--white-color)
}

.header-layout5 .header-top a:hover {
    color: var(--smoke-color)
}

.header-layout5 .header-button {
    margin-left: 130px
}

.header-layout5 .menu-area {
    background-color: var(--white-color)
}

.header-layout5 .main-menu a {
    color: var(--title-color)
}

.header-layout5 .main-menu a:hover {
    color: var(--theme-color)
}

.header-layout5 .main-menu ul.sub-menu,.header-layout5 .main-menu ul.mega-menu {
    background-color: var(--white-color)
}

.header-layout5 .main-menu ul.mega-menu>li>a {
    color: var(--title-color)
}

.header-layout5 .sticky-wrapper.sticky .logo-style3 {
    margin: 0;
    padding: 0;
    -webkit-filter: none;
    filter: none
}

@media (max-width: 991px) {
    .header-layout5 .sticky-wrapper.sticky .logo-style3 {
        padding:17px 0
    }
}

.logo-style3 {
    position: relative;
    z-index: 2;
    padding: 0 170px 39px 0;
    margin-top: -20px;
    -webkit-filter: drop-shadow(8px -4px 20px rgba(7,36,95,0.04));
    filter: drop-shadow(8px -4px 20px rgba(7,36,95,0.04))
}

.logo-style3:before {
    content: '';
    height: 151px;
    width: 2000px;
    position: absolute;
    bottom: 0px;
    right: -15px;
    background-color: var(--white-color);
    z-index: -1;
    -webkit-clip-path: polygon(0 0, calc(100% - 100px) 0, 100% 100%, 0% 100%);
    clip-path: polygon(0 0, calc(100% - 100px) 0, 100% 100%, 0% 100%)
}

@media (max-width: 1500px) {
    .logo-style3 {
        padding:0 90px 39px 0
    }

    .header-layout5 .header-top .container {
        padding-left: 300px
    }
}

@media (max-width: 1399px) {
    .header-layout5 .header-button {
        margin-left:0
    }
}

@media (max-width: 1300px) {
    .header-layout5 .header-button {
        margin-left:40px
    }

    .header-layout5 .header-button .th-btn {
        display: none
    }

    .logo-style3 {
        padding: 0 50px 39px 0
    }

    .logo-style3:before {
        right: -25px;
        -webkit-clip-path: polygon(0 0, calc(100% - 80px) 0, 100% 100%, 0% 100%);
        clip-path: polygon(0 0, calc(100% - 80px) 0, 100% 100%, 0% 100%)
    }
}

@media (max-width: 1199px) {
    .header-layout5 .header-top .container {
        padding-left:250px
    }
}

@media (max-width: 991px) {
    .header-layout5 .header-top {
        padding:10px 0
    }

    .header-layout5 .header-top .container {
        padding-left: 12px
    }

    .logo-style3 {
        padding: 17px 0;
        margin-top: 0
    }

    .logo-style3:before {
        display: none
    }
}

@media (max-width: 767px) {
    .header-layout5 .header-top:before {
        display:none
    }
}

.header-layout6 {
    --main-container: 1720px;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    width: 100%;
    background-color: transparent
}

.header-layout6 .main-menu>ul>li>a {
    color: var(--white-color)
}

.header-layout6 .main-menu>ul>li>a:hover {
    color: var(--theme-color)
}

.header-layout6 .simple-icon {
    color: var(--white-color);
    font-size: 16px
}

.header-layout6 .simple-icon:hover {
    color: var(--theme-color)
}

.header-layout6 .sticky-wrapper.sticky {
    background: var(--title-color)
}

.header-layout6 .sticky-wrapper.sticky .logo-style2 {
    padding: 15px 85px 19px 0
}

.logo-style2 {
    position: relative;
    height: 100%;
    z-index: 2;
    padding: 27px 85px 32px 0
}

.logo-style2::before,.logo-style2::after {
    content: '';
    background-color: var(--white-color);
    height: 100%;
    width: 3000px;
    position: absolute;
    top: 0;
    right: 0;
    border-radius: 0 999px 999px 0;
    z-index: -1
}

.logo-style2::after {
    right: -20px;
    width: 72px;
    background-color: transparent;
    border-right: 10px solid var(--white-color)
}

@media (max-width: 1300px) {
    .header-layout6 .header-button .th-btn {
        display:none
    }
}

@media (max-width: 1199px) {
    .header-layout6 .header-button .simple-icon {
        display:none
    }

    .header-layout6 .sticky-wrapper.sticky .logo-style2,.logo-style2 {
        padding: 20px 40px 24px 0
    }
}

@media (max-width: 375px) {
    .logo-style2 img {
        max-width:140px
    }
}

.header-layout7 .header-top {
    background-color: #F8F8F8;
    padding: 17px 0
}

.header-layout7 .header-top a:hover {
    color: var(--theme-color)
}

.header-layout7 .header-top .header-links li>i {
    color: var(--theme-color)
}

.header-layout7 .header-top .header-links li:not(:last-child):before {
    background-color: rgba(0,15,87,0.4)
}

.header-layout7 .menu-area {
    background-color: var(--title-color)
}

.header-layout7 .simple-icon,.header-layout7 .main-menu>ul>li>a {
    color: var(--white-color)
}

.header-layout7 .simple-icon:hover,.header-layout7 .main-menu>ul>li>a:hover {
    color: var(--theme-color)
}

.header-layout7 .header-top-inner {
    padding-left: 250px
}

.header-layout7 .sticky-wrapper.sticky .logo-style1 {
    padding: 17px 80px 17px 0
}

.logo-style1 {
    position: relative;
    z-index: 2;
    padding: 0 80px 39px 0;
    -webkit-filter: drop-shadow(0px -10px 20px rgba(7,36,95,0.05));
    filter: drop-shadow(0px -10px 20px rgba(7,36,95,0.05))
}

.logo-style1:before {
    content: '';
    height: 140px;
    width: 2000px;
    position: absolute;
    bottom: 0;
    right: -15px;
    background-color: var(--white-color);
    z-index: -1;
    -webkit-clip-path: polygon(0 0, calc(100% - 80px) 0, 100% 100%, 0% 100%);
    clip-path: polygon(0 0, calc(100% - 80px) 0, 100% 100%, 0% 100%)
}

@media (max-width: 1300px) {
    .header-layout7 .header-button .th-btn {
        display:none
    }
}

@media (max-width: 1199px) {
    .header-layout7 .header-button .simple-icon {
        display:none
    }

    .logo-style1 {
        padding: 0 50px 39px 0
    }

    .logo-style1:before {
        right: -25px;
        -webkit-clip-path: polygon(0 0, calc(100% - 60px) 0, 100% 100%, 0% 100%);
        clip-path: polygon(0 0, calc(100% - 60px) 0, 100% 100%, 0% 100%)
    }
}

@media (max-width: 991px) {
    .header-layout7 .header-top {
        padding:11px 0
    }

    .header-layout7 .header-top-inner {
        padding-left: 0
    }

    .logo-style1 {
        padding: 17px 80px 17px 0
    }

    .logo-style1:before {
        height: 100%
    }
}

@media (max-width: 575px) {
    .header-layout7 .sticky-wrapper.sticky .logo-style1,.logo-style1 {
        padding:17px 40px 17px 0;
        max-width: 180px
    }
}

.header-layout8 {
    --main-container: 1705px;
    position: absolute;
    top: 40px;
    left: 0;
    right: 0;
    width: 100%;
    background-color: transparent
}

.header-layout8 .main-menu ul.mega-menu>li>a,.header-layout8 .main-menu a {
    color: #2f2e2e
}

.header-layout8 .sticky-wrapper.sticky,.header-layout8 .main-menu ul.sub-menu,.header-layout8 .main-menu ul.mega-menu {
    background: white;
}

.header-layout8 .menu-bar-wrapper {
    background: #86003a;
    padding: 0 30px;
    border-radius: 20px;
    position: relative
}

.header-layout8 .menu-bar-wrapper:after {
    content: '';
    position: absolute;
    height: 100%;
    width: 100%;
    background: #bd3015;
    border-radius: 20px;
    left: 5px;
    top: 5px;
    z-index: -1
}

.header-layout8 .header-button {
    margin-left: 55px;
    gap: 30px
}

.header-layout8 .main-menu ul.sub-menu,.header-layout8 .main-menu ul.mega-menu {
    border-radius: 20px;
    border-color: var(--theme-color);
    border-top: 5px solid var(--theme-color);
    border-bottom: 5px solid var(--theme-color)
}

.header-layout8 .sticky-wrapper.sticky .menu-bar-wrapper:after {
    display: none
}

@media (max-width: 1600px) {
    .header-layout8 .menu-bar-wrapper {
        margin-right:5px
    }
}

@media (max-width: 1299px) {
    .header-layout8 .header-button {
        margin-left:0
    }

    .header-layout8 .header-button .th-btn {
        display: none
    }
}

@media (max-width: 991px) {
    .header-layout8 {
        top:0
    }

    .header-layout8 .menu-bar-wrapper {
        padding: 0;
        margin: 0
    }

    .header-layout8 .menu-bar-wrapper:after {
        display: none
    }
}

.header-layout9 {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    width: 100%;
    background-color: transparent;
    border-bottom: 1px solid rgba(255,255,255,0.3)
}

.header-layout9 .main-menu>ul>li>a {
    padding: 46.5px 0;
    color: var(--white-color)
}

.header-layout9 .main-menu>ul>li>a:hover {
    color: var(--theme-color)
}

.header-layout9:before {
    content: '';
    height: 100%;
    width: 22%;
    background-color: var(--white-color);
    opacity: 0.13;
    position: absolute;
    top: 0;
    right: 0;
    -webkit-clip-path: polygon(100px 0%, 100% 0, 100% 100%, 0% 100%);
    clip-path: polygon(100px 0%, 100% 0, 100% 100%, 0% 100%);
    z-index: -1
}

.header-layout9 .header-button {
    margin-left: 110px
}

.header-layout9 .simple-icon {
    color: var(--white-color)
}

.header-layout9 .simple-icon:hover {
    color: var(--theme-color)
}

.header-layout9 .sticky-wrapper.sticky {
    background: var(--title-color)
}

@media (min-width: 1922px) {
    .header-layout9::before {
        width:30%
    }
}

@media (max-width: 1399px) {
    .header-layout9:before {
        width:26%
    }
}

@media (max-width: 1300px) {
    .header-layout9:before {
        width:16%
    }

    .header-layout9 .header-button .th-btn {
        display: none
    }
}

@media (max-width: 1199px) {
    .header-layout9 .main-menu>ul>li>a {
        padding:31.5px 0
    }
}

@media (max-width: 991px) {
    .header-layout9:before {
        width:50%;
        -webkit-clip-path: polygon(60px 0%, 100% 0, 100% 100%, 0% 100%);
        clip-path: polygon(60px 0%, 100% 0, 100% 100%, 0% 100%)
    }
}

.header-layout10 {
    --main-container: 1380px
}

.header-layout10 .top-area {
    background-color: var(--title-color)
}

.header-layout10 .header-top {
    padding: 12px 0;
    --body-color: #fff;
    border-bottom: 1px solid #202c3c
}

.header-layout10 .header-top a,.header-layout10 .header-top li,.header-layout10 .header-top p,.header-layout10 .header-top span,.header-layout10 .header-top i {
    color: var(--white-color)
}

.header-layout10 .header-top a:hover {
    color: var(--theme-color)
}

.header-layout10 .menu-top {
    padding: 20px 0
}

.header-layout10 .menu-top .icon-btn {
    background-color: var(--theme-color);
    color: var(--white-color);
    border-color: var(--theme-color);
    margin-right: 10px;
    font-size: 14px
}

.header-layout10 .header-link {
    color: var(--white-color);
    padding-right: 30px;
    margin-right: 30px;
    border-right: 1px solid #202c3c;
    display: inline-block;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.header-layout10 .header-link:last-child {
    padding-right: 0;
    margin-right: 0;
    border-right: none
}

.header-layout10 .header-link:hover {
    color: var(--theme-color)
}

.header-layout10 .th-social a {
    background-color: #0f2239;
    border: 1px solid #4d5765;
    color: var(--white-color)
}

.header-layout10 .th-social a:hover {
    background-color: var(--theme-color);
    color: var(--white-color);
    border-color: var(--theme-color)
}

.header-layout10 .simple-icon {
    color: var(--white-color)
}

.header-layout10 .dropdown-menu {
    --body-color: #74787c
}

.header-layout10 .logo-shape {
    display: inline-block;
    height: 100%;
    width: 30%;
    position: absolute;
    top: 0;
    left: 0;
    background: var(--white-color);
    background-size: auto;
    background-repeat: repeat;
    -webkit-clip-path: polygon(0 0, calc(100% - 100px) 0%, 100% 100%, 0% 100%);
    clip-path: polygon(0 0, calc(100% - 100px) 0%, 100% 100%, 0% 100%);
    z-index: -1
}

.header-layout10 .icon-style2 {
    color: var(--title-color)
}

.header-layout10 .menu-area {
    position: relative;
    background-color: var(--theme-color);
    z-index: 2
}

@media (min-width: 1922px) {
    .header-layout10 .menu-area .container {
        margin-right:auto
    }
}

@media (max-width: 1399px) {
    .header-layout10 .menu-area .container {
        margin-right:auto
    }
}

.header-layout10 .main-menu>ul>li {
    margin: 0 18px
}

.header-layout10 .main-menu>ul>li>a {
    color: var(--white-color)
}

.header-layout10 .main-menu ul li.menu-item-has-children>a:after {
    color: var(--white-color)
}

.header-layout10 .th-menu-toggle {
    margin: 20px 0;
    background-color: var(--title-color)
}

.header-layout10 .header-button {
    margin-left: 100px
}

@media (min-width: 1922px) {
    .header-layout10 .logo-shape {
        width:34%
    }
}

@media (max-width: 1700px) {
    .header-layout10 .logo-shape {
        width:27%
    }
}

@media (max-width: 1500px) {
    .header-layout10 .logo-shape {
        width:23%
    }
}

@media (max-width: 1299px) {
    .header-layout10 .header-button {
        margin-left:60px
    }
}

@media (max-width: 1300px) {
    .header-layout10 .header-button {
        margin-left:20px
    }

    .header-layout10 .logo-shape {
        width: 26%
    }
}

@media (max-width: 1199px) {
    .header-layout10 .header-link:nth-child(2) {
        padding-right:0;
        margin-right: 0;
        border-right: none
    }

    .header-layout10 .logo-shape {
        width: 32%
    }
}

@media (max-width: 991px) {
    .header-layout10 .logo-shape {
        width:60%
    }

    .header-layout10 .header-link {
        padding-right: 0;
        margin-right: 0;
        border-right: none
    }
}

@media (max-width: 767px) {
    .header-notice {
        text-align:center;
        font-size: 14px
    }

    .header-layout10 .menu-top {
        padding: 12px 0
    }
}

@media (max-width: 575px) {
    .header-layout10 .logo-shape {
        width:280px
    }
}

.header-layout11 {
    --main-container: 1440px
}

.header-layout11 .header-top {
    background-color: var(--theme-color);
    padding: 14px 0;
    --body-color: #fff
}

.header-layout11 .header-top a,.header-layout11 .header-top li,.header-layout11 .header-top p,.header-layout11 .header-top span,.header-layout11 .header-top i {
    color: var(--body-color)
}

.header-layout11 .header-top a:hover {
    color: var(--white-color)
}

.header-layout11 .header-top li:before {
    background-color: var(--white-color)
}

.header-layout11 .simple-icon {
    color: var(--white-color)
}

.header-layout11 .dropdown-menu {
    --body-color: #74787c
}

.header-layout11 .logo-shape {
    display: inline-block;
    height: 100%;
    width: 27.7%;
    position: absolute;
    top: 0;
    left: 0;
    background-color: var(--white-color);
    -webkit-clip-path: polygon(0 0, 100% 0%, calc(100% - 50px) 100%, 0% 100%);
    clip-path: polygon(0 0, 100% 0%, calc(100% - 50px) 100%, 0% 100%);
    z-index: -1
}

.header-layout11 .menu-area {
    position: relative;
    background-color: #050f2d;
    background-size: auto;
    background-repeat: repeat;
    z-index: 2
}

.header-layout11 .main-menu>ul>li {
    margin: 0 18px
}

.header-layout11 .main-menu>ul>li>a {
    color: var(--white-color);
    padding: 41.5px 0
}

.header-layout11 .th-menu-toggle {
    margin: 20px 0
}

.header-layout11 .header-button {
    margin-left: 100px
}

.header-layout11 .icon-btn:hover {
    border-color: var(--theme-color)
}

.header-layout11 .simple-icon.style2 {
    font-size: 28px
}

@media (min-width: 1922px) {
    .header-layout11 {
        --main-container: 1440px
    }

    .header-layout11 .logo-shape {
        width: 34%
    }
}

@media (max-width: 1700px) {
    .header-layout11 .logo-shape {
        width:25%
    }
}

@media (max-width: 1399px) {
    .header-layout11 .container {
        margin-left:auto;
        margin-right: auto
    }

    .header-layout11 .header-button {
        margin-left: 60px
    }

    .header-layout11 .logo-shape {
        width: 22%
    }
}

@media (max-width: 1300px) {
    .header-layout11 .logo-shape {
        width:26%
    }

    .header-layout11 .header-button .th-btn {
        display: none
    }
}

@media (max-width: 1199px) {
    .header-layout11 .logo-shape {
        width:300px
    }
}

@media (max-width: 991px) {
    .header-layout11 .logo-shape {
        width:60%
    }
}

@media (max-width: 767px) {
    .header-layout11 .header-top {
        padding:8px 0
    }
}

@media (max-width: 375px) {
    .header-layout11 .logo-shape {
        width:75%
    }
}

.header-layout12 {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    --main-container: 1920px
}

.header-layout12 .sticky-wrapper.sticky {
    background-color: var(--title-color)
}

.header-layout12 .container {
    padding-left: 0;
    padding-right: 0
}

.header-layout12 .header-logo {
    background-color: rgba(255,255,255,0.1);
    padding: 15px 145px 15px 50px;
    border-right: 5px solid var(--theme-color);
    height: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.header-layout12 .header-top {
    padding: 15px 0;
    --body-color: #fff
}

.header-layout12 .header-top a,.header-layout12 .header-top li,.header-layout12 .header-top p,.header-layout12 .header-top span,.header-layout12 .header-top i {
    color: var(--white-color)
}

.header-layout12 .header-top a:hover {
    color: var(--theme-color)
}

.header-layout12 .header-top li:before {
    background-color: #d9d9d9
}

.header-layout12 .top-left {
    padding-left: 50px
}

.header-layout12 .top-right {
    width: 1080px;
    padding-right: 50px
}

.header-layout12 .simple-icon {
    color: var(--white-color)
}

.header-layout12 .simple-icon.style2 {
    font-size: 28px
}

.header-layout12 .dropdown-menu {
    --body-color: #74787c
}

.header-layout12 .menu-area {
    position: relative;
    padding: 0 50px;
    background-color: rgba(255,255,255,0.1);
    width: 1080px
}

.header-layout12 .main-menu>ul>li {
    margin: 0 18px
}

.header-layout12 .main-menu>ul>li>a {
    color: var(--white-color);
    padding: 36.5px 0
}

.header-layout12 .th-menu-toggle {
    margin: 15px 0
}

.header-layout12 .header-button {
    margin-left: 10px;
    gap: 30px
}

@media (max-width: 1299px) {
    .header-layout12 .header-logo {
        padding:15px 100px 15px 30px
    }

    .header-layout12 .top-left {
        padding-left: 30px
    }

    .header-layout12 .top-right {
        width: 900px;
        padding-right: 30px
    }

    .header-layout12 .menu-area {
        padding: 0 30px;
        width: 900px
    }
}

@media (max-width: 1399px) {
    .header-layout12 .container {
        max-width:100%
    }

    .header-layout12 .top-right {
        width: 687px
    }

    .header-layout12 .menu-area {
        width: 100%
    }
}

@media (max-width: 1199px) {
    .header-layout12 .header-logo {
        padding:15px 100px 15px 15px
    }

    .header-layout12 .top-left {
        padding-left: 15px
    }

    .header-layout12 .top-right {
        width: 680px;
        padding-right: 15px
    }

    .header-layout12 .menu-area {
        padding: 0 15px
    }
}

@media (max-width: 991px) {
    .header-layout12 .top-left {
        padding-left:15px
    }

    .header-layout12 .top-right {
        width: 100%
    }

    .header-layout12 .top-right .row {
        --bs-gutter-x: 50px
    }
}

@media (max-width: 767px) {
    .header-layout12 .header-logo {
        padding:15px
    }
}

.footer-wrapper {
    position: relative;
    z-index: 2;
    background-color: #0E121D
}

.footer-wrapper .newsletter-title {
    color: var(--white-color)
}

.footer-wrapper .th-social a {
    background-color: #3D4250;
    color: var(--white-color);
    border-radius: 0
}

.footer-wrapper .th-social a:hover {
    background-color: var(--theme-color);
    border-color: var(--theme-color);
    color: var(--white-color)
}

.widget-area {
    padding-bottom: 80px
}

@media (max-width: 991px) {
    .widget-area {
        padding-bottom:40px
    }
}

.copyright-wrap {
    padding: 26px 0;
    background: #262A36
}

.copyright-text {
    margin: 0
}

.copyright-text a {
    color: #df722b
}

.copyright-text a:hover {
    color: var(--white-color)
}

@media (max-width: 1399px) {
    .th-social a {
        margin-right:3px
    }

    .th-social a:last-child {
        margin-right: 0
    }
}

.footer-links ul {
    padding: 0;
    margin: 0
}

.footer-links li {
    font-family: var(--body-font);
    display: inline-block;
    margin-right: 10px;
    padding-right: 15px;
    border-right: 1px solid var(--body-color)
}

.footer-links li:last-child {
    margin-right: 0;
    border-right: 0;
    padding-right: 0
}

.footer-links a {
    font-family: inherit;
    color: var(--body-color)
}

.footer-links a:hover {
    color: var(--white-color)
}

.footer-layout-default {
    --body-color: #B2B2B2
}

.footer-layout-default .copyright-wrap {
    padding: 26px 0
}

.footer-layout1 {
    --body-color: #B2B2B2;
    overflow: hidden
}

.footer-layout1 .copyright-wrap {
    background: rgba(255,255,255,0.12);
    padding: 26px 0;
    position: relative;
    z-index: 1
}

.footer-contact {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 15px;
    padding: 30px 0
}

.footer-contact-wrap {
    display: grid;
    grid-template-columns: auto auto auto auto auto;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.footer-contact-wrap .divider {
    background-color: rgba(255,255,255,0.2);
    height: 66px;
    width: 1px
}

.footer-contact_icon {
    background: rgba(255,255,255,0.12);
    border: 1px solid rgba(255,255,255,0.34);
    border-radius: 50%;
    color: var(--white-color);
    font-size: 24px;
    --btn-size: 60px;
    position: relative;
    z-index: 1
}

.footer-contact_icon i {
    height: 100%;
    width: 100%;
    -webkit-backdrop-filter: blur(9.8px);
    backdrop-filter: blur(9.8px);
    line-height: 60px;
    border-radius: 50%
}

.footer-contact_icon:after,.footer-contact_icon:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    background: var(--theme-color);
    border-radius: 50%;
    height: 20px;
    width: 20px;
    z-index: -2
}

.footer-contact_icon:after {
    height: 30px;
    width: 30px;
    top: auto;
    bottom: -6px;
    left: auto;
    right: 0
}

.footer-contact_icon:hover {
    background: rgba(255,255,255,0.12)
}

.footer-contact_text {
    margin-bottom: 3px;
    font-size: 14px;
    font-weight: 400;
    color: #B3C1D3
}

.footer-contact_link {
    font-size: 20px;
    font-weight: 600;
    color: var(--white-color);
    display: block;
    margin-bottom: -0.2em
}

.footer-contact_link:hover {
    color: var(--theme-color)
}

@media (max-width: 991px) {
    .footer-contact {
        padding:30px 0
    }

    .footer-contact-wrap {
        grid-template-columns: 100%
    }

    .footer-contact-wrap .divider {
        display: none
    }

    .footer-contact:not(:last-child) {
        border-bottom: 1px solid rgba(255,255,255,0.2)
    }
}

.footer-layout2 {
    --body-color: #B2B2B2;
    position: relative
}

.footer-layout2:after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    background: var(--black-color);
    width: 825px;
    z-index: -1
}

.footer-layout2 .th-widget-contact {
    margin-bottom: -0.3em
}

.footer-layout2 .th-widget-about {
    max-width: 345px
}

.footer-layout2 .th-social a {
    border-radius: 5px
}

.footer-layout2 .copyright-wrap {
    padding: 17px 0
}

@media (min-width: 1922px) {
    .footer-layout2:after {
        display:none
    }
}

@media (max-width: 1500px) {
    .footer-layout2:after {
        display:none
    }
}

@media (max-width: 991px) {
    .footer-layout2 .footer-info {
        font-size:14px
    }
}

@media (max-width: 320px) {
    .footer-layout2 .footer-info-grid {
        -webkit-flex-wrap:wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }
}

.footer-layout3 {
    --body-color: #B2B2B2
}

.footer-layout3 .copyright-wrap {
    padding: 17px 0
}

.footer-layout3 .copyright-text {
    color: var(--white-color)
}

.footer-layout3 .footer-links a {
    color: var(--white-color)
}

.footer-layout3 .footer-links a:hover {
    color: var(--theme-color)
}

.footer-layout3 .th-social a {
    --icon-size: 46px
}

.info-box {
    display: inline-block
}

.info-box-wrap {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 15px;
    margin-bottom: 25px
}

.info-box-wrap:last-child {
    margin-bottom: 0
}

.info-box_text {
    display: block;
    color: var(--body-color);
    margin-bottom: 0
}

.info-box-title {
    font-size: 18px;
    font-weight: 600
}

.info-box_link {
    color: var(--body-color);
    margin-bottom: -0.4em
}

.info-box_link:hover {
    color: var(--theme-color)
}

.info-box_icon {
    color: var(--white-color);
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    font-size: 12px;
    height: 26px;
    width: 26px;
    background: var(--theme-color);
    text-align: center
}

.newsletter-form {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    width: 100%;
    max-width: 680px;
    gap: 0px
}

.newsletter-form .form-group {
    margin-bottom: 0;
    width: 100%
}

.newsletter-form .form-group>i {
    top: 19px;
    color: var(--theme-color)
}

.newsletter-form input {
    background-color: var(--white-color);
    border-radius: 0px;
    border: 0 !important;
    margin-bottom: 0;
    height: 56px;
    color: var(--title-color);
    padding: 0 20px
}

.newsletter-form input::-moz-placeholder {
    color: var(--body-color)
}

.newsletter-form input::-webkit-input-placeholder {
    color: var(--body-color)
}

.newsletter-form input:-ms-input-placeholder {
    color: var(--body-color)
}

.newsletter-form input::-ms-input-placeholder {
    color: var(--body-color)
}

.newsletter-form input::placeholder {
    color: var(--body-color)
}

.newsletter-form input:focus {
    color: var(--title-color);
    background: var(--white-color)
}

.newsletter-form .th-btn {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    box-shadow: none;
    width: 56px;
    height: 56px;
    line-height: 56px;
    padding: 0;
    text-align: center
}

@media (max-width: 767px) {
    .newsletter-wrap {
        -webkit-flex-wrap:wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }

    .newsletter-wrap .newsletter-title {
        text-align: center;
        max-width: 100%
    }
}

@media (max-width: 575px) {
    .newsletter-form {
        -webkit-flex-wrap:wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center;
        gap: 15px
    }

    .newsletter-form .th-btn {
        margin-left: 0
    }
}

.footer-layout4 {
    --body-color: #8993A1;
    --border-color: #313541
}

.footer-layout4 .th-widget-about .about-logo {
    margin-bottom: 37px
}

.footer-layout4 .widget_nav_menu {
    border-top: 1px solid var(--border-color);
    border-bottom: 1px solid var(--border-color);
    padding: 22px 0
}

.footer-layout4 .widget_nav_menu .menu {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    gap: 80px;
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap
}

@media (max-width: 991px) {
    .footer-layout4 .widget_nav_menu .menu {
        gap:20px 50px
    }
}

.footer-layout4 .widget_nav_menu a {
    margin: 0;
    padding: 0;
    font-weight: 500;
    color: var(--white-color)
}

.footer-layout4 .widget_nav_menu a:before {
    display: none
}

.footer-layout4 .newsletter-form {
    gap: 10px
}

.footer-layout4 .newsletter-form input {
    background: #262A36;
    color: var(--white-color)
}

.footer-layout4 .newsletter-form .th-btn {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    width: auto;
    padding: 0 23px
}

.footer-layout4 .copyright-wrap {
    padding: 17px 0;
    background: #262A36
}

.footer-layout5 {
    background-color: var(--title-color);
    --body-color: #fff;
    --border-color: rgba(255, 255, 255, 0.12)
}

.footer-layout5 .widget-area {
    padding-top: 100px;
    padding-bottom: 55px
}

.footer-layout5 .copyright-wrap {
    padding: 25.5px 0;
    border-top: 1px solid var(--border-color);
    background: transparent
}

.footer-top {
    border-bottom: 1px solid var(--border-color)
}

.footer-top .footer-logo {
    padding: 80px 0;
    border-right: 1px solid var(--border-color)
}

.subscribe-box {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    width: 100%;
    padding-left: 16px
}

.subscribe-box_text {
    color: rgba(255,255,255,0.6);
    font-weight: 600;
    margin-bottom: 8px
}

.subscribe-box_title {
    color: var(--white-color);
    margin-bottom: 0
}

.subscribe-box .newsletter-form {
    max-width: 440px;
    gap: 10px
}

.subscribe-box .form-control {
    border: 1px solid var(--title-color);
    color: #4D5765;
    border-radius: 5px
}

.subscribe-box .form-control::-moz-placeholder {
    color: #4D5765
}

.subscribe-box .form-control::-webkit-input-placeholder {
    color: #4D5765
}

.subscribe-box .form-control:-ms-input-placeholder {
    color: #4D5765
}

.subscribe-box .form-control::-ms-input-placeholder {
    color: #4D5765
}

.subscribe-box .form-control::placeholder {
    color: #4D5765
}

.subscribe-box .th-btn {
    min-width: 140px
}

@media (max-width: 1199px) {
    .footer-top .footer-logo {
        text-align:center;
        border-right: none;
        padding: 60px 0 30px 0
    }

    .subscribe-box {
        padding-bottom: 50px
    }
}

@media (max-width: 991px) {
    .footer-layout5 .widget-area {
        padding-top:80px;
        padding-bottom: 40px
    }

    .subscribe-box {
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center;
        text-align: center;
        gap: 20px
    }

    .subscribe-box .newsletter-form {
        max-width: 500px;
        width: 100%
    }
}

@media (max-width: 575px) {
    .subscribe-box .newsletter-form {
        -webkit-flex-wrap:wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }
}

.footer-layout6 {
    background-color: var(--title-color);
    --body-color: #fff
}

.footer-layout6 .widget-area {
    padding-top: 100px;
    padding-bottom: 55px
}

.footer-layout6 .copyright-wrap {
    padding: 16px 0
}

.newsletter-wrap2 {
    background-color: var(--theme-color);
    padding: 60px;
    position: relative;
    z-index: 4
}

.newsletter-wrap2 .newsletter-title {
    color: var(--white-color);
    margin-top: -0.2em;
    margin-bottom: 20px
}

.newsletter-wrap2 .newsletter-form {
    max-width: 600px;
    gap: 10px
}

.newsletter-wrap2 .form-control {
    border: 1px solid var(--theme-color);
    color: var(--body-color)
}

.newsletter-wrap2 .form-control::-moz-placeholder {
    color: var(--body-color)
}

.newsletter-wrap2 .form-control::-webkit-input-placeholder {
    color: var(--body-color)
}

.newsletter-wrap2 .form-control:-ms-input-placeholder {
    color: var(--body-color)
}

.newsletter-wrap2 .form-control::-ms-input-placeholder {
    color: var(--body-color)
}

.newsletter-wrap2 .form-control::placeholder {
    color: var(--body-color)
}

.newsletter-wrap2 .th-btn {
    min-width: 160px
}

.newsletter-wrap2 .newsletter-shape {
    position: absolute;
    bottom: 0;
    right: 0
}

.footer-spacer {
    height: 145px
}

@media (max-width: 1199px) {
    .newsletter-wrap2 {
        padding:60px 30px
    }

    .newsletter-wrap2 .newsletter-shape {
        max-width: 390px
    }

    .footer-spacer {
        height: 100px
    }
}

@media (max-width: 991px) {
    .footer-layout6 .widget-area {
        padding-top:80px;
        padding-bottom: 40px
    }

    .newsletter-wrap2 {
        padding: 40px;
        text-align: center
    }

    .newsletter-wrap2 .newsletter-form {
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center;
        max-width: 100%
    }

    .newsletter-wrap2 .newsletter-shape {
        max-width: 450px;
        position: relative;
        margin: -140px auto 20px auto
    }
}

@media (max-width: 575px) {
    .newsletter-wrap2 {
        padding:20px
    }

    .newsletter-wrap2 .newsletter-form {
        -webkit-flex-wrap: wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }

    .newsletter-wrap2 .newsletter-shape {
        margin: -120px auto 20px auto
    }
}

.footer-layout7 {
    background-color: var(--title-color);
    --body-color: #F8F8F8;
    overflow: hidden
}

.footer-layout7 .copyright-wrap {
    padding: 16px 0;
    background-color: #0E121D
}

.footer-layout7 .newsletter-widget {
    position: relative;
    z-index: 2;
    padding: 40px;
    padding-top: 0;
    max-width: 360px
}

.footer-layout7 .newsletter-widget .bg-shape {
    background-color: var(--theme-color);
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 200%;
    z-index: -1
}

.footer-layout7 .newsletter-widget .widget_title::before {
    background-color: var(--white-color)
}

.footer-layout7 .newsletter-widget .widget_title:after {
    border-color: var(--theme-color)
}

@media (max-width: 1199px) {
    .footer-layout7 .newsletter-widget {
        padding-top:40px
    }

    .footer-layout7 .newsletter-widget .bg-shape {
        height: 100%
    }
}

.footer-layout8 {
    background-color: var(--title-color);
    --body-color: #fff;
    --border-color: rgba(255, 255, 255, 0.12)
}

.footer-layout8 .widget-area {
    padding-top: 40px;
    padding-bottom: 46px
}

.footer-layout8 .copyright-wrap {
    padding: 25.5px 0;
    border-top: 1px solid var(--border-color);
    background: transparent
}

.subscribe-wrap .newsletter-wrap {
    border-radius: 10px;
    padding: 69.5px 80px;
    z-index: 4;
    position: relative
}

.subscribe-wrap .newsletter-wrap .newsletter-subtitle {
    font-size: 16px;
    font-weight: 600
}

.subscribe-wrap .newsletter-wrap .newsletter-title {
    font-size: 30px;
    color: var(--white-color)
}

.subscribe-wrap .newsletter-wrap .newsletter-form {
    gap: 10px
}

.subscribe-wrap .newsletter-wrap .newsletter-form .form-control {
    border-radius: 5px;
    border: 0
}

.subscribe-wrap .newsletter-wrap .newsletter-form .th-btn {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    padding: 0 30px;
    width: auto
}

@media (max-width: 1199px) {
    .subscribe-wrap .newsletter-wrap {
        padding:60px 50px
    }
}

@media (max-width: 575px) {
    .subscribe-wrap .newsletter-wrap {
        padding:50px 30px
    }
}

.breadcumb-menu {
    max-width: 100%;
    padding: 0;
    margin: 23px 0 -0.5em 0;
    list-style-type: none;
    position: relative
}

.breadcumb-menu li {
    display: inline;
    margin-right: 3px;
    padding-right: 5px;
    list-style: none;
    position: relative;
    text-transform: uppercase
}

.breadcumb-menu li:after {
    content: '\f101';
    position: relative;
    margin-left: 10px;
    font-weight: 400;
    font-size: 15px;
    color: var(--white-color);
    font-family: var(--icon-font)
}

.breadcumb-menu li a:hover {
    color: var(--theme-color)
}

.breadcumb-menu li:last-child {
    padding-right: 0;
    margin-right: 0
}

.breadcumb-menu li:last-child:after {
    display: none
}

.breadcumb-menu li,.breadcumb-menu a,.breadcumb-menu span {
    white-space: normal;
    color: inherit;
    word-break: break-word;
    font-weight: 600;
    font-size: 18px;
    font-family: var(--title-font);
    color: var(--white-color)
}

.breadcumb-title {
    font-size: 40px;
    font-weight: 700;
    line-height: 1.18;
    text-transform: uppercase;
    color: var(--white-color);
    margin: -0.17em 0 -0.26em 0
}

.breadcumb-wrapper {
    padding: 158px 0;
    padding-bottom: 81px;
    overflow: hidden;
    position: relative;
    z-index: 0
}

.breadcumb-wrapper:before {
    z-index: -1
}

.breadcumb-wrapper .breadcumb-shape {
    position: absolute;
    left: 0;
    top: 0;
    z-index: -1;
    width: 100%;
    height: 100%;
    background-position: right
}

.breadcumb-wrapper .breadcumb-shape img {
    width: 100%
}

@media (max-width: 1199px) {
    .breadcumb-title {
        font-size:42px
    }

    .breadcumb-wrapper {
        padding: 120px 0
    }
}

@media (max-width: 991px) {
    .breadcumb-wrapper {
        padding:100px 0
    }

    .breadcumb-menu {
        margin: 16px 0 -0.5em 0
    }

    .breadcumb-menu li,.breadcumb-menu a,.breadcumb-menu span {
        font-size: 16px
    }

    .breadcumb-title {
        font-size: 38px
    }
}

@media (max-width: 767px) {
    .breadcumb-wrapper {
        padding:80px 0
    }

    .breadcumb-title {
        font-size: 34px
    }
}

@media (max-width: 575px) {
    .breadcumb-title {
        font-size:28px
    }
}

.th-pagination {
    margin-bottom: 30px
}

.th-pagination ul {
    margin: 0;
    padding: 0
}

.th-pagination li {
    display: inline-block;
    margin: 0 3px;
    list-style-type: none
}

.th-pagination li:last-child {
    margin-right: 0
}

.th-pagination li:first-child {
    margin-left: 0
}

.th-pagination span,.th-pagination a {
    display: inline-block;
    text-align: center;
    position: relative;
    border: none;
    color: var(--title-color);
    background-color: #EEEEEE;
    width: 55px;
    height: 55px;
    line-height: 55px;
    z-index: 1;
    font-size: 16px;
    font-weight: 500;
    font-family: var(--body-font);
    border-radius: 0px
}

.th-pagination span.active,.th-pagination span:hover,.th-pagination a.active,.th-pagination a:hover {
    color: var(--white-color);
    background-color: var(--theme-color);
    box-shadow: none
}

@media (max-width: 767px) {
    .th-pagination span,.th-pagination a {
        width:40px;
        height: 40px;
        line-height: 40px;
        font-size: 14px
    }
}

blockquote,.wp-block-quote {
    font-size: 18px;
    line-height: 1.56;
    padding: 30px 40px;
    font-weight: 500;
    display: block;
    position: relative;
    background-color: transparent;
    margin: 35px 0 45px 0;
    color: var(--title-color);
    font-family: var(--body-font);
    font-style: italic;
    border: 1px solid #D0DBE9 !important;
    border-radius: 10px
}

blockquote p,.wp-block-quote p {
    font-size: inherit;
    font-family: inherit;
    margin-top: -0.3em;
    margin-bottom: 9px;
    line-height: inherit;
    color: inherit;
    width: 100%;
    position: relative;
    z-index: 3
}

blockquote p a,.wp-block-quote p a {
    color: inherit
}

blockquote:before,.wp-block-quote:before {
    content: "";
    position: absolute;
    top: -1px;
    left: -1px;
    height: 50px;
    width: 33px;
    background-color: var(--smoke-color)
}

blockquote:after,.wp-block-quote:after {
    content: "";
    position: absolute;
    top: -10px;
    left: 0px;
    height: 20px;
    width: 25px;
    background-color: var(--theme-color);
    -webkit-clip-path: path("M2.21945 18.2759C0.775335 16.6762 0 14.8819 0 11.9734C0 6.8553 3.44484 2.26804 8.45438 0L9.70641 2.01506C5.03057 4.65307 4.11643 8.07633 3.75189 10.2347C4.5048 9.82818 5.49044 9.68633 6.45645 9.77992C8.98576 10.0241 10.9795 12.1898 10.9795 14.8819C10.9795 16.2393 10.4625 17.5411 9.54219 18.5009C8.62192 19.4608 7.37376 20 6.07229 20C5.35256 19.9934 4.64126 19.8376 3.97981 19.5416C3.31836 19.2457 2.71996 18.8154 2.21945 18.2759ZM16.24 18.2759C14.7959 16.6762 14.0205 14.8819 14.0205 11.9734C14.0205 6.8553 17.4654 2.26804 22.4749 0L23.7269 2.01506C19.0511 4.65307 18.137 8.07633 17.7724 10.2347C18.5253 9.82818 19.511 9.68633 20.477 9.77992C23.0063 10.0241 25 12.1898 25 14.8819C25 16.2393 24.483 17.5411 23.5627 18.5009C22.6424 19.4608 21.3943 20 20.0928 20C19.3731 19.9934 18.6618 19.8376 18.0003 19.5416C17.3389 19.2457 16.7405 18.8154 16.24 18.2759Z");
    clip-path: path("M2.21945 18.2759C0.775335 16.6762 0 14.8819 0 11.9734C0 6.8553 3.44484 2.26804 8.45438 0L9.70641 2.01506C5.03057 4.65307 4.11643 8.07633 3.75189 10.2347C4.5048 9.82818 5.49044 9.68633 6.45645 9.77992C8.98576 10.0241 10.9795 12.1898 10.9795 14.8819C10.9795 16.2393 10.4625 17.5411 9.54219 18.5009C8.62192 19.4608 7.37376 20 6.07229 20C5.35256 19.9934 4.64126 19.8376 3.97981 19.5416C3.31836 19.2457 2.71996 18.8154 2.21945 18.2759ZM16.24 18.2759C14.7959 16.6762 14.0205 14.8819 14.0205 11.9734C14.0205 6.8553 17.4654 2.26804 22.4749 0L23.7269 2.01506C19.0511 4.65307 18.137 8.07633 17.7724 10.2347C18.5253 9.82818 19.511 9.68633 20.477 9.77992C23.0063 10.0241 25 12.1898 25 14.8819C25 16.2393 24.483 17.5411 23.5627 18.5009C22.6424 19.4608 21.3943 20 20.0928 20C19.3731 19.9934 18.6618 19.8376 18.0003 19.5416C17.3389 19.2457 16.7405 18.8154 16.24 18.2759Z")
}

blockquote cite,.wp-block-quote cite {
    display: inline-block;
    font-size: 20px;
    line-height: 1;
    font-weight: 500;
    font-style: normal;
    font-family: var(--title-font);
    white-space: nowrap;
    position: absolute;
    bottom: -17px;
    left: 80px;
    background-color: var(--theme-color);
    color: var(--white-color);
    padding: 7px 40px 7px 15px;
    -webkit-clip-path: polygon(0 0, 100% 0, calc(100% - 25px) 100%, 0% 100%);
    clip-path: polygon(0 0, 100% 0, calc(100% - 25px) 100%, 0% 100%);
    border-radius: 5px
}

blockquote cite br,.wp-block-quote cite br {
    display: none
}

blockquote.is-large:not(.is-style-plain),blockquote.is-style-large:not(.is-style-plain),blockquote.style-left-icon,blockquote.has-text-align-right,.wp-block-quote.is-large:not(.is-style-plain),.wp-block-quote.is-style-large:not(.is-style-plain),.wp-block-quote.style-left-icon,.wp-block-quote.has-text-align-right {
    padding: 40px;
    margin-bottom: 30px
}

blockquote.style-left-icon,.wp-block-quote.style-left-icon {
    font-size: 18px;
    color: var(--body-color);
    font-weight: 400;
    line-height: 1.556;
    background-color: var(--smoke-color);
    padding-left: 160px
}

blockquote.style-left-icon:before,.wp-block-quote.style-left-icon:before {
    right: unset;
    left: 56px;
    top: 60px;
    font-size: 6rem;
    font-weight: 400;
    line-height: 4rem;
    color: var(--theme-color);
    text-shadow: none
}

blockquote.style-left-icon cite,.wp-block-quote.style-left-icon cite {
    color: var(--title-color)
}

blockquote.style-left-icon cite:before,.wp-block-quote.style-left-icon cite:before {
    background-color: var(--title-color);
    top: 8px
}

blockquote:not(:has(>cite)) p:last-child,.wp-block-quote:not(:has(>cite)) p:last-child {
    margin-bottom: -0.3em
}

blockquote p:has(cite),.wp-block-quote p:has(cite) {
    padding-bottom: 10px
}

blockquote p cite,.wp-block-quote p cite {
    margin-top: 20px;
    margin-bottom: -0.5em;
    bottom: -32px
}

.wp-block-pullquote {
    color: var(--white-color);
    padding: 0
}

blockquote.has-very-dark-gray-color {
    color: var(--title-color) !important
}

.wp-block-pullquote blockquote,.wp-block-pullquote p {
    color: var(--title-color)
}

.wp-block-pullquote cite {
    position: absolute;
    color: var(--white-color) !important
}

.wp-block-column blockquote,.wp-block-column .wp-block-quote {
    padding: 40px 15px 40px 15px
}

.wp-block-column blockquote:before,.wp-block-column .wp-block-quote:before {
    width: 100%;
    height: 60px;
    font-size: 30px
}

.wp-block-column blockquote.style-left-icon,.wp-block-column blockquote.is-large:not(.is-style-plain),.wp-block-column blockquote.is-style-large:not(.is-style-plain),.wp-block-column blockquote.has-text-align-right,.wp-block-column .wp-block-quote.style-left-icon,.wp-block-column .wp-block-quote.is-large:not(.is-style-plain),.wp-block-column .wp-block-quote.is-style-large:not(.is-style-plain),.wp-block-column .wp-block-quote.has-text-align-right {
    padding: 40px 15px 40px 15px
}

.wp-block-column blockquote cite,.wp-block-column .wp-block-quote cite {
    font-size: 14px;
    left: 20px
}

.wp-block-column blockquote cite:before,.wp-block-column .wp-block-quote cite:before {
    bottom: 6px
}

.wp-block-pullquote__citation::before,.wp-block-pullquote cite::before,.wp-block-pullquote footer::before {
    bottom: 7px
}

.has-cyan-bluish-gray-background-color blockquote,.has-cyan-bluish-gray-background-color .wp-block-quote {
    background-color: var(--white-color)
}

@media (max-width: 767px) {
    .wp-block-pullquote.is-style-solid-color blockquote {
        max-width:90%
    }

    blockquote cite,.wp-block-quote cite {
        font-size: 18px;
        left: 30px
    }
}

@media (max-width: 575px) {
    .wp-block-quote.is-large:not(.is-style-plain) p,.wp-block-quote.is-style-large:not(.is-style-plain) p {
        font-size:1.2em
    }
}

@media (max-width: 375px) {
    blockquote cite,.wp-block-quote cite {
        font-size:18px;
        padding-left: 22px
    }

    blockquote cite:before,.wp-block-quote cite:before {
        width: 20px
    }
}

.blog-meta span,.blog-meta a {
    display: inline-block;
    margin-right: 15px;
    padding-right: 20px;
    font-size: 14px;
    color: var(--body-color);
    position: relative
}

.blog-meta span:after,.blog-meta a:after {
    content: "";
    width: 1px;
    height: 20px;
    background-color: #d3dbeb;
    position: absolute;
    top: 50%;
    right: 0;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%)
}

.blog-meta span:last-child,.blog-meta a:last-child {
    margin-right: 0;
    padding-right: 0
}

.blog-meta span:last-child:after,.blog-meta a:last-child:after {
    display: none
}

.blog-meta span i,.blog-meta a i {
    margin-right: 10px;
    color: var(--theme-color)
}

.blog-meta span img,.blog-meta a img {
    margin-right: 10px
}

.blog-meta a:hover {
    color: var(--theme-color)
}

.blog-bottom {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    border-top: 1px dashed #d3dbeb;
    padding-top: 26px;
    margin-bottom: -0.4em
}

.blog-bottom span:not(.link-btn),.blog-bottom a:not(.link-btn) {
    color: var(--body-color)
}

.blog-bottom span:not(.link-btn) i,.blog-bottom a:not(.link-btn) i {
    margin-right: 8px;
    color: var(--theme-color)
}

.blog-bottom a:hover {
    color: var(--theme-color)
}

.blog-audio img,.blog-img img,.blog-video img {
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.blog-title a {
    color: inherit
}

.blog-title a:hover {
    color: var(--theme-color)
}

.th-blog {
    margin-bottom: 30px
}

.blog-inner-title {
    font-size: 36px;
    margin-top: -0.25em;
    margin-bottom: 30px
}

.blog-author,.course-author-box {
    margin-top: 40px;
    margin-bottom: 40px;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    background-color: var(--smoke-color);
    border-radius: 8px;
    overflow: hidden
}

.blog-author .auhtor-img,.course-author-box .auhtor-img {
    min-height: 100%
}

.blog-author .auhtor-img img,.course-author-box .auhtor-img img {
    height: 100%;
    object-fit: cover;
    object-position: center center
}

.blog-author .author-name,.course-author-box .author-name {
    font-size: 24px;
    margin-top: -0.2em;
    margin-bottom: 10px
}

.blog-author .author-text,.course-author-box .author-text {
    margin-bottom: 15px
}

.blog-author .media-body,.course-author-box .media-body {
    padding: 35px 40px 30px 40px;
    -webkit-align-self: center;
    -ms-flex-item-align: center;
    align-self: center
}

.blog-author .th-social a,.course-author-box .th-social a {
    border-radius: 6px;
    --icon-size: 36px;
    font-size: 13px
}

.blog-single {
    position: relative;
    margin-bottom: var(--blog-space-y, 40px);
    background: var(--smoke-color)
}

.blog-single .blog-title {
    margin-bottom: 13px;
    font-size: 38px;
    font-weight: 600
}

.blog-single .blog-text {
    margin-bottom: 32px
}

.blog-single .social-links {
    margin: 0;
    padding: 5px 20px;
    list-style-type: none;
    display: inline-block;
    background-color: var(--smoke-color);
    border-radius: 999px
}

.blog-single .social-links li {
    display: inline-block;
    margin-right: 13px
}

.blog-single .social-links li:last-child {
    margin-right: 0
}

.blog-single .social-links a {
    line-height: 1;
    font-size: 16px;
    color: var(--title-color);
    text-align: center;
    display: block
}

.blog-single .social-links a:hover {
    color: var(--theme-color)
}

.blog-single .blog-meta {
    margin: 0 0 18px 0
}

.blog-single .blog-content {
    margin: 0 0 0 0;
    padding: var(--blog-space-y, 40px) var(--blog-space-x, 40px);
    position: relative
}

.blog-single .blog-audio,.blog-single .blog-img,.blog-single .blog-video {
    position: relative;
    overflow: hidden;
    background-color: var(--smoke-color);
    line-height: 0
}

.blog-single .blog-img .slick-arrow {
    --pos-x: 50px;
    border: none;
    background-color: var(--white-color);
    color: var(--theme-color)
}

.blog-single .blog-img .slick-arrow:hover {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.blog-single .blog-img .play-btn {
    --icon-size: 60px;
    --icon-font-size: 20px;
    position: absolute;
    left: 50%;
    top: 50%;
    margin: calc(var(--icon-size) / -2) 0 0 calc(var(--icon-size) / -2)
}

.blog-single .checklist li {
    padding: 0;
    font-family: var(--body-font);
    color: var(--body-color);
    font-weight: 400;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 8px;
    margin-bottom: 0
}

.blog-single .checklist li:before {
    display: none
}

.blog-single .th-btn {
    padding: 16px 29px
}

.blog-single:hover .blog-img .slick-arrow {
    opacity: 1;
    visibility: visible
}

.share-links-title {
    font-size: 20px;
    color: var(--title-color);
    font-family: var(--title-font);
    font-weight: 600;
    margin: 0 15px 0 0;
    display: inline-block
}

.share-links {
    margin: 30px 0 0px 0;
    border-top: 1px solid #D0DBE9;
    padding: 30px 0 0
}

.share-links>.row {
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    --bs-gutter-y: 20px
}

.share-links .tagcloud {
    display: inline-block
}

@media (max-width: 1399px) {
    .blog-single .blog-title {
        font-size:30px
    }
}

@media (max-width: 1199px) {
    blockquote,.wp-block-quote {
        font-size:18px;
        padding: 40px 20px 40px 20px
    }

    blockquote:before,.wp-block-quote:before {
        font-size: 4rem;
        line-height: 2.5rem
    }

    blockquote.style-left-icon,blockquote.is-large:not(.is-style-plain),blockquote.is-style-large:not(.is-style-plain),blockquote.has-text-align-right,.wp-block-quote.style-left-icon,.wp-block-quote.is-large:not(.is-style-plain),.wp-block-quote.is-style-large:not(.is-style-plain),.wp-block-quote.has-text-align-right {
        padding: 40px 20px 40px 20px
    }

    .blog-single {
        --blog-space-y: 30px;
        --blog-space-x: 30px
    }

    .blog-details .blog-single {
        --blog-space-x: 20px;
        --blog-space-y: 20px
    }
}

@media (max-width: 991px) {
    .blog-details .blog-single {
        --blog-space-x: 40px;
        --blog-space-y: 40px
    }
}

@media (max-width: 767px) {
    .wp-block-pullquote.is-style-solid-color blockquote {
        max-width:90%
    }

    .blog-inner-title {
        font-size: 26px
    }

    .blog-author,.course-author-box {
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -webkit-flex-direction: column;
        -ms-flex-direction: column;
        flex-direction: column
    }

    .blog-author .auhtor-img img,.course-author-box .auhtor-img img {
        width: 100%
    }

    .blog-details .blog-single {
        --blog-space-x: 20px;
        --blog-space-y: 20px
    }

    .blog-single {
        --blog-space-y: 20px;
        --blog-space-x: 20px
    }

    .blog-single .blog-title {
        font-size: 24px;
        line-height: 1.3
    }

    .blog-single .blog-text {
        margin-bottom: 15px
    }

    .blog-single .blog-bottom {
        padding-top: 15px
    }

    .blog-single .share-links-title {
        font-size: 18px;
        display: block;
        margin: 0 0 10px 0
    }
}

@media (max-width: 575px) {
    .blog-author .media-body,.course-author-box .media-body {
        padding:35px 20px 30px 20px
    }

    .blog-meta a,.blog-meta span {
        padding-right: 0
    }

    .blog-meta a::after,.blog-meta span::after {
        display: none
    }
}

@media (max-width: 375px) {
    blockquote cite,.wp-block-quote cite {
        font-size:18px;
        padding-left: 22px
    }

    blockquote cite:before,.wp-block-quote cite:before {
        width: 20px
    }
}

.th-comment-form {
    margin-top: var(--blog-space-y, 50px);
    margin-bottom: 30px;
    position: relative;
    padding: var(--blog-space-y, 40px) var(--blog-space-x, 40px);
    background: var(--smoke-color);
    border-radius: 0px
}

.th-comment-form .row {
    --bs-gutter-x: 20px
}

.th-comment-form .blog-inner-title {
    margin-bottom: 0px
}

.th-comment-form .form-title {
    margin-top: -0.35em
}

.th-comment-form .form-title a#cancel-comment-reply-link {
    font-size: 0.7em;
    text-decoration: underline
}

.th-comment-form .form-text {
    margin-bottom: 25px
}

.blog-comment-area {
    margin-bottom: 25px
}

.th-comments-wrap {
    padding: var(--blog-space-y, 40px) var(--blog-space-x, 40px);
    background: var(--smoke-color);
    border-radius: 0px
}

.th-comments-wrap {
    margin-top: var(--blog-space-y, 50px)
}

.th-comments-wrap .description p:last-child {
    margin-bottom: -0.5em
}

.th-comments-wrap .comment-respond {
    margin: 30px 0
}

.th-comments-wrap pre {
    background: #ededed;
    color: #666;
    font-size: 14px;
    margin: 20px 0;
    overflow: auto;
    padding: 20px;
    white-space: pre-wrap;
    word-wrap: break-word
}

.th-comments-wrap li {
    margin: 0;
    margin-bottom: 30px
}

.th-comments-wrap .th-post-comment {
    padding: 0;
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    margin-bottom: 30px;
    padding: 30px;
    position: relative;
    background: var(--white-color);
    border-radius: 0px
}

.th-comments-wrap .th-post-comment ol,.th-comments-wrap .th-post-comment ul,.th-comments-wrap .th-post-comment dl {
    margin-bottom: 1rem
}

.th-comments-wrap .th-post-comment ol ol,.th-comments-wrap .th-post-comment ol ul,.th-comments-wrap .th-post-comment ul ol,.th-comments-wrap .th-post-comment ul ul {
    margin-bottom: 0
}

.th-comments-wrap ul.comment-list {
    list-style: none;
    margin: 0;
    padding: 0
}

.th-comments-wrap ul.comment-list ul ul,.th-comments-wrap ul.comment-list ul ol,.th-comments-wrap ul.comment-list ol ul,.th-comments-wrap ul.comment-list ol ol {
    margin-bottom: 0
}

.th-comments-wrap>.comment-list {
    margin-bottom: -30px !important
}

.th-comments-wrap .comment-avater {
    width: 80px;
    height: 80px;
    margin-right: 25px;
    overflow: hidden;
    border-radius: 0px
}

.th-comments-wrap .comment-avater img {
    width: 100%
}

.th-comments-wrap .comment-content {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    margin-top: -6px;
    position: relative
}

.th-comments-wrap .commented-on {
    font-size: 14px;
    display: inline-block;
    font-style: italic;
    margin-bottom: 15px;
    font-weight: 400;
    color: var(--body-color)
}

.th-comments-wrap .commented-on i {
    margin-right: 7px;
    font-size: 0.9rem
}

.th-comments-wrap .name {
    margin-bottom: 2px;
    font-size: 20px
}

.th-comments-wrap .comment-top {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between
}

.th-comments-wrap .text {
    margin-bottom: -0.5em
}

.th-comments-wrap .text:last-child {
    margin-bottom: 0
}

.th-comments-wrap .comment-content p:last-of-type {
    margin-bottom: -0.5em
}

.th-comments-wrap .children {
    margin: 0;
    padding: 0;
    list-style-type: none;
    margin-left: 80px
}

.th-comments-wrap .reply_and_edit {
    position: absolute;
    top: 0;
    right: 0
}

.th-comments-wrap .reply_and_edit a {
    margin-right: 10px
}

.th-comments-wrap .reply_and_edit a:last-child {
    margin-right: 0
}

@media (max-width: 767px) {
    .th-comments-wrap .reply_and_edit {
        top:-40px
    }
}

.th-comments-wrap .reply-btn {
    font-weight: 600;
    font-size: 16px;
    color: var(--theme-color);
    display: inline-block
}

.th-comments-wrap .reply-btn i {
    margin-right: 7px
}

.th-comments-wrap .reply-btn:hover {
    color: var(--title-color)
}

.th-comments-wrap .star-rating {
    font-size: 12px;
    margin-bottom: 10px;
    position: absolute;
    top: 5px;
    right: 0;
    width: 80px
}

ul.comment-list .th-comment-item:last-child >.th-post-comment {
    border-bottom: none;
    margin-bottom: 0
}

ul.comment-list .th-comment-item:first-child >.th-post-comment {
    margin-bottom: 30px
}

.th-comments-wrap.th-comment-form {
    margin: 0
}

@media (max-width: 1199px) {
    .th-comments-wrap .children {
        margin-left:40px
    }

    .th-comments-wrap,.th-comment-form {
        --blog-space-x: 20px
    }
}

@media (max-width: 991px) {
    .th-comments-wrap,.th-comment-form {
        --blog-space-x: 40px
    }
}

@media (max-width: 767px) {
    .th-comments-wrap,.th-comment-form {
        --blog-space-x: 20px
    }

    .th-comments-wrap .th-post-comment {
        display: block
    }

    .th-comments-wrap .star-rating {
        position: relative;
        top: 0;
        right: 0
    }

    .th-comments-wrap .comment-top {
        display: block
    }

    .th-comments-wrap .comment-avater {
        margin-right: 0;
        margin-bottom: 25px
    }

    .th-comments-wrap .children {
        margin-left: 40px
    }

    .th-comments-wrap .children {
        margin-left: 30px
    }
}

@media (max-width: 767px) {
    .th-comment-form {
        --blog-space-x: 20px
    }
}

.woocommerce-Reviews .woocommerce-Reviews-title {
    margin-bottom: 0
}

.woocommerce-Reviews .comment-list {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0 24px;
    margin: -12px !important
}

.woocommerce-Reviews .th-comments-wrap li {
    margin-bottom: 0;
    width: 50%
}

.woocommerce-Reviews .th-post-comment {
    margin: 12px;
    margin-bottom: 12px !important
}

@media (max-width: 991px) {
    .woocommerce-Reviews .th-post-comment {
        display:block
    }

    .woocommerce-Reviews .th-post-comment .comment-avater {
        margin-bottom: 20px
    }
}

@media (max-width: 767px) {
    .woocommerce-Reviews .th-comments-wrap li {
        width:100%
    }
}

.th-hero-wrapper {
    position: relative;
    z-index: 2;
    overflow: hidden
}

.th-hero-wrapper .checklist ul {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 10px 30px
}

.th-hero-wrapper .checklist li {
    margin-bottom: 0 !important;
    margin-top: 0 !important;
    font-size: 18px;
    font-weight: 500;
    color: var(--title-color)
}

.hero-shape {
    position: absolute
}

.th-hero-bg {
    position: absolute;
    inset: 0
}

.th-hero-bg img {
    height: 100%;
    width: 100%;
    object-fit: cover
}

.hero-subtitle {
    display: inline-block;
    font-size: 14px;
    font-weight: 600;
    text-transform: uppercase
}

.hero-text {
    font-size: 18px;
    margin-bottom: 35px
}

.hero-title:first-of-type {
    margin-bottom: 0 !important
}

.hero-meta {
    margin-bottom: 20px;
    margin-top: -0.4em
}

.hero-meta span {
    display: inline-block;
    font-size: 20px;
    font-weight: 600;
    font-family: var(--title-font);
    text-transform: uppercase;
    color: var(--white-color);
    position: relative
}

.hero-meta span:after {
    content: "";
    height: 2px;
    width: 30px;
    background-color: var(--white-color);
    display: inline-block;
    margin: 0 15px;
    position: relative;
    top: -4px
}

.hero-meta span:last-child::after {
    display: none
}

.hero-1 {
    padding-right: 100px
}

@media (max-width: 767px) {
    .hero-1 .hero-video-wrap {
        padding-bottom:120px
    }
}

.hero-1 .hero-shape {
    display: inline-block;
    height: 460px;
    width: 100px;
    position: absolute;
    top: 0;
    right: 0;
    background-color: var(--theme-color);
    -webkit-clip-path: polygon(100% 0, 100% calc(100% - 100px), calc(100% - 140px) 100%, 0 100%, 0 0);
    clip-path: polygon(100% 0, 100% calc(100% - 100px), calc(100% - 140px) 100%, 0 100%, 0 0);
    z-index: -1
}

@media (max-width: 991px) {
    .hero-1 {
        padding-right:0
    }

    .hero-1 .hero-shape {
        display: none
    }
}

.hero-style1 {
    position: relative;
    z-index: 6;
    padding: 250px 0 230px;
    margin-left: 50px
}

@media (max-width: 1399px) {
    .hero-style1 {
        padding:200px 0 180px
    }
}

@media (max-width: 1199px) {
    .hero-style1 {
        padding:170px 0 150px
    }
}

@media (max-width: 991px) {
    .hero-style1 {
        padding:140px 0;
        margin-left: 10px
    }
}

@media (max-width: 767px) {
    .hero-style1 {
        text-align:center;
        padding: 120px 0 60px;
        margin-left: 0
    }

    .hero-style1 .btn-group {
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }
}

.hero-style1 .hero-text {
    color: #B2B2B2;
    margin-top: 15px;
    max-width: 678px
}

@media (max-width: 991px) {
    .hero-style1 .hero-text {
        font-size:14px
    }
}

.hero-style1 .hero-subtitle {
    color: var(--theme-color);
    font-size: 20px;
    font-weight: 600;
    font-family: var(--title-font);
    margin-bottom: 30px
}

.hero-style1 .hero-subtitle img {
    margin-right: -15px;
    margin-top: -21px
}

@media (max-width: 575px) {
    .hero-style1 .hero-subtitle {
        font-size:16px
    }
}

.hero-style1 .hero-title {
    margin-bottom: 27px;
    font-weight: 700;
    text-transform: uppercase
}

.hero-slider-1 .slick-dots {
    position: absolute;
    left: 120px;
    top: 50%;
    -webkit-transform: translate(0, -50%);
    -ms-transform: translate(0, -50%);
    transform: translate(0, -50%);
    margin: 0;
    padding: 27px 0
}

.hero-slider-1 .slick-dots li {
    display: block;
    margin: 28px 0
}

.hero-slider-1 .slick-dots li:first-child {
    margin-top: 0
}

.hero-slider-1 .slick-dots li:last-child {
    margin-bottom: 0
}

.hero-slider-1 .slick-dots:before,.hero-slider-1 .slick-dots:after {
    content: '';
    position: absolute;
    left: 50%;
    top: -50%;
    height: 80px;
    width: 2px;
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
    transform: translate(-50%, 0);
    background: -webkit-linear-gradient(bottom, #FF4C13 0%, rgba(255,76,19,0) 100%);
    background: linear-gradient(360deg, #FF4C13 0%, rgba(255,76,19,0) 100%)
}

.hero-slider-1 .slick-dots:before {
    bottom: -50%;
    top: auto;
    background: -webkit-linear-gradient(top, #FF4C13 0%, rgba(255,76,19,0) 100%);
    background: linear-gradient(180deg, #FF4C13 0%, rgba(255,76,19,0) 100%)
}

@media (max-width: 375px) {
    .hero-subtitle {
        font-size:12px;
        font-weight: 500
    }
}

.hero-2 .big-text {
    position: absolute;
    top: 30%;
    left: 11%;
    z-index: 2;
    -webkit-text-stroke: 1px rgba(255,255,255,0.07)
}

.hero-2 .icon-box {
    position: absolute;
    top: 50%;
    right: 240px;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    width: 60px
}

.hero-2 .icon-box .slick-arrow {
    --pos-x: 0;
    border-radius: 0;
    margin: 5px 0;
    border: none;
    background-color: rgba(255,255,255,0.15);
    color: var(--white-color)
}

.hero-2 .icon-box .slick-arrow:hover {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.hero-2 .icon-box .slick-arrow:first-child {
    margin-right: 0
}

.hero-slider-2 .th-hero-slide {
    padding: 245px 0
}

.hero-style2 {
    padding-left: 0;
    max-width: 650px
}

.hero-style2 .hero-title {
    font-weight: bold
}

.hero-style2 .hero-meta span {
    color: var(--theme-color)
}

.hero-style2 .hero-meta span:after {
    background-color: var(--theme-color)
}

.hero-style2 .hero-text {
    color: var(--border-color)
}

@media (max-width: 1399px) {
    .hero-2 .icon-box {
        right:40px
    }
}

@media (max-width: 1299px) {
    .hero-2 .big-text {
        left:0%
    }
}

@media (max-width: 1199px) {
    .hero-slider-2 .th-hero-slide {
        padding:150px 0 150px 0
    }

    .hero-style2 .hero-title {
        font-size: 46px
    }

    .hero-2 .big-text {
        left: 3%;
        top: 25%
    }
}

@media (max-width: 991px) {
    .hero-slider-2 .th-hero-slide {
        padding:100px 0 100px 0
    }

    .hero-style2 .checklist {
        margin-bottom: 34px
    }

    .hero-2 .big-text {
        top: 18%
    }
}

@media (max-width: 767px) {
    .hero-2 .icon-box {
        display:none
    }

    .th-hero-wrapper .checklist ul {
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }
}

@media (max-width: 575px) {
    .hero-slider-2 .th-hero-slide {
        padding:90px 0
    }

    .hero-style2 .hero-title {
        font-size: 38px
    }
}

@media (max-width: 440px) {
    .hero-style2 .hero-title {
        font-size:32px;
        max-width: 100%
    }
}

@media (max-width: 375px) {
    .hero-style2 .hero-title {
        font-size:28px
    }
}

.hero-3 {
    overflow: hidden
}

.hero-3 .banner-anime-img {
    position: absolute;
    width: 100%;
    height: 100%;
    z-index: 0;
    background-size: contain;
    background-position: bottom
}

.hero-slider-3 .th-hero-slide {
    padding: 150px 0 0 0
}

@media (max-width: 1299px) {
    .hero-slider-3 .th-hero-slide {
        padding:170px 0 0 0
    }
}

@media (max-width: 991px) {
    .hero-slider-3 .th-hero-slide {
        padding:150px 0 0 0
    }
}

.hero-slider-3 .slick-arrow {
    --pos-x: 100px;
    background: rgba(255,255,255,0.3);
    border: 0;
    color: var(--white-color);
    top: calc(50% + 75px)
}

.hero-slider-3 .slick-arrow:hover {
    background: var(--theme-color)
}

.th-hero-bg-overlay {
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 100%
}

.hero-style3 {
    padding: 224px 0 223px
}

@media (max-width: 1399px) {
    .hero-style3 {
        padding:180px 0
    }
}

@media (max-width: 991px) {
    .hero-style3 {
        padding:120px 0
    }
}

@media (max-width: 575px) {
    .hero-style3 {
        padding:100px 0
    }
}

.hero-style3 .hero-subtitle {
    font-size: 48px;
    font-weight: 600;
    font-family: var(--title-font);
    color: var(--theme-color2);
    text-transform: uppercase;
    margin-bottom: 28px;
    margin-top: 6px
}

@media (max-width: 1299px) {
    .hero-style3 .hero-subtitle {
        font-size:40px;
        margin-top: 0
    }
}

@media (max-width: 1199px) {
    .hero-style3 .hero-subtitle {
        font-size:30px
    }
}

@media (max-width: 767px) {
    .hero-style3 .hero-subtitle {
        font-size:24px;
        margin-bottom: 18px
    }
}

@media (max-width: 575px) {
    .hero-style3 .hero-subtitle {
        font-size:20px;
        margin-bottom: 15px
    }
}

.hero-style3 .hero-title {
    font-size: 94px;
    font-weight: 800;
    margin-bottom: 27px
}

.hero-style3 .hero-title:first-of-type {
    margin-bottom: -0.07em !important
}

@media (max-width: 1299px) {
    .hero-style3 .hero-title {
        font-size:74px
    }
}

@media (max-width: 1199px) {
    .hero-style3 .hero-title {
        font-size:60px
    }
}

@media (max-width: 767px) {
    .hero-style3 .hero-title {
        font-size:50px
    }
}

@media (max-width: 575px) {
    .hero-style3 .hero-title {
        font-size:40px
    }
}

@media (max-width: 375px) {
    .hero-style3 .hero-title {
        font-size:36px
    }
}

@media (max-width: 320px) {
    .hero-style3 .hero-title {
        font-size:30px
    }
}

.hero-style3 .hero-text {
    font-size: 16px;
    font-weight: 500;
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    margin-bottom: 40px
}

@media (max-width: 767px) {
    .hero-style3 .hero-text {
        display:block
    }
}

.hero-style3 .hero-text p {
    margin-bottom: 0;
    font-size: 16px;
    font-weight: 500;
    font-family: var(--title-font);
    color: var(--white-color)
}

@media (max-width: 767px) {
    .hero-style3 .hero-text p {
        margin-bottom:15px
    }
}

@media (max-width: 375px) {
    .hero-style3 .hero-text p {
        font-size:15px
    }
}

.hero-slider-4 .slick-arrow {
    --pos-x: 120px;
    background: rgba(255,255,255,0.3);
    border-radius: 0;
    color: var(--white-color);
    border: 0
}

.hero-slider-4 .slick-arrow:hover {
    background: var(--theme-color)
}

.hero-style4 {
    padding: 334px 0 265px
}

.hero-style4 .hero-subtitle {
    color: var(--theme-color);
    margin-bottom: 27px;
    font-size: 20px;
    font-weight: 600;
    font-family: var(--title-font);
    text-transform: uppercase;
    line-height: normal;
    margin-top: 0;
    padding: 6.5px 27px;
    border-radius: 10px;
    background: rgba(61,66,80,0.7)
}

@media (max-width: 1199px) {
    .hero-style4 .hero-subtitle {
        font-size:16px
    }
}

.hero-style4 .hero-title {
    font-size: 84px
}

@media (max-width: 1399px) {
    .hero-style4 .hero-title {
        font-size:68px
    }
}

@media (max-width: 1299px) {
    .hero-style4 .hero-title {
        font-size:60px
    }
}

@media (max-width: 1199px) {
    .hero-style4 .hero-title {
        font-size:54px
    }
}

@media (max-width: 767px) {
    .hero-style4 .hero-title {
        font-size:44px
    }
}

@media (max-width: 575px) {
    .hero-style4 .hero-title {
        font-size:34px
    }
}

@media (max-width: 375px) {
    .hero-style4 .hero-title {
        font-size:34px
    }
}

.hero-style4 .btn-group {
    margin-top: 40px
}

@media (max-width: 1199px) {
    .hero-style4 {
        padding:304px 0 245px
    }
}

@media (max-width: 991px) {
    .hero-style4 {
        padding:294px 0 245px
    }
}

@media (max-width: 767px) {
    .hero-style4 {
        padding:254px 0 185px
    }
}

.hero-5 .scroll-down {
    position: absolute;
    bottom: -24px;
    left: calc(50% - 340px);
    height: 88px;
    width: 680px;
    text-align: center;
    background-color: var(--white-color);
    -webkit-clip-path: path("M646.782 65H33.2179C103.636 65 173.285 50.3548 237.739 21.9947C302.899 -6.67547 377.101 -6.67547 442.261 21.9947C506.715 50.3548 576.364 65 646.782 65Z");
    clip-path: path("M646.782 65H33.2179C103.636 65 173.285 50.3548 237.739 21.9947C302.899 -6.67547 377.101 -6.67547 442.261 21.9947C506.715 50.3548 576.364 65 646.782 65Z")
}

.hero-5 .hero-5-scroll-wrap {
    height: 32px;
    width: 20px;
    border: 2px solid var(--title-color);
    display: inline-block;
    border-radius: 30px;
    margin-top: 20px;
    position: relative
}

.hero-5 .hero-5-scroll-wrap:before {
    content: "";
    height: 6px;
    width: 2px;
    border-radius: 50px;
    background-color: var(--title-color);
    position: absolute;
    top: 5px;
    left: 7px;
    -webkit-animation: scrollMove 1.5s infinite;
    animation: scrollMove 1.5s infinite
}

.hero-slider-5 .th-hero-slide:after {
    content: '';
    position: absolute;
    inset: 0;
    background: rgba(14,18,29,0.7);
    z-index: -1
}

.hero-slider-5 .th-hero-bg {
    z-index: -2
}

.hero-slider-5 .slick-dots {
    position: absolute;
    top: 50%;
    right: 150px;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    width: 30px
}

.hero-slider-5 .slick-dots button {
    border-radius: 0 !important;
    visibility: visible;
    opacity: 1;
    background: var(--white-color);
    width: 15px;
    height: 15px
}

.hero-slider-5 .slick-dots button:before {
    border-radius: 0 !important;
    background: transparent;
    border: 1px solid var(--theme-color);
    height: 30px;
    width: 30px;
    top: 50%;
    left: 50%
}

.hero-slider-5 .slick-dots li {
    display: block;
    margin: 35px 0
}

.hero-slider-5 .slick-dots li.slick-active button {
    background: var(--theme-color)
}

.hero-slider-5 .slick-dots:before,.hero-slider-5 .slick-dots:after {
    content: '';
    position: absolute;
    height: 100px;
    width: 2px;
    background: -webkit-linear-gradient(bottom, rgba(240,165,56,0) 0%, #F0A538 97.4%);
    background: linear-gradient(0deg, rgba(240,165,56,0) 0%, #F0A538 97.4%)
}

.hero-slider-5 .slick-dots:before {
    top: 0;
    background: -webkit-linear-gradient(top, rgba(240,165,56,0) 0%, #F0A538 97.4%);
    background: linear-gradient(180deg, rgba(240,165,56,0) 0%, #F0A538 97.4%);
    -webkit-transform: translate(0, -100%);
    -ms-transform: translate(0, -100%);
    transform: translate(0, -100%)
}

@media (max-width: 1399px) {
    .hero-slider-5 .slick-dots {
        right:80px
    }
}

@media (max-width: 991px) {
    .hero-slider-5 .slick-dots {
        right:50px;
        margin: 90px 0 0 0
    }

    .hero-slider-5 .slick-dots button {
        width: 8px;
        height: 8px
    }

    .hero-slider-5 .slick-dots button:before {
        height: 20px;
        width: 20px
    }

    .hero-slider-5 .slick-dots li {
        margin: 25px 0
    }
}

.hero-style5 {
    padding: 356px 0 227px
}

.hero-style5 .hero-subtitle {
    color: var(--theme-color);
    margin-bottom: 30px;
    font-size: 20px;
    font-weight: 600;
    font-family: var(--title-font);
    text-transform: uppercase;
    margin-top: -0.2em;
    display: block
}

@media (max-width: 1199px) {
    .hero-style5 .hero-subtitle {
        font-size:16px
    }
}

.hero-style5 .hero-title {
    font-size: 84px;
    text-transform: uppercase
}

.hero-style5 .hero-title span {
    -webkit-text-stroke: 1px var(--theme-color);
    -webkit-text-fill-color: rgba(255,255,255,0.1)
}

@media (max-width: 1399px) {
    .hero-style5 .hero-title {
        font-size:68px
    }
}

@media (max-width: 1299px) {
    .hero-style5 .hero-title {
        font-size:60px
    }
}

@media (max-width: 1199px) {
    .hero-style5 .hero-title {
        font-size:54px
    }
}

@media (max-width: 767px) {
    .hero-style5 .hero-title {
        font-size:44px
    }
}

@media (max-width: 575px) {
    .hero-style5 .hero-title {
        font-size:34px
    }
}

@media (max-width: 375px) {
    .hero-style5 .hero-title {
        font-size:34px
    }
}

.hero-style5 .btn-group {
    margin-top: 30px
}

@media (max-width: 991px) {
    .hero-style5 {
        padding:367px 0 170px
    }
}

@media (max-width: 767px) {
    .hero-style5 {
        padding:257px 0 180px
    }
}

.hero-6 .th-hero-slide {
    padding: 210px 0
}

.hero-6 .th-hero-bg img {
    object-fit: fill
}

.hero-6 .hero-img {
    position: absolute;
    bottom: 0;
    right: 15%
}

.call-btn .play-btn {
    margin-right: 15px
}

.call-btn .play-btn i {
    font-size: 14px;
    --icon-size: 45px
}

.call-btn.style-video {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.call-btn.style-video .play-btn:after,.call-btn.style-video .play-btn:before {
    background-color: transparent;
    border: 1px solid var(--white-color)
}

.call-btn.style-video .btn-content {
    margin-bottom: -0.3em
}

.call-btn.style-video .btn-title {
    font-size: 18px;
    font-weight: 700;
    margin-bottom: 3px;
    line-height: 1
}

.call-btn.style-video .btn-text {
    font-size: 14px;
    font-weight: 400;
    line-height: 1;
    font-family: var(--title-font)
}

.hero-style6 .hero-subtitle {
    font-size: 16px;
    font-weight: 600;
    color: var(--theme-color);
    text-transform: uppercase;
    margin-bottom: 21px
}

.hero-style6 .hero-subtitle:before {
    content: '';
    height: 2px;
    width: 60px;
    position: relative;
    display: inline-block;
    bottom: 5px;
    margin-right: 10px;
    background-color: var(--theme-color)
}

.hero-style6 .hero-title {
    color: var(--white-color);
    font-size: 74px;
    line-height: 1.135;
    margin-bottom: 30px !important;
    text-transform: capitalize;
    font-weight: 800
}

.hero-style6 .hero-text {
    max-width: 710px;
    margin-bottom: 40px;
    color: var(--white-color);
    font-size: 16px
}

.hero-style6 .call-btn .btn-title {
    color: var(--white-color)
}

.hero-style6 .call-btn .btn-text {
    color: var(--white-color)
}

.hero-style6 .btn-group {
    gap: 50px
}

@media (max-width: 1500px) {
    .hero-6 .hero-img {
        right:2%
    }

    .hero-style6 .hero-title {
        font-size: 64px
    }
}

@media (max-width: 1199px) {
    .hero-6 .th-hero-slide {
        padding:160px 0
    }

    .hero-6 .hero-img {
        max-width: 420px
    }

    .hero-style6 .hero-title {
        font-size: 60px;
        line-height: 1.2
    }

    .hero-style6 .hero-text {
        margin-bottom: 35px;
        max-width: 600px
    }

    .hero-style6 .hero-subtitle {
        margin-bottom: 12px
    }
}

@media (max-width: 991px) {
    .hero-6 .th-hero-slide {
        padding:120px 0
    }

    .hero-6 .hero-img {
        max-width: 320px;
        right: -5%
    }

    .hero-style6 .hero-title {
        font-size: 52px
    }

    .hero-style6 .hero-text {
        max-width: 500px
    }
}

@media (max-width: 767px) {
    .hero-6 .hero-img {
        display:none
    }

    .hero-6 .th-hero-slide {
        padding: 90px 0
    }

    .hero-style6 {
        text-align: center
    }

    .hero-style6 .hero-subtitle:before {
        display: none
    }

    .hero-style6 .hero-title {
        font-size: 46px
    }

    .hero-style6 .btn-group {
        gap: 20px 30px;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }

    .hero-style6 .call-btn {
        text-align: left
    }
}

@media (max-width: 575px) {
    .hero-style6 .hero-title {
        font-size:38px;
        margin-bottom: 15px !important
    }

    .hero-style6 .hero-text {
        margin-bottom: 25px
    }
}

@media (max-width: 375px) {
    .hero-style6 .hero-title {
        font-size:34px
    }
}

@media (max-width: 350px) {
    .hero-style6 .hero-title {
        font-size:30px
    }

    .hero-style6 .hero-text {
        font-size: 14px
    }
}

.hero-meta {
    margin-bottom: 20px;
    margin-top: -0.4em
}

.hero-meta span {
    display: inline-block;
    font-size: 20px;
    text-transform: capitalize;
    color: var(--white-color);
    position: relative
}

.hero-meta span:after {
    content: "";
    height: 2px;
    width: 30px;
    background-color: var(--white-color);
    display: inline-block;
    margin: 0 15px;
    position: relative;
    top: -4px
}

.hero-meta span:last-child::after {
    display: none
}

.big-text {
    font-family: var(--title-font);
    font-weight: 900;
    font-size: 170px;
    text-transform: uppercase;
    letter-spacing: -0.04em;
    -webkit-text-stroke: 1px rgba(255,255,255,0.23);
    color: transparent
}

.hero-7 .big-text {
    position: absolute;
    top: 32%;
    left: 9%;
    z-index: 2
}

.hero-7 .hero-img {
    position: absolute;
    top: 0;
    left: 0;
    margin-top: 100px;
    height: calc(100% - 100px);
    width: 52%;
    z-index: 1
}

.hero-7 .hero-img img {
    height: 100%;
    width: 100%
}

.hero-7 .play-btn {
    position: absolute;
    top: 50%;
    margin-top: -40px;
    right: 40px;
    z-index: 4
}

.hero-7 .icon-box {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    position: absolute;
    bottom: 60px;
    left: 9%;
    z-index: 3
}

.hero-7 .icon-btn {
    --btn-size: 80px;
    border-radius: 0;
    font-size: 26px;
    color: var(--white-color);
    background-color: var(--theme-color);
    box-shadow: 0 10px 10px 10px rgba(0,0,0,0.08)
}

.hero-7 .icon-btn:hover {
    color: var(--theme-color);
    background-color: var(--white-color)
}

.hero-style7 {
    position: relative;
    z-index: 3;
    padding: 320px 0 265px 0
}

.hero-style7 .hero-title,.hero-style7 .hero-text {
    color: var(--white-color)
}

.hero-style7 .hero-title {
    letter-spacing: -0.04em;
    word-spacing: 0.1em;
    line-height: 1.2;
    font-weight: 900
}

.hero-style7 .hero-text {
    max-width: 525px
}

@media (max-width: 767px) {
    .hero-style7 .hero-text {
        max-width:450px
    }
}

@media (max-width: 1299px) {
    .big-text {
        font-size:150px
    }

    .hero-7 .big-text {
        left: 5%
    }
}

@media (max-width: 1399px) {
    .hero-style7 {
        padding:280px 0 230px 0
    }
}

@media (max-width: 1199px) {
    .big-text {
        font-size:130px
    }

    .hero-7 .hero-img {
        margin-top: 87px;
        height: calc(100% - 87px);
        width: 70%
    }

    .hero-7 .big-text {
        left: 3%
    }

    .hero-7 .icon-box {
        left: 14%;
        bottom: 45px
    }
}

@media (max-width: 991px) {
    .big-text {
        font-size:100px
    }

    .hero-7 .hero-img {
        width: 80%;
        margin-top: 89px;
        height: calc(100% - 89px)
    }

    .hero-7 .big-text {
        top: 28%
    }

    .hero-7 .icon-box {
        left: 17%;
        bottom: 50px
    }

    .hero-7 .icon-btn {
        --btn-size: 60px;
        font-size: 20px
    }

    .hero-style7 {
        padding: 200px 0 200px 0
    }
}

@media (max-width: 767px) {
    .hero-7 .play-btn {
        display:none
    }

    .hero-7 .hero-img {
        width: 85%
    }
}

@media (max-width: 575px) {
    .big-text {
        font-size:90px
    }

    .hero-7 .hero-img {
        width: 98%
    }
}

@media (max-width: 375px) {
    .hero-7 .hero-img {
        margin-top:74px;
        height: calc(100% - 74px);
        width: 100%
    }

    .big-text {
        font-size: 70px
    }

    .hero-style7 {
        padding: 160px 0 180px 0
    }
}

.hero-8 .hero-img {
    position: absolute;
    top: 0;
    right: 0;
    z-index: 3;
    width: 45%;
    height: 100%
}

.hero-8 .hero-img:before {
    content: "";
    height: 100%;
    width: 100%;
    background-color: var(--theme-color);
    position: absolute;
    top: 0;
    right: 0;
    -webkit-clip-path: polygon(115px 0, 100% 0, 100% 100%, 115px 100%, 0 50%);
    clip-path: polygon(115px 0, 100% 0, 100% 100%, 115px 100%, 0 50%)
}

.hero-8 .hero-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    -webkit-clip-path: polygon(170px 0, 100% 0, 100% 100%, 170px 100%, 0 50%);
    clip-path: polygon(170px 0, 100% 0, 100% 100%, 170px 100%, 0 50%)
}

.hero-8 .hero-img .icon-btn {
    --btn-size: 70px;
    line-height: 60px;
    font-size: 24px;
    background-color: var(--theme-color);
    color: var(--white-color);
    border-radius: 10px;
    border: 4px solid var(--white-color);
    position: absolute;
    top: 50%;
    left: -20px;
    -webkit-transform: translateY(-50%) rotate(45deg);
    -ms-transform: translateY(-50%) rotate(45deg);
    transform: translateY(-50%) rotate(45deg)
}

.hero-8 .hero-img .icon-btn i {
    -webkit-transform: rotate(-45deg);
    -ms-transform: rotate(-45deg);
    transform: rotate(-45deg)
}

.hero-8 .hero-img .icon-btn:hover {
    background-color: var(--title-color)
}

.hero-style8 {
    position: relative;
    z-index: 6;
    padding: 245px 0 245px 0;
    max-width: 660px
}

.hero-style8 .hero-title {
    font-weight: 900;
    letter-spacing: -0.04em;
    word-spacing: 0.1em
}

.hero-style8 .hero-subtitle {
    color: var(--theme-color);
    margin-bottom: 17px;
    font-size: 20px;
    text-transform: capitalize
}

.hero-style8 .hero-text {
    max-width: 525px;
    font-size: 16px;
    margin-bottom: 30px
}

@media (max-width: 1399px) {
    .hero-style8 {
        padding:90px 0
    }

    .hero-8 .hero-img {
        max-width: 48%
    }
}

@media (max-width: 1199px) {
    .hero-style8 {
        padding:140px 0
    }
}

@media (max-width: 991px) {
    .hero-style8 {
        padding:80px 0;
        max-width: 450px
    }

    .hero-8 .hero-img {
        max-width: 34%
    }
}

@media (max-width: 767px) {
    .hero-8 .hero-img {
        display:none
    }

    .hero-style8 .hero-subtitle {
        font-size: 18px
    }
}

.hero-9 .hero-img {
    position: absolute;
    top: 0;
    right: 0;
    z-index: 2
}

.hero-9 .slick-dots {
    position: absolute;
    top: 50%;
    right: 6%;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%)
}

@media (min-width: 1922px) {
    .hero-9 .slick-dots {
        right:20%
    }
}

.hero-9 .slick-dots li {
    display: block;
    margin: 25px 0 !important
}

.hero-9 .slick-dots button {
    font-size: 0;
    padding: 0;
    background-color: transparent;
    width: 8px;
    height: 8px;
    line-height: 0;
    border-radius: 9999px;
    border: none;
    background-color: var(--white-color)
}

.hero-9 .slick-dots button:hover {
    border-color: var(--theme-color)
}

.hero-9 .slick-dots button:before {
    content: "";
    position: absolute;
    left: 50%;
    top: 50%;
    width: 26px;
    height: 26px;
    margin: -13px 0 0 -13px;
    border: 2px solid var(--theme-color);
    border-radius: 50%;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s;
    opacity: 0;
    visibility: hidden
}

.hero-9 .slick-dots .slick-active button {
    background-color: var(--theme-color)
}

.hero-9 .slick-dots .slick-active button::before {
    opacity: 1;
    visibility: visible
}

.hero-slider-9 .th-hero-slide {
    padding: 148px 0 0
}

.hero-slider-9 .slick-dots {
    z-index: 9;
    left: 128px;
    right: auto
}

.hero-slider-9 .slick-dots:after {
    content: '';
    position: absolute;
    top: calc(-50% - 19px);
    left: 50%;
    height: 80px;
    width: 2px;
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
    transform: translate(-50%, 0);
    background: -webkit-linear-gradient(bottom, var(--theme-color), transparent);
    background: linear-gradient(to top, var(--theme-color), transparent)
}

.hero-slider-9 .slick-dots:before {
    content: '';
    position: absolute;
    bottom: calc(-50% - 19px);
    left: 50%;
    height: 80px;
    width: 2px;
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
    transform: translate(-50%, 0);
    background: -webkit-linear-gradient(top, var(--theme-color), transparent);
    background: linear-gradient(to bottom, var(--theme-color), transparent)
}

.hero-slider-9 .slick-dots button {
    height: 12px;
    width: 12px
}

.hero-slider-9 .slick-dots button:before {
    width: 30px;
    height: 30px;
    margin: -15px 0 0 -15px;
    -webkit-transform: none;
    -ms-transform: none;
    transform: none
}

.hero-slider-9 .slick-dots li {
    margin: 28px 0 !important
}

.hero-style9 {
    padding-left: 0;
    margin-left: -63px;
    max-width: 650px;
    padding: 70px 0
}

.hero-style9 .hero-subtitle {
    font-size: 16px;
    font-weight: 700;
    margin-bottom: 21px
}

.hero-style9 .hero-subtitle img {
    margin-right: 10px
}

.hero-style9 .hero-text {
    color: black;
    max-width: none;
    font-size: 16px;
    margin-bottom: 40px
}

.hero-style9 .hero-title {
    font-weight: bold;
    font-size: 72px;
    line-height: 84px
}

@media (max-width: 1600px) {
    .hero-9 .hero-img {
        width:50%
    }

    .hero-slider-9 .slick-dots {
        left: 35px
    }
}

@media (max-width: 1399px) {
    .hero-style9 {
        margin-left:0
    }

    .hero-style9 .hero-title {
        font-size: 39px;
        line-height: initial
    }

    .hero-9 .hero-img {
        width: 45%;
        height: 84%
    }

    .hero-9 .hero-img img {
        height: 100%;
        object-fit: cover;
        object-position: left
    }
}

@media (max-width: 1299px) {
    .hero-style9 {
        padding:160px 0
    }

    .hero-style9 .hero-title {
        font-size: 48px
    }
}

@media (max-width: 1199px) {
    .hero-style9 {
        padding:120px 0;
        margin: auto;
        text-align: center
    }

    .hero-style9 .btn-group {
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }
}

@media (max-width: 991px) {
    .hero-slider-9 .th-hero-slide {
        padding:80px 0 0
    }

    .hero-style9 {
        padding: 120px 0
    }
}

@media (max-width: 767px) {
    .hero-style9 .hero-title {
        font-size:40px
    }
}

@media (max-width: 575px) {
    .hero-style9 {
        padding:50px 0
    }

    .hero-style9 .hero-title {
        font-size: 34px
    }
}

@media (max-width: 375px) {
    .hero-style9 .hero-title {
        font-size:32px
    }
}

.hero-10 .slick-dots {
    position: absolute;
    top: 50%;
    right: 6%;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%)
}

@media (min-width: 1922px) {
    .hero-10 .slick-dots {
        right:20%
    }
}

.hero-10 .slick-dots li {
    display: block;
    margin: 25px 0 !important
}

.hero-10 .slick-dots button {
    font-size: 0;
    padding: 0;
    background-color: transparent;
    width: 8px;
    height: 8px;
    line-height: 0;
    border-radius: 9999px;
    border: none;
    background-color: var(--white-color)
}

.hero-10 .slick-dots button:hover {
    border-color: var(--theme-color)
}

.hero-10 .slick-dots button:before {
    content: "";
    position: absolute;
    left: 50%;
    top: 50%;
    width: 26px;
    height: 26px;
    border: 2px solid var(--theme-color);
    border-radius: 50%;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s;
    opacity: 0;
    visibility: hidden
}

.hero-10 .slick-dots .slick-active button {
    background-color: var(--theme-color)
}

.hero-10 .slick-dots .slick-active button::before {
    opacity: 1;
    visibility: visible
}

.hero-style10 {
    padding: 320px 0 235px 0
}

.hero-style10 .hero-meta span {
    text-transform: uppercase;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.hero-style10 .hero-meta span:not(:last-child) {
    margin-right: 22px
}

.hero-style10 .hero-meta span:hover {
    color: var(--theme-color)
}

.hero-style10 .hero-meta span:after {
    display: none
}

.hero-style10 .hero-text {
    color: var(--white-color)
}

.hero-style10 .hero-title {
    color: var(--white-color)
}

.hero-style10 .hero-title .bg-theme {
    padding: 0 8px;
    line-height: 1
}

.hero-style10 .hero-text {
    max-width: 680px;
    font-size: 16px
}

@media (max-width: 1199px) {
    .hero-style10 {
        padding:210px 0 180px 0
    }
}

@media (max-width: 991px) {
    .hero-style10 .hero-text {
        max-width:540px
    }
}

@media (max-width: 767px) {
    .hero-style10 {
        padding:170px 0 150px 0
    }

    .hero-style10 .hero-meta span {
        font-size: 18px
    }
}

@media (max-width: 575px) {
    .hero-style10 .hero-meta span {
        font-size:16px
    }

    .hero-style10 .hero-meta span:not(:last-child) {
        margin-right: 14px
    }
}

.hero-11 {
    --main-container: 1380px
}

.hero-11 .play-btn {
    position: absolute;
    top: 50%;
    right: 10%;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%)
}

.hero-slider-11 .th-hero-slide {
    padding: 230px 0
}

.hero-style11 {
    padding-left: 40px;
    position: relative;
    z-index: 4;
    max-width: 710px
}

.hero-style11 .hero-subtitle {
    font-size: 18px;
    font-weight: 600;
    display: block;
    color: var(--theme-color);
    margin-top: -0.36em;
    margin-bottom: 25px;
    text-transform: capitalize
}

.hero-style11 .hero-title {
    font-weight: 800;
    color: var(--white-color);
    margin-bottom: 0
}

.hero-style11 .hero-title:last-of-type {
    margin-bottom: 25px
}

.hero-style11 .hero-text {
    color: var(--white-color);
    font-weight: 500;
    max-width: 100%;
    margin-bottom: 40px;
    font-size: 16px
}

@media (max-width: 1399px) {
    .hero-11 .slick-dots {
        right:10%
    }

    .hero-11 .hero-shape {
        width: 40px
    }

    .hero-slider-11 .th-hero-slide {
        padding: 190px 0 190px 0
    }

    .hero-style11 {
        padding-left: 20px
    }
}

@media (max-width: 1199px) {
    .hero-slider-11 .th-hero-slide {
        padding:150px 0 150px 0
    }

    .hero-style11 {
        max-width: 600px
    }

    .hero-style11 .hero-text {
        font-size: 16px
    }
}

@media (max-width: 991px) {
    .hero-11 .play-btn {
        display:none
    }

    .hero-slider-11 .th-hero-slide {
        padding: 100px 0 100px 0
    }

    .hero-style11 .hero-subtitle {
        margin-bottom: 20px
    }

    .hero-style11 .hero-title:last-of-type {
        margin-bottom: 20px
    }

    .hero-style11 .hero-text {
        margin-bottom: 30px
    }
}

@media (max-width: 767px) {
    .hero-11 {
        padding-right:0
    }

    .hero-11 .hero-shape {
        display: none
    }

    .hero-style11 {
        text-align: center;
        padding-left: 0
    }

    .hero-style11 .btn-wrap {
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }

    .hero-style11 .hero-title:last-of-type {
        margin-bottom: 25px
    }
}

@media (max-width: 575px) {
    .hero-style11 .hero-subtitle {
        font-size:16px;
        margin-bottom: 20px
    }

    .hero-style11 .hero-title {
        font-size: 30px
    }
}

.hero-12 {
    --main-container: 1440px
}

.hero-12 .icon-box {
    position: absolute;
    top: 50%;
    right: 115px;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    width: 60px
}

.hero-12 .icon-box .slick-arrow {
    --pos-x: 0;
    border-radius: 0;
    margin: 5px 0;
    border: none;
    background-color: rgba(255,255,255,0.15);
    color: var(--white-color)
}

.hero-12 .icon-box .slick-arrow:hover {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.hero-12 .icon-box .slick-arrow:first-child {
    margin-right: 0
}

.hero-slider-12 .th-hero-slide {
    padding: 245px 0
}

.hero-style12 {
    padding-left: 0;
    max-width: 650px
}

.hero-style12 .hero-title {
    font-weight: bold
}

.hero-style12 .hero-meta span {
    color: var(--theme-color)
}

.hero-style12 .hero-meta span:after {
    background-color: var(--theme-color)
}

@media (max-width: 1399px) {
    .hero-12 .icon-box {
        right:40px
    }
}

@media (max-width: 1199px) {
    .hero-slider-12 .th-hero-slide {
        padding:150px 0 150px 0
    }

    .hero-style12 .hero-title {
        font-size: 46px
    }
}

@media (max-width: 991px) {
    .hero-slider-12 .th-hero-slide {
        padding:100px 0 100px 0
    }

    .hero-style12 .checklist {
        margin-bottom: 34px
    }
}

@media (max-width: 767px) {
    .hero-12 .icon-box {
        display:none
    }

    .th-hero-wrapper .checklist ul {
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }

    .hero-style12 .btn-group {
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }
}

@media (max-width: 575px) {
    .hero-slider-12 .th-hero-slide {
        padding:90px 0
    }

    .hero-style12 .hero-title {
        font-size: 38px
    }
}

@media (max-width: 440px) {
    .hero-style12 .hero-title {
        font-size:32px;
        max-width: 100%
    }
}

@media (max-width: 375px) {
    .hero-style12 .hero-title {
        font-size:28px
    }
}

.hero-slider-13 .slick-dots {
    position: absolute;
    top: 50%;
    right: unset;
    left: 120px;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    width: 30px
}

.hero-slider-13 .slick-dots li {
    display: block;
    margin: 30px 0
}

.hero-slider-13 .slick-dots button {
    border-radius: 0 !important;
    visibility: visible;
    opacity: 1
}

.hero-slider-13 .slick-dots button:before {
    border-radius: 0 !important
}

.hero-style13 {
    max-width: unset
}

.hero-style13 .hero-text {
    max-width: 700px
}

.hero-style13 .hero-title .bg-theme {
    padding: 0 8px;
    line-height: 1
}

.hero-style13 .hero-meta span {
    text-transform: uppercase;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.hero-style13 .hero-meta span:not(:last-child) {
    margin-right: 22px
}

.hero-style13 .hero-meta span:hover {
    color: var(--theme-color)
}

.hero-style13 .hero-meta span:after {
    display: none
}

.hero-slider-13 .th-hero-slide {
    padding: 365px 0 225px 0
}

.hero-slider-13 .hero-style13 {
    padding-left: 480px
}

@media (max-width: 1299px) {
    .hero-slider-13 .slick-dots {
        left:35px
    }

    .hero-slider-13 .hero-style13 {
        padding-left: 518px
    }
}

@media (max-width: 1399px) {
    .hero-slider-13 .th-hero-slide {
        padding:315px 0 155px 0
    }

    .hero-slider-13 .hero-style13 {
        padding-left: 400px
    }
}

@media (max-width: 1199px) {
    .hero-slider-13 .hero-style13 {
        padding-left:160px
    }
}

@media (max-width: 991px) {
    .hero-slider-13 .th-hero-slide {
        padding:230px 0 100px 0
    }

    .hero-slider-13 .hero-style13 {
        padding-left: 0
    }

    .hero-style13 .hero-text {
        max-width: 580px
    }
}

@media (max-width: 767px) {
    .hero-style13 .btn-group {
        -webkit-box-pack:center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }
}

@media (max-width: 575px) {
    .hero-slider-13 .hero-style13 .hero-text {
        font-size:16px
    }
}

@media (max-width: 330px) {
    .hero-style13 .hero-title {
        font-size:26px
    }
}

.popup-search-box {
    position: fixed;
    top: 0;
    left: 50%;
    background-color: rgba(0,0,0,0.95);
    height: 0;
    width: 0;
    overflow: hidden;
    z-index: 99999;
    opacity: 0;
    visibility: hidden;
    border-radius: 50%;
    -webkit-transform: translateX(-50%);
    -ms-transform: translateX(-50%);
    transform: translateX(-50%);
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s
}

.popup-search-box button.searchClose {
    width: 60px;
    height: 60px;
    position: absolute;
    top: 40px;
    right: 40px;
    border-width: 1px;
    border-style: solid;
    border-color: var(--theme-color);
    background-color: transparent;
    font-size: 22px;
    border-radius: 50%;
    -webkit-transform: rotate(0);
    -ms-transform: rotate(0);
    transform: rotate(0);
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s;
    color: var(--theme-color)
}

.popup-search-box button.searchClose:hover {
    color: var(--body-color);
    background-color: #fff;
    border-color: transparent;
    border-color: transparent;
    -webkit-transform: rotate(90deg);
    -ms-transform: rotate(90deg);
    transform: rotate(90deg)
}

.popup-search-box form {
    position: absolute;
    top: 50%;
    left: 50%;
    display: inline-block;
    padding-bottom: 40px;
    cursor: auto;
    width: 100%;
    max-width: 700px;
    -webkit-transform: translate(-50%, -50%) scale(0);
    -ms-transform: translate(-50%, -50%) scale(0);
    transform: translate(-50%, -50%) scale(0);
    -webkit-transition: -webkit-transform ease 0.4s;
    transition: -webkit-transform ease 0.4s;
    transition: transform ease 0.4s;
    transition: transform ease 0.4s, -webkit-transform ease 0.4s
}

@media (max-width: 1199px) {
    .popup-search-box form {
        max-width:600px
    }
}

.popup-search-box form input {
    font-size: 18px;
    height: 70px;
    width: 100%;
    border: 2px solid var(--theme-color);
    background-color: transparent;
    padding-left: 30px;
    color: #fff;
    border-radius: 50px
}

.popup-search-box form input::-moz-placeholder {
    color: #fff
}

.popup-search-box form input::-webkit-input-placeholder {
    color: #fff
}

.popup-search-box form input:-ms-input-placeholder {
    color: #fff
}

.popup-search-box form input::-ms-input-placeholder {
    color: #fff
}

.popup-search-box form input::placeholder {
    color: #fff
}

.popup-search-box form button {
    position: absolute;
    top: 0px;
    background-color: transparent;
    border: none;
    color: #fff;
    font-size: 24px;
    right: 12px;
    color: var(--white-color);
    cursor: pointer;
    width: 70px;
    height: 70px;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s;
    -webkit-transform: scale(1.001);
    -ms-transform: scale(1.001);
    transform: scale(1.001)
}

.popup-search-box form button:hover {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1)
}

.popup-search-box.show {
    opacity: 1;
    visibility: visible;
    width: 100.1%;
    height: 100%;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s;
    border-radius: 0
}

.popup-search-box.show form {
    -webkit-transition-delay: 0.5s;
    transition-delay: 0.5s;
    -webkit-transform: translate(-50%, -50%) scale(1);
    -ms-transform: translate(-50%, -50%) scale(1);
    transform: translate(-50%, -50%) scale(1)
}

.sidemenu-wrapper {
    position: fixed;
    z-index: 99999;
    right: 0;
    top: 0;
    height: 100%;
    width: 0;
    background-color: rgba(0,0,0,0.75);
    opacity: 0;
    visibility: hidden;
    -webkit-transition: all ease 0.8s;
    transition: all ease 0.8s
}

.sidemenu-wrapper .closeButton {
    display: inline-block;
    border: 2px solid;
    width: 50px;
    height: 50px;
    line-height: 48px;
    font-size: 24px;
    padding: 0;
    position: absolute;
    top: 20px;
    right: 20px;
    background-color: var(--white-color);
    border-radius: 50%;
    -webkit-transform: rotate(0);
    -ms-transform: rotate(0);
    transform: rotate(0);
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s
}

.sidemenu-wrapper .closeButton:hover {
    color: var(--theme-color);
    border-color: var(--theme-color);
    -webkit-transform: rotate(90deg);
    -ms-transform: rotate(90deg);
    transform: rotate(90deg)
}

.sidemenu-wrapper .sidemenu-content {
    background-color: var(--white-color);
    width: 450px;
    margin-left: auto;
    padding: 80px 30px;
    height: 100%;
    overflow: scroll;
    position: relative;
    right: -500px;
    cursor: auto;
    -webkit-transition-delay: 1s;
    transition-delay: 1s;
    -webkit-transition: right ease 1s;
    transition: right ease 1s
}

.sidemenu-wrapper .sidemenu-content::-webkit-scrollbar-track {
    box-shadow: inset 0 0 1px rgba(0,0,0,0.1);
    background-color: #F5F5F5
}

.sidemenu-wrapper .sidemenu-content::-webkit-scrollbar {
    width: 2px;
    background-color: #F5F5F5
}

.sidemenu-wrapper .widget {
    padding: 0;
    border: none;
    background-color: transparent
}

.sidemenu-wrapper.show {
    opacity: 1;
    visibility: visible;
    width: 100%;
    -webkit-transition: all ease 0.8s;
    transition: all ease 0.8s
}

.sidemenu-wrapper.show .sidemenu-content {
    right: 0;
    opacity: 1;
    visibility: visible
}

.woocommerce-message,.woocommerce-info {
    position: relative;
    padding: 11px 20px 11px 50px;
    background-color: #d3d3d3;
    color: var(--body-color);
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 15px;
    border-radius: 5px
}

.woocommerce-message a,.woocommerce-info a {
    color: var(--title-color);
    text-decoration: underline
}

.woocommerce-message a:hover,.woocommerce-info a:hover {
    color: var(--title-color)
}

.woocommerce-message:before,.woocommerce-info:before {
    content: '\f06a';
    font-family: var(--icon-font);
    font-weight: 400;
    margin-right: 10px;
    font-size: 18px;
    position: absolute;
    left: 20px;
    top: 11px
}

.woocommerce-notices-wrapper .woocommerce-message {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.woocommerce-notices-wrapper .woocommerce-message a {
    color: var(--white-color)
}

.woocommerce-notices-wrapper .woocommerce-message:before {
    content: '\f14a';
    font-weight: 300
}

.woocommerce-noreviews {
    margin-bottom: -0.45em
}

.woocommerce-form-login-toggle .woocommerce-info {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.woocommerce-form-login-toggle .woocommerce-info a {
    color: inherit
}

.woocommerce-form-login-toggle .woocommerce-info a:hover {
    color: var(--title-color)
}

.woocommerce-form-register,.woocommerce-form-coupon,.woocommerce-form-login {
    margin-bottom: 30px;
    padding: 35px 40px 35px 40px;
    background-color: var(--white-color);
    border: 1px solid var(--border-color);
    box-shadow: 0px 9px 14px #fbfbfb;
    border-radius: 10px
}

@media (max-width: 575px) {
    .woocommerce-form-register,.woocommerce-form-coupon,.woocommerce-form-login {
        padding:40px 20px
    }
}

.woocommerce-form-register .form-group,.woocommerce-form-coupon .form-group,.woocommerce-form-login .form-group {
    margin-bottom: 20px
}

.woocommerce-form-register .form-group:last-child,.woocommerce-form-coupon .form-group:last-child,.woocommerce-form-login .form-group:last-child {
    margin-bottom: 0
}

.woocommerce-error {
    background-color: var(--error-color);
    color: #fff;
    list-style: none;
    padding: 10px 26px;
    margin: 0 0 30px 0;
    border-radius: 5px;
    font-weight: 700;
    font-size: 14px
}

nav.woocommerce-MyAccount-navigation li {
    border: 1px solid #ddd;
    margin: 0;
    border-top: none
}

nav.woocommerce-MyAccount-navigation li:first-child {
    border-top: 1px solid #ddd
}

nav.woocommerce-MyAccount-navigation li a {
    color: var(--title-color);
    font-weight: 700;
    padding: 7px 17px;
    display: block
}

nav.woocommerce-MyAccount-navigation li.is-active a,nav.woocommerce-MyAccount-navigation li a:hover {
    color: var(--white-color);
    background-color: var(--theme-color)
}

.woocommerce-MyAccount-content h3 {
    margin-top: -0.3em
}

.woocommerce-MyAccount-content .btn {
    background-color: var(--theme-color);
    color: var(--white-color);
    font-size: 14px;
    padding: 10px 25px;
    font-weight: 700
}

.woocommerce-MyAccount-content .btn:hover {
    background-color: var(--title-color);
    color: var(--white-color)
}

table.variations,.woocommerce-grouped-product-list-item {
    border-collapse: separate;
    border-spacing: 0 15px;
    margin-bottom: 5px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    border: none
}

table.variations td,.woocommerce-grouped-product-list-item td {
    border: none;
    vertical-align: middle;
    padding: 0 5px
}

table.variations td:first-child,.woocommerce-grouped-product-list-item td:first-child {
    padding: 0
}

table.variations label,.woocommerce-grouped-product-list-item label {
    margin: 0;
    font-size: 14px;
    text-transform: capitalize
}

table.variations label a,.woocommerce-grouped-product-list-item label a {
    color: var(--title-color)
}

table.variations label a:hover,.woocommerce-grouped-product-list-item label a:hover {
    color: var(--theme-color)
}

table.variations .label,.woocommerce-grouped-product-list-item .label {
    border: none
}

table.variations__label,.woocommerce-grouped-product-list-item__label {
    border: none !important;
    font-weight: 600
}

table.variations__price,.woocommerce-grouped-product-list-item__price {
    border: none !important
}

table.variations__price .price,table.variations__price .amount,.woocommerce-grouped-product-list-item__price .price,.woocommerce-grouped-product-list-item__price .amount {
    font-size: 18px !important
}

table.variations del,.woocommerce-grouped-product-list-item del {
    margin-left: 12px
}

.woocommerce-product-attributes th,.woocommerce-product-attributes td {
    border: 1px solid var(--border-color)
}

.woocommerce-product-attributes th p:last-child,.woocommerce-product-attributes td p:last-child {
    margin-bottom: 0
}

.woocommerce-grouped-product-list.group_table {
    border-collapse: collapse;
    margin-bottom: 15px
}

.woocommerce-grouped-product-list.group_table .woocommerce-Price-amount.amount {
    font-size: 16px;
    color: var(--title-color)
}

.woocommerce-grouped-product-list.group_table label {
    margin: 0 0 0 10px;
    margin: 0 0 0 10px;
    font-family: var(--title-font);
    font-size: 18px
}

.woocommerce-grouped-product-list.group_table .qty-input {
    border-color: #e3e6e9
}

.woocommerce-grouped-product-list.group_table tr {
    border-bottom: 1px solid #e3e6e9
}

.woocommerce-grouped-product-list.group_table tr:last-child {
    border-bottom: none
}

.woocommerce-grouped-product-list.group_table td {
    padding: 30px 5px
}

table.variations {
    width: -webkit-max-content;
    width: -moz-max-content;
    width: max-content;
    position: relative
}

table.variations td {
    padding: 0
}

table.variations td.label {
    padding-right: 10px;
    width: -webkit-max-content;
    width: -moz-max-content;
    width: max-content
}

table.variations select {
    width: -webkit-max-content;
    width: -moz-max-content;
    width: max-content;
    font-weight: 400;
    line-height: 1.5;
    vertical-align: middle;
    margin: 0;
    padding-right: 54px;
    padding-left: 20px;
    height: 50px
}

table.variations .reset_variations {
    margin-left: 16px;
    display: inline-block;
    position: absolute;
    left: 100%;
    bottom: 25px
}

.woosq-product .product .woocommerce-grouped-product-list-item__quantity,.woosq-product .product .woocommerce-grouped-product-list-item__label,.woosq-product .product .woocommerce-grouped-product-list-item__price {
    width: auto !important
}

.woosq-product .thumbnails .slick-list {
    display: block
}

.woocommerce-variation.single_variation {
    margin-bottom: 30px
}

.woocommerce-variation.single_variation .price {
    color: var(--title-color);
    font-weight: 700
}

.wooscp-table-items td.woocommerce-product-attributes-item__value {
    padding-left: 15px !important
}

.wooscp-table-items a.added_to_cart.wc-forward {
    margin-left: 15px;
    text-decoration: underline
}

.tinvwl_added_to_wishlist.tinv-modal.tinv-modal-open {
    z-index: 1111
}

table.woocommerce-product-attributes {
    margin-bottom: 30px
}

#woosq-popup .product_meta {
    margin-top: 20px
}

#woosq-popup .product_title {
    font-size: 24px;
    margin-bottom: 5px
}

#woosq-popup .single-product .product .actions {
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 20px
}

#woosq-popup .single-product .product .actions>div {
    height: auto;
    overflow: visible;
    width: -webkit-max-content;
    width: -moz-max-content;
    width: max-content
}

#woosq-popup .single-product .product .actions>div .quantity.style2.woocommerce-grouped-product-list-item__quantity {
    width: -webkit-max-content;
    width: -moz-max-content;
    width: max-content
}

.login-tab {
    margin-bottom: 30px;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center
}

.login-tab button.nav-link {
    background-color: var(--smoke-color);
    color: var(--title-color);
    padding: 11px 39px;
    font-size: 18px;
    font-weight: 500;
    border-radius: 15px â€‹15px 0
}

.login-tab button.nav-link.active {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.star-rating {
    overflow: hidden;
    position: relative;
    width: 100px;
    height: 1.2em;
    line-height: 1.2em;
    display: block;
    font-family: var(--icon-font);
    font-weight: 300;
    font-size: 14px
}

.star-rating:before {
    content: "\e28b\e28b\e28b\e28b\e28b";
    color: var(--theme-color);
    float: left;
    top: 0;
    left: 0;
    position: absolute;
    letter-spacing: 3px
}

.star-rating span {
    overflow: hidden;
    float: left;
    top: 0;
    left: 0;
    position: absolute;
    padding-top: 1.5em
}

.star-rating span:before {
    content: "\e28b\e28b\e28b\e28b\e28b";
    top: 0;
    position: absolute;
    left: 0;
    color: var(--theme-color);
    letter-spacing: 3px;
    font-weight: 700
}

.rating-select label {
    margin: 0;
    margin-right: 10px
}

.rating-select p.stars {
    margin-bottom: 0;
    line-height: 1
}

.rating-select p.stars a {
    position: relative;
    height: 14px;
    width: 18px;
    text-indent: -999em;
    display: inline-block;
    text-decoration: none
}

.rating-select p.stars a::before {
    display: block;
    position: absolute;
    top: 0;
    left: 0;
    width: 18px;
    height: 14px;
    line-height: 1;
    font-family: var(--icon-font);
    content: "\f005";
    font-weight: 400;
    text-indent: 0;
    color: var(--yellow-color)
}

.rating-select p.stars a:hover ~ a::before {
    content: "\f005";
    font-weight: 400
}

.rating-select p.stars:hover a::before {
    content: "\f005";
    font-weight: 700
}

.rating-select p.stars.selected a.active::before {
    content: "\f005";
    font-weight: 700
}

.rating-select p.stars.selected a.active ~ a::before {
    content: "\f005";
    font-weight: 400
}

.rating-select p.stars.selected a:not(.active)::before {
    content: "\f005";
    font-weight: 700
}

@media (max-width: 767px) {
    .woocommerce-message,.woocommerce-info {
        font-size:14px;
        line-height: 22px;
        padding: 10px 15px 10px 37px
    }

    .woocommerce-message:before,.woocommerce-info:before {
        font-size: 16px;
        top: 10px;
        left: 15px
    }
}

.th-product {
    text-align: center;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s
}

.th-product .product-title {
    font-size: 20px;
    margin: 10px 0 7px 0
}

.th-product .product-title a {
    color: inherit
}

.th-product .product-title a:hover {
    color: var(--theme-color)
}

.th-product .price {
    display: block;
    color: var(--body-color);
    font-weight: 500;
    margin-bottom: -0.45em;
    font-family: var(--title-font)
}

.th-product .price del {
    margin-left: 10px;
    color: #c5c5c5
}

.th-product .product-img {
    background-color: var(--smoke-color);
    overflow: hidden;
    position: relative;
    margin: 0 0 25px 0;
    text-align: center;
    background-color: var(--smoke-color);
    z-index: 2;
    border-radius: 0px
}

.th-product .product-img img {
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s;
    -webkit-transform: scale(1);
    -ms-transform: scale(1);
    transform: scale(1)
}

.th-product .category {
    color: var(--white-color);
    font-size: 14px;
    font-family: var(--title-font);
    font-weight: 500;
    padding: 1px 20px;
    display: inline-block;
    background-color: var(--theme-color);
    position: absolute;
    top: 20px;
    right: 20px;
    z-index: 3;
    border-radius: 5px
}

.th-product .star-rating {
    margin: 0 auto 5px auto;
    width: 93px
}

.th-product .actions {
    height: 100%;
    position: absolute;
    left: 0;
    top: 50%;
    right: 0;
    text-align: center;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    background-color: rgba(14,18,29,0.7);
    z-index: 3;
    margin-top: 0;
    opacity: 0;
    visibility: hidden;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.th-product .actions .icon-btn {
    box-shadow: 0px 4px 20px rgba(0,0,0,0.05)
}

.th-product .actions>* {
    margin: 0 var(--icon-gap-x, 5px)
}

.th-product .actions>*>a {
    margin: 0
}

.th-product .actions .tutor-btn {
    padding: unset;
    border-radius: 999px;
    min-width: unset
}

.th-product .icon-btn {
    -webkit-transform: translateY(30px);
    -ms-transform: translateY(30px);
    transform: translateY(30px);
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.th-product .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart-plus.no-txt,.th-product .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart.no-txt {
    width: 50px;
    height: 50px;
    line-height: 50px;
    display: inline-block
}

.th-product .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart-plus.no-txt::before,.th-product .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart.no-txt::before {
    position: relative;
    top: 0;
    left: 0;
    line-height: inherit;
    margin: 0;
    font-size: 24px
}

.th-product .tinv-wishlist a {
    display: inline-block;
    width: 50px;
    height: 50px;
    line-height: 50px;
    background-color: var(--white-color);
    color: var(--title-color);
    border-radius: 50%
}

.th-product .tinv-wishlist a:hover {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.th-product .add_to_cart_button.added {
    display: none
}

.th-product .added_to_cart {
    width: 50px;
    height: 50px;
    line-height: 50px;
    background-color: var(--white-color);
    color: var(--title-color);
    font-size: 0;
    text-align: center;
    border-radius: 50%
}

.th-product .added_to_cart:after {
    content: "\f07a";
    position: relative;
    font-family: var(--icon-font);
    font-size: 16px;
    font-weight: 700
}

.th-product .added_to_cart:hover {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.th-product .added_to_cart .tutor-mr-8 {
    margin-right: 0 !important
}

.th-product .action-btn {
    background-color: var(--white-color);
    font-size: 14px;
    font-family: var(--title-font);
    text-transform: uppercase;
    font-weight: bold;
    display: inline-block;
    padding: 13px 25px
}

.th-product:hover .actions {
    margin-top: 0;
    opacity: 1;
    visibility: visible
}

.th-product:hover .icon-btn {
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0)
}

.th-product.list-view {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    text-align: left;
    height: 100%
}

.th-product.list-view .product-img {
    width: 100%;
    max-width: 200px;
    margin: 0;
    border-radius: 8px 0 0 8px
}

.th-product.list-view .star-rating {
    margin: 0 auto 10px 0;
    width: 93px
}

.th-product.list-view .product-content {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    border: 1px solid var(--border-color);
    border-left: none;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: start;
    -webkit-align-items: flex-start;
    -ms-flex-align: start;
    align-items: flex-start;
    padding: 0 25px;
    border-radius: 0 8px 8px 0
}

.th-product.list-view .actions {
    --btn-size: 35px;
    --btn-font-size: 13px;
    --icon-gap-x: 2px
}

.th-product.list-view .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart-plus.no-txt,.th-product.list-view .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart.no-txt {
    width: 35px;
    height: 35px;
    line-height: 35px
}

.th-product.list-view .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart-plus.no-txt::before,.th-product.list-view .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart.no-txt::before {
    font-size: 20px
}

.th-product.list-view .tinv-wishlist a {
    width: 35px;
    height: 35px;
    line-height: 35px
}

.th-product.list-view .added_to_cart {
    width: 35px;
    height: 35px;
    line-height: 35px
}

.th-product.list-view .added_to_cart:after {
    font-size: 12px
}

.th-product.list-view .action-btn {
    padding: 8px 15px
}

.th-product.list-view .tag {
    top: 8px;
    right: 8px;
    padding: 0px 15px
}

.th-product.list-view .product-title {
    font-size: 18px;
    margin: 0 0 5px 0
}

.th-product.list-view .product-price {
    font-size: 14px
}

.mfp-content {
    margin: 1.5rem auto
}

.mfp-content .product-details-img {
    padding-top: 15px
}

.mfp-content .product-about {
    padding-top: 40px;
    padding-bottom: 40px
}

.mfp-content .container {
    position: relative
}

.mfp-content .product-big-img {
    margin-top: 15px;
    margin-bottom: 15px
}

.mfp-fade.mfp-bg {
    opacity: 0;
    -webkit-transition: all 0.15s ease-out;
    transition: all 0.15s ease-out
}

.mfp-fade.mfp-bg.mfp-ready {
    opacity: 0.8
}

.mfp-fade.mfp-bg.mfp-removing {
    opacity: 0
}

.mfp-fade.mfp-wrap .mfp-content {
    opacity: 0;
    -webkit-transition: all 0.4s ease-out;
    transition: all 0.4s ease-out
}

.mfp-fade.mfp-wrap.mfp-ready .mfp-content {
    opacity: 1
}

.mfp-fade.mfp-wrap.mfp-removing .mfp-content {
    opacity: 0
}

.woosq-popup {
    max-height: 500px;
    max-width: 996px
}

.woosq-popup .product_meta>span>a:after,.woosq-popup .product_meta>span>span:after {
    display: none
}

.woosq-product>.product>div {
    max-height: 500px;
    min-height: 460px;
    height: auto
}

.woosq-product .thumbnails .slick-dots li button {
    width: 12px;
    height: 12px;
    background: var(--theme-color)
}

.woosq-product .thumbnails .slick-dots li button:before {
    content: '';
    display: block;
    width: 6px;
    height: 6px;
    margin: 0;
    border-radius: 50%;
    background-color: var(--white-color);
    border: none;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.th-sort-bar {
    padding: 0;
    margin: 0 0 40px 0;
    border-radius: 5px
}

.th-sort-bar .row {
    --bs-gutter-x: 0;
    --bs-gutter-y: 15px
}

.th-sort-bar select {
    height: 50px;
    border: 1px solid var(--border-color);
    width: -webkit-fit-content;
    width: -moz-fit-content;
    width: fit-content;
    min-width: 250px;
    font-size: 16px;
    margin: 0;
    color: var(--body-color)
}

.th-sort-bar .woocommerce-result-count {
    margin-bottom: 0;
    color: var(--body-color)
}

.th-sort-bar .nav a {
    display: inline-block;
    position: relative;
    font-family: var(--title-font);
    font-weight: 600;
    font-size: 16px;
    text-transform: capitalize;
    color: var(--body-color);
    margin: 0 0 0 20px
}

.th-sort-bar .nav a.active,.th-sort-bar .nav a:hover {
    color: var(--theme-color)
}

.product-big-img {
    background-color: var(--smoke-color);
    text-align: center;
    border-radius: 10px;
    overflow: hidden
}

.product-big-img .slick-dots {
    position: absolute;
    left: 0;
    right: 0;
    text-align: center;
    bottom: 25px;
    margin-bottom: 0
}

.product-big-img .slick-arrow {
    left: 30px
}

.product-big-img .slick-arrow.slick-next {
    left: auto;
    right: 30px
}

.quantity {
    position: relative;
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    vertical-align: middle
}

.quantity>.screen-reader-text {
    display: inline-block;
    font-weight: 600;
    color: var(--title-color);
    font-family: var(--title-font);
    margin: 0;
    -webkit-align-self: center;
    -ms-flex-item-align: center;
    align-self: center;
    margin-right: 10px
}

.quantity .qty-btn,.quantity .qty-input {
    display: inline-block;
    width: 50px;
    height: 50px;
    border: none;
    border-right: none;
    background-color: transparent;
    padding: 0;
    border-radius: 0;
    text-align: center;
    color: var(--body-color);
    font-size: 18px;
    font-weight: 600
}

.quantity .qty-btn:last-child,.quantity .qty-input:last-child {
    border-right: none
}

.quantity .qty-btn {
    font-size: 16px
}

.product_meta {
    font-weight: 700;
    font-size: 16px;
    font-family: var(--body-font);
    margin: 35px 0 0 0
}

.product_meta>span {
    display: block;
    margin-bottom: 5px;
    color: var(--title-color);
    font-weight: bold
}

.product_meta>span:last-child {
    margin-bottom: 0
}

.product_meta>span a {
    color: inherit
}

.product_meta>span a:hover {
    color: var(--theme-color)
}

.product_meta>span>a,.product_meta>span>span {
    position: relative;
    color: var(--body-color);
    font-weight: 400
}

.product_meta>span>a:after,.product_meta>span>span:after {
    content: ",";
    margin-right: 5px
}

.product_meta>span>a:last-child:after,.product_meta>span>span:last-child:after {
    display: none
}

.product_meta>span>a:first-child,.product_meta>span>span:first-child {
    margin-left: 7px
}

.product-tab-style1 {
    margin: 95px 0 40px 0
}

.product-tab-style1 li {
    margin: 0 45px 0 0
}

.product-tab-style1 li:last-child {
    margin-right: 0
}

.product-tab-style1 a.active:before {
    width: 100%
}

#productTabContent {
    margin-bottom: -10px
}

#additional_information {
    margin-bottom: 40px
}

.product-inner-list>ul {
    margin: 0;
    padding: 0;
    list-style-type: none
}

.product-inner-list li {
    position: relative;
    padding-left: 15px
}

.product-inner-list li:before {
    content: "-";
    position: absolute;
    left: 0
}

.summary-content .product-title,.product-about .product-title {
    margin: 0 0 10px 0;
    font-size: 36px
}

.summary-content>.price,.product-about>.price {
    font-family: var(--title-font);
    font-size: 24px;
    font-weight: 700;
    color: var(--theme-color);
    display: inline-block;
    margin-bottom: 10px
}

.summary-content>.price del,.product-about>.price del {
    color: #D3D3D3;
    font-weight: 500;
    margin-left: 15px
}

.summary-content .woocommerce-product-rating,.summary-content .product-rating,.product-about .woocommerce-product-rating,.product-about .product-rating {
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    gap: 5px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    position: relative;
    top: 2px;
    font-size: 16px;
    line-height: 20px;
    padding: 0 0 0 0;
    margin: 0 0 0 0;
    margin-bottom: 25px;
    width: 100%
}

.summary-content .woocommerce-product-rating .star-rating,.summary-content .product-rating .star-rating,.product-about .woocommerce-product-rating .star-rating,.product-about .product-rating .star-rating {
    width: 80px;
    font-size: 12px;
    margin-right: 8px
}

.summary-content .woocommerce-review-link,.product-about .woocommerce-review-link {
    color: var(--body-color)
}

.summary-content .checklist,.product-about .checklist {
    margin: 30px 0 40px 0
}

.summary-content .checklist li,.product-about .checklist li {
    font-weight: 400
}

.summary-content .actions,.product-about .actions {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 15px 30px;
    margin: 33px 0 30px 0
}

.summary-content .actions .th-btn,.product-about .actions .th-btn {
    padding: 22px 33px
}

.summary-content .actions .th-btn.style2,.product-about .actions .th-btn.style2 {
    padding: 0;
    min-height: 50px;
    line-height: 50px
}

.summary-content .actions .th-btn .btn-icon,.product-about .actions .th-btn .btn-icon {
    padding: 10.5px 15px 10.5px 15px
}

.summary-content .actions .icon-btn,.product-about .actions .icon-btn {
    box-shadow: 0px 4px 20px rgba(0,0,0,0.14)
}

.summary-content .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart-plus.no-txt,.summary-content .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart.no-txt,.product-about .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart-plus.no-txt,.product-about .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart.no-txt {
    width: 60px;
    height: 60px;
    line-height: 60px;
    display: inline-block;
    border-radius: 5px;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.summary-content .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart-plus.no-txt::before,.summary-content .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart.no-txt::before,.product-about .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart-plus.no-txt::before,.product-about .tinv-wishlist .tinvwl_add_to_wishlist_button.tinvwl-icon-heart.no-txt::before {
    position: relative;
    top: 0;
    left: 0;
    line-height: inherit;
    margin: 0;
    font-size: 24px
}

.summary-content .tinv-wishlist a,.product-about .tinv-wishlist a {
    display: inline-block;
    width: 60px;
    height: 60px;
    line-height: 60px;
    border-radius: 0
}

.summary-content .tinv-wishlist a:hover,.product-about .tinv-wishlist a:hover {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.summary-content .quantity .qty-input,.product-about .quantity .qty-input {
    width: 100px;
    height: 60px;
    border: none;
    background-color: var(--title-color);
    color: var(--white-color);
    padding: 0 25px;
    text-align: left;
    font-weight: 500;
    border-radius: 5px
}

.summary-content .quantity .qty-btn,.product-about .quantity .qty-btn {
    color: var(--white-color);
    background-color: transparent;
    position: absolute;
    right: 25px;
    height: auto;
    width: auto;
    border: none
}

.summary-content .quantity .quantity-minus,.product-about .quantity .quantity-minus {
    bottom: 8px
}

.summary-content .quantity .quantity-plus,.product-about .quantity .quantity-plus {
    top: 8px
}

#description {
    margin-bottom: 30px
}

.product-details .th-comments-wrap {
    margin-top: 0
}

.product-details .border-title {
    position: relative;
    padding-bottom: 20px;
    margin-bottom: 40px
}

.product-details .border-title:before {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    height: 2px;
    width: 80px;
    background-color: var(--theme-color)
}

.product-inner-title {
    font-size: 32px;
    border-bottom: 1px solid var(--border-color);
    padding: 0 0 7px 0;
    margin: 0 0 30px 0
}

li.review:last-child .th-post-comment {
    border-bottom: none
}

.related-product-wrapper {
    padding-top: 115px
}

@media (max-width: 1399px) {
    .th-product.list-view .product-img {
        max-width:150px
    }
}

@media (max-width: 1199px) {
    .th-sort-bar select {
        min-width:auto
    }

    .product-tab-style1 {
        margin: 55px 0 40px 0
    }
}

@media (max-width: 991px) {
    .product-big-img {
        margin-bottom:40px
    }

    .th-product-box.list-view .product-img {
        max-width: 150px
    }

    .th-sort-bar .row {
        --bs-gutter-x: 20px
    }

    .th-sort-bar .nav a:last-child {
        margin-right: 0;
        padding-right: 0
    }

    .th-sort-bar .nav a:last-child:before {
        display: none
    }

    .woosq-product>.product .thumbnails {
        max-height: 400px;
        min-height: 200px;
        padding: 10px
    }
}

@media (max-width: 767px) {
    .th-sort-bar {
        text-align:center
    }

    .th-sort-bar .nav {
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }

    .th-sort-bar select {
        margin: 0 auto
    }

    .th-product-box.list-view .product-img {
        max-width: 130px
    }

    .th-product-box.list-view .actions {
        --btn-size: 30px;
        --btn-font-size: 10px;
        --icon-gap-x: 2px
    }

    .product-tab-style1 a {
        margin-bottom: 0
    }
}

@media (max-width: 575px) {
    .product-about .actions {
        gap:15px 15px
    }
}

@media (max-width: 375px) {
    .th-product.list-view .product-img {
        max-width:130px
    }

    .product-tab-style1 {
        display: -webkit-box;
        display: -webkit-flex;
        display: -ms-flexbox;
        display: flex;
        -webkit-flex-flow: wrap;
        -ms-flex-flow: wrap;
        flex-flow: wrap;
        gap: 15px
    }

    .product-tab-style1 li {
        margin: 0
    }
}

.woocommerce-cart-form {
    text-align: center
}

.cart_table {
    border: 1px solid #eaf0f2;
    margin-bottom: 45px
}

.cart_table thead {
    background-color: #ecf0f1
}

.cart_table thead th {
    border: none !important
}

.cart_table td:before,.cart_table th {
    font-family: var(--title-font);
    color: var(--title-color);
    font-weight: 600;
    border: none;
    padding: 27px 15px
}

.cart_table td:before {
    content: attr(data-title);
    position: absolute;
    left: 15px;
    top: 50%;
    vertical-align: top;
    padding: 0;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    display: none
}

.cart_table td {
    border: none;
    border-bottom: 1px solid #f3f3f3;
    color: #8b8b8b;
    padding: 20px 10px;
    position: relative;
    vertical-align: middle
}

.cart_table td[data-title="Name"] a {
    color: var(--title-color);
    font-weight: 500
}

.cart_table td[data-title="Name"] a:hover {
    color: var(--theme-color)
}

.cart_table .product-quantity {
    color: var(--title-color)
}

.cart_table .product-quantity input {
    position: relative;
    top: -2px
}

.cart_table .cart-productname {
    font-weight: 400;
    font-family: var(--body-font);
    color: var(--body-color)
}

.cart_table .cart-productimage {
    display: inline-block;
    border: 0 solid var(--smoke-color);
    border-radius: 5px;
    overflow: hidden
}

.cart_table .remove {
    color: var(--theme-color);
    font-size: 18px
}

.cart_table .quantity {
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.cart_table .qty-btn {
    border: 2px solid var(--smoke-color);
    background-color: transparent;
    color: #b8c6d0;
    padding: 0;
    width: 30px;
    height: 30px;
    line-height: 28px;
    font-size: 16px;
    border-radius: 4px
}

.cart_table .qty-btn:hover {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.cart_table .qty-input {
    vertical-align: middle;
    border: 2px solid var(--smoke-color);
    width: 70px;
    height: 30px;
    font-size: 14px;
    text-align: center;
    color: var(--title-color);
    font-weight: 700;
    margin: 0 10px;
    border-radius: 4px;
    padding: 0
}

.cart_table .qty-input::-moz-placeholder {
    color: var(--title-color)
}

.cart_table .qty-input::-webkit-input-placeholder {
    color: var(--title-color)
}

.cart_table .qty-input:-ms-input-placeholder {
    color: var(--title-color)
}

.cart_table .qty-input::-ms-input-placeholder {
    color: var(--title-color)
}

.cart_table .qty-input::placeholder {
    color: var(--title-color)
}

.cart_table .qty-input::-webkit-outer-spin-button,.cart_table .qty-input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0
}

.cart_table .qty-input[type=number] {
    -moz-appearance: textfield
}

.cart_table .actions {
    text-align: right;
    vertical-align: middle
}

.cart_table .actions>.th-btn {
    font-size: 16px;
    padding: 17px 28px;
    margin-right: 15px
}

.cart_table .actions>.th-btn:last-child {
    margin-right: 0
}

.cart_table .th-cart-coupon {
    float: left;
    margin: 0;
    width: 455px;
    max-width: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex
}

.cart_table .th-cart-coupon input {
    height: 50px;
    width: calc(100% - 200px);
    margin-right: 10px
}

.cart_table .th-cart-coupon .th-btn {
    font-size: 16px;
    padding: 17px 22px;
    width: -webkit-max-content;
    width: -moz-max-content;
    width: max-content
}

.cart_totals {
    border: 1px solid #ecf0f1
}

.cart_totals th,.cart_totals td {
    vertical-align: top;
    padding: 20px 20px;
    border: none;
    border-bottom: 1px solid #ecf0f1;
    font-size: 14px;
    color: var(--title-color);
    width: 55%
}

.cart_totals th:first-child,.cart_totals td:first-child {
    width: 45%;
    background-color: #f9fbfb;
    font-weight: 700;
    font-size: 14px;
    color: #333333
}

.cart_totals .shipping-calculator-button {
    display: inline-block;
    border-bottom: 1px solid;
    color: var(--title-color);
    font-weight: 700
}

.cart_totals .shipping-calculator-button:hover {
    color: var(--theme-color)
}

.cart_totals .woocommerce-shipping-destination {
    margin-bottom: 10px
}

.cart_totals .woocommerce-shipping-methods {
    margin-bottom: 0
}

.cart_totals .shipping-calculator-form {
    display: none
}

.cart_totals .shipping-calculator-form p:first-child {
    margin-top: 20px
}

.cart_totals .shipping-calculator-form p:last-child {
    margin-bottom: 0
}

.cart_totals .shipping-calculator-form .select2-container--default .select2-selection--single .select2-selection__rendered {
    line-height: 40px;
    padding-left: 15px
}

.cart_totals .shipping-calculator-form .select2-container--default .select2-selection--single .select2-selection__arrow {
    height: 40px;
    line-height: 40px;
    margin-right: 15px
}

.cart_totals .shipping-calculator-form .th-btn {
    padding: 5px 30px
}

.cart_totals .amount {
    font-weight: 700
}

.cart_totals .order-total .amount {
    color: var(--theme-color)
}

@media (max-width: 991px) {
    .cart_table th {
        padding:23px 8px;
        font-size: 14px
    }

    .cart_table .cart-productname {
        font-size: 14px
    }

    .cart_table .th-cart-coupon {
        width: 100%;
        margin-bottom: 20px;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }

    .cart_table .actions {
        text-align: center
    }
}

@media (max-width: 767px) {
    .cart_table {
        text-align:left;
        min-width: auto;
        border-collapse: separate;
        border-spacing: 0 20px;
        border: none
    }

    .cart_table thead {
        display: none
    }

    .cart_table td {
        padding: 15px;
        display: block;
        width: 100%;
        padding-left: 25%;
        text-align: right;
        border: 1px solid #f3f3f3;
        border-bottom: none
    }

    .cart_table td::before {
        display: block
    }

    .cart_table td:last-child {
        border-bottom: 1px solid #f3f3f3
    }

    .cart_table td.actions {
        padding-left: 15px;
        text-align: center
    }

    .cart_table td.actions>.th-btn {
        margin-top: 10px;
        margin-right: 0;
        display: block;
        width: -webkit-max-content;
        width: -moz-max-content;
        width: max-content;
        margin-left: auto;
        margin-right: auto
    }

    .cart_table td.actions>.th-btn:last-child {
        margin-right: auto
    }

    .cart_table .th-cart-coupon {
        width: 100%;
        text-align: center;
        float: none;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center;
        display: block;
        padding-bottom: 10px
    }

    .cart_table .th-cart-coupon input {
        width: 100%;
        margin-bottom: 10px
    }

    .cart_totals th,.cart_totals td {
        padding: 15px 10px
    }

    .cart_totals th:first-child,.cart_totals td:first-child {
        width: 17%;
        line-height: 1.4
    }
}

.woocommerce-checkout .form-group,.woocommerce-checkout .form-row {
    margin-bottom: 0
}

.woocommerce-checkout .form-select,.woocommerce-checkout .select2-container,.woocommerce-checkout .form-control {
    margin-bottom: 0
}

.woocommerce-checkout .select2-container--open .select2-dropdown--below {
    margin-top: -52px
}

.woocommerce-checkout .select2-container--open .select2-dropdown--above {
    position: relative;
    bottom: 0px
}

.woocommerce-checkout .select2-dropdown {
    border: 1px solid var(--smoke-color);
    border-top: none
}

.woocommerce-checkout .select2-container--default .select2-selection--single {
    border-radius: 5px
}

.woocommerce-checkout .select2-container--default .select2-selection--single .select2-selection__rendered,.woocommerce-checkout .select2-container--default .select2-selection--single .form-control:focus {
    color: var(--body-color)
}

.select2-container--default .select2-search--dropdown .select2-search__field {
    border: none;
    padding: 0
}

.woocommerce-form-login select,.woocommerce-form-login .form-select,.woocommerce-form-login .form-control,.woocommerce-form-login .select2,.woocommerce-form-login .select2-container,.woocommerce-form-coupon select,.woocommerce-form-coupon .form-select,.woocommerce-form-coupon .form-control,.woocommerce-form-coupon .select2,.woocommerce-form-coupon .select2-container,.woocommerce-checkout select,.woocommerce-checkout .form-select,.woocommerce-checkout .form-control,.woocommerce-checkout .select2,.woocommerce-checkout .select2-container {
    margin-bottom: var(--bs-gutter-x)
}

.woocommerce-form-login input,.woocommerce-form-coupon input {
    max-width: 450px
}

#ship-to-different-address {
    margin-top: 15px
}

.select2-container--default .select2-selection--single {
    height: 55px;
    border: none
}

.select2-container--default .select2-selection--single .select2-selection__rendered {
    line-height: 55px;
    padding-left: 25px;
    padding-right: 25px;
    background-color: var(--smoke-color);
    border-radius: 5px
}

.woocommerce-billing-fields .form-row {
    margin-bottom: 0
}

.select2-container--default .select2-selection--single .select2-selection__arrow b:before {
    content: '\f107';
    font-family: var(--icon-font)
}

.select2-container--default .select2-selection--single .select2-selection__arrow b {
    margin: 0;
    border: none;
    top: 0
}

.select2-container--default .select2-selection--single .select2-selection__arrow {
    height: 55px;
    line-height: 55px;
    margin-right: 25px
}

span.select2-selection.select2-selection--single:focus {
    outline: none
}

.shipping-calculator-form .form-select,.shipping-calculator-form .form-control {
    height: 40px;
    padding-left: 15px;
    font-size: 16px;
    border-radius: 5px;
    background-position: right 13px center
}

.shipping-calculator-form .th-btn {
    font-size: 14px;
    padding: 0 20px;
    width: -webkit-max-content;
    width: -moz-max-content;
    width: max-content;
    height: 40px
}

.checkout-ordertable th,.checkout-ordertable td {
    border: none;
    vertical-align: top;
    padding: 5px 0;
    font-size: 14px;
    font-weight: 700;
    color: #2c3e50
}

.checkout-ordertable ul {
    margin: 0;
    padding: 0
}

.checkout-ordertable .order-total .amount {
    color: var(--theme-color)
}

.checkout-ordertable input[type="hidden"] ~ label {
    color: var(--theme-color)
}

.woocommerce-checkout .form-group input:not(:last-child) {
    margin-bottom: var(--bs-gutter-x)
}

.checkout-ordertable th,.checkout-ordertable td {
    border: 1px solid #ededed;
    text-align: right;
    padding: 5px 20px
}

.checkout-ordertable th {
    text-align: left
}

.woocommerce-checkout-payment {
    text-align: left
}

.woocommerce-checkout-payment ul {
    margin: 0;
    padding: 0;
    list-style-type: none
}

.woocommerce-checkout-payment ul li {
    padding-top: 10px;
    border-bottom: 1px solid #d8d8d8;
    border-radius: 4px;
    font-size: 16px
}

.woocommerce-checkout-payment ul input[type="radio"] ~ label {
    margin-bottom: 14px;
    color: var(--body-color)
}

.woocommerce-checkout-payment ul input[type="radio"] ~ label img {
    margin-bottom: -2px;
    margin-left: 10px
}

.woocommerce-checkout-payment .place-order {
    padding-top: 30px
}

.woocommerce-checkout-payment .payment_box {
    color: #a1b1bc;
    background-color: #ecf0f1;
    border: 1px solid #d8d8d8;
    border-bottom: none;
    font-size: 14px;
    padding: 10px 20px;
    border-radius: 4px;
    display: none
}

.woocommerce-checkout-payment .payment_box p {
    margin: 0
}

.th-checkout-wrapper form.woocommerce-form {
    margin-bottom: 25px
}

@media (max-width: 767px) {
    tfoot.checkout-ordertable th {
        display:none
    }

    .woocommerce-checkout-payment ul input[type="radio"] ~ label img {
        max-width: 150px
    }

    .checkout-ordertable th,.checkout-ordertable td {
        padding: 5px 20px 5px 60px
    }
}

.tinv-wishlist input[type=checkbox] {
    display: inline-block;
    opacity: 1;
    visibility: visible;
    vertical-align: middle;
    width: auto;
    height: auto
}

.tinv-wishlist .tinv-header {
    margin-top: -0.8rem
}

.tinv-wishlist .cart-empty {
    padding: 12px 25px;
    padding-left: 50px;
    background-color: #eee;
    border-radius: 0;
    font-weight: 700;
    font-size: 14px;
    border-radius: 5px
}

.tinv-wishlist .cart-empty:before {
    top: 9px
}

.tinv-wishlist p.return-to-shop .button {
    display: inline-block;
    background-color: var(--theme-color);
    color: #fff;
    font-size: 14px;
    padding: 10px 25px;
    margin-top: 10px;
    font-weight: 700
}

.tinv-wishlist p.return-to-shop .button:Hover {
    background-color: var(--title-color);
    color: var(--white-color)
}

.tinv-wishlist table {
    border: none
}

.tinv-wishlist table th {
    color: var(--title-color)
}

.tinv-wishlist table td,.tinv-wishlist table th {
    padding: 15.3px 10px;
    border-bottom: 1px solid var(--border-color);
    text-align: center
}

.tinv-wishlist table td button.button i,.tinv-wishlist table th button.button i {
    font-size: 13px !important;
    margin-right: 5px !important
}

.tinv-wishlist table thead {
    background-color: var(--smoke-color)
}

.tinv-wishlist .product-cb,.tinv-wishlist .product-remove {
    width: 40px;
    text-align: center
}

.tinv-wishlist .product-thumbnail {
    width: 110px
}

.tinv-wishlist .product-thumbnail img {
    border-radius: 5px
}

.tinv-wishlist .stock.in-stock {
    margin-bottom: 0
}

.tinv-wishlist ins {
    text-decoration: none
}

.tinv-wishlist .product-remove button {
    border: none;
    height: 22px;
    width: 22px;
    text-align: center;
    font-size: 12px;
    line-height: 22px;
    border-radius: 4px;
    padding-top: 0
}

.tinv-wishlist .product-remove button i {
    line-height: 22px;
    font-size: 14px
}

.tinv-wishlist .tinvwl-mobile {
    display: none
}

.tinv-wishlist .social-buttons {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    max-width: 295px;
    margin-left: auto;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.tinv-wishlist .social-buttons ul {
    padding-left: 0;
    margin-bottom: 0;
    margin-left: auto;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 6px
}

.tinv-wishlist table.tinvwl-table-manage-list {
    font-size: 16px
}

.tinv-wishlist .product-stock .stock {
    display: block
}

.tinv-wishlist .product-stock span {
    display: inline
}

.tinv-wishlist .product-stock i {
    margin-right: 5px
}

.tinv-wishlist .tinv-modal .icon_big_times {
    margin-bottom: 5px;
    color: var(--theme-color)
}

.tinv-wishlist button.button {
    border: none;
    height: 40px;
    line-height: 38px;
    font-size: 12px;
    font-weight: 600;
    background-color: var(--theme-color);
    color: #fff;
    padding: 1px 15px;
    min-width: 140px;
    border-radius: 5px
}

.tinv-wishlist button.button.mask-btn {
    padding: 0
}

.tinv-wishlist button.button .btn-text-mask {
    padding: 0.5px 21px
}

.tinv-wishlist button.button:hover {
    background-color: var(--title-color);
    color: #fff
}

.tinv-wishlist button.button i {
    font-size: 18px !important;
    margin-right: 3px !important
}

.tinv-wishlist th,.tinv-wishlist td.product-name {
    font-size: 16px;
    font-weight: 600;
    font-family: var(--title-font)
}

.tinv-wishlist td.product-name a {
    color: var(--body-color)
}

.tinv-wishlist td.product-name a:hover {
    color: var(--theme-color)
}

.tinv-wishlist td.product-price del {
    margin-left: 8px;
    font-size: 0.9em
}

.tinv-wishlist .social-buttons>span {
    font-weight: 700;
    margin-right: 10px;
    font-family: var(--title-font);
    color: var(--title-color)
}

.tinv-wishlist .social-buttons li {
    display: inline-block;
    margin-right: 0
}

.tinv-wishlist .social-buttons li a.social {
    background-color: var(--theme-color);
    color: #fff;
    width: 30px;
    height: 30px;
    line-height: 30px;
    font-size: 14px;
    display: inline-block;
    text-align: center;
    border-radius: 50px;
    margin-left: 3px
}

.tinv-wishlist .social-buttons li a.social:first-child {
    margin-left: 0
}

.tinv-wishlist .social-buttons li a.social i {
    line-height: inherit
}

.tinv-wishlist .social-buttons li a.social:hover {
    background-color: var(--title-color);
    color: var(--white-color)
}

.tinvwl-input-group .form-control {
    height: 40px
}

@media (max-width: 991px) {
    .tinvwl-full {
        display:none
    }

    .tinv-wishlist .tinvwl-mobile {
        display: block
    }

    .tinv-wishlist .product-stock .tinvwl-txt {
        display: none
    }

    .tinv-wishlist .product-action .tinvwl-txt {
        display: block
    }

    .tinv-wishlist button.button {
        min-width: auto
    }

    .product-stock {
        width: 40px;
        text-align: center
    }
}

@media (max-width: 767px) {
    .tinv-wishlist table {
        table-layout:fixed;
        border-bottom: 1px solid var(--border-color)
    }

    .tinv-wishlist .product-action .tinvwl-txt {
        display: inline-block
    }

    .tinv-wishlist button.button {
        min-width: 140px
    }

    .tinv-wishlist table.tinvwl-table-manage-list tbody td.product-remove,.tinv-wishlist table.tinvwl-table-manage-list thead th:not(.product-name) {
        display: none
    }

    .tinv-wishlist table td,.tinv-wishlist table th {
        border: 1px solid var(--border-color)
    }

    .tinv-wishlist table.tinvwl-table-manage-list tbody td {
        display: block;
        width: 100% !important;
        text-align: center
    }

    .product-name {
        text-align: center
    }

    .tinv-wishlist table td,.tinv-wishlist table th {
        border-bottom: none
    }

    .tinv-wishlist table tfoot {
        border-bottom: 1px solid var(--border-color)
    }

    .tinv-wishlist .social-buttons {
        max-width: 100%;
        margin-left: unset;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -webkit-flex-direction: column;
        -ms-flex-direction: column;
        flex-direction: column
    }

    .tinv-wishlist .social-buttons ul {
        margin-left: unset;
        margin-top: 5px
    }

    .tinvwl-txt {
        display: inline-block
    }

    .tinv-wishlist .cart-empty {
        padding-left: 40px
    }
}

@media (max-width: 575px) {
    .tinv-wishlist button.button {
        min-width:100px
    }
}

@media (max-width: 1399px) {
    .contact-thumb1 img {
        width:70%
    }
}

@media (max-width: 1299px) {
    .contact-thumb1 img {
        width:65%
    }
}

@media (max-width: 1199px) {
    .contact-thumb1 {
        position:initial;
        margin-bottom: 40px;
        margin-left: 30px;
        margin-right: 30px
    }

    .contact-thumb1 img {
        width: 100%
    }
}

.contact-wrap1 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 24px;
    margin-left: -285px
}

.contact-wrap1 .contact-form-wrap {
    background: var(--white-color);
    box-shadow: 0px 6px 50px 0px rgba(0,0,0,0.07);
    padding: 30px
}

.contact-wrap1 .contact-form-wrap textarea.form-control,.contact-wrap1 .contact-form-wrap textarea {
    min-height: 100px
}

.contact-wrap1 .newsletter-card {
    padding: 50px 30px;
    min-width: 287px
}

.contact-wrap1 .newsletter-card .title-wrap {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 10px;
    margin-bottom: 22px
}

.contact-wrap1 .newsletter-card .title-wrap .sub-title {
    margin: 0;
    color: var(--theme-color);
    font-size: 14px;
    font-weight: 600;
    letter-spacing: 4.2px;
    text-transform: uppercase;
    margin-top: -0.4em;
    margin-bottom: 5px;
    display: block
}

.contact-wrap1 .newsletter-card .title-wrap .title {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 0
}

.contact-wrap1 .newsletter-card .content {
    color: #B2B2B2;
    margin-bottom: 16px
}

.contact-wrap1 .newsletter-card .newsletter-form input {
    height: 56px;
    background: #3D4250;
    color: #B2B2B2
}

.contact-wrap1 .newsletter-card .newsletter-form input::-webkit-input-placeholder {
    color: #B2B2B2
}

.contact-wrap1 .newsletter-card .newsletter-form input::-moz-placeholder {
    color: #B2B2B2
}

.contact-wrap1 .newsletter-card .newsletter-form input:-ms-input-placeholder {
    color: #B2B2B2
}

.contact-wrap1 .newsletter-card .newsletter-form input::-ms-input-placeholder {
    color: #B2B2B2
}

.contact-wrap1 .newsletter-card .newsletter-form input::placeholder {
    color: #B2B2B2
}

.contact-wrap1 .newsletter-card .contact-feature {
    background: #252A37;
    box-shadow: none;
    border: 0;
    border-radius: 0;
    padding: 0;
    gap: 15px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.contact-wrap1 .newsletter-card .contact-feature .contact-feature-icon {
    background: var(--theme-color);
    color: var(--white-color);
    border-radius: 0;
    font-size: 24px
}

.contact-wrap1 .newsletter-card .contact-feature .contact-feature_label {
    color: #B2B2B2;
    font-size: 14px;
    font-weight: 400;
    font-family: var(--body-font)
}

.contact-wrap1 .newsletter-card .contact-feature .contact-feature_link {
    color: var(--white-color);
    font-size: 18px;
    font-weight: 600
}

@media (max-width: 1199px) {
    .contact-wrap1 {
        margin-left:0
    }

    .contact-wrap1 .contact-form-wrap {
        margin-top: 0
    }
}

@media (max-width: 991px) {
    .contact-wrap1 {
        display:block
    }

    .contact-wrap1 .contact-form-wrap {
        margin-bottom: 20px
    }

    .contact-wrap1 .newsletter-form {
        -webkit-flex-wrap: nowrap;
        -ms-flex-wrap: nowrap;
        flex-wrap: nowrap;
        gap: 0
    }
}

@media (max-width: 375px) {
    .contact-wrap1 .contact-feature {
        display:-webkit-box;
        display: -webkit-flex;
        display: -ms-flexbox;
        display: flex
    }

    .contact-wrap1 .contact-feature .contact-feature-icon {
        margin-bottom: 0
    }
}

.contact-wrap2 {
    background: var(--white-color);
    box-shadow: 0px 6px 35px 0px rgba(0,0,0,0.06);
    margin-top: 80px;
    z-index: 1;
    position: relative
}

.contact-wrap2 .contact-form-wrap {
    padding: 60px
}

@media (max-width: 767px) {
    .contact-wrap2 .contact-form-wrap {
        padding:40px
    }
}

@media (max-width: 375px) {
    .contact-wrap2 .contact-form-wrap {
        padding:30px
    }
}

.contact-map {
    line-height: 0.01px;
    margin-top: -200px
}

.contact-map iframe {
    width: 100%;
    height: 700px;
    -webkit-filter: grayscale(100) brightness(0.8);
    filter: grayscale(100) brightness(0.8)
}

@media (max-width: 1399px) {
    .contact-map {
        margin-top:-100px
    }

    .contact-map iframe {
        height: 450px
    }
}

.border-title {
    position: relative;
    padding-bottom: 14px;
    margin-bottom: 25px;
    margin-top: -0.22em;
    font-weight: 600
}

.border-title:before {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    height: 3px;
    width: 80px;
    background-color: var(--theme-color)
}

.contact-info {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    max-width: 340px;
    gap: 25px;
    margin-bottom: 40px
}

.contact-info:last-of-type {
    margin-bottom: 0
}

.contact-info_icon {
    width: 70px;
    height: 70px;
    line-height: 70px;
    font-size: 30px;
    background-color: rgba(13,94,244,0.07);
    text-align: center;
    color: var(--theme-color);
    border-radius: 5px;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.contact-info_title {
    font-size: 20px;
    margin-bottom: 6px;
    margin-top: -0.2em
}

.contact-info p,.contact-info a,.contact-info span {
    font-family: var(--title-font);
    margin-bottom: -0.5em
}

.contact-info_text {
    margin-bottom: -0.45em;
    line-height: 1.5;
    display: block;
    max-width: -webkit-fit-content;
    max-width: -moz-fit-content;
    max-width: fit-content;
    font-family: var(--title-font)
}

.contact-info_text p,.contact-info_text a,.contact-info_text span {
    font-family: var(--title-font)
}

.contact-info_text a {
    color: var(--title-color)
}

.contact-info_text a:hover {
    color: var(--theme-color)
}

.contact-info:hover .contact-info_icon {
    background-color: var(--theme-color);
    color: var(--white-color)
}

@media (max-width: 767px) {
    .map-contact {
        padding:40px 40px
    }

    .contact-info {
        margin-bottom: 30px
    }

    .contact-info:last-of-type {
        margin-bottom: 0
    }
}

@media (max-width: 575px) {
    .map-contact {
        padding:40px 20px
    }
}

@media (max-width: 375px) {
    .contact-info {
        -webkit-box-orient:vertical;
        -webkit-box-direction: normal;
        -webkit-flex-direction: column;
        -ms-flex-direction: column;
        flex-direction: column;
        -webkit-box-align: start;
        -webkit-align-items: flex-start;
        -ms-flex-align: start;
        align-items: flex-start;
        gap: 20px
    }

    .contact-info .media-body {
        width: 100%
    }
}

.contact-form-wrap {
    padding: 40px;
    position: relative;
    z-index: 9
}

.contact-form-wrap .subtitle {
    font-size: 18px
}

@media (max-width: 1199px) {
    .contact-form-wrap {
        margin:0;
        margin-top: 40px
    }
}

@media (max-width: 767px) {
    .contact-form-wrap {
        padding:40px 30px;
        background-position: left center
    }
}

.contact-feature {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 25px;
    border-radius: 0px;
    border: 1px solid #ECF1F9;
    background: var(--white-color);
    box-shadow: 0px 9px 14px 0px #978a8a;
    padding: 30px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.contact-feature:not(:last-child) {
    margin-bottom: 24px
}

.contact-feature .contact-feature-icon {
    height: 70px;
    width: 70px;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    border-radius: 0px;
    line-height: 70px;
    background: #F4F4F4;
    font-size: 40px;
    text-align: center;
    color: var(--theme-color);
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.contact-feature .media-body {
    margin-bottom: -0.4em
}

.contact-feature .contact-feature_label {
    font-size: 20px;
    font-family: var(--title-font);
    color: var(--title-color);
    font-weight: 600;
    margin-top: -0.4em;
    margin-bottom: 0px
}

.contact-feature .contact-feature_link {
    font-family: var(--body-font);
    color: #4D5765;
    line-height: 24px;
    font-size: 14px;
    display: block
}

.contact-feature .contact-feature_link span {
    color: var(--title-color)
}

.contact-feature:hover .contact-feature-icon {
    background: var(--theme-color);
    color: var(--white-color)
}

@media (max-width: 375px) {
    .contact-feature {
        display:block
    }

    .contact-feature .contact-feature-icon {
        margin-bottom: 20px
    }
}

.contact-wrap3 {
    border-top: 5px solid var(--theme-color);
    background-color: var(--white-color);
    box-shadow: 0px 10px 50px rgba(7,36,95,0.1)
}

.contact-wrap3 .contact-form-wrap {
    margin-top: 0
}

.contact-wrap3 .form-title {
    margin-top: -0.26em;
    margin-bottom: 26px
}

.contact-wrap3.style2 {
    padding: 30px;
    border-top: none
}

@media (max-width: 375px) {
    .contact-wrap3.style2 {
        padding:30px 15px
    }
}

.call-btn {
    color: var(--theme-color);
    font-size: 30px;
    font-weight: bold;
    font-family: var(--title-font);
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.call-btn .play-btn {
    --icon-size: 45px;
    font-size: 14px;
    margin-right: 15px
}

.call-btn .play-btn>i {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.call-btn .play-btn:after,.call-btn .play-btn:before {
    background-color: var(--theme-color)
}

.call-btn .fa-phone {
    font-size: 22px
}

.call-btn .btn-title {
    font-size: 18px;
    margin-bottom: 2px;
    font-weight: bold
}

.call-btn .btn-text {
    font-size: 22px
}

.call-btn.style2 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 10px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.call-btn.style3 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.call-btn.style3 .btn-title {
    font-size: 16px;
    font-weight: 500;
    color: var(--white-color);
    margin-bottom: 0px
}

.call-btn.style3 .btn-text {
    font-size: 20px;
    color: var(--white-color)
}

.call-btn.style3 .play-btn>i {
    background-color: var(--white-color);
    color: var(--theme-color)
}

.call-btn.style3 .play-btn:after,.call-btn.style3 .play-btn:before {
    background-color: var(--white-color)
}

.call-btn:hover .icon-btn {
    background-color: var(--title-color)
}

.call-btn:hover .play-btn>i {
    background-color: var(--title-color)
}

.call-btn:hover .play-btn:after,.call-btn:hover .play-btn:before {
    background-color: var(--title-color)
}

@media (max-width: 767px) {
    .call-btn {
        font-size:24px
    }
}

@media (max-width: 1500px) {
    .contact-4-fan-anime {
        display:none
    }
}

.contact-wrap4 .box-wrap1 {
    padding: 30px 22px 30px 30px;
    height: 100%
}

@media (max-width: 1199px) {
    .contact-wrap4 .contact-form-wrap {
        margin-top:0
    }
}

.img-box1 {
    position: relative;
    margin-right: 12px;
    padding-bottom: 22px
}

.img-box1 .img2 {
    position: absolute;
    right: 0;
    bottom: 0;
    border: 10px solid var(--white-color);
    z-index: 1
}

@media (max-width: 375px) {
    .img-box1 .img2 {
        position:relative;
        margin-top: 20px
    }

    .img-box1 .img2 img {
        width: 100%
    }
}

@media (max-width: 1399px) {
    .img-box1 {
        margin-right:0;
        padding-right: 177px
    }
}

@media (max-width: 1299px) {
    .img-box1 {
        padding-right:255px;
        padding-bottom: 96px
    }
}

@media (max-width: 1199px) {
    .img-box1 {
        display:inline-block;
        padding-bottom: 20px;
        margin-bottom: 50px
    }
}

@media (max-width: 767px) {
    .img-box1 {
        padding-bottom:154px
    }
}

@media (max-width: 575px) {
    .img-box1 {
        padding-bottom:193px;
        padding-right: 220px
    }
}

@media (max-width: 375px) {
    .img-box1 {
        padding-right:0;
        padding-bottom: 0
    }
}

.about-grid {
    position: absolute;
    top: 0px;
    right: 10px;
    text-align: center;
    z-index: 2;
    overflow: hidden;
    background: var(--theme-color);
    padding: 75px 31.5px
}

.about-grid_year {
    font-size: 74px;
    font-weight: 800;
    color: var(--white-color);
    margin-bottom: -2px;
    margin-top: -0.23em
}

@media (max-width: 575px) {
    .about-grid_year {
        font-size:50px
    }
}

.about-grid_text {
    color: var(--white-color);
    font-size: 18px;
    font-weight: 600;
    font-family: var(--title-font);
    line-height: 28px;
    max-width: 152px;
    margin: 0;
    margin-bottom: -0.4em
}

@media (max-width: 575px) {
    .about-grid_text {
        font-size:16px;
        line-height: inherit
    }
}

@media (max-width: 375px) {
    .about-grid_text {
        margin:auto
    }
}

.about-grid_img img {
    border-radius: 10px
}

@media (max-width: 575px) {
    .about-grid {
        padding:45px 21.5px
    }
}

@media (max-width: 375px) {
    .about-grid {
        position:relative;
        margin-top: 20px;
        right: 0
    }
}

.about-grid2 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 20px
}

.about-grid2 ~ .about-grid2 {
    border-top: 1px solid var(--border-color);
    margin-top: 30px;
    padding-top: 30px
}

.about-grid2 .icon {
    height: 80px;
    width: 80px;
    line-height: 80px;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    text-align: center;
    background: rgba(255,94,20,0.1)
}

.about-grid2 .icon img {
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.about-grid2 .about-grid_title {
    margin-bottom: 5px;
    text-transform: uppercase;
    margin-top: -0.3em
}

.about-grid2 p {
    margin-bottom: -0.4em;
    max-width: 434px
}

.about-grid2:hover .icon img {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

@media (max-width: 575px) {
    .about-grid2 {
        display:block
    }

    .about-grid2 .icon {
        margin-bottom: 20px
    }
}

@media (max-width: 1500px) {
    .about-shape1 {
        left:0px !important
    }
}

@media (max-width: 375px) {
    .about-shape1 {
        display:none
    }
}

.about-content {
    padding-bottom: 40px;
    padding-left: 56px;
    padding-top: 40px
}

.about-profile {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 10px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.about-profile .avater {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    border-radius: 10px;
    overflow: hidden
}

.about-profile .about-profile-name {
    font-size: 20px;
    font-weight: 600;
    font-style: italic;
    margin-bottom: 0
}

.about-profile .desig {
    font-size: 14px;
    color: var(--theme-color);
    margin-bottom: 0
}

.about-grid-wrap {
    background: var(--smoke-color);
    padding: 20px;
    border-radius: 10px
}

@media (max-width: 767px) {
    .about-grid-wrap {
        padding:20px 20px 30px
    }
}

.about-4-bg-thumb1 {
    width: 45%;
    position: absolute;
    left: 0;
    top: 66px
}

@media (max-width: 1500px) {
    .about-4-bg-thumb1 {
        top:120px !important
    }
}

@media (max-width: 991px) {
    .about-4-bg-thumb1 {
        position:initial;
        width: auto;
        margin-right: 20px;
        margin-bottom: 20px
    }
}

.img-box4 {
    display: inline-block;
    padding-right: 128px;
    padding-bottom: 100px;
    padding-top: 24px;
    margin-right: 5px
}

.img-box4 .img2 {
    border: 10px solid var(--white-color);
    position: absolute;
    right: 0;
    bottom: -10px
}

.img-box4 .play-btn {
    position: absolute;
    right: 50%;
    bottom: 50%;
    -webkit-transform: translate(-25%, -25%);
    -ms-transform: translate(-25%, -25%);
    transform: translate(-25%, -25%)
}

@media (max-width: 1399px) {
    .img-box4 {
        margin-right:35px
    }
}

@media (max-width: 1299px) {
    .img-box4 {
        margin-right:0;
        padding-bottom: 114px
    }
}

@media (max-width: 1199px) {
    .img-box4 {
        padding-top:0
    }

    .img-box4 .shape1 {
        left: 0 !important
    }
}

@media (max-width: 767px) {
    .img-box4 .play-btn {
        -webkit-transform:translate(-70%, -50%);
        -ms-transform: translate(-70%, -50%);
        transform: translate(-70%, -50%)
    }
}

@media (max-width: 575px) {
    .img-box4 {
        padding-right:68px;
        padding-bottom: 214px
    }

    .img-box4 .play-btn {
        -webkit-transform: translate(-140%, -20%);
        -ms-transform: translate(-140%, -20%);
        transform: translate(-140%, -20%)
    }
}

@media (max-width: 375px) {
    .img-box4 {
        padding:0
    }

    .img-box4 .img2 {
        position: initial;
        margin-top: 20px;
        border: 0
    }

    .img-box4 .play-btn {
        -webkit-transform: none;
        -ms-transform: none;
        transform: none;
        bottom: auto;
        top: 20%;
        right: 40%
    }
}

.img-box5 {
    position: relative;
    display: inline-block
}

.img-box5 .play-btn {
    position: absolute;
    right: 50%;
    bottom: 50%;
    -webkit-transform: translate(80%, 90%);
    -ms-transform: translate(80%, 90%);
    transform: translate(80%, 90%)
}

.about-grid-wrap2 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 50px;
    padding-top: 28px;
    margin-bottom: -1.1em
}

@media (max-width: 767px) {
    .about-grid-wrap2 {
        -webkit-flex-wrap:wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }
}

.about-grid3 {
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    gap: 10px;
    position: relative
}

.about-grid3:after {
    content: '';
    position: absolute;
    left: 0;
    bottom: 15px;
    height: 80px;
    width: 38px;
    background: #FFEACB;
    z-index: -1;
    -webkit-clip-path: polygon(0 0, 100% 40%, 100% 100%, 0% 100%);
    clip-path: polygon(0 0, 100% 40%, 100% 100%, 0% 100%)
}

.about-grid3 .about-grid_year {
    color: var(--title-color);
    font-size: 64px;
    font-weight: 600;
    padding-left: 14px
}

.about-grid3 .about-grid_text {
    font-size: 16px;
    font-weight: 400;
    color: var(--body-color);
    max-width: 100px
}

.img-box7 {
    position: relative;
    margin-top: 40px;
    z-index: 3;
    margin-left: 0
}

.img-box7>img {
    max-width: -webkit-fit-content;
    max-width: -moz-fit-content;
    max-width: fit-content
}

.img-box7 .shape {
    position: absolute;
    left: -55px;
    bottom: 33px;
    width: 100%;
    height: 100%
}

.img-box7 .about-counter1 {
    right: 25px;
    position: absolute;
    top: 0;
    z-index: 4
}

.img-box7 .img1,.img-box7 .img2 {
    z-index: 3
}

.img-box7 .img1 img,.img-box7 .img2 img {
    border-radius: 10px
}

.img-box7 .img1 {
    -webkit-transform: translateY(-40px);
    -ms-transform: translateY(-40px);
    transform: translateY(-40px);
    padding-bottom: 178px
}

.img-box7 .img2 {
    position: absolute;
    bottom: 0;
    right: 0
}

.img-box7 .shape {
    z-index: -1;
    left: -80px
}

.about-counter1 {
    width: 240px;
    height: 240px;
    background-color: var(--theme-color);
    border-radius: 999px;
    border: 20px solid var(--white-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center
}

.about-counter1 .counter-title {
    font-size: 64px;
    color: var(--white-color);
    margin-bottom: 8px;
    line-height: 1
}

.about-counter1 .counter-text {
    font-weight: 500;
    color: var(--white-color)
}

.signature-box {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 20px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.signature-box-wrap {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 15px;
    max-width: 500px
}

.signature-box .avater img {
    border-radius: 999px;
    width: 55px
}

.signature-box .content {
    text-align: center
}

.signature-box .desig {
    font-size: 14px;
    font-weight: 500;
    border-top: 1px solid var(--border-color);
    margin-top: 4px;
    display: block
}

.about-bg-shape {
    position: relative;
    padding: 30px 0
}

.about-bg-shape .shape {
    position: absolute;
    top: 0;
    left: -100%;
    height: 100%;
    width: 100%;
    z-index: -1
}

.about-bg-shape .shape img {
    object-fit: cover;
    height: 100%;
    max-width: -webkit-fit-content;
    max-width: -moz-fit-content;
    max-width: fit-content;
    background-color: #F8F8F8
}

.arrow-list-wrap {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 30px;
    margin-bottom: 30px;
    padding-bottom: 30px;
    border-bottom: 1px solid var(--border-color)
}

@media (max-width: 767px) {
    .arrow-list-wrap {
        -webkit-flex-wrap:wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }
}

.arrow-list-wrap .th-video {
    padding: 0
}

.arrow-list ul {
    padding-left: 0;
    list-style: none;
    text-align: left;
    margin-bottom: 0
}

.arrow-list li {
    color: var(--title-color);
    margin-bottom: 10px;
    position: relative;
    padding-left: 28px
}

.arrow-list li:before {
    content: "\f178";
    font-family: var(--icon-font);
    font-weight: 600;
    color: var(--theme-color);
    position: absolute;
    left: 0;
    -webkit-transition: 0.3s ease-in-out;
    transition: 0.3s ease-in-out
}

.arrow-list li:last-child {
    margin-bottom: 0
}

@media (max-width: 1399px) {
    .about-bg-shape .shape {
        left:-350px
    }

    .about-bg-shape .shape img {
        max-width: calc(100% + 370px)
    }
}

@media (max-width: 1199px) {
    .img-box7 {
        display:inline-block;
        margin-left: 0;
        margin-bottom: 40px;
        padding-right: 120px
    }

    .img-box7>img {
        max-width: 100%
    }

    .img-box7 .shape {
        left: -40px
    }

    .img-box7 .about-counter1 {
        right: 0
    }

    .about-bg-shape {
        padding: 30px
    }

    .about-bg-shape .shape {
        left: 0
    }

    .about-bg-shape .shape img {
        max-width: 100%
    }
}

@media (max-width: 767px) {
    .about-counter1 {
        width:160px;
        height: 160px;
        border: 10px solid var(--white-color)
    }

    .about-counter1 .counter-title {
        font-size: 42px;
        margin-bottom: 5px
    }

    .about-counter1 .counter-text {
        font-size: 14px
    }
}

@media (max-width: 575px) {
    .img-box7 {
        padding-right:0
    }

    .img-box7 .img1 {
        padding-bottom: 0
    }

    .img-box7 .img2 {
        position: inherit
    }

    .img-box7 .shape {
        left: 0;
        bottom: 20px
    }

    .img-box7 .about-counter1 {
        right: 30px
    }
}

@media (max-width: 375px) {
    .about-bg-shape {
        padding:15px 15px
    }
}

.img-box8 {
    position: relative
}

.img-box8 .img1 img {
    width: 100%
}

.img-box8 .about-counter2 {
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%)
}

.about-counter2 {
    background-color: var(--white-color);
    border-radius: 999px;
    width: 250px;
    height: 250px;
    text-align: center;
    padding: 80px 10px;
    background-position: 4px 4px;
    background-size: calc(100% - 8px) calc(100% - 8px)
}

.about-counter2 .counter-title {
    color: var(--theme-color);
    font-size: 64px;
    margin-bottom: 0
}

.about-counter2 .counter-text {
    color: var(--title-color);
    font-weight: 500
}

.list-collumn2 {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    border-bottom: 1px solid var(--border-color);
    padding-bottom: 25px;
    margin-bottom: 30px;
    gap: 4px
}

.video-btn.style2 {
    font-size: 16px
}

.video-btn.style2 .play-btn {
    --icon-size: 45px;
    font-size: 14px;
    margin-right: 15px
}

.video-btn.style2 .play-btn>i {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.video-btn.style2 .play-btn:after,.video-btn.style2 .play-btn:before {
    background-color: var(--theme-color)
}

.video-btn.style2 .btn-text {
    font-weight: 600;
    display: inline-block;
    position: relative;
    color: var(--title-color);
    line-height: 1.2;
    border-bottom: 2px solid;
    -webkit-transition: 0.3s ease-in-out;
    transition: 0.3s ease-in-out
}

.video-btn.style2:hover .btn-text {
    color: var(--theme-color)
}

.video-btn.style2:hover .play-btn>i {
    background-color: var(--title-color)
}

.video-btn.style2:hover .play-btn:after,.video-btn.style2:hover .play-btn:before {
    background-color: var(--title-color)
}

@media (max-width: 1199px) {
    .img-box8 {
        margin-bottom:40px
    }
}

@media (max-width: 575px) {
    .list-collumn2 {
        grid-template-columns:repeat(1, 1fr);
        gap: 30px
    }

    .about-counter2 {
        width: 180px;
        height: 180px;
        padding: 50px 10px;
        background-position: 3px 3px;
        background-size: calc(100% - 6px) calc(100% - 6px)
    }

    .about-counter2 .counter-title {
        font-size: 44px
    }
}

.img-box9 {
    position: relative;
    margin-left: -70px;
    margin-top: 40px
}

.img-box9>img {
    max-width: -webkit-fit-content;
    max-width: -moz-fit-content;
    max-width: fit-content
}

.img-box9 .shape {
    position: absolute;
    left: -55px;
    bottom: 33px;
    width: 100%;
    height: 100%
}

.img-box9 .about-counter1 {
    position: absolute;
    top: 0;
    right: -35px;
    z-index: 4
}

@media (max-width: 1199px) {
    .img-box9 {
        display:inline-block;
        margin-left: 0;
        margin-bottom: 40px
    }

    .img-box9>img {
        max-width: 100%
    }

    .img-box9 .shape {
        left: -40px
    }

    .img-box9 .about-counter1 {
        right: 0
    }
}

@media (max-width: 575px) {
    .img-box9 {
        margin-top:20px
    }

    .img-box9 .shape {
        left: 0;
        bottom: 20px
    }
}

@media (max-width: 1500px) {
    .about-10-fan-anime {
        width:200px
    }
}

@media (max-width: 991px) {
    .about-10-fan-anime {
        width:160px
    }
}

@media (max-width: 767px) {
    .about-10-fan-anime {
        width:120px
    }
}

.img-box11 {
    position: relative;
    z-index: 2
}

.img-box11 .img1 {
    padding-top: 30px;
    padding-bottom: 135px
}

.img-box11 .img2 {
    border: 10px solid #FFFFFF;
    display: inline-block;
    position: absolute;
    bottom: 0;
    right: 0;
    -webkit-animation: moving 8s linear infinite;
    animation: moving 8s linear infinite
}

.img-box11 .shape1 {
    position: absolute;
    top: 0;
    right: 15%;
    z-index: -1;
    -webkit-animation: jumpReverseAni 7s linear infinite;
    animation: jumpReverseAni 7s linear infinite
}

.img-box11 .shape2 {
    position: absolute;
    bottom: 55px;
    left: -40px;
    z-index: -1;
    -webkit-animation: movingX 8s linear infinite;
    animation: movingX 8s linear infinite
}

.about-feature {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 20px;
    margin-top: -0.2em;
    margin-bottom: 30px;
    padding-right: 45px
}

.about-feature_icon {
    width: 80px;
    height: 80px;
    line-height: 80px;
    min-width: 80px;
    background-color: rgba(255,76,19,0.1);
    border-radius: 5px;
    text-align: center
}

.about-feature_title {
    font-size: 20px;
    margin-bottom: 9px
}

.about-feature_text {
    margin-bottom: -0.1em;
    line-height: 26px
}

@media (max-width: 1199px) {
    .img-box11 .img1 {
        padding-top:0
    }
}

@media (max-width: 991px) {
    .img-box11 {
        margin-bottom:30px
    }

    .img-box11 .img1 {
        padding-bottom: 100px
    }
}

@media (max-width: 575px) {
    .about-feature {
        padding-right:0
    }

    .img-box11 .img2 {
        max-width: 70%
    }
}

@media (max-width: 375px) {
    .about-feature {
        -webkit-flex-wrap:wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }
}

.growth-chart {
    box-shadow: 0px 10px 30px rgba(7,36,95,0.08);
    width: 100%
}

.growth-chart img {
    width: 100%
}

.bg-half-right {
    position: absolute;
    top: 0;
    right: 0;
    width: 48%;
    height: 100%;
    background-size: auto;
    background-repeat: repeat
}

.quote-style1 {
    color: var(--title-color);
    font-weight: 600;
    line-height: 28px;
    position: relative;
    padding-left: 15px;
    margin-bottom: 25px
}

.quote-style1::before {
    content: '';
    width: 3px;
    height: calc(100% - 14px);
    position: absolute;
    left: 0;
    top: 7px;
    background-color: var(--theme-color)
}

@media (max-width: 1199px) {
    .bg-half-right {
        width:100%;
        height: 40%
    }
}

.img-box13 {
    margin-right: 56px;
    margin-left: -74px
}

.achive-feature {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 20px;
    max-width: 280px
}

.achive-feature-wrap {
    display: grid;
    grid-template-columns: auto auto;
    gap: 20px;
    margin-bottom: 40px
}

.achive-feature_icon {
    width: 70px;
    height: 70px;
    line-height: 70px;
    min-width: 70px;
    background-color: rgba(255,76,19,0.1);
    border-radius: 20px;
    text-align: center
}

.achive-feature_title {
    font-size: 20px;
    line-height: 30px;
    margin-bottom: 0
}

.about-quote {
    padding: 20px 110px 20px 40px;
    border-radius: 10px;
    background-color: #F8F8F8;
    margin: 0;
    max-width: 710px
}

.about-quote:before {
    color: rgba(255,76,19,0.2);
    font-size: 40px;
    bottom: 28px;
    line-height: 1
}

.about-quote p {
    margin-top: 0
}

.about-quote p:last-of-type {
    margin-bottom: 0
}

@media (max-width: 1300px) {
    .img-box13 {
        margin-right:20px;
        margin-left: -64px
    }
}

@media (max-width: 1199px) {
    .img-box13 {
        margin:0 0 30px 0;
        text-align: center
    }
}

@media (max-width: 575px) {
    .achive-feature-wrap {
        grid-template-columns:auto
    }

    .about-quote {
        padding: 20px 50px 20px 20px;
        font-size: 16px
    }

    .about-quote:before {
        right: 20px;
        bottom: 20px
    }
}

.team-area {
    padding-bottom: 365px
}

.team-area:before {
    opacity: 0.95;
    z-index: -1
}

@media (max-width: 991px) {
    .team-area {
        padding-bottom:calc(365px - 40px)
    }
}

.team-card {
    position: relative;
    overflow: hidden
}

.team-card .team-img-wrap {
    border: 1px solid var(--body-color);
    padding: 15px;
    position: relative;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.team-card .team-img {
    overflow: hidden;
    position: relative
}

.team-card .team-img:after {
    content: '';
    position: absolute;
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
    opacity: 0;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    background: rgba(14,18,29,0.4)
}

.team-card .team-img img {
    width: 100%;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.team-card .th-social {
    position: absolute;
    bottom: 35px;
    left: 50%;
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
    transform: translate(-50%, 0);
    -webkit-transition: 0.4s;
    transition: 0.4s;
    width: -webkit-max-content;
    width: -moz-max-content;
    width: max-content
}

.team-card .th-social a {
    opacity: 0;
    -webkit-transform: translateY(20px);
    -ms-transform: translateY(20px);
    transform: translateY(20px);
    -webkit-transition: 0.3s;
    transition: 0.3s
}

.team-card .th-social a:nth-child(1) {
    -webkit-transition-delay: 0s;
    transition-delay: 0s
}

.team-card .th-social a:nth-child(2) {
    -webkit-transition-delay: 0.1s;
    transition-delay: 0.1s
}

.team-card .th-social a:nth-child(3) {
    -webkit-transition-delay: 0.2s;
    transition-delay: 0.2s
}

.team-card .th-social a:nth-child(4) {
    -webkit-transition-delay: 0.3s;
    transition-delay: 0.3s
}

.team-card .team-title {
    margin-bottom: 2px
}

.team-card .team-title a {
    color: var(--white-color)
}

.team-card .team-title a:hover {
    color: var(--theme-color)
}

.team-card .team-desig {
    color: var(--theme-color);
    display: block;
    font-size: 16px;
    font-weight: 400;
    margin-bottom: -0.3em
}

.team-card .team-content {
    padding: 30px 30px 0px 30px;
    text-align: center
}

.team-card:hover .team-img-wrap {
    border-color: var(--theme-color)
}

.team-card:hover .team-img img {
    -webkit-transform: scale(1.08);
    -ms-transform: scale(1.08);
    transform: scale(1.08)
}

.team-card:hover .team-img:after {
    opacity: 1
}

.team-card:hover .th-social a {
    opacity: 1;
    -webkit-transform: translateY(0px);
    -ms-transform: translateY(0px);
    transform: translateY(0px)
}

.team-card.style2 {
    background: var(--white-color);
    box-shadow: 0px 10px 20px 0px rgba(0,0,0,0.05)
}

.team-card.style2 .team-content {
    padding: 20px;
    position: relative;
    text-align: start
}

.team-card.style2 .box-title {
    margin-bottom: 0
}

.team-card.style2 .box-title a {
    color: var(--title-color)
}

.team-card.style2 .box-title a:hover {
    color: var(--theme-color)
}

@media (max-width: 767px) {
    .team-card.style2 .box-title {
        font-size:22px
    }
}

.team-card.style2 .team-social {
    position: absolute;
    right: 20px;
    top: 20px
}

.team-card.style2 .team-social .th-social {
    opacity: 0;
    visibility: hidden;
    bottom: 20px
}

.team-card.style2 .team-social .th-social a {
    display: block;
    margin: 0 0 10px 0;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    box-shadow: 0px 10px 20px 0px rgba(0,0,0,0.05)
}

.team-card.style2 .team-social .icon-btn {
    --btn-size: 40px;
    background: var(--theme-color);
    color: var(--white-color);
    cursor: pointer
}

.team-card.style2 .team-social:hover .icon-btn {
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg)
}

.team-card.style2 .team-social:hover .th-social {
    opacity: 1;
    visibility: visible;
    bottom: 40px
}

.team-card.style2 {
    background: var(--white-color);
    box-shadow: 0px 10px 20px 0px rgba(0,0,0,0.05)
}

.team-card.style2 .team-content {
    padding: 20px;
    position: relative;
    text-align: start
}

.team-card.style2 .box-title {
    margin-bottom: 0
}

.team-card.style2 .box-title a {
    color: var(--title-color)
}

.team-card.style2 .box-title a:hover {
    color: var(--theme-color)
}

@media (max-width: 767px) {
    .team-card.style2 .box-title {
        font-size:22px
    }
}

.team-card.style2 .team-social {
    position: absolute;
    right: 20px;
    top: 20px
}

.team-card.style2 .team-social .th-social {
    opacity: 0;
    visibility: hidden;
    bottom: 20px
}

.team-card.style2 .team-social .th-social a {
    display: block;
    margin: 0 0 10px 0;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    box-shadow: 0px 10px 20px 0px rgba(0,0,0,0.05)
}

.team-card.style2 .team-social .icon-btn {
    --btn-size: 40px;
    background: var(--theme-color);
    color: var(--white-color);
    cursor: pointer
}

.team-card.style2 .team-social:hover .icon-btn {
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg)
}

.team-card.style2 .team-social:hover .th-social {
    opacity: 1;
    visibility: visible;
    bottom: 40px
}

.team-card.style3 {
    border-radius: 10px;
    background: var(--white-color);
    box-shadow: 0px 10px 20px 0px rgba(0,0,0,0.05)
}

.team-card.style3 .team-img img {
    -webkit-transform: none;
    -ms-transform: none;
    transform: none
}

.team-card.style3 .team-img:after {
    display: none
}

.team-card.style3 .team-content {
    position: absolute;
    bottom: 0;
    text-align: start;
    padding: 30px;
    background: #fff;
    border-radius: 0 100px
}

@media (max-width: 1299px) {
    .team-card.style3 .team-content {
        padding:23px
    }
}

.team-card.style3 .box-title {
    margin-bottom: 2px
}

@media (max-width: 1299px) {
    .team-card.style3 .box-title {
        font-size:22px
    }
}

.team-card.style3 .th-social {
    position: initial;
    -webkit-transform: none;
    -ms-transform: none;
    transform: none;
    margin-top: 15px
}

.team-card.style3 .th-social a {
    opacity: 1;
    -webkit-transform: none;
    -ms-transform: none;
    transform: none;
    background: var(--smoke-color);
    -webkit-transition: 0.4s;
    transition: 0.4s;
    --icon-size: 40px
}

.team-card.style3 .th-social a:hover {
    background: var(--theme-color)
}

.team-card.style4 .team-content {
    text-align: start;
    padding: 30px 0 0 0;
    position: relative
}

.team-card.style4 .team-content .box-title {
    margin-bottom: 0
}

.team-card.style4 .team-content .team-social {
    position: absolute;
    right: 10px;
    top: 0;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%)
}

.team-card.style4 .team-content .team-social .icon-btn {
    background: var(--theme-color);
    color: var(--white-color);
    --btn-size: 40px
}

.team-card.style4 .team-content .team-social .th-social {
    bottom: 20px;
    opacity: 0;
    visibility: hidden
}

.team-card.style4 .team-content .team-social .th-social a {
    display: block;
    margin: 0;
    margin-bottom: 10px;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    --icon-size: 40px
}

.team-card.style4 .team-content .team-social:hover .icon-btn {
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg)
}

.team-card.style4 .team-content .team-social:hover .th-social {
    opacity: 1;
    visibility: visible;
    bottom: 40px
}

.team-tab {
    --body-color: #8993A1
}

.team-tab-title {
    color: var(--white-color);
    font-weight: 600;
    margin-bottom: 4px;
    margin-top: -0.2em
}

.team-tab-desig {
    color: var(--theme-color);
    margin-bottom: 26px;
    display: block
}

.team-tab-subtitle {
    color: var(--white-color);
    font-size: 20px;
    font-weight: 600;
    display: inline-block;
    border-bottom: 1px solid var(--theme-color);
    margin-top: 10px;
    padding-bottom: 8px;
    margin-bottom: 30px
}

.team-tab-wrap {
    list-style: none;
    margin: 0;
    padding: 0;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    margin-left: 68px
}

@media (max-width: 1299px) {
    .team-tab-wrap {
        margin-left:18px
    }
}

@media (max-width: 991px) {
    .team-tab-wrap {
        margin-left:0;
        margin-bottom: 40px
    }
}

.team-card.style5 .team-img-wrap {
    border: 0;
    padding: 0
}

.team-card.style5 .th-social a {
    --icon-size: 40px
}

.team-card.style5 .th-social a:not(:last-child) {
    margin-right: 7px
}

@media (max-width: 375px) {
    .team-card.style5 .th-social a {
        --icon-size: 30px;
        font-size: 14px
    }
}

.team-details-about-info .about-box {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between
}

.team-details-about-info .about-box .about-info .title {
    font-weight: 600;
    font-size: 36px;
    margin-bottom: 2px;
    margin-top: -0.2em
}

.team-details-about-info .about-box .about-info .desig {
    color: var(--body-color);
    margin-bottom: 25px;
    font-size: 14px
}

.team-details-about-info .about-contact-wrap .about-contact {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 20px 60px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.team-details-about-info .about-contact-wrap .about-contact:not(:last-child) {
    margin-bottom: 15px
}

.team-details-about-info .about-contact-wrap .about-contact .about-contact-title {
    font-size: 18px;
    font-weight: 600;
    min-width: 130px;
    margin-bottom: -0.2em
}

.team-details-about-info .about-contact-wrap .about-contact .about-contact-text {
    color: var(--body-color);
    font-weight: 400;
    margin-bottom: 0
}

@media (max-width: 375px) {
    .team-details-about-info .about-contact-wrap .about-contact {
        display:block
    }
}

@media (max-width: 1500px) {
    .team-details-thumb {
        height:100%
    }

    .team-details-thumb img {
        height: 100%;
        object-fit: cover
    }
}

@media (max-width: 991px) {
    .team-details-thumb {
        margin-bottom:40px;
        height: auto
    }
}

.th-team .play-btn {
    position: relative;
    z-index: 3;
    border: none;
    background-color: transparent;
    padding: 0
}

.th-team .play-btn>i {
    background-color: var(--theme-color);
    color: var(--white-color);
    --icon-size: 40px
}

.th-team .play-btn:before,.th-team .play-btn:after {
    background-color: var(--theme-color)
}

.th-team .play-btn:hover {
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg)
}

.th-team .th-social {
    position: absolute;
    width: 40px;
    bottom: 50px;
    right: 0
}

.th-team .th-social a {
    margin-right: 0;
    margin-bottom: 7px;
    background-color: var(--white-color);
    color: var(--theme-color);
    box-shadow: 0px 5px 18px rgba(76,88,104,0.06);
    visibility: hidden;
    opacity: 0;
    -webkit-transform: translateY(45px);
    -ms-transform: translateY(45px);
    transform: translateY(45px);
    -webkit-transition: 0.3s ease-in-out;
    transition: 0.3s ease-in-out
}

.th-team .th-social a:nth-child(1) {
    -webkit-transition-delay: 0s;
    transition-delay: 0s
}

.th-team .th-social a:nth-child(2) {
    -webkit-transition-delay: 0.1s;
    transition-delay: 0.1s
}

.th-team .th-social a:nth-child(3) {
    -webkit-transition-delay: 0.2s;
    transition-delay: 0.2s
}

.th-team .th-social a:nth-child(4) {
    -webkit-transition-delay: 0.3s;
    transition-delay: 0.3s
}

.th-team .th-social a:hover {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.th-team .team-social {
    position: absolute;
    top: -20px;
    right: 30px
}

.th-team .team-social:hover .th-social a {
    visibility: visible;
    opacity: 1;
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0)
}

.th-team .team-social:hover .th-social a:nth-child(4) {
    -webkit-transition-delay: 0s;
    transition-delay: 0s
}

.th-team .team-social:hover .th-social a:nth-child(3) {
    -webkit-transition-delay: 0.1s;
    transition-delay: 0.1s
}

.th-team .team-social:hover .th-social a:nth-child(2) {
    -webkit-transition-delay: 0.2s;
    transition-delay: 0.2s
}

.th-team .team-social:hover .th-social a:nth-child(1) {
    -webkit-transition-delay: 0.3s;
    transition-delay: 0.3s
}

.th-team:hover .team-img img {
    -webkit-transform: scale(1.08);
    -ms-transform: scale(1.08);
    transform: scale(1.08)
}

.team-grid {
    text-align: center
}

.team-grid .team-img {
    margin-bottom: 25px;
    background-color: var(--white-color);
    box-shadow: 0px 6px 15px rgba(14,18,29,0.08);
    border-radius: 999px;
    padding: 20px;
    position: relative;
    z-index: 2
}

.team-grid .team-img:before {
    content: '';
    height: 100%;
    width: 100%;
    position: absolute;
    top: 0;
    left: 0;
    border: 6px solid var(--theme-color);
    border-radius: inherit;
    -webkit-transform: scale(0.8);
    -ms-transform: scale(0.8);
    transform: scale(0.8);
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    z-index: -1
}

.team-grid .team-img img {
    border-radius: inherit;
    width: 100%;
    aspect-ratio: 16 / 16
}

.team-grid .team-title {
    margin-bottom: 0
}

.team-grid .team-desig {
    color: var(--theme-color);
    font-weight: 500;
    margin-bottom: -0.5em;
    display: block
}

.team-grid .team-social {
    top: unset;
    bottom: 35px;
    right: 35px
}

.team-grid:hover .team-img:before {
    -webkit-transform: scale(1);
    -ms-transform: scale(1);
    transform: scale(1)
}

.team-grid:hover .team-img img {
    -webkit-transform: none;
    -ms-transform: none;
    transform: none
}

@media (max-width: 575px) {
    .team-grid {
        max-width:320px;
        margin-left: auto;
        margin-right: auto
    }
}

.team-box {
    position: relative;
    max-width: 430px;
    margin: 0 auto;
    -webkit-filter: drop-shadow(4px 10px 7px rgba(7,36,95,0.05));
    filter: drop-shadow(4px 10px 7px rgba(7,36,95,0.05))
}

.team-box .team-img {
    overflow: hidden;
    position: relative;
    border-radius: 10px 10px 0 0;
    width: calc(100% - 78px)
}

.team-box .team-img img {
    width: 100%;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.team-box .team-content {
    text-align: center;
    width: calc(100% - 78px);
    padding: 35px 15px;
    border-radius: 0 0 0 10px;
    background-color: var(--white-color)
}

.team-box .team-title {
    font-size: 24px;
    margin-bottom: 4px;
    margin-top: -0.24em
}

.team-box .team-title a {
    color: inherit
}

.team-box .team-title a:hover {
    color: var(--theme-color)
}

.team-box .team-desig {
    display: block;
    margin-bottom: -0.45em
}

.team-box .team-social {
    top: unset;
    bottom: 0;
    right: 0;
    height: 100%;
    width: 78px
}

.team-box .team-social:after,.team-box .team-social:before {
    content: '';
    height: 190px;
    width: 100%;
    background-color: var(--white-color);
    border-radius: 0 10px 10px 0;
    position: absolute;
    bottom: 0;
    right: 0;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.team-box .team-social:before {
    -webkit-clip-path: polygon(0 0, 100% 35px, 100% 100%, 0% 100%);
    clip-path: polygon(0 0, 100% 35px, 100% 100%, 0% 100%)
}

.team-box .team-social:after {
    height: 0;
    bottom: 155px;
    background-color: var(--title-color);
    border-radius: 0 10px 0 0;
    z-index: -2
}

.team-box .team-social:hover:after {
    height: calc(100% - 155px)
}

.team-box .team-social:hover .play-btn {
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg)
}

.team-box .play-btn {
    position: absolute;
    top: unset;
    bottom: 150px;
    left: 50%;
    margin-left: -20px
}

.team-box .th-social {
    bottom: 200px;
    right: 50%;
    margin-right: -20px
}

.team-box:hover .team-img {
    border-radius: 10px 0 0 0
}

@media (max-width: 375px) {
    .team-box .team-img img {
        height:295px;
        object-fit: cover
    }

    .team-box .team-title {
        font-size: 20px;
        margin-bottom: 2px
    }
}

.team-card2 {
    position: relative
}

.team-card2 .team-img {
    overflow: hidden;
    border-radius: 10px 10px 0 0
}

.team-card2 .team-img img {
    width: 100%;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.team-card2 .team-title {
    font-size: 24px;
    margin-bottom: 4px;
    margin-top: -0.24em;
    -webkit-transition: 0.1s ease-in-out;
    transition: 0.1s ease-in-out
}

.team-card2 .team-title a {
    color: inherit
}

.team-card2 .team-title a:hover {
    color: var(--title-color)
}

.team-card2 .team-desig {
    color: var(--theme-color);
    display: block;
    font-family: var(--title-font);
    margin-bottom: -0.45em;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.team-card2 .team-content {
    border-radius: 0 0 10px 10px;
    background-color: var(--theme-color);
    text-align: center;
    padding: 40px 15px 40px 15px;
    box-shadow: 0px 10px 15px rgba(7,36,95,0.07);
    position: relative;
    z-index: 2
}

.team-card2 .team-content:before {
    content: '';
    width: 100%;
    height: 100%;
    background-color: var(--white-color);
    position: absolute;
    top: 0;
    left: 0;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    z-index: -1;
    border-radius: 0 0 9px 9px
}

.team-card2:hover .team-content:before {
    height: 0
}

.team-card2:hover .play-btn>i {
    background-color: var(--white-color);
    color: var(--theme-color)
}

.team-card2:hover .play-btn::before,.team-card2:hover .play-btn:after {
    background-color: var(--white-color)
}

.team-card2:hover .team-title {
    color: var(--white-color)
}

.team-card2:hover .team-desig {
    color: var(--white-color)
}

.team-card2.th-team .team-img {
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.team-card2.th-team .play-btn {
    position: relative;
    z-index: 3;
    border: none;
    background-color: transparent;
    padding: 0
}

.team-card2.th-team .play-btn>i {
    background-color: var(--theme-color);
    color: var(--white-color);
    --icon-size: 40px
}

.team-card2.th-team .play-btn:before,.team-card2.th-team .play-btn:after {
    background-color: var(--theme-color)
}

.team-card2.th-team .play-btn:hover {
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg)
}

.team-card2.th-team .th-social {
    position: absolute;
    width: 40px;
    bottom: 50px;
    right: 0
}

.team-card2.th-team .th-social a {
    margin-right: 0;
    margin-bottom: 7px;
    background-color: var(--white-color);
    color: var(--theme-color);
    box-shadow: 0px 5px 18px rgba(76,88,104,0.06);
    visibility: hidden;
    opacity: 0;
    -webkit-transform: translateY(45px);
    -ms-transform: translateY(45px);
    transform: translateY(45px);
    -webkit-transition: 0.3s ease-in-out;
    transition: 0.3s ease-in-out
}

.team-card2.th-team .th-social a:nth-child(1) {
    -webkit-transition-delay: 0s;
    transition-delay: 0s
}

.team-card2.th-team .th-social a:nth-child(2) {
    -webkit-transition-delay: 0.1s;
    transition-delay: 0.1s
}

.team-card2.th-team .th-social a:nth-child(3) {
    -webkit-transition-delay: 0.2s;
    transition-delay: 0.2s
}

.team-card2.th-team .th-social a:nth-child(4) {
    -webkit-transition-delay: 0.3s;
    transition-delay: 0.3s
}

.team-card2.th-team .th-social a:hover {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.team-card2.th-team .team-social {
    position: absolute;
    top: -20px;
    right: 30px
}

.team-card2.th-team .team-social:hover .as-social a {
    visibility: visible;
    opacity: 1;
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0)
}

.team-card2.th-team .team-social:hover .as-social a:nth-child(4) {
    -webkit-transition-delay: 0s;
    transition-delay: 0s
}

.team-card2.th-team .team-social:hover .as-social a:nth-child(3) {
    -webkit-transition-delay: 0.1s;
    transition-delay: 0.1s
}

.team-card2.th-team .team-social:hover .as-social a:nth-child(2) {
    -webkit-transition-delay: 0.2s;
    transition-delay: 0.2s
}

.team-card2.th-team .team-social:hover .as-social a:nth-child(1) {
    -webkit-transition-delay: 0.3s;
    transition-delay: 0.3s
}

.team-card2.th-team:hover .team-img img {
    -webkit-transform: scale(1.08);
    -ms-transform: scale(1.08);
    transform: scale(1.08)
}

.testi-area-1 {
    padding-top: 243px
}

@media (max-width: 991px) {
    .testi-area-1 {
        padding-top:213px
    }
}

.testi-card {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: start;
    -webkit-align-items: flex-start;
    -ms-flex-align: start;
    align-items: flex-start
}

.testi-card_img {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    position: relative;
    z-index: 1
}

.testi-card_content {
    background: var(--white-color);
    box-shadow: 0px 7px 30px 0px rgba(0,0,0,0.05);
    padding: 30px 30px 30px 150px;
    margin-left: -120px
}

.testi-card_text {
    font-size: 16px;
    font-weight: 400;
    font-style: italic;
    margin-bottom: 0
}

.testi-card_bottom {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    margin-top: 28px
}

.testi-card_name {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 0
}

.testi-card_desig {
    font-size: 14px;
    font-weight: 400;
    margin-top: 0px;
    display: block;
    margin-bottom: -0.3em
}

@media (max-width: 767px) {
    .testi-card {
        padding:30px;
        background: var(--white-color);
        box-shadow: 0px 7px 30px 0px rgba(0,0,0,0.05);
        gap: 30px
    }

    .testi-card_img {
        width: 130px
    }

    .testi-card_content {
        background: transparent;
        box-shadow: none;
        padding: 0;
        margin-left: 0
    }
}

@media (max-width: 575px) {
    .testi-card {
        display:block
    }

    .testi-card_img {
        margin-bottom: 20px
    }
}

.testi-card.style2 {
    background: #1D212D;
    padding: 40px;
    display: block;
    position: relative
}

.testi-card.style2 .testi-card-icon {
    position: absolute;
    left: 50%;
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
    transform: translate(-50%, 0);
    top: 12px
}

.testi-card.style2 .testi-card_text {
    font-style: italic;
    color: #B2B2B2;
    margin-top: -0.3em;
    margin-bottom: -0.3em
}

.testi-card.style2 .testi-card_content {
    margin: 0;
    background: transparent;
    padding: 0;
    box-shadow: none;
    margin-top: 36px;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 15px
}

.testi-card.style2 .testi-card_bottom {
    margin: 0;
    display: block
}

.testi-card.style2 .testi-card_name {
    color: var(--white-color);
    font-size: 20px;
    font-weight: 600
}

.testi-card.style2 .testi-card_desig {
    font-size: 14px;
    color: #616B79;
    margin-bottom: 7px
}

.testi-card.style2 .testi-card_review {
    color: var(--theme-color);
    font-size: 14px
}

@media (max-width: 767px) {
    .testi-card.style2 .testi-card_img {
        width:auto
    }
}

@media (max-width: 575px) {
    .testi-card.style2 .testi-card_img {
        margin-bottom:0
    }
}

@media (max-width: 375px) {
    .testi-card.style2 {
        padding:30px
    }
}

.testi-card.style3 {
    background: var(--white-color);
    border-radius: 10px;
    box-shadow: 0px 7px 30px 0px rgba(0,0,0,0.05);
    padding: 40px;
    display: block;
    position: relative
}

.testi-card.style3 .testi-card-icon {
    position: absolute;
    left: 50%;
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
    transform: translate(-50%, 0);
    top: 12px
}

.testi-card.style3 .testi-card_img img {
    border-radius: 10px
}

.testi-card.style3 .testi-card_text {
    font-style: italic;
    margin-top: -0.3em;
    margin-bottom: -0.3em
}

.testi-card.style3 .testi-card_content {
    margin: 0;
    background: transparent;
    padding: 0;
    box-shadow: none;
    margin-top: 36px;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 15px
}

.testi-card.style3 .testi-card_bottom {
    margin: 0;
    display: block
}

.testi-card.style3 .testi-card_name {
    font-size: 20px;
    font-weight: 600
}

.testi-card.style3 .testi-card_desig {
    font-size: 14px;
    color: #616B79;
    margin-bottom: 7px
}

.testi-card.style3 .testi-card_review {
    color: var(--theme-color);
    font-size: 14px
}

@media (max-width: 767px) {
    .testi-card.style3 .testi-card_img {
        width:auto
    }
}

@media (max-width: 575px) {
    .testi-card.style3 .testi-card_img {
        margin-bottom:0
    }
}

@media (max-width: 375px) {
    .testi-card.style3 {
        padding:30px
    }
}

.testi-slider3 .slick-list {
    padding-bottom: 50px
}

.testi-area-4 {
    background-size: calc(100% - 190px);
    background-position: left;
    position: relative
}

.testi-area-4:after {
    content: '';
    position: absolute;
    inset: 0;
    background: -webkit-linear-gradient(left, rgba(14,18,29,0) -5.97%, rgba(14,18,29,0.49) -.01%, rgba(14,18,29,0.66) 7.33%, rgba(14,18,29,0.8) 17.88%, rgba(14,18,29,0.9) 26.32%, rgba(14,18,29,0.94) 37.33%, #0E121D 54.58%);
    background: linear-gradient(90deg, rgba(14,18,29,0) -5.97%, rgba(14,18,29,0.49) -.01%, rgba(14,18,29,0.66) 7.33%, rgba(14,18,29,0.8) 17.88%, rgba(14,18,29,0.9) 26.32%, rgba(14,18,29,0.94) 37.33%, #0E121D 54.58%);
    width: calc(100% - 190px);
    z-index: -2
}

@media (max-width: 1700px) {
    .testi-area-4 {
        background-size:calc(100% - 100px)
    }
}

@media (max-width: 1500px) {
    .testi-area-4 {
        background-size:calc(100% - 70px)
    }
}

@media (max-width: 1399px) {
    .testi-area-4 {
        background-size:calc(100% - 30px)
    }
}

@media (max-width: 1299px) {
    .testi-area-4 {
        background-size:cover
    }

    .testi-area-4:after {
        width: 100%
    }
}

.testi4-thumb {
    right: 190px;
    top: 0;
    height: 100%;
    z-index: -1
}

.testi4-thumb img {
    height: 100%;
    object-fit: cover
}

@media (max-width: 1700px) {
    .testi4-thumb {
        right:100px
    }
}

@media (max-width: 1500px) {
    .testi4-thumb {
        right:70px
    }
}

@media (max-width: 1399px) {
    .testi4-thumb {
        right:30px
    }
}

@media (max-width: 1299px) {
    .testi4-thumb {
        right:0px;
        width: 35%
    }
}

@media (max-width: 1199px) {
    .testi4-thumb {
        display:none
    }
}

.testi-slider4 {
    max-width: 550px
}

.testi-slider4 .slick-arrow {
    background: #262A36;
    --pos-x: 0;
    top: auto;
    bottom: 0;
    right: 0;
    left: auto;
    opacity: 1;
    visibility: visible
}

.testi-slider4 .slick-arrow.slick-prev {
    right: 15px;
    -webkit-transform: translateX(-100%);
    -ms-transform: translateX(-100%);
    transform: translateX(-100%)
}

@media (max-width: 1199px) {
    .testi-slider4 {
        max-width:none;
        margin-right: 0px
    }

    .testi-slider4 .slick-arrow {
        margin: 0
    }
}

.testi-card.style4 {
    display: block;
    background: transparent;
    padding: 0
}

.testi-card.style4 .testi-card_img {
    width: auto;
    margin-bottom: 0
}

.testi-card.style4 .testi-card_text {
    font-size: 18px;
    font-weight: 500;
    color: #8993A1;
    margin-top: 0
}

.testi-card.style4 .testi-card_content {
    background: transparent;
    box-shadow: none;
    margin: 30px 0 0 0;
    padding: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 15px
}

.testi-card.style4 .testi-card_bottom {
    display: block;
    margin-top: 0
}

.testi-card.style4 .testi-card_name {
    color: var(--white-color)
}

.testi-card.style4 .testi-card_desig {
    color: #8993A1;
    margin-bottom: 7px
}

.testi-card.style4 .testi-card_review {
    color: var(--theme-color);
    font-size: 14px
}

@media (max-width: 575px) {
    .testi-card.style4 .testi-card_text {
        font-size:16px
    }
}

.testi-contace-wrap {
    margin-right: -97px
}

@media (max-width: 1700px) {
    .testi-contace-wrap {
        margin-right:0
    }
}

@media (max-width: 1199px) {
    .testi-contace-wrap {
        margin-bottom:120px;
        margin-top: -40px
    }

    .testi-contace-wrap .contact-form-wrap {
        margin-top: 0
    }
}

@media (max-width: 991px) {
    .testi-contace-wrap {
        margin-bottom:80px;
        margin-top: -20px
    }
}

.testi-area-5 {
    margin-bottom: -190px
}

.testi5-slider-wrap {
    -webkit-transform: translate(0px, 190px);
    -ms-transform: translate(0px, 190px);
    transform: translate(0px, 190px);
    margin-top: -190px;
    margin-bottom: 380px
}

.testi5-thumb-indicator {
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    margin: 0 380px;
    z-index: 1
}

@media (max-width: 1299px) {
    .testi5-thumb-indicator {
        margin:0 320px
    }
}

@media (max-width: 1199px) {
    .testi5-thumb-indicator {
        margin:0 230px
    }
}

@media (max-width: 991px) {
    .testi5-thumb-indicator {
        margin:0 100px
    }
}

@media (max-width: 575px) {
    .testi5-thumb-indicator {
        margin:0
    }
}

.testi5-thumb-indicator .testi5-thumb {
    height: 150px;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    cursor: pointer
}

.testi5-thumb-indicator .testi5-thumb img {
    border-radius: 50%;
    width: 90px;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.testi5-thumb-indicator .testi5-thumb.slick-active ~ .slick-active {
    -webkit-transform: scale(1.34);
    -ms-transform: scale(1.34);
    transform: scale(1.34)
}

@media (max-width: 767px) {
    .testi5-thumb-indicator .testi5-thumb.slick-active ~ .slick-active {
        -webkit-transform:scale(1);
        -ms-transform: scale(1);
        transform: scale(1)
    }
}

.testi5-thumb-indicator .testi5-thumb.slick-active.slick-current {
    margin: 0;
    -webkit-transform: scale(1.67);
    -ms-transform: scale(1.67);
    transform: scale(1.67);
    z-index: 1;
    position: relative
}

.testi5-thumb-indicator .testi5-thumb.slick-active.slick-current ~ .slick-active ~ .slick-active {
    -webkit-transform: scale(1);
    -ms-transform: scale(1);
    transform: scale(1);
    z-index: -1;
    position: relative
}

.testi-slider5 {
    background: var(--white-color);
    border: 6px solid #EEEEEE;
    display: block;
    text-align: center;
    padding: 105px 125px 60px;
    margin: -75px 0px 0
}

.testi-slider5 .slick-arrow {
    opacity: 1;
    visibility: visible;
    --pos-x: -30px
}

@media (max-width: 1199px) {
    .testi-slider5 {
        padding:105px 60px 60px
    }
}

@media (max-width: 991px) {
    .testi-slider5 {
        padding:105px 40px 40px
    }
}

@media (max-width: 575px) {
    .testi-slider5 {
        padding:95px 30px 30px
    }
}

.testi-card.style5 {
    display: block;
    padding: 0;
    box-shadow: none
}

.testi-card.style5 .testi-card_name {
    font-size: 24px;
    font-weight: 700;
    margin-bottom: 5px
}

.testi-card.style5 .testi-card_desig {
    color: #8993A1;
    font-size: 14px;
    font-weight: 400
}

.testi-card.style5 .testi-card_text {
    font-size: 18px;
    font-weight: 600;
    margin-top: 28px;
    margin-bottom: 27px
}

.testi-card.style5 .testi-card_review {
    color: #F0A538;
    margin-bottom: -0.3em
}

@media (max-width: 991px) {
    .testi-card.style5 .testi-card_text {
        font-size:16px;
        margin-top: 18px;
        margin-bottom: 17px
    }
}

.testi-grid {
    background-color: var(--white-color);
    border-radius: 20px;
    overflow: hidden;
    padding: 40px 40px 20px 40px;
    position: relative;
    z-index: 2
}

.testi-grid:before {
    content: '';
    height: 80px;
    width: calc(100% - 100px);
    background-color: var(--theme-color);
    position: absolute;
    bottom: -1px;
    left: 0;
    -webkit-clip-path: polygon(0 0, calc(100% - 50px) 0%, 100% 100%, 0% 100%);
    clip-path: polygon(0 0, calc(100% - 50px) 0%, 100% 100%, 0% 100%);
    z-index: -1
}

.testi-grid_text {
    margin-top: -0.5em;
    margin-bottom: 25px
}

.testi-grid_name {
    font-size: 24px;
    margin-top: 25px;
    margin-bottom: 0;
    color: var(--white-color);
    font-weight: 600
}

.testi-grid_desig {
    display: block;
    margin-bottom: -0.5em;
    color: var(--white-color)
}

.testi-grid_author {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: start;
    -webkit-align-items: flex-start;
    -ms-flex-align: start;
    align-items: flex-start;
    gap: 30px
}

.testi-grid_avater {
    border-radius: 20px;
    overflow: hidden;
    border: 4px solid var(--white-color)
}

.testi-grid_review {
    color: var(--theme-color);
    margin-top: 12px
}

.testi-grid_review i {
    font-size: 14px;
    margin-right: 3px
}

.testi-grid_quote {
    position: absolute;
    bottom: 30px;
    right: 40px
}

@media (max-width: 1199px) {
    .testi-grid:before {
        width:calc(100% - 70px)
    }

    .testi-grid_quote {
        right: 20px
    }

    .testi-grid_name {
        font-size: 22px
    }
}

@media (max-width: 575px) {
    .testi-grid:before {
        width:100%
    }

    .testi-grid_quote {
        display: none
    }
}

@media (max-width: 410px) {
    .testi-grid {
        padding:20px
    }

    .testi-grid:before {
        -webkit-clip-path: polygon(0 0, calc(100% - 35px) 0%, 100% 100%, 0% 100%);
        clip-path: polygon(0 0, calc(100% - 35px) 0%, 100% 100%, 0% 100%)
    }

    .testi-grid_author {
        gap: 20px
    }

    .testi-grid_avater {
        max-width: 70px;
        border-radius: 14px
    }

    .testi-grid_name {
        font-size: 20px
    }

    .testi-grid_text {
        font-size: 14px;
        margin-bottom: 20px
    }

    .testi-grid_desig {
        font-size: 14px
    }

    .testi-grid_review {
        margin-top: 0
    }
}

.testi-card2 {
    background-color: var(--white-color);
    padding: 40px;
    box-shadow: 0px 4px 14px rgba(7,36,95,0.06)
}

.testi-card2_img {
    margin-bottom: 23px;
    position: relative;
    display: inline-block
}

.testi-card2_img>img {
    border-radius: 50%
}

.testi-card2_quote {
    text-align: center;
    background-color: var(--white-color);
    width: 22px;
    height: 22px;
    border-radius: 3px;
    box-shadow: 0px 4px 10px rgba(7,36,95,0.15);
    line-height: 19px;
    position: absolute;
    bottom: 0;
    right: 0;
    -webkit-transform: skewY(-25deg);
    -ms-transform: skewY(-25deg);
    transform: skewY(-25deg)
}

.testi-card2_quote img {
    -webkit-transform: skewY(25deg);
    -ms-transform: skewY(25deg);
    transform: skewY(25deg)
}

.testi-card2_name {
    font-size: 24px;
    margin-bottom: 4px
}

.testi-card2_desig {
    margin-bottom: -0.45em;
    display: block
}

.testi-card2_text {
    margin-bottom: 15px
}

@media (max-width: 375px) {
    .testi-card2 {
        padding:40px 20px
    }
}

.testi-box {
    overflow: hidden
}

.testi-box_content {
    padding: 60px 30px 30px 30px;
    border-radius: 10px;
    background-color: var(--white-color)
}

.testi-box_img {
    margin-left: 30px;
    margin-bottom: -40px;
    width: 80px
}

.testi-box_img img {
    border-radius: 999px
}

.testi-box_name {
    font-size: 24px;
    margin-bottom: 4px;
    margin-top: -0.24em;
    font-weight: 700
}

.testi-box_desig {
    color: var(--theme-color);
    margin-bottom: 15px;
    display: block
}

.testi-box_text {
    padding-left: 19px;
    margin-bottom: -0.45em;
    position: relative
}

.testi-box_text:before {
    content: '';
    height: calc(100% - 14px);
    width: 4px;
    background-color: var(--theme-color);
    position: absolute;
    top: 7px;
    left: 0
}

@media (max-width: 1199px) {
    .testi-sec {
        background-position:center right
    }
}

.counter-area-1 {
    padding: 85px 0
}

.counter-grid {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 20px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.counter-grid_icon img {
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.counter-grid_number {
    color: var(--white-color);
    margin-bottom: -7px;
    margin-top: -0.16em;
    font-weight: 700;
    font-size: 48px
}

@media (max-width: 1199px) {
    .counter-grid_number {
        font-size:36px;
        margin-bottom: 0
    }
}

@media (max-width: 767px) {
    .counter-grid_number {
        font-size:28px
    }
}

.counter-grid_text {
    color: #B2B2B2;
    display: block;
    margin-bottom: -0.5em;
    font-size: 16px
}

.counter-grid:hover .counter-grid_icon img {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

.counter-area-2 {
    padding: 60px
}

@media (max-width: 1299px) {
    .counter-area-2 {
        padding:50px
    }
}

@media (max-width: 575px) {
    .counter-area-2 {
        padding:30px
    }
}

@media (max-width: 1199px) {
    .counter-thumb img {
        width:100%
    }
}

.counter-grid.style2 {
    background: var(--white-color);
    padding: 40px 30px 40px 40px;
    position: relative
}

.counter-grid.style2:after {
    content: '';
    position: absolute;
    left: 5px;
    top: 5px;
    height: 30px;
    width: 30px;
    border-right: 30px solid var(--white-color);
    border-top: 30px solid var(--theme-color)
}

.counter-grid.style2 .details {
    position: relative;
    z-index: 1
}

.counter-grid.style2 .counter-grid_icon {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none
}

.counter-grid.style2 .counter-grid_number {
    color: var(--title-color);
    font-size: 64px;
    font-weight: 700;
    margin-bottom: 1px
}

.counter-grid.style2 .counter-grid_number-shadow {
    position: absolute;
    font-size: 69px;
    font-weight: 700;
    -webkit-text-stroke: 1px var(--border-color);
    -webkit-text-fill-color: transparent;
    z-index: -1;
    top: -12px;
    left: 4px
}

.counter-grid.style2 .counter-grid_text {
    color: var(--body-color)
}

@media (max-width: 1299px) {
    .counter-grid.style2 {
        padding:30px 30px 30px 30px
    }

    .counter-grid.style2 .counter-grid_text {
        font-size: 14px
    }
}

@media (max-width: 575px) {
    .counter-grid.style2 .counter-grid_number-shadow {
        font-size:49px
    }

    .counter-grid.style2 .counter-grid_number {
        font-size: 44px
    }
}

@media (max-width: 375px) {
    .counter-grid.style2 {
        display:block
    }

    .counter-grid.style2 .counter-grid_icon {
        margin-bottom: 25px
    }

    .counter-grid.style2 .counter-grid_number-shadow {
        top: -3px
    }
}

.counter-area-3 {
    border-bottom: 1px solid var(--border-color)
}

.counter-grid.style3 {
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.counter-grid.style3 .counter-grid_icon {
    -webkit-filter: drop-shadow(0px 10px 50px rgba(30,40,58,0.12));
    filter: drop-shadow(0px 10px 50px rgba(30,40,58,0.12));
    height: 80px;
    width: 80px;
    line-height: 80px;
    border-radius: 50%;
    background: var(--white-color);
    text-align: center;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none
}

.counter-grid.style3 .counter-grid_number {
    color: var(--title-color);
    font-weight: 400;
    margin-bottom: 0
}

.counter-grid.style3 .counter-grid_number .counter-number {
    font-weight: 700
}

.counter-grid.style3 .counter-grid_text {
    color: var(--body-color)
}

.counter-area-4 {
    border: 1px solid var(--border-color);
    padding: 80px;
    position: relative
}

.counter-area-4:after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    background: var(--smoke-color);
    width: 46%;
    -webkit-clip-path: polygon(0 0, 100% 0, 80% 100%, 0% 100%);
    clip-path: polygon(0 0, 100% 0, 80% 100%, 0% 100%);
    z-index: 0
}

@media (max-width: 1299px) {
    .counter-area-4 {
        padding:60px
    }
}

@media (max-width: 767px) {
    .counter-area-4 {
        padding:40px 20px
    }

    .counter-area-4:after {
        display: none
    }
}

.counter-area-4.bg-shadow {
    box-shadow: 0px 10px 50px 0px rgba(0,0,0,0.07)
}

.counter-wrap4 {
    padding: 0 0.75rem;
    margin-left: 80px
}

@media (max-width: 1500px) {
    .counter-wrap4 {
        margin-left:30px
    }
}

@media (max-width: 1199px) {
    .counter-wrap4 {
        margin-left:0
    }
}

.counter-grid.style4 .counter-grid_icon {
    height: 80px;
    width: 80px;
    line-height: 80px;
    text-align: center;
    border-radius: 50%;
    background: var(--white-color);
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    box-shadow: 0px 10px 50px rgba(30,40,58,0.12)
}

@media (max-width: 767px) {
    .counter-grid.style4 .counter-grid_icon {
        height:70px;
        width: 70px;
        line-height: 70px
    }

    .counter-grid.style4 .counter-grid_icon img {
        width: 40px
    }
}

.counter-grid.style4 .counter-grid_number {
    color: var(--title-color);
    margin-bottom: 0
}

.counter-grid.style4 .counter-grid_text {
    color: var(--body-color)
}

@media (max-width: 1299px) {
    .counter-grid.style4 .counter-grid_text {
        font-size:14px
    }
}

.counter-grid-wrap {
    --space-x: 60px;
    --space-y: 45px;
    padding: 0
}

.counter-grid-wrap:not(:nth-child(3n)) {
    border-right: unset
}

.counter-grid-wrap:not(:nth-last-child(-n+2)) {
    padding-bottom: var(--space-y)
}

.counter-grid-wrap:not(:nth-child(-n+2)) {
    padding-top: var(--space-y);
    border-top: 1px solid var(--border-color)
}

.counter-grid-wrap:nth-child(odd) {
    padding-right: var(--space-x)
}

.counter-grid-wrap:nth-child(even) {
    padding-left: var(--space-x);
    border-left: 1px solid var(--border-color)
}

.counter-grid-wrap:not(:nth-last-child(-n+4)) {
    border-top: 0
}

@media (max-width: 1500px) {
    .counter-grid-wrap {
        --space-x: 40px
    }
}

@media (max-width: 1299px) {
    .counter-grid-wrap {
        --space-x: 30px;
        --space-y: 30px
    }
}

@media (max-width: 767px) {
    .counter-grid-wrap:nth-child(even) {
        padding-left:12px;
        border-left: 0
    }

    .counter-grid-wrap:not(:nth-child(-n+2)) {
        border-top: 0;
        padding-top: 0
    }

    .counter-grid-wrap:nth-child(odd) {
        padding-left: 12px;
        padding-right: 12px;
        padding-top: 0
    }
}

@media (max-width: 575px) {
    .counter-grid-wrap:not(:nth-child(-n+2)) {
        padding-bottom:var(--space-x)
    }

    .counter-grid-wrap:last-child {
        padding-bottom: 0
    }
}

.counter-card {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 10px
}

.counter-card-wrap {
    padding: 65px
}

.counter-card-wrap2 {
    padding: 60px 0
}

.counter-card_icon {
    width: 80px;
    height: 80px;
    line-height: 70px;
    background-color: var(--theme-color);
    border: 10px solid #bdbdbd;
    border-radius: 50%;
    box-sizing: content-box;
    text-align: center
}

.counter-card_icon img {
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.counter-card_number {
    color: var(--white-color);
    margin-bottom: 5px;
    margin-top: -0.24em
}

.counter-card_text {
    color: var(--white-color);
    display: block;
    margin-bottom: -0.45em
}

.counter-card:hover .counter-card_icon img {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

.counter-card.style2 .counter-card_icon {
    border: none
}

@media (max-width: 1399px) {
    .counter-card_number {
        max-width:110px
    }
}

@media (max-width: 1199px) {
    .counter-card_number {
        font-size:40px
    }
}

@media (max-width: 767px) {
    .counter-card {
        -webkit-box-orient:vertical;
        -webkit-box-direction: normal;
        -webkit-flex-direction: column;
        -ms-flex-direction: column;
        flex-direction: column;
        gap: 20px;
        text-align: center
    }

    .counter-card_number {
        max-width: 100%
    }
}

@media (max-width: 375px) {
    .counter-card-wrap {
        padding:65px 20px
    }
}

.counter-card.style3 {
    position: relative
}

.counter-card.style3 .counter-card_bg-number {
    font-weight: 800;
    font-size: 120px;
    font-family: var(--title-font);
    position: absolute;
    -webkit-text-stroke: 1px rgba(255,255,255,0.15);
    color: transparent;
    left: 50%;
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
    transform: translate(-50%, 0)
}

.counter-card.style3 .media-body {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 10px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.counter-card.style3 .media-body .counter-card_number {
    font-weight: 800;
    margin: 0 0 -0.3em
}

.counter-card.style3 .media-body .counter-card_text {
    font-size: 18px;
    font-weight: 500;
    width: 140px;
    line-height: 26px
}

@media (max-width: 1199px) {
    .counter-card.style3 .media-body {
        -webkit-box-pack:center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }

    .counter-card.style3 .counter-card_bg-number {
        font-size: 90px
    }
}

@media (max-width: 991px) {
    .counter-card.style3 .counter-card_bg-number {
        font-size:60px;
        line-height: initial;
        -webkit-transform: translate(-50%, -50%);
        -ms-transform: translate(-50%, -50%);
        transform: translate(-50%, -50%);
        top: 50%
    }
}

@media (max-width: 767px) {
    .counter-card.style3 {
        text-align:left
    }
}

.blog-single.style2 {
    margin-bottom: 0
}

.blog-single.style2 .blog-content {
    padding: 30px
}

.blog-single.style2 .blog-meta {
    margin-right: 70px
}

.blog-single.style2 .blog-meta span,.blog-single.style2 .blog-meta a {
    padding-right: 0;
    margin-right: 25px
}

@media (max-width: 1299px) {
    .blog-single.style2 .blog-meta span,.blog-single.style2 .blog-meta a {
        margin-right:15px
    }
}

@media (max-width: 991px) {
    .blog-single.style2 .blog-meta span,.blog-single.style2 .blog-meta a {
        margin-right:20px
    }
}

.blog-single.style2 .blog-meta span:after,.blog-single.style2 .blog-meta a:after {
    display: none
}

.blog-single.style2 .blog-meta span:last-child,.blog-single.style2 .blog-meta a:last-child {
    margin-right: 0px
}

.blog-single.style2 .blog-date {
    position: absolute;
    top: 0;
    right: 20px;
    background: var(--theme-color);
    padding: 24px 8px 15px;
    color: var(--white-color);
    text-align: center;
    font-size: 12px;
    -webkit-transform: translate(0, -50%);
    -ms-transform: translate(0, -50%);
    transform: translate(0, -50%)
}

.blog-single.style2 .blog-date span {
    font-size: 36px;
    display: block;
    font-family: var(--title-font);
    font-weight: 700;
    margin-bottom: 7px
}

@media (max-width: 1299px) {
    .blog-single.style2 .blog-date span {
        font-size:30px;
        margin-bottom: 0px
    }
}

.blog-single.style2 .blog-img img {
    width: 100%;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

@media (max-width: 1399px) {
    .blog-single.style2 {
        --blog-space-y: 30px;
        --blog-space-x: 30px
    }
}

@media (max-width: 991px) {
    .blog-single.style2 .box-title {
        font-size:22px
    }
}

.blog-single.style2:hover .blog-img img {
    -webkit-transform: scale(1.08);
    -ms-transform: scale(1.08);
    transform: scale(1.08)
}

.blog-single.style3 {
    padding: 20px 20px 40px 20px;
    border-radius: 20px;
    margin-bottom: 0;
    background: transparent;
    border: 2px solid #EEEEEE
}

@media (max-width: 991px) {
    .blog-single.style3 {
        padding:20px 20px 30px 20px
    }
}

.blog-single.style3 .blog-img {
    margin-bottom: 40px;
    border-radius: 20px;
    position: relative
}

.blog-single.style3 .blog-img img {
    width: 100%;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    border-radius: 20px
}

@media (max-width: 991px) {
    .blog-single.style3 .blog-img {
        margin-bottom:30px
    }
}

.blog-single.style3 .blog-meta {
    margin-bottom: 15px
}

.blog-single.style3 .blog-meta span,.blog-single.style3 .blog-meta a {
    padding-right: 0;
    margin-right: 25px
}

@media (max-width: 991px) {
    .blog-single.style3 .blog-meta span,.blog-single.style3 .blog-meta a {
        margin-right:20px
    }
}

.blog-single.style3 .blog-meta span:after,.blog-single.style3 .blog-meta a:after {
    display: none
}

.blog-single.style3 .blog-meta span:last-child,.blog-single.style3 .blog-meta a:last-child {
    margin-right: 0px
}

.blog-single.style3 .blog-meta span.blog-date,.blog-single.style3 .blog-meta a.blog-date {
    background: var(--theme-color);
    color: var(--white-color);
    padding: 0px 15px;
    border-radius: 20px;
    font-size: 12px
}

.blog-single.style3 .blog-content {
    padding: 0px 20px 0px 20px
}

@media (max-width: 991px) {
    .blog-single.style3 .blog-content {
        padding:0px 10px 0px 10px
    }
}

@media (max-width: 575px) {
    .blog-single.style3 .blog-content {
        padding:0
    }
}

.blog-single.style3 .blog-title {
    margin-bottom: 22px;
    font-size: 30px;
    text-transform: capitalize
}

@media (max-width: 1199px) {
    .blog-single.style3 .blog-title {
        font-size:24px
    }
}

.blog-single.style3:hover .blog-img img {
    -webkit-transform: scale(1.08);
    -ms-transform: scale(1.08);
    transform: scale(1.08)
}

.blog-single.style4 {
    padding: 0;
    box-shadow: none;
    position: relative;
    border-radius: 0px;
    background-color: var(--smoke-color);
    margin-bottom: 0
}

.blog-single.style4 .blog-img {
    z-index: 0
}

.blog-single.style4 .blog-img img {
    width: 100%
}

.blog-single.style4 .blog-content {
    padding: 40px;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

@media (max-width: 575px) {
    .blog-single.style4 .blog-content {
        padding:30px
    }
}

.blog-single.style4 .blog-meta {
    margin-top: -6px;
    margin-bottom: 25px
}

.blog-single.style4 .blog-meta span,.blog-single.style4 .blog-meta a {
    margin-right: 27px;
    padding-right: 0
}

@media (max-width: 1299px) {
    .blog-single.style4 .blog-meta span,.blog-single.style4 .blog-meta a {
        margin-right:17px
    }
}

.blog-single.style4 .blog-meta span:after,.blog-single.style4 .blog-meta a:after {
    display: none
}

.blog-single.style4 .box-title {
    font-weight: 700;
    margin-bottom: 14px;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

@media (max-width: 1399px) {
    .blog-single.style4 .box-title {
        font-size:22px
    }
}

@media (max-width: 375px) {
    .blog-single.style4 .box-title {
        font-size:18px
    }
}

.blog-single.style5 {
    margin-bottom: 0
}

.blog-single.style5 .blog-content {
    padding: 30px
}

.blog-single.style5 .blog-meta {
    margin-right: 70px
}

.blog-single.style5 .blog-meta span,.blog-single.style5 .blog-meta a {
    padding-right: 0;
    margin-right: 25px
}

@media (max-width: 1299px) {
    .blog-single.style5 .blog-meta span,.blog-single.style5 .blog-meta a {
        margin-right:15px
    }
}

@media (max-width: 991px) {
    .blog-single.style5 .blog-meta span,.blog-single.style5 .blog-meta a {
        margin-right:20px
    }
}

.blog-single.style5 .blog-meta span:after,.blog-single.style5 .blog-meta a:after {
    display: none
}

.blog-single.style5 .blog-meta span:last-child,.blog-single.style5 .blog-meta a:last-child {
    margin-right: 0px
}

.blog-single.style5 .blog-date {
    position: absolute;
    top: 0;
    left: 0;
    background: var(--theme-color);
    padding: 45px 8px 55px;
    color: var(--white-color);
    text-align: center;
    font-size: 12px;
    border-right: 8px solid var(--white-color);
    border-bottom: 8px solid var(--white-color);
    border-radius: 0 0 80px 0
}

.blog-single.style5 .blog-date span {
    font-size: 36px;
    display: block;
    font-family: var(--title-font);
    font-weight: 700;
    margin-bottom: 28px
}

.blog-single.style5 .blog-img img {
    width: 100%;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

@media (max-width: 1399px) {
    .blog-single.style5 {
        --blog-space-y: 30px;
        --blog-space-x: 30px
    }
}

@media (max-width: 991px) {
    .blog-single.style5 .box-title {
        font-size:22px
    }
}

.blog-single.style5:hover .blog-img img {
    -webkit-transform: scale(1.08);
    -ms-transform: scale(1.08);
    transform: scale(1.08)
}

.blog-meta span img,.blog-meta a img {
    margin-right: 10px;
    border-radius: 99px
}

.blog-meta.style2 span,.blog-meta.style2 a {
    font-family: var(--body-font);
    margin-right: 25px;
    padding-right: 0;
    color: #6A6E71
}

.blog-meta.style2 span:after,.blog-meta.style2 a:after {
    display: none
}

.blog-meta.style2 span:last-child,.blog-meta.style2 a:last-child {
    margin-right: 0
}

.blog-meta a:hover {
    color: var(--theme-color)
}

.blog-grid {
    --space: 50px;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    background-color: var(--smoke-color);
    position: relative;
    border-radius: 0px;
    overflow: hidden
}

.blog-grid-wrap {
    display: grid;
    grid-template-areas: "one one one one one one two two two two two two" "one one one one one one three three three three three three"
}

.blog-grid .tag {
    font-size: 14px;
    font-weight: 500;
    text-transform: uppercase;
    color: var(--theme-color);
    background-color: #ECF3FF;
    padding: 5px 16px;
    border-radius: 4px;
    display: inline-block;
    margin-bottom: 15px
}

.blog-grid .blog-img {
    position: relative;
    min-width: 280px;
    height: 100%;
    overflow: hidden;
    margin: -1px
}

.blog-grid .blog-img img {
    height: 100%;
    width: 100%;
    object-fit: cover;
    object-position: center center;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.blog-grid .blog-img .blog-date {
    position: absolute;
    top: 10px;
    left: 10px;
    background: var(--theme-color);
    padding: 20px 8px 8px;
    color: var(--white-color);
    text-align: center;
    font-size: 12px
}

.blog-grid .blog-img .blog-date span {
    font-size: 36px;
    display: block;
    font-family: var(--title-font);
    font-weight: 700;
    margin-bottom: 7px
}

@media (max-width: 1299px) {
    .blog-grid .blog-img .blog-date span {
        font-size:30px;
        margin-bottom: 0px
    }
}

.blog-grid .blog-content {
    padding: 30px 30px 17px 30px;
    -webkit-align-self: center;
    -ms-flex-item-align: center;
    align-self: center
}

.blog-grid .blog-title {
    font-size: 24px;
    margin-bottom: 14px;
    margin-top: 18px;
    line-height: 1.417;
    font-weight: 600
}

.blog-grid .blog-meta {
    margin-bottom: -0.4em;
    margin-top: -0.3em
}

.blog-grid .blog-meta span:after,.blog-grid .blog-meta a:after {
    display: none
}

.blog-grid .blog-meta span,.blog-grid .blog-meta a {
    margin-right: 0;
    padding-right: 28px
}

.blog-grid .blog-meta span:last-child,.blog-grid .blog-meta a:last-child {
    padding-right: 0
}

.blog-grid .blog-text {
    border-bottom: 1px solid var(--border-color);
    padding-bottom: 21px;
    margin-bottom: 13px
}

.blog-grid:nth-child(1) {
    grid-area: one;
    margin-right: 12px;
    display: block;
    background-color: var(--smoke-color)
}

.blog-grid:nth-child(1) .blog-content {
    padding: 40px
}

.blog-grid:nth-child(1) .blog-img {
    min-width: 100%;
    height: auto
}

.blog-grid:nth-child(1) .blog-title {
    font-size: 30px;
    line-height: 1.333
}

.blog-grid:nth-child(1) .blog-text {
    margin-bottom: 23px
}

.blog-grid:nth-child(2) {
    grid-area: two;
    margin-left: 12px;
    margin-bottom: 24px
}

.blog-grid:nth-child(3) {
    grid-area: three;
    margin-left: 12px
}

.blog-grid:hover .blog-img img {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1)
}

@media (max-width: 1399px) {
    .blog-grid {
        --space: 30px
    }
}

@media (max-width: 1299px) {
    .blog-grid .blog-img {
        min-width:250px
    }
}

@media (max-width: 1299px) {
    .blog-grid .blog-title {
        font-size:22px;
        margin-bottom: 15px
    }

    .blog-grid .blog-content {
        padding: 25px
    }

    .blog-grid:nth-child(1) .blog-title {
        font-size: 26px
    }
}

@media (max-width: 1199px) {
    .blog-grid {
        --space: 60px
    }

    .blog-grid-wrap {
        grid-template-areas: "one one one" "two two two" "three three three"
    }

    .blog-grid .blog-img {
        min-width: 400px;
        height: 250px
    }

    .blog-grid .blog-content {
        padding: 30px 30px 17px 30px
    }

    .blog-grid:nth-child(1) {
        margin-right: 0;
        margin-bottom: 24px
    }

    .blog-grid:nth-child(1) .blog-content {
        padding: 40px 40px 27px 40px
    }

    .blog-grid:nth-child(2) {
        margin-left: 0
    }

    .blog-grid:nth-child(3) {
        margin-left: 0
    }
}

@media (max-width: 991px) {
    .blog-grid .blog-img {
        min-width:250px;
        height: 100%
    }

    .blog-grid:nth-child(1) .blog-content {
        padding: 30px 30px 27px 30px
    }
}

@media (max-width: 767px) {
    .blog-grid {
        --space: 30px;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -webkit-flex-direction: column;
        -ms-flex-direction: column;
        flex-direction: column
    }

    .blog-grid .blog-img {
        height: 100%
    }

    .blog-grid .blog-content {
        -webkit-align-self: flex-start;
        -ms-flex-item-align: start;
        align-self: flex-start
    }
}

@media (max-width: 575px) {
    .blog-grid:nth-child(1) .blog-title {
        font-size:22px
    }
}

@media (max-width: 375px) {
    .blog-grid .blog-title {
        font-size:20px
    }

    .blog-grid:nth-child(1) .blog-title {
        font-size: 20px
    }

    .blog-grid:nth-child(1) .blog-content {
        padding: 30px 15px 27px
    }

    .blog-grid .blog-content {
        padding: 30px 15px 17px
    }
}

.blog-grid.style2 {
    background-color: var(--white-color);
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    box-shadow: 0px 6px 30px rgba(7,36,95,0.08);
    border-radius: 10px;
    margin: 0
}

.blog-grid.style2 .blog-img {
    overflow: hidden;
    border-radius: 10px 0 0 10px
}

.blog-grid.style2 .blog-img img {
    width: 100%;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.blog-grid.style2 .blog-content {
    padding: 25px 15px 25px 30px;
    border-radius: 0px 10px 10px 0
}

.blog-grid.style2 .blog-title {
    font-size: 24px;
    margin-bottom: 17px
}

.blog-grid.style2 .blog-meta {
    margin-bottom: 12px
}

.blog-grid.style2 .blog-meta a {
    font-size: 14px;
    font-weight: 500
}

.blog-grid.style2 .blog-text {
    margin-bottom: 14px;
    padding-bottom: 0;
    border-bottom: 0
}

.blog-grid.style2.style-big .blog-img {
    border-radius: 10px 10px 0 0
}

.blog-grid.style2.style-big .blog-content {
    padding: 40px;
    border-radius: 0px 0px 10px 10px
}

.blog-grid.style2.style-big .blog-meta {
    margin-bottom: 17px
}

.blog-grid.style2.style-big .blog-title {
    font-size: 26px
}

.blog-grid.style2.style-small {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.blog-grid.style2.style-small:not(:last-child) {
    margin-bottom: 24px
}

.blog-grid.style2.style-small .blog-img {
    min-width: 218px;
    height: 100%
}

.blog-grid.style2.style-small .blog-img img {
    height: 100%;
    object-fit: cover
}

.blog-grid.style2:hover .blog-img img {
    -webkit-transform: scale(1.08);
    -ms-transform: scale(1.08);
    transform: scale(1.08)
}

@media (max-width: 767px) {
    .blog-grid.style2 .blog-content {
        padding:40px
    }

    .blog-grid.style2.style-small {
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -webkit-flex-direction: column;
        -ms-flex-direction: column;
        flex-direction: column;
        -webkit-box-align: stretch;
        -webkit-align-items: stretch;
        -ms-flex-align: stretch;
        align-items: stretch
    }

    .blog-grid.style2.style-small .blog-img {
        max-height: 265px;
        min-width: 100%;
        border-radius: 10px 10px 0 0
    }
}

@media (max-width: 375px) {
    .blog-grid.style2 .blog-title {
        font-size:22px !important;
        line-height: 1.3
    }

    .blog-grid.style2 .blog-content {
        padding: 40px 20px !important
    }
}

.blog-card .blog-title {
    font-size: 24px;
    margin-top: -25px;
    line-height: 1.417;
    font-weight: 700;
    margin-bottom: 5px
}

.blog-card .blog-img {
    overflow: hidden
}

.blog-card .blog-img img {
    width: 100%;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.blog-card .blog-content {
    padding: 40px 30px;
    box-shadow: 0px 6px 15px rgba(7,36,95,0.07);
    background-color: var(--white-color)
}

.blog-card .blog-meta {
    margin-bottom: 20px;
    display: inline-block
}

.blog-card .blog-meta span,.blog-card .blog-meta a {
    margin-left: 0;
    margin-right: 16px;
    padding-right: 20px
}

.blog-card .blog-meta span:after,.blog-card .blog-meta a:after {
    content: '';
    height: 20px;
    width: 1px;
    background-color: rgba(0,15,87,0.3);
    position: absolute;
    top: 50%;
    right: 0;
    margin-top: 0px
}

.blog-card .blog-meta span:last-child,.blog-card .blog-meta a:last-child {
    padding-right: 0;
    margin-right: 0
}

.blog-card .blog-meta span:last-child:after,.blog-card .blog-meta a:last-child:after {
    display: none
}

.blog-card .blog-meta.style2 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    padding: 13px 18px;
    background-color: var(--title-color);
    position: relative;
    margin-top: -28px;
    margin-bottom: 35px
}

.blog-card .blog-meta.style2:before {
    content: '';
    height: 100%;
    width: 56%;
    background-color: var(--theme-color);
    position: absolute;
    top: 0;
    left: 0;
    -webkit-clip-path: polygon(calc(100% - 25px) 0, 100% 50%, calc(100% - 25px) 100%, 0 100%, 0 0);
    clip-path: polygon(calc(100% - 25px) 0, 100% 50%, calc(100% - 25px) 100%, 0 100%, 0 0)
}

.blog-card .blog-meta.style2 span,.blog-card .blog-meta.style2 a {
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    color: var(--white-color);
    margin-right: 0 !important;
    padding-right: 0 !important
}

.blog-card .blog-meta.style2 span::after,.blog-card .blog-meta.style2 a::after {
    display: none
}

.blog-card .blog-meta.style2 span:hover,.blog-card .blog-meta.style2 a:hover {
    color: var(--white-color)
}

.blog-card .blog-text {
    margin-bottom: 5px
}

.blog-card .line-btn {
    margin-bottom: -0.1em;
    display: block;
    width: -webkit-fit-content;
    width: -moz-fit-content;
    width: fit-content
}

.blog-card:hover .blog-img img {
    -webkit-transform: scale(1.08);
    -ms-transform: scale(1.08);
    transform: scale(1.08)
}

@media (max-width: 1399px) {
    .blog-card .blog-content {
        padding:40px 20px
    }
}

@media (max-width: 1199px) {
    .blog-card .blog-content {
        padding:40px 40px
    }
}

@media (max-width: 991px) {
    .blog-card .blog-title {
        font-size:22px
    }

    .blog-card .blog-content {
        padding: 40px 20px
    }
}

@media (max-width: 767px) {
    .blog-card .blog-content {
        padding:40px
    }

    .blog-card .blog-title {
        font-size: 24px
    }
}

@media (max-width: 410px) {
    .blog-card .blog-content {
        padding:40px 20px
    }

    .blog-card .blog-meta span:not(:last-child),.blog-card .blog-meta a:not(:last-child) {
        padding-right: 12px;
        margin-right: 8px
    }
}

@media (max-width: 375px) {
    .blog-card .blog-title {
        font-size:20px;
        line-height: 1.5
    }
}

@media (max-width: 350px) {
    .blog-card .blog-title {
        font-size:18px;
        line-height: 1.6;
        margin-bottom: 10px
    }

    .blog-card .blog-text {
        font-size: 14px;
        margin-bottom: 15px
    }

    .blog-card .blog-meta.style2 {
        padding: 10px 10px;
        margin: -25px -20px 35px -20px
    }
}

.blog-space-bottom {
    margin-bottom: -105px;
    padding-bottom: 165px
}

.blog-card3 {
    border-radius: 10px;
    padding: 30px;
    box-shadow: 0px 6px 15px rgba(7,36,95,0.07);
    background-color: var(--white-color)
}

.blog-card3 .blog-meta {
    margin-bottom: 22px
}

.blog-card3 .blog-meta .author {
    font-size: 16px;
    font-weight: 600
}

.blog-card3 .blog-img {
    border-radius: 10px
}

.blog-card3 .blog-content {
    padding: 30px 0 0 0;
    box-shadow: none
}

.blog-card3 .blog-content .box-title {
    margin-bottom: 5px
}

.blog-card3 .blog-content .link-btn.style3 {
    color: var(--theme-color)
}

.blog-card3 .blog-content .link-btn.style3:before {
    background: var(--theme-color)
}

@media (max-width: 991px) {
    .blog-space-bottom {
        padding-bottom:180px;
        margin-bottom: -135px
    }

    .blog-card3 {
        padding: 20px 20px 30px
    }
}

.feature-area-1 {
    box-shadow: 0px 6px 30px 0px rgba(0,0,0,0.06)
}

@media (max-width: 991px) {
    .feature-area-1 {
        box-shadow:none
    }
}

.feature-card-wrap {
    margin: 0;
    padding: 0;
    list-style: none;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex
}

.feature-card-wrap .feature-card {
    width: 16.666%
}

.feature-card-wrap .feature-card .feature-card-active-wrap {
    background: var(--theme-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    padding: 40px;
    gap: 30px;
    opacity: 0;
    width: 636px;
    position: absolute;
    inset: 0;
    visibility: hidden;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.feature-card-wrap .feature-card .feature-card-active-wrap .feature-card_details {
    max-width: none
}

.feature-card-wrap .feature-card .feature-card-active-wrap .feature-card_icon {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none
}

.feature-card-wrap .feature-card .feature-card-active-wrap .feature-card_icon img {
    -webkit-filter: brightness(999);
    filter: brightness(999)
}

.feature-card-wrap .feature-card .feature-card-active-wrap .feature-card_title {
    -webkit-transition: 0.4s;
    transition: 0.4s;
    font-size: 30px;
    font-weight: 700;
    line-height: 38px;
    color: var(--white-color);
    cursor: pointer
}

.feature-card-wrap .feature-card .feature-card-active-wrap .feature-card_title a {
    color: var(--white-color)
}

.feature-card-wrap .feature-card .feature-card-active-wrap .feature-card_text {
    color: var(--white-color);
    opacity: 1;
    height: auto;
    -webkit-transform: scaleY(1);
    -ms-transform: scaleY(1);
    transform: scaleY(1);
    margin-bottom: 27px
}

@media (max-width: 1700px) {
    .feature-card-wrap .feature-card {
        padding:40px 30px 47px
    }

    .feature-card-wrap .feature-card .feature-card_title {
        font-size: 18px;
        line-height: 28px
    }

    .feature-card-wrap .feature-card .feature-card_text {
        font-size: 14px
    }

    .feature-card-wrap .feature-card .feature-card-active-wrap {
        width: 100%;
        padding: 30px;
        gap: 20px
    }

    .feature-card-wrap .feature-card .feature-card-active-wrap .feature-card_title {
        font-size: 24px
    }
}

@media (max-width: 1500px) {
    .feature-card-wrap .feature-card .feature-card_title {
        font-size:16px
    }

    .feature-card-wrap .feature-card .feature-card_icon {
        margin-bottom: 20px
    }

    .feature-card-wrap .feature-card .feature-card-active-wrap {
        -webkit-box-align: center;
        -webkit-align-items: center;
        -ms-flex-align: center;
        align-items: center;
        width: 479px
    }

    .feature-card-wrap .feature-card .feature-card-active-wrap .feature-card_title {
        margin-bottom: 10px;
        font-size: 22px
    }

    .feature-card-wrap .feature-card .feature-card-active-wrap .feature-card_text {
        display: none
    }
}

@media (max-width: 1399px) {
    .feature-card-wrap .feature-card {
        padding:30px 25px 37px
    }

    .feature-card-wrap .feature-card .feature-card-active-wrap {
        width: 451px
    }

    .feature-card-wrap .feature-card .feature-card-active-wrap .feature-card_title {
        font-size: 20px;
        line-height: initial
    }
}

@media (max-width: 1299px) {
    .feature-card-wrap .feature-card {
        padding:30px 25px 25px;
        width: 20%
    }

    .feature-card-wrap .feature-card .feature-card-active-wrap {
        display: none
    }
}

@media (max-width: 1199px) {
    .feature-card-wrap .feature-card .feature-card_title {
        font-size:14px;
        line-height: inherit
    }
}

@media (max-width: 991px) {
    .feature-card-wrap .feature-card {
        display:inline-block;
        width: 33%
    }
}

@media (max-width: 767px) {
    .feature-card-wrap .feature-card {
        width:43%
    }
}

@media (max-width: 575px) {
    .feature-card-wrap .feature-card {
        width:90%
    }
}

.feature-card-wrap .item-active {
    width: 33.333%
}

.feature-card-wrap .item-active.feature-card {
    background: var(--theme-color)
}

.feature-card-wrap .item-active .feature-card-active-wrap {
    opacity: 1;
    visibility: visible
}

@media (max-width: 1299px) {
    .feature-card-wrap .item-active {
        width:20%
    }

    .feature-card-wrap .item-active.feature-card {
        background: var(--white-color)
    }
}

@media (max-width: 991px) {
    .feature-card-wrap .item-active {
        width:33%
    }
}

@media (max-width: 767px) {
    .feature-card-wrap .item-active {
        width:43%
    }
}

@media (max-width: 575px) {
    .feature-card-wrap .item-active {
        width:90%
    }
}

@media (max-width: 991px) {
    .feature-card-wrap {
        -webkit-flex-wrap:wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        gap: 24px;
        -webkit-box-pack: center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center;
        padding-bottom: 20px
    }
}

.feature-card {
    padding: 40px 40px 47px;
    background-color: var(--white-color);
    border-radius: 0px;
    box-shadow: 0px 6px 30px 0px rgba(0,0,0,0.06);
    -webkit-transition: 0.4s;
    transition: 0.4s;
    position: relative
}

.feature-card .feature-card_details {
    max-width: 234px
}

.feature-card_icon {
    margin-bottom: 40px
}

.feature-card_icon img {
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.feature-card_title {
    font-size: 20px;
    margin-bottom: 0;
    margin-top: -0.2em;
    font-weight: 600;
    line-height: 30px
}

.feature-card_title a {
    color: var(--title-color)
}

.feature-card_title a:hover {
    color: var(--theme-color)
}

.feature-card_text {
    margin-bottom: -0.45em;
    margin-top: 16px;
    -webkit-transition: 0.7s;
    transition: 0.7s;
    height: 0;
    opacity: 0;
    line-height: 26px;
    -webkit-transform: scaleY(0);
    -ms-transform: scaleY(0);
    transform: scaleY(0)
}

.feature-card .btn-wrap {
    -webkit-transition: 0.7s;
    transition: 0.7s;
    --btn-size: 30px;
    cursor: pointer;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 5px
}

.feature-card .btn-wrap .icon-btn {
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.feature-card .btn-wrap .link-btn {
    color: var(--white-color)
}

.feature-card .btn-wrap .link-btn:before {
    background: var(--white-color)
}

.feature-card:hover .feature-card_icon img {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

.feature-area-2 {
    background: var(--white-color);
    box-shadow: 0px 10px 30px 0px rgba(7,36,95,0.08);
    margin-top: -80px;
    position: relative;
    z-index: 2
}

.feature-card2 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 30px;
    padding: 30px;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    box-shadow: 0px 6px 30px 0px rgba(0,0,0,0.06)
}

.feature-card2-text {
    margin-bottom: -0.5em;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.feature-card2-icon img {
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.feature-card2.item-active,.feature-card2:hover {
    background: var(--theme-color)
}

.feature-card2.item-active .feature-card2-icon img,.feature-card2:hover .feature-card2-icon img {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

.feature-card2.item-active .box-title a,.feature-card2:hover .box-title a {
    color: var(--white-color)
}

.feature-card2.item-active .feature-card2-text,.feature-card2:hover .feature-card2-text {
    color: var(--white-color)
}

@media (max-width: 1299px) {
    .feature-card2 {
        display:block
    }

    .feature-card2 .feature-card2-icon {
        margin-bottom: 30px
    }

    .feature-card2 .feature-card2-text {
        font-size: 15px
    }
}

@media (max-width: 1199px) {
    .feature-card2 {
        display:-webkit-box;
        display: -webkit-flex;
        display: -ms-flexbox;
        display: flex
    }
}

@media (max-width: 375px) {
    .feature-card2 {
        display:block
    }

    .feature-card2 .box-title {
        font-size: 22px
    }

    .feature-card2 .feature-card2-text {
        font-size: 16px
    }
}

.feature-box {
    background-color: var(--white-color);
    border: 1px solid #E4E4E4;
    border-top: 5px solid var(--theme-color);
    box-shadow: 0px 6px 15px rgba(14,18,29,0.06);
    border-radius: 10px;
    padding: 35px
}

.feature-box_icon {
    margin-bottom: 20px
}

.feature-box_icon img {
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.feature-box_title {
    margin-bottom: 10px
}

.feature-box_text {
    font-size: 14px;
    margin-bottom: -0.5em
}

.feature-box:hover .feature-box_icon img {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

@media (max-width: 767px) {
    .feature-box {
        text-align:center
    }
}

.feature-card3 {
    padding: 50px 40px 65px 40px;
    background-color: var(--theme-color);
    box-shadow: 0px 10px 30px rgba(7,36,95,0.08);
    border-radius: 20px;
    text-align: center;
    position: relative;
    z-index: 2;
    margin-bottom: 27.5px
}

.feature-card3:before,.feature-card3:after {
    content: '';
    width: calc(100% - 4px);
    height: calc(100% - 4px);
    position: absolute;
    top: 2px;
    left: 2px;
    background-color: var(--white-color);
    z-index: -1;
    border-radius: 19px;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.feature-card3:after {
    width: 100%;
    height: 100%;
    background-image: -webkit-linear-gradient(top, #FF4C13 0%, rgba(255,255,255,0) 80%);
    background-image: linear-gradient(180deg, #FF4C13 0%, rgba(255,255,255,0) 80%);
    z-index: -2;
    top: 0;
    left: 0
}

.feature-card3_icon {
    width: 80px;
    height: 80px;
    line-height: 80px;
    background-color: var(--theme-color);
    border-radius: 50%;
    margin: 0 auto 29px auto;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    position: relative;
    z-index: 2
}

.feature-card3_icon::before {
    content: '';
    width: 100%;
    height: 100%;
    position: absolute;
    top: -10px;
    left: -10px;
    background-color: inherit;
    opacity: 0.3;
    z-index: -1;
    border-radius: inherit
}

.feature-card3_icon img {
    -webkit-filter: brightness(0) invert(1);
    filter: brightness(0) invert(1);
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.feature-card3_title {
    font-size: 24px;
    margin-bottom: 15px;
    margin-top: -0.24em;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.feature-card3_text {
    margin-bottom: -0.45em;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.feature-card3 .icon-btn {
    --btn-size: 55px;
    background-color: var(--theme-color);
    color: var(--white-color);
    box-shadow: 0px 8px 19px rgba(255,76,19,0.3);
    position: absolute;
    bottom: -27.5px;
    left: 50%;
    margin-left: -27.5px
}

.feature-card3:hover::before,.feature-card3:hover:after {
    height: 0
}

.feature-card3:hover .feature-card3_icon {
    background-color: var(--white-color)
}

.feature-card3:hover .feature-card3_icon img {
    -webkit-filter: none;
    filter: none;
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

.feature-card3:hover .feature-card3_title {
    color: var(--white-color)
}

.feature-card3:hover .feature-card3_text {
    color: var(--white-color)
}

.feature-card3:hover .icon-btn {
    background-color: var(--white-color);
    color: var(--theme-color);
    -webkit-animation: jumpIcon 1s linear infinite;
    animation: jumpIcon 1s linear infinite
}

@media (max-width: 1399px) {
    .feature-card3 {
        padding:50px 20px 65px 20px
    }
}

@-webkit-keyframes jumpIcon {
    0% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }

    50% {
        -webkit-transform: translateY(-8px);
        transform: translateY(-8px)
    }

    100% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }
}

@keyframes jumpIcon {
    0% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }

    50% {
        -webkit-transform: translateY(-8px);
        transform: translateY(-8px)
    }

    100% {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }
}

.feature-grid {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 20px;
    padding: 40px 0;
    position: relative;
    z-index: 2
}

.feature-grid-wrap {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    padding: 0 30px;
    box-shadow: 0px 10px 30px rgba(7,36,95,0.08);
    background-color: var(--white-color);
    margin-top: -60px;
    position: relative;
    z-index: 4
}

.feature-grid:not(:last-child) {
    padding-right: 40px
}

.feature-grid_icon img {
    min-width: 50px;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.feature-grid_title {
    font-size: 24px;
    margin-bottom: 10px;
    margin-top: -0.24em
}

.feature-grid_text {
    margin-bottom: -0.5em
}

.feature-grid:nth-child(even):before {
    content: '';
    height: 100%;
    width: calc(100% + 60px);
    background-color: var(--theme-color);
    position: absolute;
    top: 0;
    left: -60px;
    z-index: -1;
    -webkit-clip-path: polygon(0 0, calc(100% - 60px) 0%, 100% 50%, calc(100% - 60px) 100%, 0 100%, 60px 50%);
    clip-path: polygon(0 0, calc(100% - 60px) 0%, 100% 50%, calc(100% - 60px) 100%, 0 100%, 60px 50%)
}

.feature-grid:nth-child(even) .feature-grid_title,.feature-grid:nth-child(even) .feature-grid_text,.feature-grid:nth-child(even) .feature-grid_icon img {
    -webkit-filter: brightness(0) invert(1);
    filter: brightness(0) invert(1)
}

.feature-grid:hover .feature-grid_icon img {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

@media (max-width: 1299px) {
    .feature-grid_title {
        font-size:22px
    }
}

@media (max-width: 1199px) {
    .feature-grid {
        padding:30px 0
    }

    .feature-grid:not(:last-child) {
        padding-right: 22px
    }

    .feature-grid:nth-child(even):before {
        width: calc(100% + 50px);
        left: -44px;
        -webkit-clip-path: polygon(0 0, calc(100% - 55px) 0%, 100% 50%, calc(100% - 55px) 100%, 0 100%, 55px 50%);
        clip-path: polygon(0 0, calc(100% - 55px) 0%, 100% 50%, calc(100% - 55px) 100%, 0 100%, 55px 50%)
    }
}

@media (max-width: 991px) {
    .feature-grid-wrap {
        grid-template-columns:repeat(1, 1fr)
    }

    .feature-grid:not(:last-child) {
        padding-right: 0
    }

    .feature-grid:nth-child(even) {
        padding-left: 30px
    }

    .feature-grid:nth-child(even):before {
        width: calc(100% + 60px);
        left: -30px
    }
}

@media (max-width: 480px) {
    .feature-grid-wrap {
        padding:0 15px
    }

    .feature-grid:nth-child(even) {
        padding-left: 0
    }

    .feature-grid:nth-child(even):before {
        width: calc(100% + 30px);
        left: -15px;
        -webkit-clip-path: none;
        clip-path: none
    }
}

.video-btn {
    font-size: 36px;
    color: var(--white-color);
    background-color: var(--theme-color);
    padding: 42px 57px
}

.video-btn:hover {
    background-color: var(--title-color);
    color: var(--white-color)
}

@media (max-width: 767px) {
    .video-btn {
        font-size:24px;
        padding: 22px 37px
    }
}

.video-btn.style2 {
    background: transparent;
    padding: 0
}

.checklist ul {
    padding-left: 0;
    list-style: none;
    text-align: left;
    margin-bottom: 0
}

.checklist li {
    color: var(--title-color);
    margin-bottom: 10px;
    font-weight: 500;
    position: relative;
    padding-left: 28px
}

.checklist li:before {
    content: "\f058";
    font-family: var(--icon-font);
    font-weight: 900;
    color: var(--theme-color);
    position: absolute;
    left: 0;
    -webkit-transition: 0.3s ease-in-out;
    transition: 0.3s ease-in-out
}

.checklist li:first-child {
    margin-top: -0.5em
}

.checklist li:last-child {
    margin-bottom: -0.5em
}

.checklist .check-text {
    margin-bottom: 0
}

.checklist .check-title {
    margin-bottom: 10px;
    font-size: 24px
}

.checklist.style2 ul {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    -webkit-column-gap: 50px;
    -moz-column-gap: 50px;
    column-gap: 50px
}

@media (max-width: 1399px) {
    .checklist.style2 ul {
        gap:20px
    }
}

@media (max-width: 767px) {
    .checklist.style2 ul {
        grid-template-columns:repeat(1, 1fr)
    }
}

.checklist.style2 li {
    color: var(--body-color);
    padding-left: 40px;
    margin-bottom: 0
}

.checklist.style2 li:before {
    font-size: 24px;
    top: 5px
}

.checklist.style2 li:first-child {
    margin-top: 0
}

.checklist.style3 li {
    font-family: var(--body-font);
    font-weight: 400;
    padding-left: 35px;
    margin-bottom: 14px
}

.checklist.style3 li:before {
    content: "\f14a";
    font-size: 24px
}

.checklist.style3 li:last-child {
    margin-bottom: -0.5em
}

.checklist.style4 li {
    font-family: var(--body-font);
    font-weight: 400
}

.checklist.style4 li:before {
    content: "\f00c";
    font-size: 18px
}

.checklist.style5 li {
    font-family: var(--body-font);
    font-weight: 400;
    font-size: 16px;
    padding-left: 32px;
    margin-bottom: 14px
}

.checklist.style5 li:before {
    content: "\f336";
    font-size: 18px
}

.checklist.style5 li:last-child {
    margin-bottom: -0.5em
}

.checklist.style6 li {
    font-family: var(--body-font);
    font-weight: 400;
    font-size: 16px;
    padding-left: 32px;
    margin-bottom: 14px
}

.checklist.style6 li:before {
    font-weight: 300;
    font-size: 20px
}

.checklist.style6 li:last-child {
    margin-bottom: -0.5em
}

.checklist.style7 li:before {
    font-weight: 300;
    font-size: 16px
}

.checklist.style7 li:last-child {
    margin-bottom: -0.5em
}

.checklist.style8 ul {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 20px 50px;
    -webkit-box-align: baseline;
    -webkit-align-items: baseline;
    -ms-flex-align: baseline;
    align-items: baseline
}

.checklist.style8 li {
    font-weight: 500;
    font-family: var(--title-font);
    padding-left: 36px;
    margin-bottom: 0px
}

.checklist.style8 li:before {
    background: url(../img/icon/check-icon.svg);
    color: transparent;
    height: 26px;
    width: 26px
}

.checklist.style8 li:last-child {
    margin-bottom: -0.5em
}

@media (max-width: 1199px) {
    .checklist.style8 ul {
        grid-template-columns:repeat(1, 1fr)
    }
}

@media (max-width: 991px) {
    .checklist.style8 ul {
        grid-template-columns:repeat(2, 1fr)
    }
}

@media (max-width: 767px) {
    .checklist.style8 ul {
        gap:20px 30px
    }
}

@media (max-width: 575px) {
    .checklist.style8 ul {
        grid-template-columns:repeat(1, 1fr)
    }
}

.checklist.style9 li {
    color: var(--body-color);
    font-weight: 400
}

.checklist.style9 li:before {
    font-weight: 300;
    font-size: 16px
}

.checklist.style9 li:last-child {
    margin-bottom: -0.5em
}

@media (max-width: 1199px) {
    .checklist.mb-40 {
        margin-bottom:32px
    }
}

@media (max-width: 1199px) {
    .checklist.mb-45 {
        margin-bottom:35px
    }
}

.notification-box {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    margin-left: auto;
    margin-right: auto;
    gap: 30px;
    position: relative;
    z-index: 3
}

.notification-box .th-btn {
    margin-left: auto
}

.notification-box .notification-title {
    margin-bottom: 6px;
    color: var(--white-color)
}

.notification-box .notification-text {
    margin-bottom: 0;
    color: var(--white-color)
}

@media (max-width: 991px) {
    .notification-box {
        padding:25px;
        gap: 20px
    }
}

@media (max-width: 767px) {
    .notification-box {
        padding:35px 15px;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -webkit-flex-direction: column;
        -ms-flex-direction: column;
        flex-direction: column
    }

    .notification-box .notification-content {
        text-align: center
    }

    .notification-box .th-btn {
        margin-left: unset
    }
}

.achive-counter {
    background: #FFFFFF;
    box-shadow: 0px 6px 30px rgba(14,18,29,0.06);
    border-radius: 10px;
    position: relative;
    padding: 24px 30px 24px 120px
}

.achive-counter-wrap {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 24px;
    max-width: 660px;
    margin-left: auto;
    margin-right: auto
}

.achive-counter_icon {
    display: inline-block;
    width: 90px;
    width: 70px;
    line-height: 90px;
    background-color: var(--theme-color);
    position: absolute;
    top: 0;
    left: 30px;
    text-align: center;
    border-radius: 0 0 99px 99px
}

.achive-counter_number {
    color: var(--theme-color);
    font-size: 36px;
    margin-bottom: 0
}

.achive-counter .counter-number {
    font-weight: 900
}

.achive-counter_text {
    margin-bottom: 0
}

@media (max-width: 767px) {
    .achive-counter {
        padding:24px 15px 24px 95px
    }

    .achive-counter-wrap {
        gap: 15px
    }

    .achive-counter_icon {
        left: 10px
    }
}

@media (max-width: 575px) {
    .achive-counter {
        padding:24px 30px 24px 120px;
        max-width: 300px;
        margin-left: auto;
        margin-right: auto
    }

    .achive-counter-wrap {
        grid-template-columns: auto
    }

    .achive-counter_icon {
        left: 30px
    }
}

.bg-img {
    position: absolute;
    inset: 0;
    height: 100%;
    width: 100%
}

.bg-img img {
    width: 100%;
    height: 100%
}

.img-left {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2;
    height: 100%;
    width: 48%
}

.img-left img {
    height: 100%;
    width: 100%;
    object-fit: cover;
    object-position: top right
}

@media (max-width: 1199px) {
    .img-left {
        position:relative;
        width: 100%
    }
}

.insta-box {
    position: relative;
    border-radius: 8px;
    overflow: hidden
}

.insta-box .icon-btn {
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%) scale(0);
    -ms-transform: translate(-50%, -50%) scale(0);
    transform: translate(-50%, -50%) scale(0);
    -webkit-transition-delay: 0.3s;
    transition-delay: 0.3s
}

.insta-box img {
    width: 100%
}

.insta-box::before {
    content: "";
    width: 100%;
    height: 100%;
    background-color: #001D52;
    position: absolute;
    inset: 0;
    -webkit-transform: scale(0);
    -ms-transform: scale(0);
    transform: scale(0);
    visibility: hidden;
    opacity: 0;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    border-radius: inherit
}

.insta-box:hover:before {
    -webkit-transform: scale(1);
    -ms-transform: scale(1);
    transform: scale(1);
    visibility: visible;
    opacity: 0.6
}

.insta-box:hover .icon-btn {
    -webkit-transform: translate(-50%, -50%) scale(1);
    -ms-transform: translate(-50%, -50%) scale(1);
    transform: translate(-50%, -50%) scale(1)
}

.th-box {
    text-align: center
}

.th-box_img {
    margin-bottom: -110px;
    max-width: 476px;
    margin-left: auto;
    margin-right: auto;
    z-index: 2;
    position: relative;
    padding-top: 30px
}

@media (max-width: 575px) {
    .th-box_img {
        margin-bottom:-68px
    }
}

.th-box_img:before,.th-box_img:after {
    content: "";
    width: 100%;
    height: 80%;
    position: absolute;
    top: 0;
    right: 0;
    left: 0;
    background-color: var(--smoke-color);
    z-index: -1;
    border-width: 9px 15px 0 15px;
    border-style: solid;
    border-color: var(--theme-color);
    border-radius: 999px
}

.th-box_img::after {
    border: none;
    top: 9px;
    left: 13px;
    width: calc(100% - 26px)
}

.th-box_content {
    padding: 140px 60px 60px 60px;
    background-color: var(--smoke-color);
    border-radius: 15px
}

@media (max-width: 575px) {
    .th-box_content {
        padding:100px 20px 45px 20px
    }
}

.th-box_text {
    max-width: 450px;
    margin: 0 auto 23px auto
}

.th-box.theme2 {
    --theme-color: #F20F10;
    --smoke-color: #FFF3F3
}

.th-box.theme2 .th-btn {
    box-shadow: 0px 6px 16px rgba(242,15,16,0.24)
}

.th-video {
    position: relative;
    background-color: var(--white-color);
    border-radius: 10px;
    box-shadow: 0px 4px 16px #EBEEF3;
    padding: 20px
}

.th-video img {
    border-radius: inherit;
    width: 100%
}

.th-video .play-btn {
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%)
}

.th-video .play-btn>i {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.th-video .play-btn:after,.th-video .play-btn:before {
    background-color: var(--theme-color)
}

@media (max-width: 1199px) {
    p.mb-30 {
        margin-bottom:25px
    }

    p.mb-35 {
        margin-bottom: 28px
    }

    p.mb-40 {
        margin-bottom: 32px
    }

    p.mb-45 {
        margin-bottom: 35px
    }
}

.wcu-wrap1 {
    padding: 80px 375px 80px 80px;
    position: relative;
    margin-top: 80px;
    margin-left: -100px
}

.wcu-wrap1 .video-wrap {
    position: absolute;
    background: var(--theme-color);
    border: 0;
    padding: 51.5px 64px 71.5px;
    border-radius: 0;
    right: -75px;
    bottom: 40px;
    -webkit-transform: rotate(-55deg);
    -ms-transform: rotate(-55deg);
    transform: rotate(-55deg);
    z-index: 1;
    box-shadow: none
}

.wcu-wrap1 .video-wrap .play-btn {
    -webkit-transform: rotate(55deg);
    -ms-transform: rotate(55deg);
    transform: rotate(55deg)
}

@media (max-width: 1500px) {
    .wcu-wrap1 {
        margin-left:0;
        padding: 80px 335px 80px 80px;
        margin-top: 50px
    }
}

@media (max-width: 1399px) {
    .wcu-wrap1 {
        padding:80px 280px 80px 80px
    }
}

@media (max-width: 1299px) {
    .wcu-wrap1 {
        padding:70px 210px 70px 70px
    }
}

@media (max-width: 1199px) {
    .wcu-wrap1 {
        margin-top:0
    }

    .wcu-wrap1 .video-wrap {
        right: 40px;
        top: -96px;
        bottom: auto;
        -webkit-transform: rotate(-45deg);
        -ms-transform: rotate(-45deg);
        transform: rotate(-45deg)
    }

    .wcu-wrap1 .video-wrap .play-btn {
        -webkit-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        transform: rotate(45deg)
    }
}

@media (max-width: 991px) {
    .wcu-wrap1 {
        padding:70px
    }
}

@media (max-width: 767px) {
    .wcu-wrap1 {
        padding:50px
    }
}

@media (max-width: 575px) {
    .wcu-wrap1 {
        padding:40px
    }

    .wcu-wrap1 .video-wrap {
        display: none
    }
}

@media (max-width: 375px) {
    .wcu-wrap1 {
        padding:40px 20px
    }
}

.wcu-img-1 {
    position: relative;
    margin-right: -295px;
    margin-left: -320px;
    height: 100%;
    padding-bottom: 80px
}

.wcu-img-1 .img1 {
    height: 100%
}

.wcu-img-1 .img1 img {
    width: 100%;
    height: 100%;
    object-fit: cover
}

@media (max-width: 1660px) {
    .wcu-img-1 {
        margin-right:-140px
    }
}

@media (max-width: 1500px) {
    .wcu-img-1 {
        margin-right:-50px
    }
}

@media (max-width: 1399px) {
    .wcu-img-1 {
        margin-right:00px;
        margin-left: -250px
    }
}

@media (max-width: 1299px) {
    .wcu-img-1 {
        margin-left:-200px;
        padding-bottom: 70px
    }
}

@media (max-width: 1199px) {
    .wcu-img-1 {
        margin-right:0;
        margin-left: 0;
        height: auto;
        padding-bottom: 0
    }
}

.wcu-box {
    background: rgba(255,255,255,0.6);
    border-radius: 20px;
    padding: 0px 20px 24px;
    margin-top: 26px;
    position: relative;
    z-index: 1
}

.wcu-box_icon {
    color: var(--white-color);
    border-radius: 50%;
    background: var(--white-color);
    display: inline-block;
    padding: 8px;
    -webkit-transform: translate(0, -50%);
    -ms-transform: translate(0, -50%);
    transform: translate(0, -50%);
    margin-bottom: -23px
}

.wcu-box .box-title {
    margin-bottom: 0px;
    font-size: 18px;
    line-height: initial;
    margin-top: -10px
}

@media (max-width: 1399px) {
    .wcu-box .box-title {
        font-size:20px
    }
}

.wcu-img-2 {
    position: relative;
    display: inline-block
}

.wcu-img-2 .wcu-experience-wrap {
    font-size: 74px;
    font-weight: 700;
    font-family: var(--title-font);
    position: absolute;
    bottom: 0;
    right: 135px;
    color: var(--theme-color)
}

.wcu-img-2 .wcu-experience-wrap span {
    font-size: 24px;
    font-weight: 600;
    color: var(--title-color)
}

@media (max-width: 575px) {
    .wcu-img-2 .wcu-experience-wrap {
        font-size:40px;
        right: 62px
    }
}

.wcu-box.style2 {
    background: var(--white-color);
    padding: 20px;
    box-shadow: 0px 4px 30px 0px rgba(0,0,0,0.06);
    border-radius: 0;
    margin: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 15px
}

.wcu-box.style2 .wcu-box_icon {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    color: var(--theme-color);
    -webkit-transform: none;
    -ms-transform: none;
    transform: none;
    margin: 0;
    padding: 0;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.wcu-box.style2 .wcu-box_title {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 2px
}

.wcu-box.style2 .wcu-box_title a {
    color: var(--title-color)
}

.wcu-box.style2 .wcu-box_title a:hover {
    color: var(--theme-color)
}

.wcu-box.style2 .wcu-box_text {
    margin-bottom: -0.5em;
    font-size: 14px
}

.wcu-box.style2:hover .wcu-box_icon {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

.wcu-img-3 {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    z-index: -1
}

.wcu-img-3 img {
    height: 100%;
    object-fit: cover;
    object-position: top left
}

@media (max-width: 1700px) {
    .wcu-img-3 {
        width:40%
    }
}

@media (max-width: 1299px) {
    .wcu-img-3 {
        width:35%
    }
}

@media (max-width: 991px) {
    .wcu-img-3 {
        display:none
    }
}

.wcu-contact-wrap textarea.form-control,.wcu-contact-wrap textarea {
    min-height: 100px
}

.wcu-contact-wrap .form-group {
    --bs-gutter-x: 15px
}

@media (max-width: 1199px) {
    .wcu-contact-wrap .contact-form-wrap {
        margin-top:0
    }
}

.wcu-grid {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 20px
}

.wcu-grid-title {
    font-size: 20px;
    font-weight: 600;
    color: var(--white-color);
    display: inline-block;
    padding-bottom: 8px;
    margin-bottom: 20px;
    border-bottom: 1px solid rgba(82,195,6,0.3)
}

.wcu-grid-icon {
    height: 80px;
    width: 80px;
    line-height: 80px;
    background: var(--theme-color);
    text-align: center;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none
}

.wcu-grid-icon img {
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.wcu-grid-content {
    color: var(--light-color);
    margin-bottom: -0.3em
}

.wcu-grid:hover .wcu-grid-icon img {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

@media (max-width: 575px) {
    .wcu-grid {
        display:block
    }

    .wcu-grid .wcu-grid-icon {
        margin-bottom: 20px
    }
}

.wcu-img-4 {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    z-index: 0;
    width: 46%
}

.wcu-img-4 img {
    height: 100%;
    width: 100%;
    object-fit: cover;
    object-position: top left
}

.wcu-img-4 .wcu-grid {
    position: absolute;
    left: 0;
    bottom: 0;
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    background: var(--theme-color);
    padding: 28px 30px 24px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.wcu-img-4 .wcu-grid_year {
    color: var(--white-color);
    font-size: 74px;
    font-weight: 700;
    margin-bottom: 0;
    line-height: normal
}

.wcu-img-4 .wcu-grid_text {
    font-size: 18px;
    font-weight: 500;
    color: var(--white-color);
    font-family: var(--title-font);
    margin-bottom: 0
}

.wcu-img-4 .wcu-grid_title {
    color: var(--white-color);
    margin-bottom: 0;
    font-size: 24px;
    font-weight: 600
}

@media (max-width: 1199px) {
    .wcu-img-4 .wcu-grid .wcu-grid_year {
        font-size:54px
    }
}

@media (max-width: 767px) {
    .wcu-img-4 .wcu-grid {
        padding:23px 25px 21px
    }

    .wcu-img-4 .wcu-grid .wcu-grid_year {
        font-size: 44px
    }

    .wcu-img-4 .wcu-grid .wcu-grid_title {
        font-size: 20px
    }
}

@media (max-width: 375px) {
    .wcu-img-4 .wcu-grid .wcu-grid_title {
        font-size:18px
    }
}

@media (max-width: 991px) {
    .wcu-img-4 {
        position:relative;
        width: 100%;
        top: -80px
    }
}

.wcu-skill-wrap {
    border-top: 1px solid var(--border-color);
    padding-top: 40px;
    margin-top: 40px
}

.skill-feature:not(:last-child) {
    margin-bottom: 25px
}

.skill-feature_title,.skill-feature .progress-value {
    font-size: 16px;
    font-weight: 400;
    margin-bottom: 9px;
    margin-top: -0.2em;
    font-family: var(--body-font);
    color: var(--title-color)
}

.skill-feature .progress {
    position: relative;
    height: 10px;
    background-color: var(--border-color);
    overflow: visible;
    border-radius: 0px
}

.skill-feature .progress-bar {
    background-color: var(--theme-color);
    height: 4px;
    margin: 3px;
    border-radius: 0px;
    position: relative;
    overflow: visible;
    position: relative
}

.skill-feature .progress-bar:after {
    position: absolute;
    content: '';
    height: 10px;
    width: 1px;
    background: var(--theme-color);
    right: 0
}

.skill-feature .progress-value {
    position: absolute;
    top: -31px;
    right: 0
}

.skill-feature.style2:not(:last-child) {
    margin-bottom: 30px
}

.skill-feature.style2 .progress-value,.skill-feature.style2 .skill-feature_title {
    color: var(--body-color)
}

.skill-feature.style2 .progress {
    background: #4D5765;
    height: 6px;
    border-radius: 10px
}

.skill-feature.style2 .progress-bar {
    margin: 0;
    border-radius: 10px
}

.skill-feature.style2 .progress-bar:after {
    display: none
}

.skill-feature.style3:not(:last-child) {
    margin-bottom: 30px
}

.skill-feature.style3 .progress-value,.skill-feature.style3 .skill-feature_title {
    color: var(--title-color);
    font-weight: 600;
    font-size: 18px;
    font-family: var(--title-font)
}

.skill-feature.style3 .progress {
    background: #E4E4E4;
    height: 8px;
    border-radius: 10px
}

.skill-feature.style3 .progress-bar {
    margin: 0;
    border-radius: 10px;
    height: 100%
}

.skill-feature.style3 .progress-bar:after {
    display: none
}

.mission-grid {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    gap: 80px
}

.mission-grid .mission-img {
    -webkit-box-flex: 586px;
    -webkit-flex: 586px;
    -ms-flex: 586px;
    flex: 586px;
    border-radius: 0px;
    overflow: hidden
}

.mission-grid .mission-img img {
    width: 100%
}

.mission-grid .mission-img .play-btn {
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%)
}

.mission-grid .mission-content {
    -webkit-box-flex: 554px;
    -webkit-flex: 554px;
    -ms-flex: 554px;
    flex: 554px
}

.mission-grid .mission-title {
    margin-bottom: 22px
}

.mission-grid .mission-text {
    margin-bottom: 25px
}

.mission-grid .checklist {
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--border-color)
}

.mission-grid .checklist ul {
    display: grid;
    grid-template-columns: auto auto;
    -webkit-box-align: baseline;
    -webkit-align-items: baseline;
    -ms-flex-align: baseline;
    align-items: baseline
}

.mission-grid.style2 {
    gap: 40px
}

.mission-grid.style2 .mission-img {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none
}

@media (max-width: 1299px) {
    .mission-grid.style2 .mission-img {
        -webkit-box-flex:445px;
        -webkit-flex: 445px;
        -ms-flex: 445px;
        flex: 445px
    }
}

@media (max-width: 1199px) {
    .mission-grid.style2 {
        display:block
    }

    .mission-grid.style2 .mission-img {
        margin-bottom: 30px
    }
}

.mission-feature {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 10px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.mission-feature-wrap {
    display: grid;
    grid-template-columns: auto auto
}

.mission-feature_icon {
    min-width: 50px
}

.mission-feature_subtitle {
    font-size: 14px;
    color: var(--theme-color);
    margin-bottom: 0
}

.mission-feature_title {
    font-size: 18px;
    margin-bottom: 0
}

@media (max-width: 1399px) {
    .mission-grid {
        gap:40px
    }

    .tab-menu1 {
        margin-bottom: 40px
    }
}

@media (max-width: 991px) {
    .mission-grid {
        -webkit-box-orient:vertical;
        -webkit-box-direction: normal;
        -webkit-flex-direction: column;
        -ms-flex-direction: column;
        flex-direction: column;
        -webkit-box-align: stretch;
        -webkit-align-items: stretch;
        -ms-flex-align: stretch;
        align-items: stretch;
        gap: 30px
    }

    .mission-grid .mission-img {
        -webkit-box-flex: 1;
        -webkit-flex: 1;
        -ms-flex: 1;
        flex: 1
    }

    .mission-grid .mission-content {
        -webkit-box-flex: 1;
        -webkit-flex: 1;
        -ms-flex: 1;
        flex: 1
    }
}

@media (max-width: 420px) {
    .tab-menu1 button {
        -webkit-box-flex:50%;
        -webkit-flex: 50%;
        -ms-flex: 50%;
        flex: 50%;
        margin-bottom: -1px
    }

    .mission-grid .checklist ul {
        grid-template-columns: auto
    }

    .mission-feature-wrap {
        grid-template-columns: auto;
        gap: 20px
    }
}

.wcu-history-wrap {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 21px
}

.wcu-history-wrap:not(:last-child) {
    margin-bottom: 30px
}

.wcu-history-wrap .history-wrap-date {
    background: var(--white-color);
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    text-align: center;
    color: var(--theme-color);
    font-size: 18px;
    font-weight: 600;
    font-family: var(--title-font);
    padding: 25px;
    margin-right: 20px;
    position: relative;
    max-width: 142px;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    -webkit-filter: drop-shadow(0px 0px 30px rgba(0,0,0,0.05));
    filter: drop-shadow(0px 0px 30px rgba(0,0,0,0.05))
}

.wcu-history-wrap .history-wrap-date:after {
    content: '';
    position: absolute;
    right: -20px;
    top: 50%;
    -webkit-transform: translate(0, -50%);
    -ms-transform: translate(0, -50%);
    transform: translate(0, -50%);
    width: 20px;
    height: 20px;
    border-left: solid 20px var(--white-color);
    border-bottom: solid 17px transparent;
    border-top: solid 17px transparent
}

@media (max-width: 767px) {
    .wcu-history-wrap {
        display:block
    }

    .wcu-history-wrap .history-wrap-date {
        max-width: none;
        display: block;
        margin-right: 0;
        margin-bottom: 30px
    }

    .wcu-history-wrap .history-wrap-date:after {
        bottom: -20px;
        top: auto;
        right: 50%;
        width: 20px;
        height: 20px;
        -webkit-transform: translate(50%, 0);
        -ms-transform: translate(50%, 0);
        transform: translate(50%, 0);
        border-top: solid 20px var(--white-color);
        border-left: solid 17px transparent;
        border-right: solid 17px transparent;
        border-bottom: 0
    }
}

.history-card {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    background: var(--white-color);
    -webkit-filter: drop-shadow(0px 0px 30px rgba(0,0,0,0.05));
    filter: drop-shadow(0px 0px 30px rgba(0,0,0,0.05));
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.history-card .history-card-img {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    height: 100%
}

.history-card .history-card-img img {
    height: 100%;
    max-width: 140px;
    object-fit: cover
}

.history-card .history-card-details {
    padding: 30px
}

.history-card .history-card-title {
    font-size: 18px;
    font-weight: 600;
    margin-top: -0.3em;
    margin-bottom: 10px
}

.history-card .history-card-text {
    margin-bottom: -0.5em
}

@media (max-width: 575px) {
    .history-card {
        display:block
    }

    .history-card .history-card-img img {
        max-width: none;
        width: 100%;
        max-height: 200px
    }
}

.wcu-img-5 {
    position: relative;
    height: 100%
}

.wcu-img-5 .img1 {
    padding-bottom: 80px
}

.wcu-img-5 .img1 img {
    border-radius: 10px
}

.wcu-img-5 .mission-box {
    box-shadow: 0px 10px 20px rgba(7,36,95,0.06);
    border-radius: 10px;
    background-color: var(--white-color);
    padding: 30px;
    position: absolute;
    bottom: 0;
    right: -30px;
    max-width: 395px
}

@media (max-width: 1399px) {
    .wcu-img-5 .mission-box {
        right:-12px
    }
}

@media (max-width: 1199px) {
    .wcu-img-5 {
        margin-bottom:20px
    }

    .wcu-img-5 .img1 img {
        max-width: 700px;
        width: 100%
    }
}

@media (max-width: 575px) {
    .wcu-img-5 .img1 img {
        height:460px
    }
}

.mission-box {
    width: 100%
}

.mission-box-wrap {
    width: 100%
}

.mission-box .mission-title {
    margin-bottom: 10px;
    margin-top: -0.2em
}

.mission-box .mission-text {
    margin-bottom: 18px
}

.mission-box .mission-img img {
    max-width: -webkit-fit-content;
    max-width: -moz-fit-content;
    max-width: fit-content;
    border-radius: 5px
}

.mission-box .checklist-wrap {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 20px
}

.mission-box .checklist-wrap .checklist.style5 li:not(:last-child) {
    margin-bottom: 5px
}

@media (max-width: 375px) {
    .mission-box .checklist-wrap {
        -webkit-flex-wrap:wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }
}

.video-box1 {
    position: relative;
    z-index: 2;
    line-height: 0
}

.video-box1 .img1 {
    border-radius: 10px;
    overflow: hidden;
    display: inline-block;
    position: absolute;
    top: 0;
    left: 0
}

.video-box1 .bg-shape {
    border-radius: 10px;
    overflow: hidden;
    display: inline-block;
    z-index: -1;
    width: 79%
}

.video-box1 .play-bg {
    display: inline-block;
    padding: 50px 50px 70px 50px;
    border-radius: 10px;
    position: absolute;
    bottom: 0;
    left: 21%
}

.video-box1 .play-btn:hover:before,.video-box1 .play-btn:hover:after {
    background-color: var(--title-color)
}

.video-box1 .play-btn:hover i {
    background-color: var(--title-color)
}

.mission-area {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

@media (max-width: 1199px) {
    .video-box1 {
        margin-bottom:40px
    }
}

@media (max-width: 767px) {
    .video-box1 .img1 {
        width:95%
    }

    .video-box1 .bg-shape {
        width: 88%
    }

    .video-box1 .play-bg {
        left: 12%;
        padding: 40px 40px 50px 40px
    }
}

@media (max-width: 575px) {
    .mission-area {
        -webkit-flex-wrap:wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }
}

.why-bg-smoke-shape {
    width: calc(var(--main-container));
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
    transform: translate(-50%, 0);
    height: 302px;
    background: #F8F8F8
}

.client-review-wrap {
    line-height: 26px;
    max-width: 465px;
    margin-bottom: 34px
}

.client-review-wrap .star-rating {
    margin-bottom: 8px
}

.client-review-wrap .star-rating span:before {
    color: var(--theme-color)
}

.client-review-wrap span {
    text-decoration: underline;
    text-underline-offset: 3px
}

.feature-box2 {
    background-color: var(--white-color);
    padding: 80px 0 0 80px;
    margin-left: calc(-24px - 92px);
    position: relative;
    border-radius: 10px 0 0 0;
    height: 100%
}

.single-feature-box {
    background: #F8F8F8;
    border-radius: 10px;
    padding: 25px;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 15px;
    max-width: 340px
}

.single-feature-box .box-title {
    margin-bottom: 7px
}

.single-feature-box_text {
    margin-bottom: -0.5em
}

.video-box2 {
    position: relative
}

.video-box2 .img1 {
    border-radius: 10px;
    overflow: hidden
}

.video-box2 .play-bg {
    position: absolute;
    top: 50%;
    left: 50%;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%)
}

.video-box2 .play-bg i {
    width: var(--icon-size, 70px);
    height: var(--icon-size, 70px);
    line-height: var(--icon-size, 70px);
    font-size: var(--icon-font-size, 22px)
}

.video-box2 .play-bg i:before {
    margin-left: -0.1em
}

@media (max-width: 1200px) {
    .why-bg-smoke-shape {
        width:1116px
    }

    .feature-box2 {
        padding: 45px 0 0 45px
    }
}

@media (max-width: 1199px) {
    .why-bg-smoke-shape {
        width:936px
    }

    .single-feature-box .box-title {
        font-size: 22px
    }
}

@media (max-width: 991px) {
    .feature-box2 {
        margin:0;
        padding: 0;
        height: auto
    }

    .video-box2 {
        display: inline-block
    }
}

@media (max-width: 1500px) {
    .why-10-fan-anime {
        display:none
    }
}

.th-video3 {
    position: relative;
    z-index: 2
}

.th-video3 img {
    width: 100%
}

.th-video3 .play-btn {
    position: absolute;
    top: 22%;
    right: 25%
}

@media (max-width: 1199px) {
    .th-video3 {
        margin-bottom:30px
    }

    .th-video3 .play-btn {
        top: 24%;
        right: 28%
    }
}

@media (max-width: 991px) {
    .th-video3 .play-btn {
        top:23%;
        right: 26%
    }
}

@media (max-width: 575px) {
    .th-video3 .play-btn {
        top:20%;
        right: 24%;
        --icon-size: 50px
    }
}

.tab-menu1 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 24px
}

.tab-menu1 button {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    font-size: 24px;
    font-weight: 600;
    font-family: var(--title-font);
    color: var(--title-color);
    background-color: var(--white-color);
    position: relative;
    z-index: 2;
    padding: 27px;
    text-align: center;
    border: 0;
    margin: 0;
    box-shadow: 0px 6px 30px 0px rgba(0,0,0,0.05);
    cursor: pointer
}

.tab-menu1 button:before {
    content: '';
    height: 100%;
    width: 100%;
    background-color: var(--theme-color);
    position: absolute;
    top: 0;
    left: 0;
    -webkit-transform: scaleX(0);
    -ms-transform: scaleX(0);
    transform: scaleX(0);
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    z-index: -1
}

.tab-menu1 button:hover {
    color: var(--title-color)
}

.tab-menu1 button.active {
    color: var(--white-color)
}

.tab-menu1 button.active:before {
    -webkit-transform: scaleX(1);
    -ms-transform: scaleX(1);
    transform: scaleX(1)
}

@media (max-width: 1199px) {
    .tab-menu1 button {
        font-size:20px
    }
}

@media (max-width: 991px) {
    .tab-menu-wrap {
        margin-bottom:30px
    }

    .tab-menu1 {
        gap: 25px
    }

    .tab-menu1 button {
        -webkit-box-flex: 1;
        -webkit-flex: auto;
        -ms-flex: auto;
        flex: auto;
        font-size: 16px;
        padding: 16px 15px
    }
}

@media (max-width: 767px) {
    .tab-menu-wrap .shape {
        display:none
    }

    .tab-menu1 {
        gap: 20px;
        -webkit-flex-wrap: wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }
}

.tab-menu2 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 0px
}

.tab-menu2 button {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    font-size: 20px;
    font-weight: 600;
    color: var(--title-color);
    background-color: var(--white-color);
    position: relative;
    z-index: 2;
    padding: 20px;
    text-align: center;
    border: 1px solid var(--border-color);
    margin: 0;
    margin-right: -1px;
    cursor: pointer
}

.tab-menu2 button:before {
    content: '';
    height: 100%;
    width: 100%;
    background-color: var(--theme-color);
    position: absolute;
    top: 0;
    left: 0;
    -webkit-transform: scaleX(0);
    -ms-transform: scaleX(0);
    transform: scaleX(0);
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    z-index: -1
}

.tab-menu2 button:hover {
    color: var(--title-color)
}

.tab-menu2 button.active {
    color: var(--white-color)
}

.tab-menu2 button.active:before {
    -webkit-transform: scaleX(1);
    -ms-transform: scaleX(1);
    transform: scaleX(1)
}

@media (max-width: 991px) {
    .tab-menu2 {
        gap:25px
    }

    .tab-menu2 button {
        -webkit-box-flex: 1;
        -webkit-flex: auto;
        -ms-flex: auto;
        flex: auto;
        font-size: 16px;
        padding: 16px 15px
    }
}

@media (max-width: 767px) {
    .tab-menu2 {
        gap:6px 20px;
        -webkit-flex-wrap: wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }
}

.tab-menu3 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
    gap: 19px;
    border-right: 1px solid rgba(0,15,87,0.2);
    margin-right: 30px;
    padding-right: 30px
}

.tab-menu3 button {
    font-size: 30px;
    color: var(--title-color);
    font-weight: 700;
    width: 65px;
    height: 65px;
    line-height: 60px;
    text-align: center;
    padding: 0 4px 0 0;
    border: none;
    background-color: transparent;
    background-image: url("data:image/svg+xml,%3Csvg width='65' height='65' viewBox='0 0 65 65' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath opacity='0.2' d='M5 10C5 7.23858 7.23858 5 10 5H35H47.9289C49.255 5 50.5268 5.52678 51.4645 6.46447L63.5355 18.5355C64.4732 19.4732 65 20.745 65 22.0711V35V60C65 62.7614 62.7614 65 60 65H10C7.23858 65 5 62.7614 5 60V10Z' fill='%23FF4C13'/%3E%3Cpath d='M0.5 5C0.5 2.51472 2.51472 0.5 5 0.5H30H42.9289C44.1224 0.5 45.267 0.974106 46.1109 1.81802L58.182 13.8891C59.0259 14.733 59.5 15.8776 59.5 17.0711V30V55C59.5 57.4853 57.4853 59.5 55 59.5H5C2.51472 59.5 0.5 57.4853 0.5 55V5Z' fill='%23F8F8F8' stroke='%23FF4C13'/%3E%3C/svg%3E");
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.tab-menu3 button.active {
    color: var(--white-color);
    background-image: url("data:image/svg+xml,%3Csvg width='65' height='65' viewBox='0 0 65 65' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 5C0 2.23858 2.23858 0 5 0H30H42.9289C44.255 0 45.5268 0.526784 46.4645 1.46447L58.5355 13.5355C59.4732 14.4732 60 15.745 60 17.0711V30V55C60 57.7614 57.7614 60 55 60H5C2.23858 60 0 57.7614 0 55V5Z' fill='%23FF4C13'/%3E%3Cpath opacity='0.2' d='M5 10C5 7.23858 7.23858 5 10 5H35H47.9289C49.255 5 50.5268 5.52678 51.4645 6.46447L63.5355 18.5355C64.4732 19.4732 65 20.745 65 22.0711V35V60C65 62.7614 62.7614 65 60 65H10C7.23858 65 5 62.7614 5 60V10Z' fill='%23FF4C13'/%3E%3C/svg%3E")
}

@media (max-width: 1399px) {
    .tab-menu3 {
        margin-right:10px;
        padding-right: 10px
    }
}

@media (max-width: 1199px) {
    .tab-menu3 {
        margin-right:40px;
        padding-right: 40px
    }
}

@media (max-width: 575px) {
    .tab-menu3 {
        -webkit-box-orient:horizontal;
        -webkit-box-direction: normal;
        -webkit-flex-direction: row;
        -ms-flex-direction: row;
        flex-direction: row;
        padding-right: 0;
        margin-right: 0;
        border-right: none;
        padding-bottom: 25px;
        margin-bottom: 25px;
        border-bottom: 1px solid rgba(0,15,87,0.2);
        gap: 30px;
        width: 100%
    }
}

.tab-menu4 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    margin-bottom: 30px;
    position: relative;
    padding-bottom: 6px;
    text-align: center
}

.tab-menu4 button {
    color: var(--title-color);
    font-weight: 600;
    background-color: transparent;
    border: none;
    padding: 0;
    position: relative;
    margin-right: 30px
}

.tab-menu4 button:after {
    content: "";
    height: 18px;
    width: 2px;
    background-color: var(--body-color);
    opacity: 0.3;
    position: absolute;
    top: 50%;
    right: -15px;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%)
}

.tab-menu4 button:last-of-type {
    margin-right: 0
}

.tab-menu4 button:last-of-type:after {
    display: none
}

.tab-menu4 button:hover,.tab-menu4 button.active {
    color: var(--theme-color)
}

.tab-menu4 .indicator {
    position: absolute;
    bottom: 0 !important;
    left: var(--pos-x);
    top: unset !important;
    width: var(--width-set);
    background-color: var(--theme-color);
    height: 3px !important;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.tab-menu4 .indicator:after {
    content: "";
    width: 0;
    height: 0;
    border-style: solid;
    border-width: 8px 8px 0 8px;
    border-color: var(--theme-color) transparent transparent transparent;
    position: absolute;
    top: 100%;
    left: 50%;
    -webkit-transform: translateX(-50%);
    -ms-transform: translateX(-50%);
    transform: translateX(-50%)
}

.gallery-img {
    position: relative;
    z-index: 2;
    border-radius: 0px;
    overflow: hidden
}

.gallery-img img {
    width: 100%;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.gallery-img:before {
    content: "";
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    background-color: var(--title-color);
    visibility: hidden;
    opacity: 0;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    z-index: 1
}

.gallery-btn {
    background-color: var(--theme-color);
    color: var(--white-color);
    width: 50px;
    height: 50px;
    line-height: 50px;
    border-radius: 0px;
    position: absolute;
    top: 50%;
    font-size: 20px;
    left: 50%;
    -webkit-transform: translate(-50%, 50%);
    -ms-transform: translate(-50%, 50%);
    transform: translate(-50%, 50%);
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    text-align: center;
    visibility: hidden;
    opacity: 0;
    z-index: 2
}

.gallery-btn:hover {
    background-color: var(--white-color);
    color: var(--theme-color)
}

.gallery-card {
    position: relative
}

.gallery-card .gallery-content {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    padding: 30px 15px;
    text-align: center;
    z-index: 3;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    visibility: visible;
    opacity: 0;
    -webkit-transform: translateY(50px);
    -ms-transform: translateY(50px);
    transform: translateY(50px);
    -webkit-transition-delay: 0.1s;
    transition-delay: 0.1s
}

.gallery-card .gallery-title {
    font-size: 24px;
    font-weight: 600;
    color: var(--white-color);
    margin-bottom: 0
}

.gallery-card .gallery-tag {
    color: var(--white-color);
    font-weight: 500;
    display: block;
    margin-bottom: 4px
}

.gallery-card:hover .gallery-img:before {
    visibility: visible;
    opacity: 0.5
}

.gallery-card:hover .gallery-img img {
    -webkit-transform: scale(1.06);
    -ms-transform: scale(1.06);
    transform: scale(1.06)
}

.gallery-card:hover .gallery-btn {
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    visibility: visible;
    opacity: 1
}

.gallery-card:hover .gallery-content {
    visibility: visible;
    opacity: 1;
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0)
}

@media (max-width: 1199px) {
    .gallery-card .gallery-tag {
        margin-bottom:0
    }
}

@media (max-width: 991px) {
    .gallery-img img {
        min-height:320px;
        object-fit: cover
    }
}

.faq-area-1 {
    padding-top: 120px
}

@media (max-width: 1199px) {
    .faq-area-1 {
        padding-top:20px
    }
}

.accordion-card {
    margin-bottom: 25px;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    box-shadow: 0px 10px 30px 0px rgba(0,0,0,0.05)
}

.accordion-card .accordion-button {
    font-size: 18px;
    font-weight: 500;
    font-family: var(--title-font);
    border: 0;
    color: var(--white-color);
    background-color: #282C38;
    border-radius: 5px;
    padding: 15px 60px 15px 25px;
    min-height: 55px;
    gap: 10px;
    margin-bottom: 0;
    text-align: left;
    -webkit-transition: 0.3s;
    transition: 0.3s;
    position: relative
}

.accordion-card .accordion-button:after {
    content: "\2b";
    width: 55px;
    height: 55px;
    height: 100%;
    line-height: 1;
    background-image: none;
    font-family: var(--icon-font);
    color: var(--theme-color);
    font-weight: 900;
    font-size: 1em;
    display: grid;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    text-align: center;
    position: absolute;
    top: 0;
    right: 8px
}

.accordion-card .accordion-button:focus {
    outline: none;
    box-shadow: none
}

.accordion-card .accordion-button:not(.collapsed) {
    color: var(--white-color);
    background-color: #282C38;
    box-shadow: none;
    border-radius: 5px 5px 0 0
}

.accordion-card .accordion-button:not(.collapsed):after {
    content: "\f068"
}

.accordion-card .accordion-collapse {
    border: none
}

.accordion-card .accordion-body {
    box-shadow: 0px 5px 15px rgba(42,77,113,0.04);
    border-radius: 0 0 5px 5px;
    background-color: #282C38;
    padding: 0px 25px 30px 25px
}

.accordion-card .faq-text {
    color: #050505d6;
    margin-bottom: -0.48em
}

.accordion-card .faq-img {
    height: 100%
}

.accordion-card .faq-img img {
    height: 100%;
    object-fit: cover
}

.accordion-card:last-child {
    margin-bottom: 0
}

@media (max-width: 575px) {
    .accordion-card .accordion-button {
        font-size:16px
    }
}

.accordion-card.style2 {
    box-shadow: none
}

.accordion-card.style2 .accordion-button {
    background: #F4F4F4;
    color: var(--title-color);
    border-radius: 0
}

.accordion-card.style2 .accordion-button:after {
    content: "\f063"
}

.accordion-card.style2 .accordion-body {
    border: 1px solid #E4E4E4;
    border-top: 0;
    background: var(--white-color);
    border-radius: 0;
    padding: 30px;
    box-shadow: none
}

.accordion-card.style2 .faq-text {
    color: #4D5765;
    margin-top: -0.3em
}

.faq-img {
    margin-left: -250px
}

@media (max-width: 1500px) {
    .faq-img {
        margin-left:-80px
    }
}

@media (max-width: 1399px) {
    .faq-img {
        margin-left:0
    }
}

@media (max-width: 1500px) {
    .faq-3-fan-anime {
        display:none
    }
}

.accordion-card.style3 {
    margin-bottom: 20px;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.accordion-card.style3 .accordion-button {
    font-size: 18px;
    font-weight: 500;
    font-family: var(--title-font);
    border: 0;
    color: var(--title-color);
    background-color: rgba(0,15,87,0.1);
    box-shadow: 0px 5px 15px rgba(42,77,113,0.04);
    border-radius: 0;
    padding: 14.5px 60px 14.5px 25px;
    min-height: 55px;
    gap: 10px;
    margin-bottom: 0;
    text-align: left;
    -webkit-transition: 0.3s;
    transition: 0.3s;
    position: relative
}

.accordion-card.style3 .accordion-button:after {
    content: "\f063";
    height: 100%;
    width: 70px;
    line-height: 1;
    background-image: none;
    background-color: var(--theme-color);
    font-family: var(--icon-font);
    color: var(--white-color);
    font-weight: 700;
    font-size: 1em;
    display: grid;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    text-align: center;
    position: absolute;
    top: 0;
    right: 0;
    -webkit-clip-path: polygon(20px 0%, 100% 0, 100% 100%, 0% 100%);
    clip-path: polygon(20px 0%, 100% 0, 100% 100%, 0% 100%);
    padding-left: 10px;
    -webkit-transition: 0.3s ease-in-out;
    transition: 0.3s ease-in-out
}

.accordion-card.style3 .accordion-button:focus {
    outline: none;
    box-shadow: none
}

.accordion-card.style3 .accordion-button:not(.collapsed) {
    color: var(--title-color);
    background-color: rgba(0,15,87,0.1);
    box-shadow: none;
    border-radius: 0
}

.accordion-card.style3 .accordion-button:not(.collapsed):after {
    content: '\f062';
    -webkit-transform: rotate(0);
    -ms-transform: rotate(0);
    transform: rotate(0)
}

.accordion-card.style3 .accordion-collapse {
    border: none
}

.accordion-card.style3 .accordion-body {
    box-shadow: 0px 5px 15px rgba(42,77,113,0.04);
    border-radius: 0;
    background-color: var(--white-color);
    border: 1px solid rgba(0,15,87,0.1);
    padding: 23px 25px 30px 25px
}

.accordion-card.style3 .faq-text {
    margin-bottom: -0.48em
}

.accordion-card.style3 .faq-img {
    height: 100%
}

.accordion-card.style3 .faq-img img {
    height: 100%;
    object-fit: cover
}

.accordion-card.style3:last-child {
    margin-bottom: 0
}

@media (max-width: 575px) {
    .accordion-card.style3 .accordion-button {
        font-size:16px
    }
}

.cta-area-1 {
    position: relative;
    background: var(--white-color);
    box-shadow: 0px 10px 30px 0px rgba(0,0,0,0.07);
    margin-top: -245px
}

.cta-area-1 .contact-form-wrap {
    background: var(--white-color)
}

.cta-area-1 .contact-form-wrap .title {
    margin-top: -0.3em;
    font-weight: 700;
    margin-bottom: 20px
}

@media (max-width: 1199px) {
    .cta-area-1 .contact-form-wrap {
        margin-top:0
    }
}

.cta-wrap {
    padding: 40px;
    position: relative;
    z-index: 3
}

.cta-wrap .sec-title {
    font-size: 30px;
    line-height: 40px
}

.cta-wrap .sec-text {
    margin: 30px 0
}

.cta-wrap .cta-link-wrap {
    border-top: 1px solid rgba(255,255,255,0.5);
    border-bottom: 1px solid rgba(255,255,255,0.5);
    gap: 30px
}

.cta-wrap .cta-link-wrap .cta-link {
    padding: 20px 0
}

.cta-wrap .cta-link-wrap .cta-link ~ .cta-link {
    border-left: 1px solid rgba(255,255,255,0.5);
    padding-left: 30px
}

@media (max-width: 1199px) {
    .cta-wrap .cta-link-wrap {
        display:-webkit-inline-box;
        display: -webkit-inline-flex;
        display: -ms-inline-flexbox;
        display: inline-flex;
        margin-right: 30px;
        margin-bottom: 0
    }
}

@media (max-width: 991px) {
    .cta-wrap .cta-link-wrap {
        display:-webkit-box;
        display: -webkit-flex;
        display: -ms-flexbox;
        display: flex;
        margin-bottom: 40px;
        -webkit-flex-wrap: wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }
}

@media (max-width: 575px) {
    .cta-wrap .cta-link-wrap {
        margin-right:0;
        border: 0;
        display: block
    }

    .cta-wrap .cta-link-wrap .cta-link {
        padding: 0
    }

    .cta-wrap .cta-link-wrap .cta-link ~ .cta-link {
        padding-left: 0;
        border-left: 0;
        border-top: 1px solid rgba(255,255,255,0.5);
        padding-top: 30px;
        margin-top: 30px
    }
}

.cta-wrap .th-btn {
    margin-left: auto;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none
}

.cta-link-wrap {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 40px
}

.cta-link {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 10px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.cta-link-icon {
    width: var(--icon-size, 36px);
    height: var(--icon-size, 36px);
    line-height: var(--icon-size, 36px);
    background: var(--white-color);
    border-radius: 50%;
    text-align: center;
    color: var(--theme-color);
    font-size: 18px;
    position: relative
}

.cta-link-icon:after,.cta-link-icon:before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    background-color: var(--white-color);
    z-index: -1;
    border-radius: 50%;
    -webkit-transition: all ease 0.4s;
    transition: all ease 0.4s
}

.cta-link-icon:after {
    -webkit-animation-delay: 2s;
    animation-delay: 2s
}

.cta-link p {
    font-size: 14px;
    font-weight: 400;
    color: var(--white-color);
    margin-bottom: 2px;
    margin-top: -0.4em
}

.cta-link .cta-single-link {
    font-size: 18px;
    font-weight: 600;
    font-family: var(--title-font);
    color: var(--white-color)
}

.cta-area-2 {
    background: #F4F4F4
}

.cta-area-2 .cta-text {
    font-size: 18px;
    font-weight: 600;
    font-family: var(--title-font);
    color: #4D5765;
    margin-bottom: -0.5em
}

.process-card {
    background: var(--white-color);
    box-shadow: 0px 6px 30px 0px rgba(0,0,0,0.06);
    text-align: center;
    position: relative;
    margin-top: 50px;
    padding: 85px 30px 40px;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    z-index: 1
}

.process-card_icon {
    width: 100px;
    height: 100px;
    line-height: 100px;
    border-radius: 0;
    background: var(--white-color);
    position: absolute;
    top: -50px;
    left: 50%;
    -webkit-transform: translateX(-50%);
    -ms-transform: translateX(-50%);
    transform: translateX(-50%);
    -webkit-transition: 0.4s;
    transition: 0.4s;
    box-shadow: 0px 6px 30px 0px rgba(0,0,0,0.1)
}

.process-card_icon:after {
    content: '';
    position: absolute;
    left: 50%;
    bottom: -12px;
    height: 12px;
    width: 22px;
    background: transparent;
    border-top: 12px solid var(--white-color);
    border-right: 11px solid transparent;
    border-left: 11px solid transparent;
    border-bottom: 0;
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
    transform: translate(-50%, 0);
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.process-card_icon img {
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.process-card_bg-shape {
    position: absolute;
    inset: 0;
    opacity: 0.05;
    z-index: -1
}

.process-card_subtitle {
    font-size: 14px;
    text-transform: uppercase;
    margin-bottom: 10px;
    display: block
}

.process-card_title {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 15px;
    display: block;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.process-card_text {
    margin-bottom: -0.5em
}

.process-card:hover {
    background: var(--title-color);
    --body-color: #8993A1
}

.process-card:hover .process-card_bg-shape {
    opacity: 0.15
}

.process-card:hover .process-card_icon {
    background: var(--theme-color)
}

.process-card:hover .process-card_icon:after {
    border-top: 12px solid var(--theme-color)
}

.process-card:hover .process-card_icon img {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

.process-card:hover .process-card_title {
    color: var(--white-color)
}

.process-card.style2 {
    padding: 0;
    background: transparent;
    box-shadow: none;
    text-align: left;
    margin: 0
}

.process-card.style2 .process-card_details {
    padding: 176px 30px 30px;
    margin-top: -150px;
    margin-left: 80px;
    position: relative;
    z-index: -1;
    background-size: calc(100% + 60px) calc(100% + 72px);
    -webkit-filter: drop-shadow(0px 6px 30px rgba(0,0,0,0.06));
    filter: drop-shadow(0px 6px 30px rgba(0,0,0,0.06))
}

.process-card.style2 .process-card_title {
    margin-bottom: 25px;
    color: var(--title-color)
}

.process-card.style2 .checklist {
    margin-bottom: 30px
}

.process-card.style2 .checklist li {
    font-weight: 400;
    color: var(--body-color)
}

.process-card.style2 .checklist li:not(:last-child) {
    margin-bottom: 5px
}

.process-card.style2 .th-btn {
    padding: 17px 20px
}

@media (max-width: 575px) {
    .process-card.style2 .process-card_details {
        margin-left:40px
    }
}

.process-card2 {
    text-align: center;
    max-width: 187px;
    height: 187px;
    background-color: var(--white-color);
    border: 3px solid var(--theme-color);
    margin: 17px;
    position: relative;
    border-radius: 9999px;
    padding: 42px 6px
}

.process-card2-wrap {
    position: relative
}

.process-card2-wrap:after {
    content: '';
    height: 42px;
    width: 116px;
    background-image: url("data:image/svg+xml,%3Csvg width='116' height='42' viewBox='0 0 116 42' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath opacity='0.3' d='M115.551 36.6652C111.559 29.4285 108.897 21.8539 105.787 14.2467C104.978 12.2611 102.253 13.5251 102.477 15.3846C102.847 18.5361 103.56 21.6643 104.519 24.7352C98.3211 19.1913 90.7487 14.5818 83.8058 11.0206C74.4953 6.24801 64.2973 2.90809 53.9555 1.36405C36.8086 -1.19473 13.0193 2.07937 1.18365 16.1594C0.506835 16.9694 1.66463 18.0051 2.48375 17.6096C10.8028 13.6619 18.1327 9.40841 27.3743 7.72378C36.4214 6.07799 46.0699 6.15641 55.1077 7.96139C64.6604 9.87409 73.5052 13.8715 81.802 18.943C88.7376 23.1882 94.6187 28.5144 100.852 33.5113C95.1561 33.508 89.4292 34.5084 84.7225 36.8576C81.9555 38.2404 83.4736 42.4769 86.4885 41.9425C91.0648 41.1333 95.3424 39.7652 100.05 39.5838C104.415 39.4115 108.626 39.9863 112.924 40.6872C114.981 41.0253 116.495 38.3804 115.551 36.6652Z' fill='white'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-size: contain;
    position: absolute;
    top: 0;
    left: calc(100% - 30px)
}

.process-card2-wrap:nth-child(even):after {
    top: unset;
    bottom: 0;
    -webkit-transform: rotateX(180deg);
    transform: rotateX(180deg)
}

.process-card2-wrap:last-child:after {
    display: none
}

.process-card2:before {
    content: '';
    width: 216px;
    height: 216px;
    position: absolute;
    top: -17px;
    left: -17px;
    border: 4px dotted var(--theme-color);
    border-radius: inherit
}

.process-card2_icon {
    width: 82px;
    height: 82px;
    line-height: 78px;
    border: 3px solid var(--white-color);
    background-color: var(--theme-color);
    border-radius: 50%;
    font-size: 34px;
    color: var(--white-color);
    position: absolute;
    top: -40px;
    left: -17px
}

.process-card2_icon i {
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.process-card2_title {
    font-size: 20px;
    margin-bottom: 8px;
    text-align: center
}

.process-card2_text {
    margin-bottom: 0;
    font-size: 14px
}

.process-card2:hover:before {
    -webkit-animation: spin 10s linear infinite;
    animation: spin 10s linear infinite
}

@media (max-width: 1300px) {
    .process-card2-wrap:after {
        left:calc(100% - 50px)
    }
}

@media (max-width: 1199px) {
    .process-card2 {
        margin:14px
    }

    .process-card2-wrap:after {
        height: 24px;
        left: calc(100% - 55px)
    }

    .process-card2-wrap:nth-child(even):after {
        left: calc(100% - 45px)
    }
}

@media (max-width: 991px) {
    .process-card2 {
        margin:14px auto
    }

    .process-card2-wrap:after {
        height: 42px;
        left: calc(100% - 68px)
    }

    .process-card2-wrap:nth-child(even):after {
        display: none
    }
}

@media (max-width: 767px) {
    .process-card2-wrap:after {
        height:32px
    }
}

@media (max-width: 575px) {
    .process-card2-wrap:after {
        display:none
    }
}

@media (max-width: 1600px) {
    .event-slider-1 .slick-arrow {
        display:none !important
    }
}

.event-meta {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 5px 20px
}

.event-meta p,.event-meta span,.event-meta a {
    margin-bottom: 0;
    font-size: 14px
}

.event-meta p i,.event-meta span i,.event-meta a i {
    margin-right: 5px;
    color: var(--theme-color)
}

.event-author {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 15px
}

.event-author .avater {
    max-width: 45px;
    border-radius: 999px;
    overflow: hidden
}

.event-author .author-name {
    font-size: 16px;
    font-weight: 500;
    color: var(--title-color)
}

.event-author .author-desig {
    font-size: 12px;
    margin-bottom: 0
}

.event-card {
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 30px;
    position: relative;
    padding: 40px;
    border-radius: 10px;
    background-color: var(--white-color);
    border: 1px solid var(--border-color);
    z-index: 2;
    margin-top: 67px
}

@media (max-width: 1500px) {
    .event-card {
        margin-left:30px;
        margin-top: 47px
    }
}

@media (max-width: 1299px) {
    .event-card {
        padding:30px;
        margin-top: 30px
    }
}

@media (max-width: 1199px) {
    .event-card {
        margin-top:0;
        margin-left: 0
    }
}

@media (max-width: 991px) {
    .event-card {
        margin-top:30px;
        margin-left: 30px
    }
}

@media (max-width: 320px) {
    .event-card {
        margin-left:0;
        margin-top: 0
    }
}

.event-card_img {
    overflow: hidden;
    -webkit-mask-size: 100% 100%;
    mask-size: 100% 100%;
    display: inline-block;
    position: absolute;
    top: -67px;
    left: -35px
}

.event-card_img img {
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

@media (max-width: 1500px) {
    .event-card_img {
        left:-30px
    }
}

@media (max-width: 1399px) {
    .event-card_img {
        width:180px;
        top: -47px
    }
}

@media (max-width: 1299px) {
    .event-card_img {
        width:140px;
        top: -30px
    }
}

@media (max-width: 1199px) {
    .event-card_img {
        position:initial;
        width: auto
    }
}

@media (max-width: 991px) {
    .event-card_img {
        position:absolute
    }
}

@media (max-width: 375px) {
    .event-card_img {
        width:155px
    }
}

@media (max-width: 320px) {
    .event-card_img {
        width:125px;
        position: initial
    }
}

.event-card .event-author {
    padding-left: 155px;
    margin-bottom: 30px
}

@media (max-width: 1399px) {
    .event-card .event-author {
        padding-left:135px
    }
}

@media (max-width: 1299px) {
    .event-card .event-author {
        padding-left:105px
    }
}

@media (max-width: 1199px) {
    .event-card .event-author {
        padding-left:0;
        margin-bottom: 20px
    }
}

@media (max-width: 991px) {
    .event-card .event-author {
        padding-left:160px;
        margin-bottom: 80px
    }
}

@media (max-width: 375px) {
    .event-card .event-author {
        padding-left:110px;
        margin-bottom: 40px
    }
}

@media (max-width: 320px) {
    .event-card .event-author {
        padding-left:0px;
        margin-bottom: 20px
    }
}

.event-card .event-meta {
    margin-top: -0.3em;
    margin-bottom: 10px
}

.event-card_title {
    font-size: 22px;
    font-weight: 600;
    margin-bottom: 25px
}

.event-card_title a {
    color: inherit
}

.event-card_title a:hover {
    color: var(--theme-color)
}

.event-card_bottom {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 15px 25px
}

.event-card .event-card-shape {
    position: absolute;
    right: 40px;
    bottom: 40px
}

@media (max-width: 1299px) {
    .event-card .event-card-shape {
        right:30px;
        bottom: 30px
    }
}

.event-card .th-btn {
    padding: 15.5px 27px
}

.event-card:hover .event-card_img img {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1)
}

.event-details .event-img {
    border-radius: 10px;
    overflow: hidden;
    margin-bottom: 40px
}

.event-details .event-img img {
    min-height: 300px;
    object-fit: cover
}

.event-details .checklist ul li {
    font-weight: 400;
    font-family: var(--body-font);
    color: var(--body-color)
}

.event-details .checklist ul li:before {
    font-weight: 400
}

.event-grid {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    margin-bottom: 50px;
    position: relative
}

.event-grid:last-of-type {
    margin-bottom: 0
}

.event-grid .event-img {
    width: 41.6666666667%;
    position: relative;
    height: 240px;
    border-radius: 10px
}

.event-grid .event-img img {
    width: -webkit-fit-content;
    width: -moz-fit-content;
    width: fit-content;
    height: 100%;
    object-fit: cover;
    border-radius: 10px
}

.event-grid .event-content {
    background-color: var(--white-color);
    width: 63%;
    box-shadow: 0px 4px 29px rgba(152,170,204,0.15);
    border-radius: 10px;
    padding: 60px 60px 60px 40px;
    position: absolute;
    bottom: 50%;
    right: 0;
    z-index: 3;
    -webkit-transform: translateY(50%);
    -ms-transform: translateY(50%);
    transform: translateY(50%);
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    margin-left: 40px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.event-grid .event-content .media-body {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none
}

.event-grid .event-content .event-bg-shape {
    position: absolute;
    left: -40px;
    top: 0;
    height: 100%;
    width: 100%;
    background: var(--white-color);
    z-index: -1;
    -webkit-mask-size: cover
}

@media (max-width: 1299px) {
    .event-grid .event-content {
        width:66%;
        padding: 50px 50px 50px 30px
    }
}

@media (max-width: 1199px) {
    .event-grid .event-content {
        width:73%;
        padding: 40px 40px 40px 20px
    }
}

.event-grid .event-title {
    font-size: 24px;
    font-weight: 600;
    margin-top: -0.2em;
    margin-bottom: 12px
}

.event-grid .event-title a {
    color: var(--title-color)
}

.event-grid .event-title a:hover {
    color: var(--theme-color)
}

@media (max-width: 1199px) {
    .event-grid .event-title {
        font-size:22px
    }
}

.event-grid .event-meta {
    gap: 5px 30px;
    margin-bottom: -0.3em
}

@media (max-width: 767px) {
    .event-grid {
        display:block
    }

    .event-grid .event-img {
        width: 100%;
        border-radius: 10px 10px 0 0
    }

    .event-grid .event-img img {
        border-radius: 10px 10px 0 0
    }

    .event-grid .event-content {
        position: initial;
        width: auto;
        -webkit-transform: none;
        -ms-transform: none;
        transform: none;
        margin: 0;
        padding: 40px;
        display: block;
        border-radius: 0 0 10px 10px
    }

    .event-grid .event-content .event-bg-shape {
        display: none
    }

    .event-grid .event-content .media-body {
        margin-top: 30px
    }
}

@media (max-width: 575px) {
    .event-grid .event-content {
        padding:30px
    }
}

.event-grid:nth-of-type(odd) {
    -webkit-box-orient: horizontal;
    -webkit-box-direction: reverse;
    -webkit-flex-direction: row-reverse;
    -ms-flex-direction: row-reverse;
    flex-direction: row-reverse
}

.event-grid:nth-of-type(odd) .event-content {
    right: unset;
    left: 0;
    margin-left: 0;
    margin-right: 40px;
    padding: 60px 40px 60px 60px
}

.event-grid:nth-of-type(odd) .event-content .event-bg-shape {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg);
    left: auto;
    right: -40px
}

@media (max-width: 1299px) {
    .event-grid:nth-of-type(odd) .event-content {
        padding:50px 30px 50px 50px
    }
}

@media (max-width: 1199px) {
    .event-grid:nth-of-type(odd) .event-content {
        padding:40px 20px 40px 40px
    }
}

@media (max-width: 767px) {
    .event-grid:nth-of-type(odd) .event-content {
        margin:0;
        padding: 40px
    }
}

@media (max-width: 575px) {
    .event-grid:nth-of-type(odd) .event-content {
        padding:30px
    }
}

.elementor-widget-container .event-grid:nth-of-type(even) {
    -webkit-box-orient: horizontal;
    -webkit-box-direction: reverse;
    -webkit-flex-direction: row-reverse;
    -ms-flex-direction: row-reverse;
    flex-direction: row-reverse
}

.elementor-widget-container .event-grid:nth-of-type(even) .event-content {
    right: unset;
    left: 0;
    margin-left: 0;
    margin-right: 40px;
    padding: 60px 40px 60px 60px
}

.elementor-widget-container .event-grid:nth-of-type(even) .event-content .event-bg-shape {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg);
    left: auto;
    right: -40px
}

@media (max-width: 1199px) {
    .elementor-widget-container .event-grid:nth-of-type(even) .event-content {
        padding:40px 20px 40px 40px
    }
}

@media (max-width: 767px) {
    .elementor-widget-container .event-grid:nth-of-type(even) .event-content {
        margin:0;
        padding: 40px
    }
}

@media (max-width: 575px) {
    .elementor-widget-container .event-grid:nth-of-type(even) .event-content {
        padding:30px
    }
}

.event-details-wrap {
    border-radius: 10px;
    border: 1px solid #E3EAF3;
    background: var(--white-color);
    padding: 40px;
    margin-bottom: 30px
}

@media (max-width: 575px) {
    .event-details-wrap {
        padding:30px
    }
}

.event-details-wrap .event-img {
    border-radius: 10px;
    margin-bottom: 40px
}

.event-details-wrap .event-img img {
    border-radius: 10px
}

.counter-list.event-counter {
    background: var(--smoke-color);
    border-radius: 10px;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    margin: 60px 0 0 0;
    padding: 0;
    gap: 0
}

.counter-list.event-counter li {
    display: block;
    text-align: center;
    padding: 59px 87px
}

.counter-list.event-counter li:after {
    display: none
}

.counter-list.event-counter li:not(:last-child) {
    border-right: 2px solid var(--white-color)
}

.counter-list.event-counter li .count-number {
    color: var(--title-color);
    font-size: 44px;
    font-weight: 600;
    margin-bottom: 17px;
    margin-top: 4px
}

.counter-list.event-counter li .count-name {
    color: var(--body-color);
    font-family: var(--body-font);
    text-transform: uppercase;
    font-weight: 400;
    margin-bottom: -0.4em;
    display: block
}

@media (max-width: 1399px) {
    .counter-list.event-counter li {
        padding:49px 60px
    }
}

@media (max-width: 1299px) {
    .counter-list.event-counter li {
        padding:39px 54px
    }

    .counter-list.event-counter li .count-number {
        font-size: 36px
    }
}

@media (max-width: 1199px) {
    .counter-list.event-counter li {
        padding:30px 42px
    }

    .counter-list.event-counter li .count-number {
        font-size: 30px;
        margin-bottom: 10px
    }
}

@media (max-width: 991px) {
    .counter-list.event-counter li {
        padding:30px 52px
    }
}

@media (max-width: 767px) {
    .counter-list.event-counter li {
        padding:20px 33px
    }

    .counter-list.event-counter li .count-number {
        font-size: 24px
    }

    .counter-list.event-counter li .count-name {
        font-size: 14px
    }
}

@media (max-width: 767px) {
    .counter-list.event-counter {
        margin:40px 0 0 0
    }
}

@media (max-width: 575px) {
    .counter-list.event-counter {
        display:grid;
        grid-template-columns: repeat(2, 1fr)
    }

    .counter-list.event-counter li:nth-child(1) {
        border-bottom: 2px solid var(--white-color)
    }

    .counter-list.event-counter li:nth-child(2) {
        border-right: 0;
        border-bottom: 2px solid var(--white-color)
    }
}

.category-sec-wrap .sec-title {
    font-size: 36px;
    margin-bottom: 90px
}

@media (max-width: 1299px) {
    .category-sec-wrap .sec-title {
        margin-bottom:80px
    }
}

@media (max-width: 1199px) {
    .category-sec-wrap .sec-title {
        margin-bottom:30px
    }
}

@media (max-width: 767px) {
    .category-sec-wrap .sec-title {
        font-size:28px
    }
}

.category-sec-wrap .category-slider {
    padding-top: 35px
}

.category-sec-wrap .category-slider .slick-arrow {
    opacity: 1;
    visibility: visible;
    --pos-x: 0;
    top: 20px;
    right: 60px;
    left: auto;
    width: 40px;
    height: 30px;
    line-height: 30px;
    border-radius: 10px;
    background: var(--smoke-color);
    box-shadow: none;
    color: var(--theme-color)
}

.category-sec-wrap .category-slider .slick-arrow.slick-next {
    right: 10px
}

.category-sec-wrap .category-slider .slick-arrow:hover {
    background: var(--theme-color);
    color: var(--white-color)
}

@media (max-width: 1399px) {
    .category-sec-wrap .category-slider {
        margin-left:30px
    }
}

@media (max-width: 1299px) {
    .category-sec-wrap .category-slider {
        margin-top:80px
    }
}

@media (max-width: 1199px) {
    .category-sec-wrap .category-slider {
        margin-top:20px;
        margin-left: 0;
        margin-right: 0
    }
}

@media (max-width: 1299px) {
    .category-sec-wrap .category-shape-arrow {
        top:50px
    }
}

.category-card {
    text-align: center;
    border-radius: 10px;
    border: 1px solid var(--f-2-f-2-f-2, #F2F2F2);
    background: var(--white-color, #fff);
    box-shadow: 0px 6px 20px 0px rgba(0,0,0,0.06);
    padding: 20px
}

.category-card_icon {
    width: 60px;
    height: 60px;
    line-height: 60px;
    min-width: 60px;
    background-color: var(--smoke-color);
    border-radius: 999px;
    text-align: center;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    margin: auto;
    margin-bottom: 20px
}

.category-card_icon img {
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.category-card_title {
    font-size: 20px;
    font-weight: 500;
    margin-top: -0.23em;
    margin-bottom: 2px
}

.category-card_title a {
    color: inherit
}

.category-card_title a:hover {
    color: var(--theme-color)
}

.category-card_text {
    margin-bottom: 17px
}

.category-card .th-btn {
    padding: 10.5px 20px;
    width: 100%
}

.category-card:hover .category-card_icon {
    background-color: var(--theme-color)
}

.category-card:hover .category-card_icon img {
    -webkit-filter: brightness(0) invert(1);
    filter: brightness(0) invert(1)
}

.category-card.style2 {
    background: transparent;
    box-shadow: none;
    border: 0;
    padding: 30px;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.category-card.style2 .category-card_icon {
    background: #E8EFFA;
    margin-bottom: 30px;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.category-card.style2 .category-card_icon img {
    -webkit-filter: none;
    filter: none
}

.category-card.style2 .box-title {
    font-weight: 500;
    margin-bottom: 10px
}

.category-card.style2 .category-card_text {
    font-family: var(--body-font);
    display: block;
    margin-bottom: 13px
}

.category-card.style2 .link-btn {
    font-weight: 600;
    color: var(--title-color)
}

.category-card.style2 .link-btn:hover {
    color: var(--theme-color)
}

.category-card.style2.cat-card2-active,.category-card.style2:hover {
    border-radius: 10px;
    background: var(--white-color);
    box-shadow: 0px 10px 30px 0px rgba(206,211,230,0.45)
}

.category-card.style2.cat-card2-active .category-card_icon,.category-card.style2:hover .category-card_icon {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

@media (max-width: 767px) {
    .category-card {
        -webkit-box-orient:vertical;
        -webkit-box-direction: normal;
        -webkit-flex-direction: column;
        -ms-flex-direction: column;
        flex-direction: column;
        -webkit-box-align: center;
        -webkit-align-items: center;
        -ms-flex-align: center;
        align-items: center;
        gap: 22px
    }

    .category-card_content {
        text-align: center
    }

    .category-card_title {
        margin-bottom: 10px
    }

    .category-card_text {
        max-width: 360px;
        margin-left: auto;
        margin-right: auto
    }
}

.category-list {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 5px;
    border-radius: 10px;
    border: 1px solid #D0DBE9;
    background: var(--white-color);
    border-radius: 10px;
    margin-left: 30px;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    position: relative;
    z-index: 2
}

.category-list:before {
    content: '';
    background-color: var(--theme-color);
    width: 0;
    height: 0;
    border-radius: inherit;
    position: absolute;
    top: 0;
    right: 0;
    -webkit-transition: 0.4s linear;
    transition: 0.4s linear;
    z-index: -1
}

.category-list_icon {
    width: 60px;
    height: 60px;
    line-height: 60px;
    min-width: 60px;
    background-color: #EBF2FF;
    border-radius: 10px;
    text-align: center;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    margin-right: 15px;
    border: 1px solid #D0DBE9;
    margin-left: -30px
}

.category-list_icon img {
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.category-list_content {
    position: relative;
    overflow: hidden;
    padding: 26px 26px 26px 0;
    width: 100%;
    border-radius: 10px
}

.category-list .icon-btn {
    margin-left: auto;
    min-width: 50px;
    border: 1px solid var(--theme-color);
    color: var(--theme-color);
    position: absolute;
    bottom: -12px;
    right: -12px;
    opacity: 0;
    line-height: 44px;
    -webkit-transition: 0.7s;
    transition: 0.7s
}

.category-list .icon-btn i {
    margin-left: -8px
}

.category-list_title {
    font-size: 24px;
    font-weight: 500;
    margin-top: -0.23em;
    margin-bottom: 2px;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.category-list_title a {
    color: inherit;
    -webkit-transition: 0s;
    transition: 0s
}

@media (max-width: 1399px) {
    .category-list_title {
        font-size:22px
    }
}

@media (max-width: 1299px) {
    .category-list_title {
        font-size:18px
    }
}

.category-list_text {
    display: block;
    margin-bottom: -0.4em;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.category-list:hover {
    box-shadow: 0px 10px 12px 0px rgba(13,94,244,0.2)
}

.category-list:hover:before {
    width: 100%;
    height: 100%
}

.category-list:hover .category-list_title {
    color: var(--white-color)
}

.category-list:hover .category-list_text {
    color: var(--white-color)
}

.category-list:hover .category-list_icon {
    background: var(--theme-color)
}

.category-list:hover .category-list_icon img {
    -webkit-filter: brightness(99);
    filter: brightness(99)
}

.category-list:hover .icon-btn {
    background-color: var(--white-color);
    color: var(--theme-color);
    border-color: var(--white-color);
    opacity: 1
}

.tab-menu1 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 24px
}

.tab-menu1 button {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    font-size: 24px;
    font-weight: 600;
    font-family: var(--title-font);
    color: var(--title-color);
    background-color: var(--white-color);
    position: relative;
    z-index: 2;
    padding: 27px;
    text-align: center;
    border: 0;
    margin: 0;
    box-shadow: 0px 6px 30px 0px rgba(0,0,0,0.05);
    cursor: pointer
}

.tab-menu1 button:before {
    content: '';
    height: 100%;
    width: 100%;
    background-color: var(--theme-color);
    position: absolute;
    top: 0;
    left: 0;
    -webkit-transform: scaleX(0);
    -ms-transform: scaleX(0);
    transform: scaleX(0);
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    z-index: -1
}

.tab-menu1 button:hover {
    color: var(--title-color)
}

.tab-menu1 button.active {
    color: var(--white-color)
}

.tab-menu1 button.active:before {
    -webkit-transform: scaleX(1);
    -ms-transform: scaleX(1);
    transform: scaleX(1)
}

@media (max-width: 1199px) {
    .tab-menu1 button {
        font-size:20px
    }
}

@media (max-width: 991px) {
    .tab-menu-wrap {
        margin-bottom:30px
    }

    .tab-menu1 {
        gap: 25px
    }

    .tab-menu1 button {
        -webkit-box-flex: 1;
        -webkit-flex: auto;
        -ms-flex: auto;
        flex: auto;
        font-size: 16px;
        padding: 16px 15px
    }
}

@media (max-width: 767px) {
    .tab-menu-wrap .shape {
        display:none
    }

    .tab-menu1 {
        gap: 20px;
        -webkit-flex-wrap: wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }
}

.tab-menu2 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 0px
}

.tab-menu2 button {
    -webkit-box-flex: 1;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    font-size: 20px;
    font-weight: 600;
    color: var(--title-color);
    background-color: var(--white-color);
    position: relative;
    z-index: 2;
    padding: 20px;
    text-align: center;
    border: 1px solid var(--border-color);
    margin: 0;
    margin-right: -1px;
    cursor: pointer
}

.tab-menu2 button:before {
    content: '';
    height: 100%;
    width: 100%;
    background-color: var(--theme-color);
    position: absolute;
    top: 0;
    left: 0;
    -webkit-transform: scaleX(0);
    -ms-transform: scaleX(0);
    transform: scaleX(0);
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    z-index: -1
}

.tab-menu2 button:hover {
    color: var(--title-color)
}

.tab-menu2 button.active {
    color: var(--white-color)
}

.tab-menu2 button.active:before {
    -webkit-transform: scaleX(1);
    -ms-transform: scaleX(1);
    transform: scaleX(1)
}

@media (max-width: 991px) {
    .tab-menu2 {
        gap:25px
    }

    .tab-menu2 button {
        -webkit-box-flex: 1;
        -webkit-flex: auto;
        -ms-flex: auto;
        flex: auto;
        font-size: 16px;
        padding: 16px 15px
    }
}

@media (max-width: 767px) {
    .tab-menu2 {
        gap:6px 20px;
        -webkit-flex-wrap: wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap
    }
}

.tab-menu3 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
    gap: 19px;
    border-right: 1px solid rgba(0,15,87,0.2);
    margin-right: 30px;
    padding-right: 30px
}

.tab-menu3 button {
    font-size: 30px;
    color: var(--title-color);
    font-weight: 700;
    width: 65px;
    height: 65px;
    line-height: 60px;
    text-align: center;
    padding: 0 4px 0 0;
    border: none;
    background-color: transparent;
    background-image: url("data:image/svg+xml,%3Csvg width='65' height='65' viewBox='0 0 65 65' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath opacity='0.2' d='M5 10C5 7.23858 7.23858 5 10 5H35H47.9289C49.255 5 50.5268 5.52678 51.4645 6.46447L63.5355 18.5355C64.4732 19.4732 65 20.745 65 22.0711V35V60C65 62.7614 62.7614 65 60 65H10C7.23858 65 5 62.7614 5 60V10Z' fill='%23FF4C13'/%3E%3Cpath d='M0.5 5C0.5 2.51472 2.51472 0.5 5 0.5H30H42.9289C44.1224 0.5 45.267 0.974106 46.1109 1.81802L58.182 13.8891C59.0259 14.733 59.5 15.8776 59.5 17.0711V30V55C59.5 57.4853 57.4853 59.5 55 59.5H5C2.51472 59.5 0.5 57.4853 0.5 55V5Z' fill='%23F8F8F8' stroke='%23FF4C13'/%3E%3C/svg%3E");
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.tab-menu3 button.active {
    color: var(--white-color);
    background-image: url("data:image/svg+xml,%3Csvg width='65' height='65' viewBox='0 0 65 65' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 5C0 2.23858 2.23858 0 5 0H30H42.9289C44.255 0 45.5268 0.526784 46.4645 1.46447L58.5355 13.5355C59.4732 14.4732 60 15.745 60 17.0711V30V55C60 57.7614 57.7614 60 55 60H5C2.23858 60 0 57.7614 0 55V5Z' fill='%23FF4C13'/%3E%3Cpath opacity='0.2' d='M5 10C5 7.23858 7.23858 5 10 5H35H47.9289C49.255 5 50.5268 5.52678 51.4645 6.46447L63.5355 18.5355C64.4732 19.4732 65 20.745 65 22.0711V35V60C65 62.7614 62.7614 65 60 65H10C7.23858 65 5 62.7614 5 60V10Z' fill='%23FF4C13'/%3E%3C/svg%3E")
}

@media (max-width: 1399px) {
    .tab-menu3 {
        margin-right:10px;
        padding-right: 10px
    }
}

@media (max-width: 1199px) {
    .tab-menu3 {
        margin-right:40px;
        padding-right: 40px
    }
}

@media (max-width: 575px) {
    .tab-menu3 {
        -webkit-box-orient:horizontal;
        -webkit-box-direction: normal;
        -webkit-flex-direction: row;
        -ms-flex-direction: row;
        flex-direction: row;
        padding-right: 0;
        margin-right: 0;
        border-right: none;
        padding-bottom: 25px;
        margin-bottom: 25px;
        border-bottom: 1px solid rgba(0,15,87,0.2);
        gap: 30px;
        width: 100%
    }
}

.tab-menu4 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    margin-bottom: 30px;
    position: relative;
    padding-bottom: 6px;
    text-align: center
}

.tab-menu4 button {
    color: var(--title-color);
    font-weight: 600;
    background-color: transparent;
    border: none;
    padding: 0;
    position: relative;
    margin-right: 30px
}

.tab-menu4 button:after {
    content: "";
    height: 18px;
    width: 2px;
    background-color: var(--body-color);
    opacity: 0.3;
    position: absolute;
    top: 50%;
    right: -15px;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%)
}

.tab-menu4 button:last-of-type {
    margin-right: 0
}

.tab-menu4 button:last-of-type:after {
    display: none
}

.tab-menu4 button:hover,.tab-menu4 button.active {
    color: var(--theme-color)
}

.tab-menu4 .indicator {
    position: absolute;
    bottom: 0 !important;
    left: var(--pos-x);
    top: unset !important;
    width: var(--width-set);
    background-color: var(--theme-color);
    height: 3px !important;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.tab-menu4 .indicator:after {
    content: "";
    width: 0;
    height: 0;
    border-style: solid;
    border-width: 8px 8px 0 8px;
    border-color: var(--theme-color) transparent transparent transparent;
    position: absolute;
    top: 100%;
    left: 50%;
    -webkit-transform: translateX(-50%);
    -ms-transform: translateX(-50%);
    transform: translateX(-50%)
}

.client-area-1 {
    padding: 60px
}

.client-area-1 .sec-title {
    font-size: 36px
}

.client-area-1 .icon-box {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 10px;
    margin-top: 22px
}

.client-area-1 .icon-box button {
    --icon-size: 46px;
    background: transparent;
    border: 1px solid #4D5765;
    color: var(--white-color);
    font-size: 20px;
    margin: 0
}

.client-area-1 .icon-box button:hover {
    background: var(--theme-color);
    border-color: var(--theme-color)
}

@media (max-width: 991px) {
    .client-area-1 .icon-box {
        -webkit-box-pack:center;
        -webkit-justify-content: center;
        -ms-flex-pack: center;
        justify-content: center
    }
}

@media (max-width: 575px) {
    .client-area-1 {
        padding:60px 40px
    }
}

.client-area-2 {
    padding: 45px 0;
    border-bottom: 1px solid var(--border-color)
}

.client-area-3 {
    padding: 55px 40px 55px 0px;
    position: relative;
    z-index: 3;
    margin-right: 150px
}

@media (max-width: 1500px) {
    .client-area-3 {
        margin-right:110px
    }
}

@media (max-width: 1399px) {
    .client-area-3 {
        margin-right:70px
    }
}

@media (max-width: 1299px) {
    .client-area-3 {
        margin-right:0;
        padding: 55px 20px
    }
}

.client-area-4 {
    position: relative;
    padding: 55px 0;
    margin: 0 -50px
}

.client-area-4:after {
    content: '';
    position: absolute;
    height: 100%;
    width: calc(100% + 100px);
    background: var(--theme-color);
    inset: 0;
    left: -50px;
    z-index: -1;
    -webkit-clip-path: polygon(0 0, 100% 0, 95% 100%, 5% 100%);
    clip-path: polygon(0 0, 100% 0, 95% 100%, 5% 100%)
}

.client-area-4:before {
    content: '';
    position: absolute;
    height: 101px;
    width: calc(100% + 190px);
    background: var(--body-color);
    inset: 0;
    left: -95px;
    z-index: -1;
    -webkit-clip-path: polygon(3% 0, 97% 0, 100% 100%, 0 100%);
    clip-path: polygon(3% 0, 97% 0, 100% 100%, 0 100%)
}

@media (max-width: 1500px) {
    .client-area-4 {
        margin:0
    }

    .client-area-4:before {
        width: calc(100% + 184px);
        left: -92px
    }
}

@media (max-width: 1399px) {
    .client-area-4 {
        margin:0 55px
    }

    .client-area-4:before {
        width: calc(100% + 178px);
        left: -89px
    }
}

@media (max-width: 1299px) {
    .client-area-4 {
        margin:0 70px
    }

    .client-area-4:before {
        width: calc(100% + 172px);
        left: -86px
    }
}

@media (max-width: 1199px) {
    .client-area-4:before {
        width:calc(100% + 160px);
        left: -80px
    }
}

@media (max-width: 991px) {
    .client-area-4 {
        padding:30px 0
    }

    .client-area-4:before {
        width: calc(100% + 146px);
        left: -73px;
        height: 75px
    }
}

@media (max-width: 767px) {
    .client-area-4:before {
        width:calc(100% + 132px);
        left: -66px
    }
}

@media (max-width: 575px) {
    .client-area-4:before {
        width:calc(100% + 126px);
        left: -63px
    }
}

@media (max-width: 320px) {
    .client-area-4:before {
        width:calc(100% + 120px);
        left: -60px;
        height: 73px
    }
}

.client-area-5 {
    background-size: calc(100% - 240px);
    padding: 55px 0
}

@media (max-width: 1700px) {
    .client-area-5 {
        background-size:calc(100% - 240px) 100%
    }
}

@media (max-width: 1500px) {
    .client-area-5 {
        background-size:calc(100% - 100px) 100%
    }
}

@media (max-width: 1399px) {
    .client-area-5 {
        background-size:cover
    }
}

.client-slider5 {
    margin: 0 20px
}

@media (max-width: 1700px) {
    .client-slider5 {
        margin:0 120px
    }
}

@media (max-width: 1500px) {
    .client-slider5 {
        margin:0 50px
    }
}

@media (max-width: 1399px) {
    .client-slider5 {
        margin:0
    }
}

.client-thumb.style2 {
    -webkit-filter: grayscale(1) opacity(0.5);
    filter: grayscale(1) opacity(0.5);
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.client-thumb.style2:hover {
    -webkit-filter: none;
    filter: none
}

.brand-box {
    padding: 25px 0
}

.brand-box-wrap {
    background-color: var(--smoke-color);
    box-shadow: -1000px 0 0 0 var(--smoke-color)
}

.brand-icon-wrap {
    height: 100%;
    background-color: var(--body-color);
    display: grid;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-clip-path: polygon(50px 0%, 100% 0, 100% 100%, 50px 100%, 0% 50%);
    clip-path: polygon(50px 0%, 100% 0, 100% 100%, 50px 100%, 0% 50%)
}

.brand-icon-wrap .slick-arrow {
    margin-left: 25px;
    top: 0
}

@media (max-width: 1399px) {
    .brand-box-wrap {
        box-shadow:-200px 0 0 0 var(--smoke-color)
    }
}

@media (max-width: 767px) {
    .brand-icon-wrap .slick-arrow {
        margin-right:0
    }
}

@media (max-width: 575px) {
    .brand-box {
        text-align:center
    }

    .brand-box-wrap {
        box-shadow: none;
        margin: 0 -15px;
        padding: 0 15px
    }
}

.th-video2 {
    position: relative
}

.th-video2 .play-bg {
    position: absolute;
    top: 0;
    left: 50%;
    -webkit-transform: translateX(-50%);
    -ms-transform: translateX(-50%);
    transform: translateX(-50%);
    z-index: 4
}

.th-video2 .play-bg .play-btn {
    position: absolute;
    bottom: 65px;
    left: 50%
}

.th-video2 .play-bg .play-btn:hover>i {
    background-color: var(--title-color);
    color: var(--white-color)
}

.th-video2 .play-bg .play-btn:hover::before,.th-video2 .play-bg .play-btn:hover:after {
    background-color: var(--title-color)
}

.img-right {
    position: absolute;
    top: 0;
    right: 0;
    z-index: 4;
    height: 100%;
    width: 44%
}

.img-right img {
    width: 100%;
    height: 100%;
    object-fit: cover
}

@media (max-width: 1199px) {
    .img-right {
        position:relative;
        width: 100%;
        margin-bottom: -65px
    }
}

@media (max-width: 991px) {
    .img-right {
        margin-bottom:-35px
    }
}

@media (max-width: 575px) {
    .th-video2 .play-bg {
        left:30%;
        -webkit-transform: translateX(-30%);
        -ms-transform: translateX(-30%);
        transform: translateX(-30%)
    }
}

@media (max-width: 375px) {
    .th-video2 .play-bg .play-btn {
        bottom:30px;
        left: 45%
    }
}

.pricing-card-wrap {
    -webkit-transform: translate(0px, 270px);
    -ms-transform: translate(0px, 270px);
    transform: translate(0px, 270px);
    margin-top: -293px;
    margin-bottom: 270px
}

.price-card {
    padding: 40px;
    position: relative;
    z-index: 2;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    border-radius: 0px;
    background: var(--white-color);
    box-shadow: 0px 4px 30px 0px rgba(1,19,60,0.08);
    overflow: hidden
}

.price-card .price-card-bg-shape {
    position: absolute;
    top: 0;
    left: 0;
    opacity: 0;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.price-card_top {
    margin-bottom: 40px;
    padding-bottom: 32px;
    border-bottom: 1px solid var(--border-color)
}

.price-card_title {
    font-size: 20px;
    font-weight: 600;
    display: inline-block;
    border-bottom: 2px solid var(--theme-color);
    padding-bottom: 5px;
    margin-top: -0.2em;
    margin-bottom: 27px;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.price-card_text {
    margin-bottom: -0.4em;
    margin-top: 11px;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.price-card_price {
    font-size: 48px;
    font-weight: 700;
    line-height: 1;
    margin: 0;
    position: relative;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    color: var(--theme-color)
}

.price-card_price .duration {
    font-size: 18px;
    font-weight: 500;
    margin-left: -10px;
    margin-bottom: 0;
    position: relative;
    display: inline-block;
    top: -1px;
    left: 0;
    color: var(--body-color)
}

.price-card .checklist {
    margin: 0px 0 43px 0
}

.price-card .checklist li {
    color: #4D5765
}

.price-card .checklist li:before {
    font-weight: 400
}

.price-card .checklist li.unavailable {
    opacity: 0.5
}

.price-card.active,.price-card:hover {
    background: var(--title-color)
}

.price-card.active .price-card-bg-shape,.price-card:hover .price-card-bg-shape {
    opacity: 0.15
}

.price-card.active .price-card_title,.price-card:hover .price-card_title {
    color: var(--white-color)
}

.price-card.active .price-card_top,.price-card:hover .price-card_top {
    border-color: #4D5765
}

.price-card.active .checklist li,.price-card.active .price-card_price .duration,.price-card:hover .checklist li,.price-card:hover .price-card_price .duration {
    color: #8993A1
}

@media (max-width: 1399px) {
    .price-card .price-card_price {
        font-size:40px
    }
}

@media (max-width: 1199px) {
    .price-card .price-card_price {
        font-size:36px
    }
}

@media (max-width: 767px) {
    .price-card .price-card_price {
        font-size:28px
    }

    .price-card .price-card_price .duration {
        margin-left: -5px
    }
}

@media (max-width: 375px) {
    .price-card {
        padding:30px
    }
}

.available-list2 ul {
    padding: 0;
    margin: 0;
    list-style: none
}

.available-list2 li {
    position: relative;
    margin-bottom: 10px;
    padding-left: 26px
}

.available-list2 li:last-child {
    margin-bottom: 0
}

.available-list2 li:before {
    content: "\f058";
    font-family: var(--icon-font);
    font-weight: 600;
    color: var(--theme-color);
    font-size: 1em;
    vertical-align: text-top;
    position: absolute;
    top: 0;
    left: 0
}

.available-list2 li.unavailable {
    color: #bdbdbd
}

.available-list2 li.unavailable:before {
    color: #bdbdbd
}

.price-box {
    padding: 40px;
    background-color: var(--white-color);
    border-radius: 10px;
    position: relative;
    z-index: 2;
    box-shadow: 0px 4px 30px rgba(1,19,60,0.08)
}

.price-box_price {
    color: var(--theme-color);
    font-size: 48px;
    font-weight: bold;
    line-height: 1
}

.price-box_price .currency {
    font-size: 24px;
    position: relative;
    top: -25px
}

.price-box_price .duration {
    color: var(--title-color);
    font-size: 16px;
    font-weight: 600;
    margin-left: -14px
}

.price-box_title {
    border-bottom: 2px solid var(--theme-color);
    max-width: -webkit-fit-content;
    max-width: -moz-fit-content;
    max-width: fit-content;
    margin-top: -0.24em;
    margin-bottom: 25px
}

.price-box .available-list2 {
    border-top: 1px solid var(--border-color);
    padding-top: 28px;
    margin-top: 28px;
    margin-bottom: 30px
}

.price-box .th-btn {
    border-radius: 4px;
    background-color: var(--title-color)
}

.price-box .th-btn:before,.price-box .th-btn:after {
    background-color: var(--theme-color)
}

.price-sec {
    max-width: 1720px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 30px;
    margin-top: -120px;
    position: relative;
    z-index: 3;
    box-shadow: 0px 6px 50px rgba(14,18,29,0.06)
}

@media (max-width: 360px) {
    .price-box {
        padding:40px 20px
    }

    .price-box_title {
        font-size: 22px
    }
}

@media (max-width: 991px) {
    .price-sec {
        margin-top:-80px;
        border-radius: 15px
    }
}

.service-tab-menu .tab-btn {
    border: 1px solid var(--border-color);
    background: var(--white-color);
    width: 100%;
    font-size: 18px;
    font-weight: 400;
    padding: 14px 30px;
    position: relative
}

@media (max-width: 1299px) {
    .service-tab-menu .tab-btn {
        font-size:16px
    }
}

@media (max-width: 1199px) {
    .service-tab-menu .tab-btn {
        padding:14px 11px
    }
}

.service-tab-menu .tab-btn ~ .tab-btn {
    margin-top: 12px
}

.service-tab-menu .tab-btn:after {
    content: '';
    position: absolute;
    right: -12px;
    top: 0;
    background: #B53900;
    width: 22px;
    height: 20px;
    -webkit-clip-path: polygon(0 0, 55% 0%, 100% 100%, 0% 100%);
    clip-path: polygon(0 0, 55% 0%, 100% 100%, 0% 100%);
    z-index: -1;
    opacity: 0
}

.service-tab-menu .tab-btn.active {
    background: var(--theme-color);
    border-color: var(--theme-color);
    color: var(--white-color)
}

.service-tab-menu .tab-btn.active:after {
    opacity: 1
}

@media (max-width: 991px) {
    .service-tab-menu {
        margin-bottom:30px
    }
}

.service-card-icon {
    text-align: center;
    position: relative;
    z-index: 1;
    display: inline-block;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    margin-bottom: 30px
}

.service-card-icon img {
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.service-card .service-card-content {
    border: 1px solid var(--border-color);
    padding: 30px;
    background-size: auto;
    background-position: top right;
    margin-bottom: 10px
}

@media (max-width: 1299px) {
    .service-card .box-title a {
        font-size:22px
    }
}

.service-card .box-title a:hover {
    color: var(--theme-color)
}

.service-card-text {
    margin-bottom: -0.3em;
    font-size: 14px
}

.service-card-img {
    border-radius: 0px;
    position: relative;
    z-index: 1;
    -webkit-clip-path: polygon(100% 0, 100% 50%, 81% 100%, 0 100%, 0 0);
    clip-path: polygon(100% 0, 100% 50%, 81% 100%, 0 100%, 0 0)
}

.service-card-img:after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 100%;
    background: #00112B;
    opacity: 0;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    border-radius: 0px;
    z-index: 0
}

.service-card-img img {
    border-radius: 0px;
    width: 100%
}

.service-card:hover .service-card-icon {
    border-color: var(--theme-color2)
}

.service-card:hover .service-card-icon img {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

.service-card:hover .service-card-img:after {
    opacity: 0.7
}

.service-card.style2 {
    border-radius: 0px;
    background: var(--white-color);
    box-shadow: 0px 10px 30px 0px rgba(0,0,0,0.03);
    padding: 40px;
    margin: 0;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    position: relative;
    margin: 20px 0 0 20px;
    z-index: 0
}

.service-card.style2.bg-shadow {
    box-shadow: 0px 6px 30px 0px rgba(0,0,0,0.06)
}

.service-card.style2:after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 100%;
    background: var(--title-color);
    z-index: -1;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    opacity: 0
}

.service-card.style2 .service-card-bg-img {
    position: absolute;
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
    opacity: 0;
    z-index: -1;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.service-card.style2 .service-content {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex
}

.service-card.style2 .service-card-icon {
    width: 100px;
    height: 100px;
    line-height: 100px;
    background: var(--white-color);
    box-shadow: 0px 10px 30px 0px rgba(0,0,0,0.03);
    border-right: 10px solid var(--smoke-color);
    border-bottom: 10px solid var(--smoke-color);
    box-sizing: content-box;
    top: -60px;
    left: -60px;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    margin: 0 -20px -26px 0
}

.service-card.style2 .service-card-icon img {
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.service-card.style2 .box-title {
    margin-bottom: 0
}

.service-card.style2 .service-card-number {
    color: #B2B2B2;
    margin-left: auto
}

.service-card.style2 .service-card-text {
    margin-bottom: -0.3em;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    font-size: 16px;
    color: var(--body-color)
}

.service-card.style2 .th-btn {
    margin-top: 38px;
    font-size: 14px;
    font-weight: 700;
    padding: 15px 20px
}

.service-card.style2 .service-card-shape {
    position: absolute;
    right: 0;
    bottom: 0;
    opacity: 0.12
}

.service-card.style2:hover:after {
    opacity: 0.86
}

.service-card.style2:hover .box-title a {
    color: var(--white-color)
}

.service-card.style2:hover .service-card-bg-img {
    opacity: 1
}

.service-card.style2:hover .service-card-number {
    color: var(--theme-color)
}

.service-card.style2:hover .service-card-text {
    color: #B2B2B2
}

.service-card.style2:hover .service-card-icon {
    background: var(--theme-color)
}

.service-card.style2:hover .service-card-icon img {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg);
    -webkit-filter: brightness(99);
    filter: brightness(99)
}

.service-card.style2:hover .th-btn {
    border-color: var(--theme-color);
    color: var(--theme-color)
}

.service-card.style2:hover .th-btn:hover {
    color: var(--white-color)
}

.service-card.style2:hover .service-card-shape {
    -webkit-filter: brightness(99);
    filter: brightness(99)
}

@media (max-width: 1299px) {
    .service-card.style2 {
        padding:30px;
        margin: 30px 0 0 30px
    }

    .service-card.style2 .service-card-icon {
        margin: 0 -30px -26px 0
    }

    .service-card.style2 .service-card-text {
        font-size: 14px
    }

    .service-card.style2 .th-btn {
        margin-top: 28px
    }
}

@media (max-width: 1199px) {
    .service-card.style2 .service-card-icon {
        margin:0 -40px -36px 0
    }
}

@media (max-width: 991px) {
    .service-card.style2 {
        box-shadow:0px 0px 30px 0px rgba(206,211,230,0.3)
    }
}

.details-more-wrap {
    position: relative
}

.details-more-wrap:after {
    content: '';
    position: absolute;
    left: 0;
    top: 50%;
    height: 1px;
    width: 100%;
    border: 1px dashed rgba(178,178,178,0.5);
    z-index: -1
}

.details-more-wrap .details-more-text {
    margin-bottom: 0;
    padding: 4px 25px;
    border-radius: 30px;
    border: 1px solid var(--border-color);
    display: inline-block
}

.service-card.style3 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    background: var(--white-color);
    border-radius: 10px;
    box-shadow: 0px 10px 30px 0px rgba(0,0,0,0.04);
    overflow: hidden
}

.service-card.style3 .service-card-thumb {
    position: relative;
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none
}

.service-card.style3 .service-card-thumb>img {
    height: 100%;
    object-fit: cover;
    object-position: right
}

.service-card.style3 .service-card-thumb .service-card-icon {
    height: 70px;
    width: 70px;
    line-height: 70px;
    border-radius: 50%;
    background: #FDFEFC;
    border: 5px solid var(--white-color);
    box-sizing: content-box;
    position: absolute;
    right: 2px;
    top: 30px;
    margin: 0
}

.service-card.style3 .service-card-content {
    border: 0;
    padding: 30px 30px 28px 20px;
    margin: 0;
    -webkit-align-self: center;
    -ms-flex-item-align: center;
    align-self: center
}

.service-card.style3 .box-title {
    margin-bottom: 8px;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    cursor: pointer
}

.service-card.style3 .box-title:hover {
    color: var(--theme-color)
}

.service-card.style3 .service-card-text {
    font-size: 16px;
    margin-bottom: 15px
}

@media (max-width: 1299px) {
    .service-card.style3 .service-card-text {
        font-size:14px
    }
}

.service-card.style3 .link-btn {
    color: var(--title-color)
}

.service-card.style3 .link-btn:before {
    background: var(--title-color)
}

.service-card.style3 .link-btn:hover {
    color: var(--theme-color)
}

.service-card.style3 .link-btn:hover:before {
    background: var(--theme-color)
}

.service-card.style3:hover .service-card-icon {
    background: var(--theme-color)
}

.service-card.style3:hover .service-card-icon img {
    -webkit-filter: brightness(999);
    filter: brightness(999)
}

@media (max-width: 575px) {
    .service-card.style3 {
        display:block
    }

    .service-card.style3 .service-card-thumb {
        display: inline-block
    }
}

.service-tab-1 .slick-list {
    padding-bottom: 50px
}

.service-tab-1 .slick-arrow {
    padding: 0;
    background: rgba(255,255,255,0.3);
    color: var(--white-color);
    font-size: 24px;
    top: 100px
}

.service-tab-1 .slick-arrow:hover {
    color: var(--white-color)
}

.service-tab-1 .tab-btn {
    display: block;
    cursor: pointer;
    text-align: center;
    font-family: var(--title-font);
    color: var(--title-color);
    background: var(--smoke-color);
    padding: 40px 27px 43px;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    position: relative
}

.service-tab-1 .tab-btn .icon {
    display: block;
    margin-bottom: 20px
}

.service-tab-1 .tab-btn .box-title {
    font-size: 20px;
    font-weight: 600;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.service-tab-1 .tab-btn:after {
    content: '';
    position: absolute;
    left: 50%;
    bottom: -21px;
    height: 21px;
    width: 41px;
    background: transparent;
    border-top: 21px solid var(--theme-color);
    border-right: 20.5px solid transparent;
    border-left: 20.5px solid transparent;
    border-bottom: 0;
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
    transform: translate(-50%, 0);
    opacity: 0;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.service-tab-1 .slick-current .tab-btn {
    background: var(--theme-color)
}

.service-tab-1 .slick-current .tab-btn:after {
    opacity: 1
}

.service-tab-1 .slick-current .box-title {
    color: var(--white-color)
}

.service-tab-1 .slick-current ~ .slick-slide .tab-btn {
    background: #E4E4E4
}

.service-tab-1 .slick-current ~ .slick-slide ~ .slick-slide .tab-btn {
    background: #EEEEEE
}

.service-tab-1 .slick-current ~ .slick-slide ~ .slick-slide ~ .slick-slide .tab-btn {
    background: var(--smoke-color)
}

@media (max-width: 575px) {
    .service-tab-1 .tab-btn {
        padding:30px 27px 23px
    }
}

.service4-content-wrap {
    background-color: #262A36;
    border: 1px solid var(--body-color)
}

.service4-content-wrap .service-content {
    padding: 50px 0 50px 50px;
    --body-color: #8993A1
}

.service4-content-wrap .service-content .service-title {
    color: var(--white-color);
    font-weight: 600;
    margin-top: -0.25em;
    margin-bottom: 22px
}

.service4-content-wrap .service-content .checklist {
    margin-top: 36px
}

.service4-content-wrap .service-content .checklist li {
    color: var(--body-color)
}

@media (max-width: 991px) {
    .service4-content-wrap .service-content {
        padding:50px
    }
}

@media (max-width: 575px) {
    .service4-content-wrap .service-content {
        padding:30px
    }
}

.service4-content-wrap .service-img {
    height: 100%
}

.service4-content-wrap .service-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: left
}

.service-sec-5 {
    background-size: calc(100% - 240px) 100%
}

@media (max-width: 1500px) {
    .service-sec-5 {
        background-size:calc(100% - 100px) 100%
    }
}

@media (max-width: 1399px) {
    .service-sec-5 {
        background-size:cover
    }
}

.service-sec-5 .service-thumb {
    height: 100%
}

.service-sec-5 .service-thumb img {
    object-fit: cover
}

@media (max-width: 991px) {
    .service-sec-5 .service-thumb {
        height:auto;
        margin-bottom: 24px
    }

    .service-sec-5 .service-thumb img {
        width: 100%
    }
}

.service-card.style5 {
    background: var(--white-color);
    box-shadow: 0px 10px 30px 0px rgba(0,0,0,0.04);
    padding: 30px;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 30px;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.service-card.style5:hover {
    background: var(--title-color)
}

.service-card.style5:hover .box-title {
    color: var(--white-color)
}

.service-card.style5:hover .service-card-text {
    color: #8993A1
}

.service-card.style5 .service-card-icon {
    -webkit-box-flex: 0;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none
}

.service-card.style5 .service-card-content {
    border: 0;
    padding: 0;
    margin: 0
}

.service-card.style5 .box-title {
    cursor: pointer;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.service-card.style5 .box-title:hover {
    color: var(--theme-color)
}

.service-card.style5 .service-card-text {
    margin-bottom: 15px;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    font-size: 16px
}

@media (max-width: 1199px) {
    .service-card.style5 {
        display:block
    }
}

.th-modal {
    z-index: 99
}

.th-modal .icon-btn {
    --btn-size: 40px;
    outline: 0;
    box-shadow: none;
    position: absolute;
    top: -20px;
    right: -20px;
    background: var(--theme-color);
    opacity: 1;
    color: var(--white-color)
}

.th-modal .modal-dialog {
    margin-top: 50px
}

.th-modal .modal-content {
    padding: 40px
}

@media (max-width: 575px) {
    .th-modal .modal-content {
        padding:25px
    }

    .th-modal .icon-btn {
        right: 0
    }
}

.service-info-list {
    margin: 0;
    padding: 0;
    list-style: none;
    border-left: 1px solid var(--border-color);
    padding-left: 30px;
    margin-bottom: 30px
}

.service-info-list li strong {
    margin-right: 10px
}

.service-info-list li:not(:last-child) {
    margin-bottom: 20px
}

@media (max-width: 1199px) {
    .service-info-list {
        padding-left:0;
        border-left: 0
    }
}

.service-list {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 25px
}

.service-list-wrap {
    --space-x: 35px;
    --space-y: 35px
}

.service-list-wrap:not(:nth-last-child(-n+3)) {
    border-bottom: 1px solid var(--border-color);
    padding-bottom: var(--space-y)
}

.service-list-wrap:not(:nth-child(-n+3)) {
    padding-top: var(--space-y)
}

.service-list-wrap:not(:nth-child(3n)) {
    border-right: 1px solid var(--border-color)
}

.service-list-wrap:not(:nth-child(3n+1)) {
    padding-left: var(--space-x)
}

.service-list_icon {
    min-width: 60px
}

.service-list_icon img {
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.service-list_title {
    margin-bottom: 10px;
    cursor: pointer;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.service-list_title:hover {
    color: var(--theme-color)
}

.service-list_text {
    margin-bottom: 20px
}

.service-list_btn {
    font-size: 14px;
    font-weight: 600;
    text-transform: uppercase;
    color: var(--title-color)
}

.service-list_btn .icon-btn {
    --btn-size: 40px;
    box-shadow: 0px 0px 10px rgba(14,18,29,0.12);
    background-color: var(--white-color);
    color: var(--theme-color);
    font-size: 14px;
    margin-right: 10px;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.service-list_btn:hover {
    color: var(--theme-color)
}

.service-list_btn:hover .icon-btn {
    background-color: var(--theme-color);
    color: var(--white-color)
}

.service-list:hover .service-list_icon img {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

@media (max-width: 1300px) {
    .service-list {
        -webkit-box-orient:vertical;
        -webkit-box-direction: normal;
        -webkit-flex-direction: column;
        -ms-flex-direction: column;
        flex-direction: column
    }
}

@media (max-width: 991px) {
    .service-list-wrap:not(:nth-last-child(-n+3)) {
        border-bottom:unset;
        padding-bottom: unset
    }

    .service-list-wrap:not(:nth-child(-n+3)) {
        padding-top: unset
    }

    .service-list-wrap:not(:nth-child(3n)) {
        border-right: unset
    }

    .service-list-wrap:not(:nth-child(3n+1)) {
        padding-left: unset
    }

    .service-list-wrap:not(:nth-last-child(-n+2)) {
        border-bottom: 1px solid var(--border-color);
        padding-bottom: var(--space-y)
    }

    .service-list-wrap:not(:nth-child(-n+2)) {
        padding-top: var(--space-y)
    }

    .service-list-wrap:nth-child(odd) {
        padding-right: var(--space-x)
    }

    .service-list-wrap:nth-child(even) {
        padding-left: var(--space-x);
        border-left: 1px solid var(--border-color)
    }
}

@media (max-width: 767px) {
    .service-list-wrap {
        padding:var(--space-y) var(--space-x) !important
    }

    .service-list-wrap:first-child {
        padding-top: 0 !important
    }

    .service-list-wrap:last-child {
        padding-bottom: 0 !important
    }

    .service-list-wrap:nth-child(odd) {
        border-left: 1px solid var(--border-color);
        border-bottom: 1px solid var(--border-color)
    }

    .service-list-wrap:nth-child(even) {
        border-right: 1px solid var(--border-color);
        border-left: unset
    }
}

@media (max-width: 360px) {
    .service-list-wrap {
        --space-x: 20px
    }

    .service-list_title {
        font-size: 22px
    }
}

.service-grid {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    background-color: var(--white-color);
    position: relative;
    padding: 40px;
    gap: 40px;
    border-radius: 20px;
    z-index: 3
}

.service-grid_img {
    position: relative;
    overflow: hidden;
    z-index: 2;
    min-width: 350px;
    border-radius: inherit
}

.service-grid_img img {
    width: 100%;
    -webkit-transition: 0.4s ease;
    transition: 0.4s ease
}

.service-grid_icon {
    width: 60px;
    height: 60px;
    line-height: 56px;
    background-color: var(--theme-color);
    color: var(--white-color);
    font-size: 32px;
    text-align: center;
    border-radius: 50%;
    position: relative;
    top: 0;
    left: 0;
    margin: 5px;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.service-grid_icon img {
    -webkit-filter: brightness(0) invert(1);
    filter: brightness(0) invert(1);
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.service-grid_icon:before {
    content: '';
    width: 70px;
    height: 70px;
    position: absolute;
    top: -5px;
    left: -5px;
    background-color: transparent;
    border: 1px solid var(--theme-color);
    border-radius: inherit
}

.service-grid_content {
    position: relative;
    z-index: 2
}

.service-grid_icon-overlay {
    position: absolute;
    top: 0;
    right: 0;
    z-index: -1
}

.service-grid_text {
    margin-bottom: 18px
}

.service-grid_title {
    font-size: 24px;
    margin-top: 25px;
    margin-bottom: 14px
}

.service-grid_title a {
    color: inherit
}

.service-grid_title a:hover {
    color: var(--theme-color)
}

.service-grid .checklist ul {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    margin-bottom: 20px;
    gap: 0 5px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.service-grid .checklist ul li {
    padding-left: 22px;
    margin-bottom: 5px
}

.service-grid .checklist ul li:first-child {
    margin-top: 0
}

.service-grid .checklist ul li:last-child {
    margin-bottom: 5px
}

.service-grid .th-btn {
    border-radius: 5px
}

.service-grid:hover .service-grid_img img {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1)
}

#serviceGridSlider {
    position: relative;
    z-index: 3
}

.service-thumb {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    gap: 20px;
    background-color: var(--white-color);
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 12px;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    cursor: pointer
}

.service-thumb-wrap {
    background-color: var(--theme-color);
    position: relative;
    padding: 24px 24px 24px 0;
    z-index: 2
}

.service-thumb-wrap:after {
    content: '';
    height: 100%;
    width: calc(100% + 180px);
    background-color: inherit;
    position: absolute;
    bottom: 0;
    right: 0;
    -webkit-clip-path: polygon(120px 0%, 100% 0, 100% 100%, 0% 100%);
    clip-path: polygon(120px 0%, 100% 0, 100% 100%, 0% 100%);
    z-index: -1
}

.service-thumb_img {
    min-width: 70px
}

.service-thumb_img img {
    border-radius: 5px
}

.service-thumb_title {
    font-size: 20px;
    margin-bottom: 0
}

.slick-current .service-thumb {
    border-right: 7px solid var(--title-color)
}

.arrow-btn {
    font-size: 20px;
    background-color: transparent;
    color: var(--white-color);
    border: 1px solid;
    display: inline-block;
    width: 100%;
    height: 55px;
    line-height: 53px;
    border-radius: 5px
}

.arrow-btn.prev {
    margin-bottom: 12px
}

@media (max-width: 1199px) {
    .service-thumb-wrap {
        padding:40px 0 40px 0
    }

    .service-thumb-wrap:after {
        content: '';
        height: calc(100% + 180px);
        width: calc(100% + 80px);
        left: -40px;
        -webkit-clip-path: polygon(0 120px, 100% 0, 100% 100%, 0% 100%);
        clip-path: polygon(0 120px, 100% 0, 100% 100%, 0% 100%)
    }
}

@media (max-width: 991px) {
    .service-grid {
        -webkit-flex-wrap:wrap;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        gap: 30px
    }

    .service-grid_img {
        min-width: 100%;
        width: 100%;
        height: 300px
    }

    .service-grid_img img {
        height: 100%;
        object-fit: cover
    }
}

@media (max-width: 450px) {
    .service-grid {
        padding:20px;
        border-radius: 10px
    }
}

@media (max-width: 375px) {
    .service-grid_title {
        font-size:22px
    }

    .service-grid .checklist ul {
        grid-template-columns: repeat(1, 1fr)
    }
}

.service-card2 {
    position: relative;
    overflow: hidden;
    z-index: 2
}

.service-card2_img img {
    width: 100%
}

.service-card2_content {
    position: relative;
    left: 50px;
    margin-top: -94px;
    max-width: calc(100% - 50px);
    padding: 30px;
    z-index: 3;
    background-color: var(--theme-color);
    box-shadow: 0px 6px 20px rgba(7,36,95,0.06)
}

.service-card2_content:before {
    content: "";
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    z-index: -1;
    background-color: var(black);
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.service-card2_icon {
    width: 60px;
    height: 60px;
    line-height: 56px;
    background-color: var(--theme-color);
    color: var(--white-color);
    font-size: 32px;
    text-align: center;
    border-radius: 50%;
    position: absolute;
    top: -35px;
    left: -35px;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.service-card2_icon img {
    -webkit-filter: brightness(0) invert(1);
    filter: brightness(0) invert(1);
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.service-card2_icon:before {
    content: '';
    width: 70px;
    height: 70px;
    position: absolute;
    top: -5px;
    left: -5px;
    background-color: transparent;
    border: 1px solid var(--white-color);
    border-radius: inherit
}

.service-card2_title {
    font-size: 24px;
    font-weight: 700;
    line-height: 1.35;
    margin-top: -0.25em;
    margin-bottom: 10px
}

.service-card2_title a {
    color: inherit
}

.service-card2_title a:hover {
    color: var(--title-color)
}

.service-card2_text {
    margin-bottom: -0.5em;
    -webkit-transition: 0.3s ease-in-out;
    transition: 0.3s ease-in-out
}

.service-card2_btn {
    background-color: var(--theme-color);
    color: var(--white-color);
    width: 50px;
    height: 112px;
    line-height: 115px;
    display: inline-block;
    text-align: center;
    position: absolute;
    left: 0;
    bottom: 0
}

.service-card2_btn:hover {
    color: var(--white-color)
}

.service-card2:hover .service-card2_title {
    color: var(--white-color)
}

.service-card2:hover .service-card2_text {
    color: var(--white-color)
}

.service-card2:hover .service-card2_content:before {
    height: 0
}

.service-card2:hover .service-card2_icon {
    background-color: var(--white-color)
}

.service-card2:hover .service-card2_icon img {
    -webkit-filter: none;
    filter: none;
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

.service-card2:hover .service-card2_btn {
    background-color: var(--title-color)
}

@media (max-width: 767px) {
    .service-card2_content {
        padding:50px
    }
}

@media (max-width: 575px) {
    .service-card2_content {
        padding:40px
    }
}

@media (max-width: 375px) {
    .service-card2_content {
        padding:30px 20px
    }
}

.service-box.style2 {
    padding: 30px 30px 28px;
    background: var(--white-color);
    box-shadow: 0px 8px 19px rgba(220,220,220,0.3);
    border-radius: 10px
}

.service-box.style2 .service-box_img img {
    border-radius: 10px
}

.service-box.style2:before {
    display: none
}

.service-box.style2 .service-box_content {
    padding: 0;
    margin-top: 23px;
    position: relative;
    z-index: 1
}

.service-box.style2 .service-box_icon {
    position: absolute;
    right: 0;
    top: 7px
}

.service-box.style2 .service-box_icon img {
    -webkit-filter: none;
    filter: none;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.service-box.style2 .service-box_bg-icon {
    position: absolute;
    left: 50%;
    -webkit-transform: translate(-50%, -10px);
    -ms-transform: translate(-50%, -10px);
    transform: translate(-50%, -10px);
    -webkit-filter: grayscale(1);
    filter: grayscale(1);
    opacity: 0.07;
    z-index: -1
}

.service-box.style2 .service-box_bg-icon img {
    width: 200px
}

.service-box.style2 .service-box_subtitle {
    font-size: 14px;
    font-weight: 500;
    color: var(--theme-color);
    font-family: var(--body-font);
    display: block;
    margin-bottom: 14px
}

.service-box.style2 .box-title {
    font-weight: 700
}

.service-box.style2 .service-box_text {
    color: var(--body-color);
    margin-bottom: -0.5em
}

.service-box.style2 .service-box_btn {
    background: transparent;
    padding: 22px 0 0 0;
    color: var(--theme-color);
    display: inline-block;
    font-size: 14px;
    font-weight: 700
}

.service-box.style2 .service-box_btn i {
    -webkit-transition: 0.4s;
    transition: 0.4s;
    margin-left: 4px
}

.service-box.style2 .service-box_btn:hover i {
    margin-left: 10px
}

.service-box.style2 .service-box_btn:before {
    display: none
}

.service-box:hover .service-box_icon img {
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

@media (max-width: 1199px) {
    .service-box.style2 .service-box_icon img {
        width:32px
    }
}

@media (max-width: 375px) {
    .service-box.style2 {
        padding:20px 20px 18px
    }
}

.service-box2 {
    position: relative;
    box-shadow: 0px 6px 14px rgba(7,36,95,0.08);
    background-color: var(--theme-color);
    z-index: 2
}

.service-box2::before {
    content: '';
    width: 100%;
    height: 100%;
    background-color: var(--white-color);
    z-index: -1;
    position: absolute;
    top: 0;
    left: 0;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.service-box2_icon {
    margin-bottom: 18px
}

.service-box2_icon img {
    -webkit-transition: 0.4s ease;
    transition: 0.4s ease
}

.service-box2_content {
    padding: 30px
}

.service-box2_title {
    font-size: 24px;
    margin-bottom: 11px;
    -webkit-transition: 0.1s ease-in-out;
    transition: 0.1s ease-in-out
}

.service-box2_title a {
    color: inherit
}

.service-box2_title a:hover {
    color: var(--white-color)
}

.service-box2_text {
    margin-bottom: -0.5em;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.service-box2_btn {
    font-size: 14px;
    font-weight: bold;
    text-transform: uppercase;
    color: var(--body-color);
    display: block;
    padding: 22px 30px;
    position: relative;
    z-index: 2;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.service-box2_btn::before {
    content: '';
    width: 100%;
    height: 100%;
    background-color: var(--white-color);
    z-index: -1;
    border-top: 1px solid rgba(217,217,217,0.5);
    position: absolute;
    top: 0;
    right: 0;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.service-box2_btn i {
    margin-left: 4px
}

.service-box2:hover::before {
    width: 0
}

.service-box2:hover .service-box2_title,.service-box2:hover .service-box2_text,.service-box2:hover .service-box2_btn {
    color: var(--white-color)
}

.service-box2:hover .service-box2_icon img {
    -webkit-filter: brightness(0) invert(1);
    filter: brightness(0) invert(1);
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

.service-box2:hover .service-box2_btn::before {
    width: 0
}

.project-card-img {
    overflow: hidden
}

.project-card-img img {
    width: 100%;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.project-card-icon {
    border: 7px solid #D4CBB9;
    border-radius: 50%;
    height: 100px;
    width: 100px;
    border-radius: 50%;
    text-align: center;
    line-height: 83px;
    -webkit-transform: translate(45px, -117px);
    -ms-transform: translate(45px, -117px);
    transform: translate(45px, -117px);
    position: relative;
    z-index: 1;
    background: var(--white-color);
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.project-card-icon img {
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.project-card-content {
    margin-bottom: 20px;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

@media (max-width: 320px) {
    .project-card-content {
        font-size:14px
    }
}

.project-card-details {
    margin: 0 15px;
    padding: 80px 30px 30px;
    -webkit-filter: drop-shadow(0px 8px 10px rgba(7,36,95,0.08));
    filter: drop-shadow(0px 8px 10px rgba(7,36,95,0.08));
    background: var(--white-color);
    -webkit-clip-path: polygon(100% 0, 100% 75%, 75% 100%, 0 100%, 0 0);
    clip-path: polygon(100% 0, 100% 75%, 75% 100%, 0 100%, 0 0);
    margin-top: -57px;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

@media (max-width: 991px) {
    .project-card .box-title {
        font-size:22px
    }
}

@media (max-width: 320px) {
    .project-card .box-title {
        font-size:20px
    }
}

.project-card .th-btn {
    padding: 15px 25px;
    font-size: 14px
}

.project-card:hover .project-card-img img {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1)
}

.project-card:hover .project-card-icon {
    border-color: var(--white-color);
    background: var(--theme-color)
}

.project-card:hover .project-card-icon img {
    -webkit-filter: brightness(99);
    filter: brightness(99);
    -webkit-transform: rotateY(180deg);
    transform: rotateY(180deg)
}

.project-card:hover .project-card-details {
    background-color: var(--theme-color)
}

.project-card:hover .box-title a {
    color: var(--white-color)
}

.project-card:hover .box-title a:hover {
    color: var(--title-color)
}

.project-card:hover .project-card-content {
    color: var(--white-color)
}

.project-card:hover .th-btn {
    color: var(--theme-color);
    border-color: var(--white-color);
    background: var(--white-color)
}

.project-card:hover .th-btn:hover:before,.project-card:hover .th-btn:hover:after {
    background-color: var(--white-color)
}

.project-card.style1-1 .project-card-details {
    margin-top: -57px;
    padding: 30px;
    position: relative;
    background: transparent
}

.project-card.style1-1 .project-card-details:before,.project-card.style1-1 .project-card-details:after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    background-color: #e7e7e7;
    -webkit-clip-path: polygon(100% 0, 100% 75%, 75% 100%, 0 100%, 0 0);
    clip-path: polygon(100% 0, 100% 75%, 75% 100%, 0 100%, 0 0);
    z-index: -2;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.project-card.style1-1 .project-card-details:before {
    background-color: var(--white-color);
    height: calc(100% - 2px);
    width: calc(100% - 2px);
    top: 1px;
    left: 1px;
    z-index: -1
}

.project-card.style1-1:hover .project-card-details {
    background: var(--theme-color);
    -webkit-clip-path: polygon(100% 0, 100% 75%, 75% 100%, 0 100%, 0 0);
    clip-path: polygon(100% 0, 100% 75%, 75% 100%, 0 100%, 0 0)
}

.project-card.style1-1:hover .project-card-details:after,.project-card.style1-1:hover .project-card-details:before {
    opacity: 0;
    visibility: hidden
}

.project-slider2 {
    margin-left: 328px;
    height: 440px
}

.project-slider2 .slick-arrow {
    --pos-x: -105px;
    margin-top: -63.5px
}

.project-slider2 .slick-arrow.slick-next {
    right: auto;
    left: var(--pos-x);
    margin-top: 7.5px
}

.project-slider2 .slick-slide {
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.project-slider2 .slick-slide .project-card-img {
    height: 440px;
    overflow: hidden
}

.project-slider2 .slick-slide .project-card-img img {
    height: 100%;
    object-fit: cover
}

.project-slider2 .slick-current {
    width: calc(598px + 24px) !important
}

.project-slider2 .slick-current .project-card.style2 {
    width: 100%
}

.project-slider2 .slick-current .project-card.style2 .project-card-content {
    height: 100%;
    -webkit-transform: scaleY(1);
    -ms-transform: scaleY(1);
    transform: scaleY(1);
    opacity: 1;
    margin-top: 15px
}

@media (max-width: 767px) {
    .project-slider2 .slick-current {
        width:588px !important
    }
}

@media (max-width: 575px) {
    .project-slider2 .slick-current {
        width:413px !important
    }
}

@media (max-width: 375px) {
    .project-slider2 .slick-current {
        width:363px !important
    }
}

@media (max-width: 320px) {
    .project-slider2 .slick-current {
        width:308px !important
    }
}

@media (max-width: 1700px) {
    .project-slider2 {
        margin-left:150px
    }
}

@media (max-width: 1500px) {
    .project-slider2 {
        margin-left:0px
    }
}

@media (max-width: 767px) {
    .project-slider2 .slick-list {
        margin-left:-6px
    }
}

.project-card.style2 {
    -webkit-transition: 0.4s;
    transition: 0.4s;
    position: relative
}

.project-card.style2 .project-card-details {
    padding: 30px 75px 30px 30px;
    -webkit-clip-path: polygon(0 0, 85% 0, 100% 100%, 0% 100%);
    clip-path: polygon(0 0, 85% 0, 100% 100%, 0% 100%);
    max-width: 360px;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    margin: 0
}

.project-card.style2 .project-card-details-wrap {
    display: inline-block;
    margin: 20px;
    position: absolute;
    left: 0;
    bottom: 0
}

.project-card.style2 .project-card-details-wrap .gallery-btn {
    opacity: 1;
    visibility: visible;
    box-shadow: 0px 8px 19px 0px rgba(255,76,19,0.3);
    border-radius: 0;
    background: var(--theme-color);
    color: var(--white-color);
    right: 0;
    top: 50%;
    left: auto;
    bottom: auto;
    -webkit-transform: translate(0, -50%);
    -ms-transform: translate(0, -50%);
    transform: translate(0, -50%);
    z-index: 9
}

.project-card.style2 .project-card-details .project-subtitle {
    font-size: 16px;
    font-weight: 400;
    font-family: var(--body-font);
    color: var(--theme-color);
    margin-top: -0.3em
}

.project-card.style2 .project-card-details .box-title {
    margin-bottom: 0
}

.project-card.style2 .project-card-details .box-title a {
    color: var(--title-color)
}

.project-card.style2 .project-card-details .project-card-content {
    height: 0;
    margin-bottom: -0.4em;
    opacity: 0;
    -webkit-transform: scaleY(0);
    -ms-transform: scaleY(0);
    transform: scaleY(0);
    -webkit-transition: 0.4s;
    transition: 0.4s;
    color: var(--body-color)
}

.project-card.style2:hover .project-card-details {
    background: var(--white-color)
}

@media (max-width: 1700px) {
    .project-card.style2 .project-card-details .box-title {
        font-size:22px
    }
}

@media (max-width: 375px) {
    .project-card.style2 .project-card-details {
        padding:30px 45px 30px 30px
    }
}

.project-slider3 .slick-arrow {
    display: none !important
}

.project-slider3 .mn-4 {
    margin-left: 12px;
    margin-right: 12px
}

.project-slider3 .mn-4 .project-card.style3 {
    margin-left: 0;
    margin-right: 0
}

.project-card-wrap .project-card.style3 {
    height: 228px
}

.project-card.style3 {
    margin-left: 12px;
    margin-right: 12px;
    position: relative;
    overflow: hidden
}

.project-card.style3 .project-card-details-wrap {
    display: -webkit-inline-box;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 30px;
    background: var(--white-color);
    position: absolute;
    right: 0;
    bottom: -15px;
    gap: 40px;
    opacity: 0;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.project-card.style3 .project-card-details-wrap .project-card-details {
    margin: 0;
    -webkit-clip-path: none;
    clip-path: none;
    padding: 0;
    box-shadow: none;
    background: transparent
}

.project-card.style3 .project-card-details-wrap .project-subtitle {
    font-size: 14px;
    font-weight: 400;
    color: #8A8A8A;
    margin-top: -0.3em;
    margin-bottom: 12px
}

.project-card.style3 .project-card-details-wrap .box-title {
    margin-bottom: -0.3em;
    font-size: 18px
}

.project-card.style3 .project-card-details-wrap .box-title a {
    color: var(--title-color)
}

.project-card.style3 .project-card-details-wrap .box-title a:hover {
    color: var(--theme-color)
}

.project-card.style3 .project-card-details-wrap .icon-btn {
    --btn-size: 30px;
    border-radius: 0;
    background: var(--theme-color);
    box-shadow: 0px 8px 19px 0px rgba(255,76,19,0.3);
    color: var(--white-color);
    line-height: 33px
}

.project-card.style3:hover .project-card-details-wrap {
    opacity: 1;
    bottom: 0
}

.project-card.style4 .project-card-details {
    margin: 0;
    -webkit-clip-path: none;
    clip-path: none;
    background: transparent;
    box-shadow: none;
    padding: 0
}

.project-card.style4 .project-card-details .project-subtitle {
    color: var(--theme-color);
    font-size: 16px;
    font-weight: 400;
    margin-bottom: 14px;
    display: block
}

.project-card.style4 .project-card-details .project-card-title a {
    color: var(--title-color)
}

.project-card.style4 .project-card-details .project-card-title a:hover {
    color: var(--theme-color)
}

@media (max-width: 1299px) {
    .project-card.style4 .project-card-details .project-card-title {
        font-size:30px
    }
}

@media (max-width: 1199px) {
    .project-card.style4 .project-card-details .project-card-title {
        font-size:26px
    }
}

.project-card.style4 .project-card-details .project-card-content {
    color: var(--body-color);
    margin-bottom: 27px
}

@media (max-width: 1199px) {
    .project-card.style4 .project-card-details .project-card-content {
        font-size:14px
    }
}

.project-card.style4 .project-card-details .project-card-info-title {
    font-size: 18px;
    font-weight: 600;
    display: inline-block;
    padding-bottom: 3px;
    border-bottom: 2px solid var(--theme-color);
    margin-bottom: 8px
}

.project-card.style4 .project-card-details .project-card-info-meta {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    -webkit-flex-flow: wrap;
    -ms-flex-flow: wrap;
    flex-flow: wrap;
    gap: 20px
}

.project-card.style4 .project-card-details .project-card-single-info {
    font-size: 14px
}

.project-card.style4 .project-card-details .project-card-single-info strong {
    display: block;
    font-weight: 600;
    text-transform: uppercase;
    color: var(--title-color)
}

.portfolio-slider4 {
    margin: 0 -100px 0px -500px;
    padding-bottom: 70px
}

.portfolio-slider4 .slick-dots {
    margin: 60px 0px 0 200px;
    position: absolute;
    left: 50%;
    bottom: 0;
    -webkit-transform: translate(-50%, 0);
    -ms-transform: translate(-50%, 0);
    transform: translate(-50%, 0);
    width: auto;
    max-width: none;
    display: inline-block
}

.portfolio-slider4 .slick-dots:after {
    content: '05';
    position: absolute;
    right: -40px;
    top: 3px;
    font-size: 16px;
    font-weight: 400;
    color: var(--title-color)
}

.portfolio-slider4 .slick-dots li {
    background: #E4E4E4;
    margin: 0;
    height: 2px;
    width: 118px;
    padding: 0;
    counter-increment: li
}

.portfolio-slider4 .slick-dots li:after {
    content: "0" counter(li);
    position: absolute;
    left: -40px;
    top: 3px;
    font-size: 16px;
    font-weight: 400;
    color: var(--title-color);
    opacity: 0
}

.portfolio-slider4 .slick-dots li button {
    background: transparent;
    height: 2px;
    width: 118px
}

.portfolio-slider4 .slick-dots li button:before {
    width: 0;
    height: 2px;
    top: -4px;
    left: 0;
    -webkit-transform: none;
    -ms-transform: none;
    transform: none;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.portfolio-slider4 .slick-dots li.slick-active button:before {
    width: 100%
}

.portfolio-slider4 .slick-dots li.slick-active:after {
    opacity: 1
}

@media (max-width: 1199px) {
    .portfolio-slider4 {
        margin:0 30px 0px 30px;
        padding-bottom: 60px
    }

    .portfolio-slider4 .slick-dots {
        margin: 60px 0px 0 0px;
        display: -webkit-box;
        display: -webkit-flex;
        display: -ms-flexbox;
        display: flex
    }

    .portfolio-slider4 .slick-dots li {
        width: 80px
    }

    .portfolio-slider4 .slick-dots li button {
        width: 80px
    }
}

@media (max-width: 767px) {
    .portfolio-slider4 {
        margin:0 30px 0px 30px;
        padding-bottom: 0
    }
}

@media (max-width: 575px) {
    .portfolio-slider4 {
        margin:0
    }
}

.project-card.style5 .project-card-details-wrap {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    margin: 30px 0 0 0;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.project-card.style5 .project-card-details {
    background: transparent;
    -webkit-clip-path: none;
    clip-path: none;
    padding: 0;
    -webkit-filter: none;
    filter: none;
    margin: 0
}

.project-card.style5 .box-title {
    font-size: 30px;
    font-weight: 600;
    margin-bottom: 10px
}

.project-card.style5 .box-title a {
    color: var(--title-color)
}

.project-card.style5 .box-title:hover a {
    color: var(--theme-color)
}

.project-card.style5 .project-location {
    margin-bottom: 0;
    font-size: 14px;
    color: var(--theme-color);
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    gap: 7px;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center
}

.project-card.style5 .project-location i {
    font-size: 20px
}

.project-card.style5 .project-card-number {
    font-size: 64px;
    font-weight: 700;
    font-family: var(--title-font);
    -webkit-text-stroke: 1px #E4E4E4;
    color: transparent
}

@media (max-width: 991px) {
    .project-card.style5 .box-title {
        font-size:24px
    }

    .project-card.style5 .project-card-number {
        font-size: 50px
    }
}

@media (max-width: 375px) {
    .project-card.style5 .box-title {
        font-size:20px
    }

    .project-card.style5 .project-card-number {
        font-size: 40px
    }
}

.project-block .project-content {
    background: var(--white-color);
    padding: 30px;
    margin: 0 auto;
    position: relative;
    z-index: 4;
    width: 100%;
    border-radius: 0 0 10px 10px;
    box-shadow: 0px 6px 15px rgba(14,18,29,0.06);
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    margin-bottom: 2px
}

.project-block .project-img {
    overflow: hidden;
    position: relative;
    z-index: 2;
    border-radius: 10px 10px 0 0
}

.project-block .project-img img {
    width: 100%;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    border-radius: 10px 10px 0 0
}

.project-block .project-subtitle {
    margin-top: -0.45em;
    margin-bottom: 6px;
    color: var(--theme-color)
}

.project-block .project-title {
    font-size: 24px;
    margin-bottom: -0.24em
}

.project-block .project-title a {
    color: inherit
}

.project-block .project-title a:hover {
    color: var(--theme-color)
}

.project-block .project-icon {
    display: inline-block;
    background-color: var(--theme-color);
    width: 50px;
    height: 50px;
    line-height: 50px;
    font-size: 16px;
    color: var(--white-color);
    box-shadow: 0px 8px 19px rgba(255,76,19,0.3);
    border-radius: 5px;
    text-align: center
}

.project-block .project-icon:hover {
    background-color: var(--title-color);
    color: var(--white-color)
}

#projectSlide4 .slick-list {
    padding-right: 20%
}

@media (max-width: 1299px) {
    #projectSlide4 .slick-list {
        padding-right:14%
    }
}

@media (max-width: 1399px) {
    #projectSlide4 .slick-list {
        padding-right:10%
    }
}

@media (max-width: 1300px) {
    #projectSlide4 .slick-list {
        padding-right:0
    }

    .project-block .project-title {
        font-size: 22px
    }
}

@media (max-width: 767px) {
    .project-block {
        max-width:400px;
        margin-left: auto;
        margin-right: auto
    }
}

@media (max-width: 360px) {
    .project-block .project-subtitle {
        font-size:14px
    }

    .project-block .project-title {
        font-size: 18px
    }
}

.project-grid {
    position: relative
}

.project-grid .project-content {
    background: var(--white-color);
    box-shadow: 0px 4px 15px rgba(7,36,95,0.1);
    padding: 30px;
    margin: 0 auto;
    z-index: 4;
    width: calc(100% - 80px);
    position: absolute;
    bottom: 40px;
    left: 40px;
    border-radius: 0
}

.project-grid .project-img {
    overflow: hidden;
    position: relative;
    z-index: 2
}

.project-grid .project-img img {
    width: 100%;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.project-grid .project-subtitle {
    margin-top: -0.45em;
    margin-bottom: 3px
}

.project-grid .project-title {
    font-size: 30px;
    margin-bottom: -0.2em
}

.project-grid .project-title a {
    color: inherit
}

.project-grid .project-title a:hover {
    color: var(--theme-color)
}

.project-grid .project-icon {
    display: inline-block;
    background-color: var(--theme-color);
    width: 50px;
    height: 50px;
    line-height: 50px;
    font-size: 16px;
    color: var(--white-color);
    box-shadow: 0px 8px 19px rgba(255,76,19,0.3);
    text-align: center;
    position: absolute;
    top: 50%;
    right: 30px;
    margin-top: -25px;
    border-radius: 0
}

.project-grid .project-icon:hover {
    background-color: var(--title-color);
    color: var(--white-color)
}

.project-grid:hover .project-img img {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1)
}

.project-6thumb {
    margin-bottom: var(--bs-gutter-x);
    cursor: pointer
}

.project-6thumb .project-thumb_img img {
    height: 192px
}

.icon-box.style3 {
    background-color: var(--body-color);
    gap: 10px;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    padding: 30px
}

.icon-box.style3 .slick-arrow {
    margin: 0
}

@media (max-width: 1299px) {
    .project-6thumb .project-thumb_img img {
        height:168px;
        width: 100%;
        object-fit: cover
    }
}

@media (max-width: 1199px) {
    .project-6thumb .project-thumb_img img {
        height:140px
    }

    .project-grid .project-img img {
        height: 428px;
        object-fit: cover
    }

    .icon-box.style3 {
        padding: 20px
    }
}

@media (max-width: 991px) {
    .projectSlideThumb {
        margin-top:24px
    }
}

@media (max-width: 575px) {
    .project-grid .project-img img {
        height:350px
    }

    .project-grid .project-title {
        font-size: 22px
    }

    .project-grid .project-content {
        padding: 30px 75px 30px 20px;
        width: calc(100% - 40px);
        bottom: 20px;
        left: 20px
    }

    .project-grid .project-icon {
        right: 20px
    }
}

@media (max-width: 375px) {
    .project-grid .project-title {
        font-size:20px
    }

    .project-grid .project-content {
        width: 100%;
        bottom: 0;
        left: 0;
        border-radius: 0;
        border: 1px solid var(--border-color)
    }
}

.project-card2-wrap {
    max-width: 996px;
    margin-left: 18px;
    position: relative
}

.project-card2-wrap .icon-box {
    position: absolute;
    top: 50%;
    right: -140px;
    width: 60px
}

.project-card2-wrap .icon-box .slick-arrow:first-child {
    margin-bottom: 10px
}

.project-card2 .project-img {
    border-radius: 10px;
    position: relative;
    overflow: hidden
}

.project-card2 .project-img img {
    -webkit-transition: 0.4s;
    transition: 0.4s;
    width: 100%
}

.project-card2 .project-img:before {
    content: '';
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    background: -webkit-linear-gradient(bottom, #07245F 0%, rgba(7,36,95,0) 100%);
    background: linear-gradient(0deg, #07245F 0%, rgba(7,36,95,0) 100%);
    z-index: 1
}

.project-card2 .project-content {
    margin: -65px auto 0 auto;
    background: var(--white-color);
    box-shadow: 0px 4px 15px rgba(7,36,95,0.1);
    border-radius: 10px;
    padding: 30px;
    width: calc(100% - 40px);
    position: relative;
    z-index: 4
}

.project-card2 .project-subtitle {
    margin-top: -0.45em;
    margin-bottom: 6px
}

.project-card2 .project-title {
    font-size: 20px;
    margin-bottom: -0.2em
}

.project-card2 .project-title a {
    color: var(--title-color)
}

.project-card2 .project-title a:hover {
    color: var(--theme-color)
}

.project-card2 .project-icon {
    display: inline-block;
    background-color: var(--theme-color);
    width: 50px;
    height: 50px;
    line-height: 50px;
    font-size: 16px;
    color: var(--white-color);
    box-shadow: 0px 8px 19px rgba(255,76,19,0.3);
    border-radius: 5px;
    text-align: center;
    position: absolute;
    top: -25px;
    right: 25px
}

.project-card2 .project-icon:hover {
    background-color: var(--title-color);
    color: var(--white-color)
}

.project-card2:hover .project-img img {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1)
}

.project-card2:hover .project-icon {
    -webkit-animation: jumpIcon 1s linear infinite;
    animation: jumpIcon 1s linear infinite
}

@media (max-width: 1399px) {
    .project-card2 .project-title {
        font-size:18px
    }

    .project-card2-wrap {
        margin-left: 0
    }

    .project-card2-wrap .icon-box {
        display: none
    }
}

.project-9-fan-anime {
    -webkit-transform: translate(0, -373px);
    -ms-transform: translate(0, -373px);
    transform: translate(0, -373px)
}

@media (max-width: 1700px) {
    .project-9-fan-anime {
        -webkit-transform:translate(0, -210px);
        -ms-transform: translate(0, -210px);
        transform: translate(0, -210px);
        width: 220px
    }
}

@media (max-width: 1500px) {
    .project-9-fan-anime {
        display:none
    }
}

.project-block2 {
    position: relative
}

.project-block2:before,.project-block2:after {
    content: '';
    position: absolute;
    height: 0;
    width: 100%;
    bottom: 0;
    left: 0;
    background: -webkit-linear-gradient(top, rgba(14,18,29,0) 1.56%, rgba(14,18,29,0.866415) 71.85%, rgba(14,18,29,0.948351) 81.69%, #0E121D 90.92%);
    background: linear-gradient(180deg, rgba(14,18,29,0) 1.56%, rgba(14,18,29,0.866415) 71.85%, rgba(14,18,29,0.948351) 81.69%, #0E121D 90.92%);
    z-index: 1;
    opacity: 0;
    -webkit-transition: 0.4s;
    transition: 0.4s
}

.project-block2:before {
    border: 1px solid;
    border-image-source: linear-gradient(to top, var(--theme-color), transparent);
    border-image-slice: 1;
    background: transparent;
    z-index: 2
}

.project-block2 .project-content {
    position: absolute;
    width: 100%;
    bottom: 0;
    background: transparent;
    padding: 50px;
    -webkit-transition: 0.4s;
    transition: 0.4s;
    opacity: 0;
    z-index: 3
}

.project-block2 .project-content .project-title {
    margin-bottom: 17px
}

.project-block2 .project-content .project-title a {
    color: var(--white-color)
}

.project-block2 .project-content .project-title a:hover {
    color: var(--theme-color)
}

.project-block2 .project-content .project-text {
    color: var(--border-color);
    margin-bottom: 25px
}

.project-block2:hover:after,.project-block2:hover:before {
    opacity: 1;
    height: 100%
}

.project-block2:hover .project-content {
    opacity: 1
}

@media (max-width: 1600px) {
    .project-block2 .project-content {
        padding:40px
    }
}

@media (max-width: 375px) {
    .project-block2 .project-content {
        padding:30px
    }
}

.project-box {
    position: relative;
    overflow: hidden
}

.project-box .project-img:before {
    content: '';
    width: 100%;
    height: 100%;
    position: absolute;
    top: 100%;
    left: 0;
    background: -webkit-linear-gradient(bottom, #07245F .08%, rgba(7,36,95,0) 59.32%);
    background: linear-gradient(0deg, #07245F .08%, rgba(7,36,95,0) 59.32%);
    z-index: 1;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out
}

.project-box .project-img img {
    -webkit-transition: 0.4s;
    transition: 0.4s;
    width: 100%
}

.project-box .project-content {
    position: absolute;
    bottom: 20px;
    left: 20px;
    visibility: hidden;
    opacity: 0;
    -webkit-transition: 0.4s ease-in-out;
    transition: 0.4s ease-in-out;
    -webkit-transform: translateY(50px);
    -ms-transform: translateY(50px);
    transform: translateY(50px);
    border-radius: 0;
    background: var(--white-color);
    box-shadow: 0px 4px 15px rgba(7,36,95,0.1);
    padding: 30px;
    width: calc(100% - 40px);
    margin: 0 auto;
    z-index: 4
}

.project-box .project-subtitle {
    margin-top: -0.45em;
    margin-bottom: 6px
}

.project-box .project-icon {
    position: absolute;
    top: -25px;
    right: 25px;
    border-radius: 0;
    display: inline-block;
    background-color: var(--theme-color);
    width: 50px;
    height: 50px;
    line-height: 50px;
    font-size: 16px;
    color: var(--white-color);
    box-shadow: 0px 8px 19px rgba(255,76,19,0.3);
    text-align: center
}

.project-box .project-icon:hover {
    background-color: var(--title-color);
    color: var(--white-color)
}

.project-box .project-title {
    font-size: 24px;
    margin-bottom: -0.24em
}

.project-box .project-title a {
    color: inherit
}

.project-box .project-title a:hover {
    color: var(--theme-color)
}

.project-box:hover .project-img::before {
    top: 0
}

.project-box:hover .project-img img {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1)
}

.project-box:hover .project-icon {
    -webkit-animation: jumpIcon 1s linear infinite;
    animation: jumpIcon 1s linear infinite
}

.project-box:hover .project-content {
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0);
    visibility: visible;
    opacity: 1
}

.slick-current.slick-center .project-box .project-img::before {
    top: 0
}

.slick-current.slick-center .project-box .project-img img {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1)
}

.slick-current.slick-center .project-box .project-icon {
    -webkit-animation: jumpIcon 1s linear infinite;
    animation: jumpIcon 1s linear infinite
}

.slick-current.slick-center .project-box .project-content {
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0);
    visibility: visible;
    opacity: 1
}

@media (max-width: 767px) {
    .project-sec-10.bg-top-center {
        background-size:100% 80%
    }
}

.px-5 {
    padding-right: 5px;
    padding-left: 5px
}

.px-10 {
    padding-right: 10px;
    padding-left: 10px
}

.px-15 {
    padding-right: 15px;
    padding-left: 15px
}

.px-20 {
    padding-right: 20px;
    padding-left: 20px
}

.px-25 {
    padding-right: 25px;
    padding-left: 25px
}

.px-30 {
    padding-right: 30px;
    padding-left: 30px
}

.px-35 {
    padding-right: 35px;
    padding-left: 35px
}

.px-40 {
    padding-right: 40px;
    padding-left: 40px
}

.px-45 {
    padding-right: 45px;
    padding-left: 45px
}

.px-50 {
    padding-right: 50px;
    padding-left: 50px
}

.py-5 {
    padding-top: 5px;
    padding-bottom: 5px
}

.py-10 {
    padding-top: 10px;
    padding-bottom: 10px
}

.py-15 {
    padding-top: 15px;
    padding-bottom: 15px
}

.py-20 {
    padding-top: 20px;
    padding-bottom: 20px
}

.py-25 {
    padding-top: 25px;
    padding-bottom: 25px
}

.py-30 {
    padding-top: 30px;
    padding-bottom: 30px
}

.py-35 {
    padding-top: 35px;
    padding-bottom: 35px
}

.py-40 {
    padding-top: 40px;
    padding-bottom: 40px
}

.py-45 {
    padding-top: 45px;
    padding-bottom: 45px
}

.py-50 {
    padding-top: 50px;
    padding-bottom: 50px
}

.pt-5 {
    padding-top: 5px
}

.pt-10 {
    padding-top: 10px
}

.pt-15 {
    padding-top: 15px
}

.pt-20 {
    padding-top: 20px
}

.pt-25 {
    padding-top: 25px
}

.pt-30 {
    padding-top: 30px
}

.pt-35 {
    padding-top: 35px
}

.pt-40 {
    padding-top: 40px
}

.pt-45 {
    padding-top: 45px
}

.pt-50 {
    padding-top: 50px
}

.pb-5 {
    padding-bottom: 5px
}

.pb-10 {
    padding-bottom: 10px
}

.pb-15 {
    padding-bottom: 15px
}

.pb-20 {
    padding-bottom: 20px
}

.pb-25 {
    padding-bottom: 25px
}

.pb-30 {
    padding-bottom: 30px
}

.pb-35 {
    padding-bottom: 35px
}

.pb-40 {
    padding-bottom: 40px
}

.pb-45 {
    padding-bottom: 45px
}

.pb-50 {
    padding-bottom: 50px
}

.pl-5 {
    padding-left: 5px
}

.pl-10 {
    padding-left: 10px
}

.pl-15 {
    padding-left: 15px
}

.pl-20 {
    padding-left: 20px
}

.pl-25 {
    padding-left: 25px
}

.pl-30 {
    padding-left: 30px
}

.pl-35 {
    padding-left: 35px
}

.pl-40 {
    padding-left: 40px
}

.pl-45 {
    padding-left: 45px
}

.pl-50 {
    padding-left: 50px
}

.pr-5 {
    padding-right: 5px
}

.pr-10 {
    padding-right: 10px
}

.pr-15 {
    padding-right: 15px
}

.pr-20 {
    padding-right: 20px
}

.pr-25 {
    padding-right: 25px
}

.pr-30 {
    padding-right: 30px
}

.pr-35 {
    padding-right: 35px
}

.pr-40 {
    padding-right: 40px
}

.pr-45 {
    padding-right: 45px
}

.pr-50 {
    padding-right: 50px
}

.mx-5 {
    margin-right: 5px;
    margin-left: 5px
}

.mx-10 {
    margin-right: 10px;
    margin-left: 10px
}

.mx-15 {
    margin-right: 15px;
    margin-left: 15px
}

.mx-20 {
    margin-right: 20px;
    margin-left: 20px
}

.mx-25 {
    margin-right: 25px;
    margin-left: 25px
}

.mx-30 {
    margin-right: 30px;
    margin-left: 30px
}

.mx-35 {
    margin-right: 35px;
    margin-left: 35px
}

.mx-40 {
    margin-right: 40px;
    margin-left: 40px
}

.mx-45 {
    margin-right: 45px;
    margin-left: 45px
}

.mx-50 {
    margin-right: 50px;
    margin-left: 50px
}

.my-5 {
    margin-top: 5px;
    margin-bottom: 5px
}

.my-10 {
    margin-top: 10px;
    margin-bottom: 10px
}

.my-15 {
    margin-top: 15px;
    margin-bottom: 15px
}

.my-20 {
    margin-top: 20px;
    margin-bottom: 20px
}

.my-25 {
    margin-top: 25px;
    margin-bottom: 25px
}

.my-30 {
    margin-top: 30px;
    margin-bottom: 30px
}

.my-35 {
    margin-top: 35px;
    margin-bottom: 35px
}

.my-40 {
    margin-top: 40px;
    margin-bottom: 40px
}

.my-45 {
    margin-top: 45px;
    margin-bottom: 45px
}

.my-50 {
    margin-top: 50px;
    margin-bottom: 50px
}

.mt-5 {
    margin-top: 5px
}

.mt-10 {
    margin-top: 10px
}

.mt-15 {
    margin-top: 15px
}

.mt-20 {
    margin-top: 20px
}

.mt-25 {
    margin-top: 25px
}

.mt-30 {
    margin-top: 30px
}

.mt-35 {
    margin-top: 35px
}

.mt-40 {
    margin-top: 40px
}

.mt-45 {
    margin-top: 45px
}

.mt-50 {
    margin-top: 50px
}

.mb-5 {
    margin-bottom: 5px
}

.mb-10 {
    margin-bottom: 10px
}

.mb-15 {
    margin-bottom: 15px
}

.mb-20 {
    margin-bottom: 20px
}

.mb-25 {
    margin-bottom: 25px
}

.mb-30 {
    margin-bottom: 30px
}

.mb-35 {
    margin-bottom: 35px
}

.mb-40 {
    margin-bottom: 40px
}

.mb-45 {
    margin-bottom: 45px
}

.mb-50 {
    margin-bottom: 50px
}

.ml-5 {
    margin-left: 5px
}

.ml-10 {
    margin-left: 10px
}

.ml-15 {
    margin-left: 15px
}

.ml-20 {
    margin-left: 20px
}

.ml-25 {
    margin-left: 25px
}

.ml-30 {
    margin-left: 30px
}

.ml-35 {
    margin-left: 35px
}

.ml-40 {
    margin-left: 40px
}

.ml-45 {
    margin-left: 45px
}

.ml-50 {
    margin-left: 50px
}

.mr-5 {
    margin-right: 5px
}

.mr-10 {
    margin-right: 10px
}

.mr-15 {
    margin-right: 15px
}

.mr-20 {
    margin-right: 20px
}

.mr-25 {
    margin-right: 25px
}

.mr-30 {
    margin-right: 30px
}

.mr-35 {
    margin-right: 35px
}

.mr-40 {
    margin-right: 40px
}

.mr-45 {
    margin-right: 45px
}

.mr-50 {
    margin-right: 50px
}

.mb-60 {
    margin-bottom: 60px
}

.mt-60 {
    margin-top: 60px
}

.mt-n1 {
    margin-top: -.25rem
}

.mt-n2 {
    margin-top: -.6rem
}

.mt-n3 {
    margin-top: -1rem
}

.mt-n4 {
    margin-top: -1.5rem
}

.mt-n5 {
    margin-top: -3rem
}

.mb-n1 {
    margin-bottom: -.25rem
}

.mb-n2 {
    margin-bottom: -.6rem
}

.mb-n3 {
    margin-bottom: -1rem
}

.mb-n4 {
    margin-bottom: -1.5rem
}

.mb-n5 {
    margin-bottom: -3rem
}

.space,.space-top {
    padding-top: 50px
}

.space,.space-bottom {
    padding-bottom: 50px
}

.space-extra,.space-extra-top {
    padding-top: calc(var(--section-space) - 30px)
}

.space-extra,.space-extra-bottom {
    padding-bottom: calc(var(--section-space) - 30px)
}

.space-extra2,.space-extra2-top {
    padding-top: calc(var(--section-space) - 40px)
}

.space-extra2,.space-extra2-bottom {
    padding-bottom: calc(var(--section-space) - 40px)
}

@media (max-width: 991px) {
    .space,.space-top {
        padding-top:var(--section-space-mobile)
    }

    .space,.space-bottom {
        padding-bottom: var(--section-space-mobile)
    }

    .space-extra,.space-extra-top {
        padding-top: calc(var(--section-space-mobile) - 30px)
    }

    .space-extra,.space-extra-bottom {
        padding-bottom: calc(var(--section-space-mobile) - 30px)
    }

    .space-top-md-none {
        padding-top: 0
    }
}

.fix-icon {
    display: inline-block;
    position: fixed;
    bottom: 100px;
    right: 20px;
    z-index: 999999;
}

img:not([draggable]), embed, object, video {
    max-width: 139% !important;
    height: auto;
}

.header-layout8 .sticky-wrapper.sticky, .header-layout8 .main-menu ul.sub-menu, .header-layout8 .main-menu ul.mega-menu {
    background: #890034;
}

#fix-icon {
    -webkit-animation-duration: 2.5s;
    animation-duration: 2.5s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
    -webkit-animation-timing-function: linear;
    animation-timing-function: linear;
    animation-iteration-count: infinite;
    -webkit-animation-iteration-count: infinite;
}

.fix-icon-item {
    animation: bounce 1s infinite alternate;
    animation-duration: 1s;
    -webkit-animation: bounce 1s infinite alternate;
    animation-duration: 1s;
    animation-timing-function: ease;
    animation-iteration-count: infinite;
    animation-fill-mode: none;
}

.fix-icon-item img {
    width: 55px !important;
    height: 55px !important;
    background: #df722b;
    border-radius: 50%;
    text-align: center;
    cursor: pointer;
    padding: 10px;
}

.fix-icon-whataap {
    display: inline-block;
    position: fixed;
    bottom: 30px;
    right: 20px;
    z-index: 999999;
    transition: all0.5s ease-in-out;
}

.fix-icon-whataap-item img {
    border-radius: 50%;
    box-shadow: 1px 1px 4px rgba(60, 60, 60, .4);
    transition: box-shadow .2s;
    cursor: pointer;
    overflow: hidden;
    width: 55px !important;
    height: 55px !important;
    background: #25d366 !important;
}

@media (max-width: 767px) {
    .lg {
        width:247px!important;
        background-color: white!important;
    }

    .gl {
        background-color: white!important;
    }

    .hero-style9 .hero-subtitle {
        font-size: 14px!important;
        margin-bottom: 10px!important;
    }

    .hero-style9 .hero-title {
        font-size: 18px!important;
    }

    .hero-style9 .hero-text {
        font-size: 15px!important;
    }

    .im1 {
        width: 100%!important;
        height: 35%!important;
    }

    .hero-9 .hero-img {
        top: 150px!important;
    }

    .cod {
        margin-top: 440px;
    }

    .ab {
        padding-top: 35px;
        padding-bottom: 15px;
    }

    .ba {
        margin-top: 30px!important;
    }

    .bs {
        margin-top: 45px;
    }

    .blog-meta a i {
        margin-right: -6px!important;
    }

    .th-menu-wrapper .mobile-logo {
        max-width: 233px!important;
    }

    .ct {
        padding-top: 55px;
    }

    .gh {
        margin-top: 108px !important;
    }

    .pd {
        padding-bottom: 15px;
    }

    .ht {
        padding-top: 20px;
    }

    .abt {
        padding-top: 0px;
    }

    .st {
        padding-top: 5px!important;
    }

    .ctp {
        padding-top: 0px!important;
    }
}

.login-popup {
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    z-index: 1099;
    background-color: rgba(0,0,0,0.6);
    opacity: 0;
    transition: all 1s ease;
}

.login-popup.show {
    visibility: visible;
    opacity: 1;
}

.login-popup .box {
    width: 1000px;
    position: absolute;
    left: 50%;
    top: 49%;
    transform: translate(-50%,-50%);
    display: flex;
    flex-wrap: wrap;
    opacity: 0;
    margin-left: 50px;
    transition: all 1s ease;
    padding-top: 70px;
}

.login-popup.show .box {
    opacity: 1;
    margin-left: 0;
}

.login-popup .box .img-area {
    flex: 0 0 50%;
    max-width: 25%;
    position: relative;
    overflow: hidden;
    padding: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.login-popup .box .img-area h1 {
    font-size: 30px;
}

.login-popup .box .img-area .img {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-image: url('img/bg.jpg');
    background-size: cover;
    background-position: center;
    animation: zoomInOut 7s linear infinite;
    z-index: -1;
}

@keyframes zoomInOut {
    0%,100% {
        transform: scale(1);
    }

    50% {
        transform: scale(1.1);
    }
}

.login-popup .box .form {
    flex: 0 0 50%;
    max-width: 50%;
    padding: 40px 30px;
}

.login-popup .box .form h1 {
    color: #000000;
    font-size: 30px;
    margin: 0 0 15px;
}

.login-popup .box .form .form-control {
    height: 45px;
    margin-bottom: 30px;
    width: 100%;
    border: none;
    border-bottom: 1px solid #626262;
    font-size: 15px;
    color: #000000;
}

.login-popup .box .form .form-control:focus {
    outline: none;
}

.login-popup .box .form label {
    font-size: 15px;
    color: #555555;
}

.login-popup .box .form .btn {
    width: 93%;
    background-color: #0070ba;
    margin-top: 5px;
    height: 45px;
    border: none;
    border-radius: 10px;
    font-size: 15px;
    text-transform: uppercase;
    color: #ffffff;
    cursor: pointer;
}

.login-popup .box .form .btn:focus {
    outline: none;
}

.login-popup .box .form .close {
    top: 0px;
    font-size: 30px;
    color: white;
    float: right;
    margin-top: -20px;
}

/*responsive*/
@media(max-width: 767px) {
    .login-popup .box {
        width: calc(112% - 0px);
    }

    .login-popup .box .img-area {
        display: none;
    }

    .login-popup .box .form {
        flex: 0 0 100%;
        max-width: 100%;
    }

    .bv {
        font-size: 22px !important;
    }
}

@media (max-width: 767px) {
    .lg {
        width: 247px !important;
        background-color: #be0e00 !important;
    }
}

@media (max-width: 767px) {
    .gl {
        background-color: #ff9900 !important;
    }
}

.th-menu-wrapper .th-menu-area {
    width: 100%;
    max-width: 310px;
    background-color: #ffa200;
    border-right: 3px solid var(--theme-color);
    height: 100%;
    position: relative;
    left: -110%;
    opacity: 0;
    visibility: hidden;
    -webkit-transition: all ease 1s;
    transition: all ease 1s;
    z-index: 1;
}

.blog-card .blog-meta.style2 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    padding: 13px 18px;
    background-color: #0e121d00;
    position: relative;
    margin-top: -28px;
    margin-bottom: 35px;
}

.blog-card .blog-content {
    padding: 40px 30px;
    box-shadow: 0px 6px 15px rgba(7, 36, 95, 0.07);
    background-color: #de7100;
}

.blog-card .blog-title {
    font-size: 24px;
    margin-top: -25px;
    line-height: 1.417;
    color: white;
    font-weight: 700;
    margin-bottom: 5px;
}

.box-title {
    font-size: 24px;
    line-height: 1.417;
    font-weight: 600;
    margin-top: -0.32em;
    text-align: center;
}

.bg-title {
    background-color: #de7100 !important;
}

.header-layout8 .main-menu ul.mega-menu>li>a, .header-layout8 .main-menu a {
    color: #ffffff;
}

.footer-layout8 .copyright-wrap {
    padding: 25.5px 0;
    border-top: 1px solid var(--border-color);
    background: black;
}

@media (max-width: 767px) {
    .gl {
        background-color: #c00000 !important;
    }
}
.blog-card .blog-meta.style2 {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    padding: 13px 18px;
    background-color: #000000;
    position: relative;
    margin-top: -28px;
    margin-bottom: 35px;
}

.blog-card .blog-title {
    font-size: 20px;
    margin-top: -25px;
    line-height: 1.417;
    color: white;
    font-weight: 700;
    margin-bottom: 5px;
}
.blog-card .blog-content {
    padding: 40px 30px;
    box-shadow: 0px 6px 15px rgba(7, 36, 95, 0.07);
    background-color: #ffffff;
}
.blog-card .blog-title {
    font-size: 20px;
    margin-top: -25px;
    line-height: 1.417;
    color: #a0008d;
    font-weight: 700;
    margin-bottom: 5px;
}
.blog-card .blog-meta.style2:before {
    content: '';
    height: 100%;
    width: 56%;
    background-color: #f90c0d;
    position: absolute;
    top: 0;
    left: 0;
    -webkit-clip-path: polygon(calc(100% - 25px) 0, 100% 50%, calc(100% - 25px) 100%, 0 100%, 0 0);
    clip-path: polygon(calc(100% - 25px) 0, 100% 50%, calc(100% - 25px) 100%, 0 100%, 0 0);
}
.blog-meta span i, .blog-meta a i {
    margin-right: 10px;
    color: #ffffff;
}
    </style> 
    -->
     <style>.whats-app {
    position: fixed;
    width: 48px;
    height: 48px;
    bottom: 7px;
    right: 24px;
    background-color: #4caf50;
    color: #FFF;
    border-radius: 50px;
    text-align: center;
    font-size: 30px;
    box-shadow: 2px 2px 3px #999;
    z-index: 100;
}

.my-float {
           margin-top: 10px;

}


.whats-apps {
    position: fixed;
    width: 48px;
    height: 48px;
    bottom: 63px;
    right: 23px;
    background-color: #000;
    color: #FFF;
    border-radius: 50px;
    text-align: center;
    font-size: 30px;
    box-shadow: 2px 2px 3px #999;
    z-index: 100;
}
  
  
  .whats-appss {
    position: fixed;
    width: 48px;
    height: 48px;
    bottom: 120px;
    right: 20px;
    background-color: #000;
    color: #FFF;
    border-radius: 50px;
    text-align: center;
    font-size: 30px;
    box-shadow: 2px 2px 3px #999;
    z-index: 100;}
    
    .whats-appss {
    position: fixed;
    width: 48px;
    height: 48px;
    bottom: 120px;
    right: 20px;
    background-color: #ff0c0c;
    color: #FFF;
    border-radius: 50px;
    text-align: center;
    font-size: 30px;
    box-shadow: 2px 2px 3px #999;
    z-index: 100;
}

.whats-apps {
    position: fixed;
    width: 48px;
    height: 48px;
    bottom: 63px;
    right: 23px;
    background-color: #ff00a5;
    color: #FFF;
    border-radius: 50px;
    text-align: center;
    font-size: 30px;
    box-shadow: 2px 2px 3px #999;
    z-index: 100;
}

.whats-apps {
    position: fixed;
    width: 48px;
    height: 48px;
    bottom: 63px;
    right: 23px;
    background-color: #ff8d00;
    color: #FFF;
    border-radius: 50px;
    text-align: center;
    font-size: 30px;
    box-shadow: 2px 2px 3px #999;
    z-index: 100;
}

</style>

</head>
<body>  
<!-- Google Tag Manager (noscript) -->

<!-- End Google Tag Manager (noscript) -->
<a class="whats-app" href="https://api.whatsapp.com/send?phone=14374556999&amp;text=Hi, I contacted you through your website.." target="_blank">
    <i class="fab fa-whatsapp my-float"></i>
</a>
  <a class="whats-apps" href="tel:<?php echo $phone?>" target="_blank">
    <i class="fa fa-phone my-float "></i>
</a>


	<!-- top-bar-start -->
	<div class="hidden-xs">
		<div class="top_header" style="background: #F00000;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #DC281E, #F00000);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #DC281E, #F00000); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */;    background: linear-gradient(to right, #708A58, #347433);
">
		  <div class="container">
			<div class="top_header_inner">
			  <div class="logo">
		
			
			  </div>
			  
			   <div class="logo">
	
			
			  </div>
			  
			  
				
				 <div class="get_advise">
				<div class="get_advise_img"> <img class="img-fluid" src="images/get-advise.png" alt="Get Advise from best Astrologer" title="Get Advise from best astrologer"> </div>
				<div class="get_advise_text"> <span>Consult Today</span> <a href="tel:<?php echo $linkphone?>" title="<?php echo $linkphone?>"><?php echo $phone?></a> </div>
				<div class="clearfix"></div>
			  </div>
				
			  
			</div>
		  </div>
		</div>
	</div>	
	<!-- top-bar-end -->
	
	
	<!-- for mobile header -->
	<div class="visible-xs">
    <div class="top_header" style="background: #FF416C;  /* fallback for old browsers */
background: -webkit-linear-gradient(to top, #FF4B2B, #FF416C);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to top, #FF4B2B, #FF416C); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */;    background: linear-gradient(to top, #8A0000, #347433);">
	
	
	
		
			
			
      <div class="container">
          
        <div class="top_header_inner">
          <div class="logo">

		  <a href="index.html"><img class="img-fluid hidden-xs" src="images/mlogo.jpg" alt="Shiva Ji Trusted Astrologer"style="width:100%"></a>
		  </div>
		  
        <marquee>  <strong style="color:white;"> We Provide Genuine Spells For Every Problems - Get Real Master Advice On Love/Relationship Marriage, Career/Finance, Family Matters, Legal & More  The ritual is 100% safe for you.
		 </marquee> </strong>

		
		</div>
      </div>
    </div>
	<div class="top_header m_header_contact hidden-xs" style="background-color: #fd3c02;">
      <div class="container">
        
      </div>
    </div>
	</div>
	
	<div class="container hidden-xs">
	   <marquee>  <strong style="color:#850a0a;"> We are Provide Genuine Spells For Every Problems - Get Real Master Advice On Love/Relationship Marriage, Career/Finance, Family Matters, Legal & More  The ritual is 100% safe for you.
		 </marquee> </strong>
</div>
     <!-- Start Navigation -->
    <nav class="navbar navbar-default bootsnav navbar-sticky nav-back">
        <div class="container">            
            <!-- Start Header Navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="" ><img src="images/mlogo.jpg" class="logo animated  slow pulse" alt="image-logo"></a>
                <!--
                	
					<ul class="" style="float:right;">
					    Follow us <br>
             <a href="https://www.facebook.com/people/Pandit-Sidhu/pfbid023pVBHYPX5Dk3TPV6XaLUq4N4ddnWso7Vobd1Z25DB6exbkLquwX4bc9hz5N4pH2Ll/?mibextid=uzlsIk">
                  <img src="images/fbb.png" style="width:30px;">
              </a>
             
                  <a href="https://www.instagram.com/pan_ditsidhu/?igsh=ZHZ1cDc4djNweTc3&utm_source=qr">
                       <img src="images/inn.png" style="width:30px;">
                  </a>
                 
             <a href="https://www.youtube.com/@Pandit-Sidhu?si=4YHoewhqmXO-OHy2"> <img src="images/ytt.png" style="width:30px;"></a>
            </ul>
			
			-->
            </div>
            <!-- End Header Navigation -->

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="navbar-menu">
                <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
                    <li class="active"><a href="index.php">Home</a></li>
                    <li><a href="about-us.php">About us</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Services</a>
                        <ul class="dropdown-menu">
                       
                            <li><a href="get-love-back.php">Love Problem</a></li>
                            <li><a href="black-magic-removal.php">Black magic Removal</a></li>
                            <li><a href="marriage-problem.php">Marriage problem</a></li>
                            <li><a href="career.php">Career and Business Problem</a></li>
                            <li><a href="spiritual-healing.php">Spiritual healing</a></li>
                            <li><a href="financial.php">Financial Problem</a></li>
                            <li><a href="palm reading.php">Palm and Face reading</a></li>
                            <li><a href="negative-energy.php">Negitive energy</a></li>
                            <li><a href="childless-couple.php">Childless Couple</a></li>
                            <li><a href="witch.php">Witchcraft Removal</a></li>
                            <li><a href="court.php">Court Case Problem</a></li>

                        </ul>
                    
                                       

					
					<li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Poojaservices</a>
                        <ul class="dropdown-menu" style=" ">
                            <li><a href="shani.php">Shani Pooja</a></li>
                            <li><a href="rahu.php">Rahu Pooja</a></li>
                            <li><a href="graha.php">Shiva Pooja</a></li>
                            <li><a href="durga.php">Durga Pooja</a></li>
                            <li><a href="kalikamata.php">Kalimata Pooja</a></li>
                            <li><a href="radha.php">Radha Krishna Pooja</a></li>
                            <li><a href="hanuman.php">Hanuman Pooja</a></li>
                            <li><a href="ganesha.php">Ganesha Pooja</a></li>
                        </ul>
                    </li>

                     <li><a href="contact-us.php">Contact Us</a></li>
                                        <li> 
 <button type="submit" class="send_button full_button" name="submit" value="submit" style="    margin-top: 18px;    background: #970089;"><i class="ico-check3"></i><span> <a href="contact-us.php" style="color:white;"> Book appointment  </a> </span> </button>
                                          </li>

                </ul>
            </div><!-- /.navbar-collapse -->
        </div>
    </nav>
    <!-- End Navigation -->
	<script src="js/jssor.slider.min.js" type="text/javascript"></script>

    <script type="text/javascript">
        jssor_1_slider_init = function() {

            var jssor_1_SlideshowTransitions = [
              {$Duration:500,$Delay:30,$Cols:8,$Rows:4,$Clip:15,$SlideOut:true,$Formation:$JssorSlideshowFormations$.$FormationStraightStairs,$Assembly:2049,$Easing:$Jease$.$OutQuad},
            ];

            var jssor_1_options = {
              $AutoPlay: 1,
              $SlideshowOptions: {
                $Class: $JssorSlideshowRunner$,
                $Transitions: jssor_1_SlideshowTransitions,
                $TransitionsOrder: 1
              },
              $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$
              },
              $BulletNavigatorOptions: {
                $Class: $JssorBulletNavigator$
              }
            };

            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

            /*#region responsive code begin*/

            var MAX_WIDTH = 3000;

            function ScaleSlider() {
                var containerElement = jssor_1_slider.$Elmt.parentNode;
                var containerWidth = containerElement.clientWidth;

                if (containerWidth) {

                    var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                    jssor_1_slider.$ScaleWidth(expectedWidth);
                }
                else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }

            ScaleSlider();

            $Jssor$.$AddEvent(window, "load", ScaleSlider);
            $Jssor$.$AddEvent(window, "resize", ScaleSlider);
            $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
            /*#endregion responsive code end*/
        };
    </script>