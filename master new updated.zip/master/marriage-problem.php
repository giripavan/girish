<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Marriage Problem Solution</title>
  <?php include('header.php'); ?>
</head>
<body>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>

<style>
  body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #24003d, #0f1842);
    color: white;
  }

  .section-wrapper {
    max-width: 1200px;
    margin: auto;
    padding: 80px 20px;
    display: flex;
    flex-wrap: wrap;
    gap: 40px;
  }

  .left-image {
    flex: 1 1 400px;
  }

  .left-image img {
    width: 100%;
    height: 100%;
    max-height: 500px;
    object-fit: cover;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 255, 0.2);
  }

  .right-content {
    flex: 1 1 600px;
  }

  .right-content h1 {
    font-size: 4.5rem;
    color: #ffc0cb;
    margin-bottom: 20px;
  }

  .right-content p {
    font-size: 2.1rem;
    line-height: 1.7;
    color: #e0d8f5;
    margin-bottom: 30px;
  }

  .card-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
  }

  .info-card {
    flex: 1 1 260px;
    background: rgba(255, 255, 255, 0.07);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 15px;
    padding: 20px;
    cursor: pointer;
    transition: 0.3s ease;
    display: flex;
    flex-direction: column;
  }

  .info-card:hover {
    background: rgba(255, 255, 255, 0.15);
  }

  .info-card-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 10px;
  }

  .info-card i {
    font-size: 1.8rem;
    color: #ffc0cb;
  }

   .info-card h3 {
    font-size: 1.9rem;
    color: yellow;
    margin: 0;
  }

 .info-card .card-detail {
    margin-top: 10px;
    font-size: 1.95rem;
    line-height: 1.5;
    color: white;
    display: none;
  }

  .info-card.active .card-detail {
    display: block;
    animation: fadeIn 0.4s ease;
  }

  .contact-btn {
    margin-top: 40px;
    display: inline-block;
    background: linear-gradient(135deg, #ff80ab, #d500f9);
    color: black;
    padding: 14px 30px;
    border-radius: 40px;
    font-weight: bold;
    font-size: 1rem;
    text-decoration: none;
    transition: background 0.3s ease;
  }

  .contact-btn:hover {
    background: linear-gradient(135deg, #ff99cc, #e040fb);
    color: #000;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @media (max-width: 768px) {
    .section-wrapper {
      flex-direction: column;
    }

    .right-content {
      order: 1;
    }

    .left-image {
      order: 2;
      margin-top: 30px;
    }

    .card-grid {
      order: 3;
    }

    .right-content h1 {
      font-size: 2.5rem;
    }

    .info-card {
      flex: 1 1 100%;
    }
  }
</style>

<section class="section-wrapper">

  <!-- Left Image -->
  <div class="left-image">
    <img src="./images/msse2.jpg" alt="Marriage Problem Solution" />
  </div>

  <!-- Right Content -->
  <div class="right-content">
    <h1><i class="fas fa-ring"></i> Marriage Issues</h1>
    <p>
      Facing delays in marriage? Struggling with frequent arguments or in-laws’ interference? Astrology provides time-honored remedies for marital peace and life-long harmony.
    </p>
    <p>
      Discover how kundali doshas, planetary misalignments, and spiritual imbalances can be resolved using sacred rituals, poojas, and expert astrological insight. Build a stronger, united marriage with divine guidance.
    </p>

    <!-- Cards -->
    <div class="card-grid">
      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-user-clock"></i>
          <h3>Marriage Delay</h3>
        </div>
        <div class="card-detail">
          Late marriage is often caused by Mangal dosha, Shani effects, or Rahu-Ketu imbalance—remedied through proper poojas and gemstones.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-comments"></i>
          <h3>Marital Conflicts</h3>
        </div>
        <div class="card-detail">
          Constant disagreements can be due to nakshatra clash, horoscope mismatch, or evil influences. Remedies help bring back peace.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-hands"></i>
          <h3>Family Interference</h3>
        </div>
        <div class="card-detail">
          External influence from in-laws or relatives can weaken the bond. Spiritual rituals strengthen the couple’s mutual energy.
        </div>
      </div>

      <div class="info-card" onclick="toggleCard(this)">
        <div class="info-card-header">
          <i class="fas fa-star-and-crescent"></i>
          <h3>Pooja & Remedies</h3>
        </div>
        <div class="card-detail">
          Perform Parvati-Shiva Pooja, Swayamvara Parvati Homa, or Navagraha Shanti for marital bliss and divine harmony.
        </div>
      </div>
    </div>

    <!-- Contact Button -->
    <a href="contact-us.php" class="contact-btn">Talk to Astrologer</a>
  </div>
</section>

<script>
  function toggleCard(card) {
    card.classList.toggle('active');
  }
</script>

<?php include('testimonials.php'); ?>
<?php include('faq.php'); ?>
<?php include('footer.php'); ?>

</body>
</html>
