<section class="about-section">
  <div class="about-container">
    <!-- Left Astrology Wheel Image -->
    <div class="about-left">
      <img src="images/ao1.jpg" alt="Astrology Chart" />
    </div>

    <!-- Right Content -->
    <div class="about-right">
      <h1>About Master</h1>
      <h2>We Can Help Find Your<br>Future With Astrology</h2>
<p>
  <strong style="color: yellow; font-family: 'Georgia', serif; letter-spacing: 1px;">
    MASTER
  </strong> is a renowned astrology expert known for delivering accurate horoscope readings, powerful spiritual remedies, and insightful guidance rooted in ancient Vedic traditions. With deep knowledge of planetary movements, karma healing, love compatibility, and dosha analysis, 
  <strong style="color: yellow; font-family: 'Georgia', serif; letter-spacing: 1px;">
    MASTER
  </strong> helps individuals overcome life’s challenges and realign their destiny through divine wisdom.
</p>

      
      <ul class="services">
        <li>Love Problem</li>
        <li>Court Problem </li>
        <li>Marriage Problem</li>
        <li>Tarot Reading</li>
        <li>Palm Reading</li>
        <li>Black  Magic</li>
      </ul>

      <!-- Author -->
      
    </div>
  </div>
</section>

<style>
.about-section {
  background:rgb(69, 3, 37);
  color: #fff;
  padding: 80px 50px;
  font-family: 'Segoe UI', sans-serif;
}

.about-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
}

.about-left {
  flex: 1;
  text-align: center;
}

.about-left img {
  max-width: 100%;
  width: 400px;
  height: auto;
}

.about-right {
  flex: 1;
  padding-left: 50px;
  max-width: 600px;
}

.about-right h1 {
  color: #a09ce8;
  font-family: 'Georgia', serif;
  font-size: 46px;
  font-weight: 500;
  margin-bottom: 10px;
}

.about-right h2 {
  color:yellow;
  font-size: 36px;
  font-family: 'Georgia', serif;
  line-height: 1.3;
  margin-bottom: 20px;
}

.about-right p {
  color: white;
  font-size: 19px;
  margin-bottom: 30px;
}

.services {
  display: grid;
  grid-template-columns: repeat(2, auto);
  gap: 10px 40px;
  margin-bottom: 40px;
  padding-left: 0;
}

.services li {
  list-style: none;
  color: #dcdcff;
  position: relative;
  padding-left: 18px;
  font-size: 16px;
}

.services li::before {
  content: '✦';
  position: absolute;
  left: 0;
  color: #a09ce8;
}

.author-box {
  display: flex;
  align-items: center;
  gap: 15px;
}

.author-box img {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  object-fit: cover;
}

.author-box h4 {
  margin: 0;
  font-size: 18px;
  color: #fff;
}

.author-box p {
  margin: 0;
  color: #a09ce8;
  font-size: 14px;
}

@media (max-width: 1024px) {
  .about-container {
    flex-direction: column;
    text-align: center;
  }

  .about-right {
    padding-left: 0;
    margin-top: 40px;
  }

  .author-box {
    justify-content: center;
  }
}
</style>


<link href="https://fonts.googleapis.com/css2?family=Marcellus&display=swap" rel="stylesheet">
<style>
  body {
    margin: 0;
    font-family: 'Marcellus', serif;
    background-color:rgba(14, 1, 15, 0.96);
    color: #fff;
  }

  .services-section {
    background-color: rgba(14, 1, 15, 0.96);
    text-align: center;
    padding: 80px 20px;
    position: relative;
    overflow: hidden;
  }

  .services-section::before {
    content: '';
    background: url('https://cdn.pixabay.com/photo/2012/11/28/10/40/moon-67672_1280.jpg') no-repeat center;
    background-size: contain;
    position: absolute;
    right: 10%;
    bottom: 0;
    width: 400px;
    height: 400px;
    opacity: 0.2;
    pointer-events: none;
  }

  .services-section h1 {
    color: rgb(239, 57, 114);
    font-size: 36px;
    letter-spacing: 1px;
    margin-bottom: 10px;
  }

  .services-section h2 {
    font-size: 32px;
    margin: 0 0 10px;
  }

  .services-section p {
    max-width: 700px;
    margin: 0 auto 40px;
    font-size: 14px;
    opacity: 0.9;
  }

  .services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 30px;
    max-width: 1100px;
    margin: 0 auto;
  }

  .service-box {
    background: rgba(2, 49, 54, 0.97);
    border: 1px solid #fff;
    padding: 30px 20px;
    border-radius: 50%;
    width: 250px;
    height: 250px;
    margin: 0 auto;
    text-align: center;
    position: relative;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }

  .service-box:hover {
    transform: translateY(-10px);
    box-shadow: 0 0 20px rgb(159, 33, 33);
  }

  .service-box img {
    width: 60px;
    height: 60px;
    margin-bottom: 15px;
  }

  .service-box h3 {
    font-size: 16px;
    color: yellow;
    font-weight: bold;
    margin: 0 0 10px;
    text-transform: uppercase;
    margin-bottom: 10px;
  }

  .service-box p {
    font-size: 12px;
    line-height: 1.4;
    color: white;
    padding: 0 10px;
  }

  @media (max-width: 600px) {
    .service-box {
      width: 200px;
      height: 200px;
    }

    .service-box p {
      display: none;
    }
  }
</style>
</head>
<body>






