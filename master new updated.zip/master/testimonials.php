<section style="background: radial-gradient(circle at center, #0b0e26, #050823); padding: 80px 20px; font-family: 'Segoe UI', sans-serif; color: white;">
  <style>
    .testimonial-block {
      text-align: center;
      max-width: 1200px;
      margin: auto;
    }

    .testimonial-block h2 {
      color: #d84f7b;
      font-size: 36px;
      margin-bottom: 10px;
    }

    .testimonial-block p {
      color: #bfbfc6;
      font-size: 16px;
      max-width: 600px;
      margin: 0 auto 40px;
    }

    .testimonial-wrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 30px;
      flex-wrap: wrap;
      position: relative;
    }

    .arrow {
      font-size: 24px;
      color: #fff;
      cursor: pointer;
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      z-index: 1;
    }

    .arrow.left {
      left: -30px;
    }

    .arrow.right {
      right: -30px;
    }

    .testimonial-card {
      background-color: #0f122b;
      width: 300px;
      border: 1px solid #1a1f3c;
      border-radius: 10px;
      overflow: hidden;
      text-align: center;
      padding-bottom: 30px;
      box-shadow: 0 0 10px rgba(255,255,255,0.05);
    }

    .testimonial-card img.cover {
      width: 100%;
      height: 140px;
      object-fit: cover;
    }

    .testimonial-card img.avatar {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      margin-top: -40px;
      border: 4px solid #fff;
      object-fit: cover;
    }

    .testimonial-card h4 {
      margin: 10px 0 4px;
      color: #13a3f7;
    }

    .testimonial-card span {
      font-size: 14px;
      color: #ccc;
    }

    .testimonial-card p {
      font-style: italic;
      font-size: 14px;
      margin: 20px;
      color: #ccc;
    }

    .quote-icon {
      font-size: 24px;
      color: #d84f7b;
    }

    @media (max-width: 768px) {
      .testimonial-wrapper {
        flex-direction: column;
      }

      .arrow {
        display: none;
      }
    }
  </style>

  <div class="testimonial-block">
    <h2>What Clients Are Saying</h2>
    <p>Real experiences from individuals transformed through MASTER's astrological guidance.</p>

    <div class="testimonial-wrapper">
      <div class="arrow left">&#8592;</div>

      <!-- Testimonial 1 -->
      <div class="testimonial-card">
        <img src="images/a6.jpg" class="cover" alt="cover">
        <img src="https://randomuser.me/api/portraits/women/1.jpg" class="avatar" alt="avatar">
        <h4>Karen J. Hogan</h4>
        <span>Toronto</span>
        <p>“Astrology with MASTER revealed the clarity I needed. His guidance helped me reset my life.”</p>
        <div class="quote-icon">&#10077;</div>
      </div>

      <!-- Testimonial 2 -->
      <div class="testimonial-card">
        <img src="images/a6.jpg" class="cover" alt="cover">
        <img src="https://randomuser.me/api/portraits/women/2.jpg" class="avatar" alt="avatar">
        <h4>Stephie J. Bellamy</h4>
        <span>Winnipeg</span>
        <p>“I never believed in astrology, but MASTER's reading was unbelievably accurate and healing.”</p>
        <div class="quote-icon">&#10077;</div>
      </div>

      <!-- Testimonial 3 -->
      <div class="testimonial-card">
        <img src="images/a6.jpg" class="cover" alt="cover">
        <img src="https://randomuser.me/api/portraits/men/3.jpg" class="avatar" alt="avatar">
        <h4>Stuart</h4>
        <span>Canada</span>
        <p>“MASTER helped me understand my relationship through stars. Everything he said came true.”</p>
        <div class="quote-icon">&#10077;</div>
      </div>

      <!-- Testimonial 4 -->
      <div class="testimonial-card">
        <img src="images/a6.jpg" class="cover" alt="cover">
        <img src="https://randomuser.me/api/portraits/men/10.jpg" class="avatar" alt="avatar">
        <h4>James F. Martin</h4>
        <span>Vancouver</span>
        <p>“MASTER’s guidance during my career crisis helped me choose the right path with confidence.”</p>
        <div class="quote-icon">&#10077;</div>
      </div>

      <!-- Testimonial 5 -->
      <div class="testimonial-card">
        <img src="images/a6.jpg" class="cover" alt="cover">
        <img src="https://randomuser.me/api/portraits/women/5.jpg" class="avatar" alt="avatar">
        <h4>Anna</h4>
        <span>Montreal</span>
        <p>“Through MASTER’s astrological remedies, I found peace in my married life. Truly divine.”</p>
        <div class="quote-icon">&#10077;</div>
      </div>

      <!-- Testimonial 6 -->
      <div class="testimonial-card">
        <img src="images/a6.jpg" class="cover" alt="cover">
        <img src="https://randomuser.me/api/portraits/men/6.jpg" class="avatar" alt="avatar">
        <h4>Arjun Mehra</h4>
        <span>Ottawa</span>
        <p>“MASTER connected me to spiritual insights that changed how I view my life’s purpose.”</p>
        <div class="quote-icon">&#10077;</div>
      </div>

      <div class="arrow right">&#8594;</div>
    </div>
  </div>
</section>
