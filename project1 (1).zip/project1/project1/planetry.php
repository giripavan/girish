 <style>
    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f4f4f8;
      margin: 0;
      padding: 20px;
    }

    h1.section-heading {
      text-align: center;
      font-size: 2.2rem;
      color: #333;
      margin-bottom: 30px;
    }

    .slider-wrapper {
      overflow: hidden;
      max-width: 1000px;
      margin: auto;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      background: #fff;
    }

    .slider-track {
      display: flex;
      transition: transform 0.8s ease-in-out;
      width: 100%;
    }

    .slide {
      display: flex;
      flex: 0 0 100%;
      flex-wrap: nowrap;
      align-items: center;
      min-height: 300px;
      padding: 20px;
    }

    .image-box {
      flex: 1 1 40%;
      max-width: 40%;
      padding-right: 20px;
    }

    .image-box img {
      width: 100%;
      height: auto;
      display: block;
      border-radius: 8px;
      object-fit: cover;
    }

    .content-box {
      flex: 1 1 60%;
      max-width: 60%;
      padding-left: 20px;
    }

    .content-box h2 {
      font-size: 1.8rem;
      color: #2c3e50;
      margin-bottom: 15px;
    }

    .content-box p {
      font-size: 1rem;
      color: #555;
      line-height: 1.6;
    }

    /* Responsive for mobile */
    @media (max-width: 768px) {
      .slide {
        flex-direction: column;
        padding: 10px;
      }

      .image-box {
        order: 1;
        max-width: 100%;
        padding: 0 0 15px 0;
      }

      .content-box {
        order: 2;
        max-width: 100%;
        padding: 0;
        text-align: center;
      }

      .content-box h2 {
        font-size: 1.4rem;
      }

      .content-box p {
        font-size: 0.95rem;
      }
    }
  </style>
</head>
<body>

  <h1 class="section-heading">Planetary Overview</h1>

  <div class="slider-wrapper">
    <div class="slider-track" id="sliderTrack">

      <div class="slide">
        <div class="image-box">
          <img src="https://upload.wikimedia.org/wikipedia/commons/c/c3/Solar_sys8.jpg" alt="Sun">
        </div>
        <div class="content-box">
          <h2>Sun (Surya)</h2>
          <p>The Sun represents soul, authority, ego, and vitality. It rules over health, leadership, and willpower. A strong Sun brings confidence and fame.</p>
        </div>
      </div>

      <div class="slide">
        <div class="image-box">
          <img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/FullMoon2010.jpg" alt="Moon">
        </div>
        <div class="content-box">
          <h2>Moon (Chandra)</h2>
          <p>The Moon governs emotions, mind, motherly love, and intuition. A balanced Moon ensures emotional strength and mental clarity.</p>
        </div>
      </div>

      <div class="slide">
        <div class="image-box">
          <img src="https://upload.wikimedia.org/wikipedia/commons/0/02/OSIRIS_Mars_true_color.jpg" alt="Mars">
        </div>
        <div class="content-box">
          <h2>Mars (Mangal)</h2>
          <p>Mars symbolizes courage, energy, action, and aggression. It is associated with war, property, and youthful strength.</p>
        </div>
      </div>

      <div class="slide">
        <div class="image-box">
          <img src="https://upload.wikimedia.org/wikipedia/commons/2/2e/Mercury_in_true_color.jpg" alt="Mercury">
        </div>
        <div class="content-box">
          <h2>Mercury (Budha)</h2>
          <p>Mercury stands for intelligence, communication, logic, and trade. It favors analysis, speech, writing, and business skills.</p>
        </div>
      </div>

      <div class="slide">
        <div class="image-box">
          <img src="https://upload.wikimedia.org/wikipedia/commons/e/e2/Jupiter.jpg" alt="Jupiter">
        </div>
        <div class="content-box">
          <h2>Jupiter (Guru)</h2>
          <p>Jupiter is the planet of wisdom, spirituality, and expansion. It brings luck, growth, higher education, and moral values.</p>
        </div>
      </div>

      <div class="slide">
        <div class="image-box">
          <img src="https://upload.wikimedia.org/wikipedia/commons/e/e5/Venus-real_color.jpg" alt="Venus">
        </div>
        <div class="content-box">
          <h2>Venus (Shukra)</h2>
          <p>Venus governs love, beauty, luxury, and relationships. It influences romance, creativity, and artistic talent.</p>
        </div>
      </div>

      <div class="slide">
        <div class="image-box">
          <img src="https://upload.wikimedia.org/wikipedia/commons/c/c7/Saturn_during_Equinox.jpg" alt="Saturn">
        </div>
        <div class="content-box">
          <h2>Saturn (Shani)</h2>
          <p>Saturn rules discipline, karma, obstacles, and perseverance. It rewards hard work and patience, and teaches life lessons.</p>
        </div>
      </div>

      <div class="slide">
        <div class="image-box">
          <img src="https://upload.wikimedia.org/wikipedia/commons/0/0c/Shadow_planet.jpg" alt="Rahu">
        </div>
        <div class="content-box">
          <h2>Rahu (North Node)</h2>
          <p>Rahu is a shadow planet representing illusion, ambition, and material desires. It brings sudden changes and breakthroughs.</p>
        </div>
      </div>

      <div class="slide">
        <div class="image-box">
          <img src="https://upload.wikimedia.org/wikipedia/commons/1/17/Ketu_artistic.jpg" alt="Ketu">
        </div>
        <div class="content-box">
          <h2>Ketu (South Node)</h2>
          <p>Ketu symbolizes detachment, spirituality, past karma, and liberation. It inspires spiritual awakening and non-attachment.</p>
        </div>
      </div>

    </div>
  </div>

  <script>
    const track = document.getElementById('sliderTrack');
    const slides = document.querySelectorAll('.slide');
    let currentIndex = 0;

    function moveToNextSlide() {
      currentIndex = (currentIndex + 1) % slides.length;
      track.style.transform = `translateX(-${currentIndex * 100}%)`;
    }

    setInterval(moveToNextSlide, 5000); // Slide every 5 seconds
  </script>