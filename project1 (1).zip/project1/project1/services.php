<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    body {
      font-family: 'Open Sans', sans-serif;
      background-color: #f4f4f4;
      color: #fff;
      margin: 0;
      padding: 0;
    }

    .astrology-services {
      padding: 50px 20px;
      text-align: center;
    }

    .section-title {
      font-size: 2.5rem;
      margin-bottom: 30px;
      color: #262a5a;
    }

    .services-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 20px;
      max-width: 1000px;
      margin: auto;
    }

    .service-card {
      background-size: cover;
      background-position: center;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      padding: 20px;
      transition: transform 0.3s ease-in-out;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      position: relative;
      overflow: hidden;
    }

    .service-card::before {
      content: "";
      position: absolute;
      inset: 0;
      background: rgba(0, 0, 0, 0.6); /* Dark overlay */
      z-index: 0;
    }

    .service-content {
      position: relative;
      z-index: 1;
    }

    .service-icon {
      font-size: 50px;
      color: #ffd700;
      margin-bottom: 15px;
    }

    .service-card h3 {
      font-size: 1.8rem;
      margin: 10px 0;
    }

    .service-card p {
      font-size: 1rem;
      color: #f0f0f0;
    }

    .service-card:hover {
      transform: translateY(-5px);
    }

    .contact-options {
      display: flex;
      justify-content: center;
      gap: 15px;
      margin-top: 20px;
    }

    .contact-options a {
      text-decoration: none;
      color: #fff;
      background-color: #25D366;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: transform 0.2s;
    }

    .contact-options a.call {
      background-color: #007BFF;
    }

    .contact-options a:hover {
      transform: scale(1.2);
    }

   @media (max-width: 768px) {
  .section-title {
    font-size: 2rem;
    margin-bottom: 10px;
  }

  .services-grid {
    grid-template-columns: 1fr;
  }

  .service-card h3 {
    font-size: 1.5rem;
  }

  .service-card p {
    font-size: 0.9rem;
  }
}

  </style>
</head>
<body>

  <section class="astrology-services">
    <h2 class="section-title">Our Astrology Services</h2>
    <div class="services-grid">

      <!-- Service 1 -->
      <div class="service-card" style="background-image: url('images/s1.jpg');">
        <div class="service-content">
          <i class="fas fa-star service-icon"></i>
          <h3>Birth Chart Reading</h3>
          <p>Understand your personality, strengths, and life purpose through detailed natal chart analysis.</p>
          <div class="contact-options">
            <a href="https://wa.me/918050706494" target="_blank"><i class="fab fa-whatsapp"></i></a>
            <a href="tel:+1234567890" class="call"><i class="fas fa-phone-alt"></i></a>
          </div>
        </div>
      </div>

      <!-- Service 2 -->
      <div class="service-card" style="background-image: url('https://images.unsplash.com/photo-1524253482453-3fed8d2fe12b?auto=format&fit=crop&w=800&q=60');">
        <div class="service-content">
          <i class="fas fa-heart service-icon"></i>
          <h3>Love Compatibility</h3>
          <p>Discover how your zodiac sign aligns with your partner's and how to build a harmonious relationship.</p>
          <div class="contact-options">
            <a href="https://wa.me/1234567890" target="_blank"><i class="fab fa-whatsapp"></i></a>
            <a href="tel:+1234567890" class="call"><i class="fas fa-phone-alt"></i></a>
          </div>
        </div>
      </div>

      <!-- Service 3 -->
      <div class="service-card" style="background-image: url('https://images.unsplash.com/photo-1605902711622-cfb43c4437d7?auto=format&fit=crop&w=800&q=60');">
        <div class="service-content">
          <i class="fas fa-briefcase service-icon"></i>
          <h3>Career Guidance</h3>
          <p>Find your ideal career path and make informed decisions based on planetary influence in your chart.</p>
          <div class="contact-options">
            <a href="https://wa.me/1234567890" target="_blank"><i class="fab fa-whatsapp"></i></a>
            <a href="tel:+1234567890" class="call"><i class="fas fa-phone-alt"></i></a>
          </div>
        </div>
      </div>

      <!-- Service 4 -->
      <div class="service-card" style="background-image: url('https://images.unsplash.com/photo-1518544800872-9c8528bf44f5?auto=format&fit=crop&w=800&q=60');">
        <div class="service-content">
          <i class="fas fa-calendar-alt service-icon"></i>
          <h3>Yearly Horoscope</h3>
          <p>Plan your year ahead with insights into opportunities and challenges guided by astrological trends.</p>
          <div class="contact-options">
            <a href="https://wa.me/1234567890" target="_blank"><i class="fab fa-whatsapp"></i></a>
            <a href="tel:+1234567890" class="call"><i class="fas fa-phone-alt"></i></a>
          </div>
        </div>
      </div>

      <!-- Service 5 -->
      <div class="service-card" style="background-image: url('https://images.unsplash.com/photo-1613067286469-f3d683bb7fd4?auto=format&fit=crop&w=800&q=60');">
        <div class="service-content">
          <i class="fas fa-heartbeat service-icon"></i>
          <h3>Health Forecast</h3>
          <p>Get astrological advice on your physical and mental well-being based on your zodiac and transits.</p>
          <div class="contact-options">
            <a href="https://wa.me/1234567890" target="_blank"><i class="fab fa-whatsapp"></i></a>
            <a href="tel:+1234567890" class="call"><i class="fas fa-phone-alt"></i></a>
          </div>
        </div>
      </div>

      <!-- Service 6 -->
      <div class="service-card" style="background-image: url('https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=60');">
        <div class="service-content">
          <i class="fas fa-hashtag service-icon"></i>
          <h3>Numerology Report</h3>
          <p>Discover the power of your numbers and how they influence your personality and future outcomes.</p>
          <div class="contact-options">
            <a href="https://wa.me/1234567890" target="_blank"><i class="fab fa-whatsapp"></i></a>
            <a href="tel:+1234567890" class="call"><i class="fas fa-phone-alt"></i></a>
          </div>
        </div>
      </div>

    </div>
  </section>