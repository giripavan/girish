 <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Open Sans', sans-serif;
      background-color:rgba(55, 55, 212, 0.93);
      color: #fff;
    }

    .faq-section-with-image {
      background: linear-gradient(to right,rgba(28, 28, 44, 0),rgba(35, 35, 197, 0));
      padding: 60px 20px;
    }

    .faq-container {
      display: flex;
      max-width: 1100px;
      margin: 0 auto;
      gap: 30px;
      align-items: flex-start;
    }

    .faq-image {
      flex: 0 0 550px;
    }

    .faq-image img {
      width: 100%;
      height: auto;
      object-fit: cover;
      border-radius: 16px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.5);
      display: block;
    }

    .faq-content {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
    }

    .faq-title {
      font-size: 2.2rem;
      margin-bottom: 30px;
      color: #ff874e;
      font-family: 'Playfair Display', serif;
    }

    .faq-content details {
      background-color: rgba(47, 47, 122, 0.95); /* Transparent background */
      margin-bottom: 15px;
      border-radius: 8px;
      padding: 15px 20px;
      transition: all 0.4s ease;
      box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    }

    .faq-content summary {
      font-weight: bold;
      font-size: 1.05rem;
      cursor: pointer;
      position: relative;
      color: #ffcb9a;
    }

    .faq-content summary::after {
      content: '+';
      position: absolute;
      right: 0;
      font-size: 1.5rem;
      color: #ff874e;
      transition: transform 0.3s ease;
    }

    .faq-content details[open] summary::after {
      content: '-';
      transform: rotate(180deg);
    }

    .faq-content p {
      margin-top: 10px;
      color: #ddd;
      line-height: 1.6;
      animation: fadeIn 0.4s ease;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-5px); }
      to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 900px) {
      .faq-container {
        flex-direction: column;
        align-items: center;
      }

      .faq-image {
        width: 100%;
        max-width: 500px;
        margin-bottom: -180px;
      }

      .faq-content {
        width: 100%;
      }

      .faq-title {
        text-align: center;
      }
    }
  </style>
</head>
<body>

<section class="faq-section-with-image">
  <div class="faq-container">
    <div class="faq-image">
      <img src="images/np1.jpg" alt="Astrology Illustration">
    </div>
    <div class="faq-content">
      <h2 class="faq-title">Frequently Asked Questions</h2>

      <details open>
        <summary>What is astrology and how does it work?</summary>
        <p>Astrology is the study of celestial bodies and their influence on human lives. It provides insights based on your birth chart.</p>
      </details>

      <details>
        <summary>Can astrology help with love and relationships?</summary>
        <p>Yes, it can provide clarity using compatibility charts, synastry, and love planet alignments.</p>
      </details>

      <details>
        <summary>What is a birth chart?</summary>
        <p>A birth chart is a map of the sky at your exact birth time, used to interpret your personality and destiny.</p>
      </details>

      <details>
        <summary>Are astrology predictions accurate?</summary>
        <p>Accuracy depends on personalized readings rather than generic horoscopes. Charts offer deeper insights.</p>
      </details>

      <details>
        <summary>What’s the difference between sun and moon signs?</summary>
        <p>Sun sign reflects your core self, while moon sign governs emotions and inner world.</p>
      </details>
    </div>
  </div>
</section>

<script>
  const allDetails = document.querySelectorAll(".faq-content details");

  allDetails.forEach((targetDetail) => {
    targetDetail.addEventListener("click", () => {
      allDetails.forEach((detail) => {
        if (detail !== targetDetail) {
          detail.removeAttribute("open");
        }
      });
    });
  });
</script>