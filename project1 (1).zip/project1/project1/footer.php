  <footer style="background:#0b0c2a; color:white; text-align:center; padding:20px;">
    &copy; <?php echo date("Y"); ?> Zodiac Astrology. All rights reserved.
  </footer>
</body>
</html>
