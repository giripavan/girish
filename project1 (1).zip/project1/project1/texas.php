<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php include('header.php'); ?>
</head>

<body>
  <!-- Love Astrology Section -->
  <section style="padding: 60px 0; background: linear-gradient(135deg, #e0e8ff, #f7f7ff); min-height: 100vh; display: flex; align-items: center; position: relative; overflow: hidden;">
    
    <!-- Animated Background Elements -->
    <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 0;">
      <div style="position: absolute; top: 10%; left: 5%; width: 100px; height: 100px; border-radius: 50%; background: rgba(255,215,0,0.1); animation: float 8s ease-in-out infinite;"></div>
      <div style="position: absolute; top: 70%; left: 80%; width: 150px; height: 150px; border-radius: 50%; background: rgba(255,215,0,0.08); animation: float 10s ease-in-out infinite reverse;"></div>
      <div style="position: absolute; top: 30%; left: 60%; width: 80px; height: 80px; border-radius: 50%; background: rgba(255,215,0,0.12); animation: float 12s ease-in-out infinite 2s;"></div>
      <div style="position: absolute; top: 80%; left: 20%; width: 120px; height: 120px; border-radius: 50%; background: rgba(255,215,0,0.15); animation: float 9s ease-in-out infinite reverse 1s;"></div>
    </div>

    <div class="container" style="position: relative; z-index: 1;">
      <div class="row justify-content-center">
        <div class="col-xl-10 col-lg-11 col-md-12">
          <div class="main-card" style="background: rgba(255, 255, 255, 0); border-radius: 20px; overflow: hidden; box-shadow: 0 15px 40px rgba(0,0,0,0.15);">

            <!-- Header Section -->
            <div style="background: linear-gradient(135deg, #c2185b 0%, #8c0032 100%); padding: 30px; text-align: center;">
              <h2 style="color: white; font-size: 36px; font-weight: 700; margin: 0; letter-spacing: 1px;">
                <span style="display: inline-block; border-bottom: 3px solid #ffd740; padding-bottom: 8px; font-family: 'Playfair Display', serif;">Love Astrology Solutions</span>
              </h2>
            </div>

            <!-- Content Section -->
            <div style="padding: 30px; background: rgba(255,255,255,0.85);">
              <div class="content-columns" style="display: flex; flex-wrap: wrap; justify-content: center; align-items: flex-start; gap: 30px;">

                <!-- Text Content -->
                <div class="text-content" style="flex: 1; min-width: 280px; box-sizing: border-box;">
                  <div style="border-left: 4px solid #c2185b; padding-left: 20px; margin-bottom: 25px;">
                    <p style="font-size: 1.8rem; line-height: 1.7; color: #333; margin-bottom: 20px;">
                      Struggling with love life challenges? Psychic Lakshmi Chandrakanth, a renowned love astrologer in New York, offers powerful Vedic astrology solutions to attract your soulmate, heal broken relationships, and create lasting romantic connections through cosmic alignment.
                    </p>
                    <p style="font-size: 1.75rem; line-height: 1.7; color: #333;">
                      His proven love astrology methods analyze your birth chart's romantic potential, remove karmic blocks, and enhance Venus energy to help you find true love, improve existing relationships, and experience deeper emotional fulfillment.
                    </p>
                  </div>

                  <!-- Services -->
                  <div style="background: rgba(248,187,208,0.2); border-radius: 12px; padding: 20px; margin-top: 20px; border: 1px solid #f8bbd0;">
                    <h4 style="color: #c2185b; font-size: 20px; margin-top: 0; margin-bottom: 15px;">
                      <i class="fas fa-heart" style="color: #c2185b; margin-right: 8px;"></i> Love Services
                    </h4>
                    <ul style="padding-left: 20px; margin-bottom: 0;">
                      <li style="margin-bottom: 8px; font-size: 14px; color: #555;">Soulmate Attraction & Compatibility</li>
                      <li style="margin-bottom: 8px; font-size: 14px; color: #555;">Relationship Healing & Reconciliation</li>
                      <li style="margin-bottom: 8px; font-size: 14px; color: #555;">Marriage Timing & Harmony</li>
                      <li style="font-size: 14px; color: #555;">Love Problem Remedies</li>
                    </ul>
                  </div>
                </div>

                <!-- Image Content -->
                <div class="image-content" style="flex: 1; min-width: 280px; box-sizing: border-box;">
                  <div style="height: 100%; display: flex; flex-direction: column; gap: 20px;">
                    <div style="background: rgba(240,240,240,0.8); border-radius: 12px; overflow: hidden; height: 300px; border: 2px solid #c2185b;">
                      <img src="./images/pnll.jpg" alt="Love Astrologer Nandhaji" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>

                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
                      <div style="background: rgba(248,187,208,0.3); border-radius: 8px; padding: 12px; text-align: center; border: 1px solid #f8bbd0;">
                        <i class="fas fa-heart" style="font-size: 20px; color: #c2185b; margin-bottom: 5px;"></i>
                        <p style="font-size: 11px; margin: 0; color: #333;">Romance</p>
                      </div>
                      <div style="background: rgba(248,187,208,0.3); border-radius: 8px; padding: 12px; text-align: center; border: 1px solid #f8bbd0;">
                        <i class="fas fa-ring" style="font-size: 20px; color: #c2185b; margin-bottom: 5px;"></i>
                        <p style="font-size: 11px; margin: 0; color: #333;">Marriage</p>
                      </div>
                      <div style="background: rgba(248,187,208,0.3); border-radius: 8px; padding: 12px; text-align: center; border: 1px solid #f8bbd0;">
                        <i class="fas fa-hand-holding-heart" style="font-size: 20px; color: #c2185b; margin-bottom: 5px;"></i>
                        <p style="font-size: 11px; margin: 0; color: #333;">Commitment</p>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

              <!-- CTA -->
              <div style="text-align: center; margin-top: 30px;">
                <a href="contact-us.php" style="display: inline-block; background: linear-gradient(135deg, #c2185b 0%, #8c0032 100%); color: white; padding: 12px 30px; border-radius: 50px; text-decoration: none; font-weight: 600; font-size: 16px; box-shadow: 0 5px 15px rgba(194,24,91,0.3); transition: all 0.3s;">
                  Find Your Love Solutions
                  <i class="fas fa-arrow-right" style="margin-left: 8px;"></i>
                </a>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Styles -->
  <style>
    @keyframes float {
      0%, 100% { transform: translateY(0) translateX(0); }
      25% { transform: translateY(-20px) translateX(10px); }
      50% { transform: translateY(10px) translateX(-15px); }
      75% { transform: translateY(-10px) translateX(15px); }
    }

    @media (max-width: 767px) {
      .content-columns {
        flex-direction: column !important;
      }
      .text-content, .image-content {
        min-width: 100% !important;
        max-width: 100% !important;
      }
    }
  </style>

  <?php include('testimonials.php'); ?>
  <?php include('locations.php'); ?>
  <?php include('footer.php'); ?>
</body>
</html>
