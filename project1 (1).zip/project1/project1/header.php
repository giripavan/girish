<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Zodiac - Find Your Way</title>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Open+Sans&display=swap"
    rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Open Sans', sans-serif;
    }

    header {
      background: url('images/celestial-background.jpg') no-repeat center center/cover;
      color: #fff;
      position: relative;
    }

    .navbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 20px 30px;
      background-color: rgba(0, 0, 0, 0.6);
      flex-wrap: wrap;
      position: relative;
    }

    .logo {
      display: flex;
      align-items: center;
      font-size: 1.8rem;
      font-weight: bold;
      color: #fff;
    }

    .logo img {
      height: 50px;
      margin-right: 10px;
    }

    .nav-links {
      list-style: none;
      display: flex;
      gap: 25px;
      align-items: center;
    }

    .nav-links li {
      position: relative;
    }

    .nav-links a {
      color: white;
      text-decoration: none;
      font-weight: 600;
      font-size: 16px;
      cursor: pointer;
    }

    .nav-links a:hover {
      color: #ff874e;
    }

    .dropdown {
      margin-left: 18px;

    }

    .dropdown-menu {
      display: none;
      position: absolute;
      top: 100%;
      left: 0;
      background-color: #222;
      padding: 10px 0;
      min-width: 200px;
      z-index: 10001;
      border-radius: 0 0 6px 6px;
    }

    .dropdown-menu li a {
      display: block;
      padding: 10px 20px;
      color: white;
      font-size: 14px;
    }

    .dropdown-menu li a:hover {
      background-color: rgb(196, 160, 143);
    }

    .dropdown.open>.dropdown-menu {
      display: block !important;
      background: #222;
      box-shadow: none;
    }

    .quote-btn {
      background: #ff874e;
      padding: 10px 20px;
      color: white;
      border: none;
      border-radius: 4px;
      font-weight: bold;
      text-decoration: none;
      cursor: pointer;
    }

    .quote-btn:hover {
      background: #e46528;
    }

    .search-icon {
      color: white;
      font-size: 18px;
      margin-right: 10px;
      cursor: pointer;
    }

    .menu-toggle {
      display: none;
      font-size: 26px;
      color: white;
      cursor: pointer;
    }

    .navbar-right {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    @media (max-width: 768px) {
      .menu-toggle {
        display: block;
      }

      .nav-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0, 0, 0, 0.5);
        z-index: 9999;
        transition: opacity 0.3s;
      }

      .nav-overlay.active {
        display: block;
        opacity: 1;
      }

      .nav-links {
        display: flex;
        flex-direction: column;
        background-color: rgba(0, 0, 0, 0.97);
        position: fixed;
        top: 0;
        left: -260px;
        width: 250px;
        height: 100vh;
        padding: 40px 20px 20px 20px;
        gap: 10px;
        z-index: 10000;
        box-shadow: 2px 0 8px rgba(0, 0, 0, 0.2);
        transition: left 0.3s;
      }

      .nav-links.active {
        left: 0;
      }

      .dropdown {
        margin-left: 0 !important;
        width: 100%;
      }

      .nav-links li.left-align {
        align-self: flex-start;
        width: 100%;
        text-align: left;
      }

      .nav-links li.left-align a {
        width: 100%;
        display: inline-block;
      }

      .dropdown-menu {
        width: 100%;
        display: none !important;
        position: static;
        background: #222;
        box-shadow: none;
      }
    }

    .floating-buttons {
      position: fixed;
      bottom: 20px;
      right: 20px;
      display: flex;
      flex-direction: column;
      gap: 15px;
      z-index: 1000;
    }

    .whatsapp-button,
    .call-button {
      background-color: #25D366;
      color: white;
      font-size: 24px;
      padding: 15px;
      border-radius: 50%;
      text-align: center;
      text-decoration: none;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
      transition: transform 0.3s ease;
    }

    .call-button {
      background-color: #0a66c2;
    }

    .whatsapp-button:hover,
    .call-button:hover {
      transform: scale(1.1);
    }
  </style>
</head>

<body>
  <header>
    <div class="navbar">
      <div class="logo">
        <img src="images/zodiac-logo.png" alt="Zodiac Logo" />
        Zodiac
      </div>
      <div class="menu-toggle" onclick="toggleMenu()">&#9776;</div>

      <div class="nav-overlay" id="navOverlay"></div>
      <ul class="nav-links" id="navLinks">
        <li class="left-align"><a href="index.php">Home</a></li>
        <li class="left-align"><a href="about-us.php">About Us</a></li>

        <li class="dropdown">
          <a href="javascript:void(0)" class="dropdown-toggle">Services &#9662;</a>
          <ul class="dropdown-menu">
            <li><a href="love-problem.php">Love Problem Solutions</a></li>
            <li><a href="love-problem.php">Marriage Problem Solutions</a></li>
            <li><a href="love-problem.php">Black Magic Removal</a></li>
          </ul>
        </li>

        <li class="dropdown">
          <a href="javascript:void(0)" class="dropdown-toggle">Locations &#9662;</a>
          <ul class="dropdown-menu">
            <li><a href="texas.php">Texas</a></li>
            <li><a href="/new-york">New York</a></li>
            <li><a href="/new-jersey">New Jersey</a></li>
          </ul>
        </li>

        <li class="left-align"><a href="contact-us.php">Contact Us</a></li>
      </ul>


      <div class="navbar-right">
        <span class="search-icon">&#128269;</span>
        <a class="quote-btn" href="#">Free Quote</a>
      </div>
    </div>
  </header>

  <div class="floating-buttons">
    <a href="https://wa.me/1234567890" target="_blank" class="whatsapp-button" title="Chat on WhatsApp">🟢</a>
    <a href="tel:+1234567890" class="call-button" title="Call Now">📞</a>
  </div>

  <script>
    function toggleMenu() {
      const navLinks = document.getElementById('navLinks');
      const navOverlay = document.getElementById('navOverlay');
      navLinks.classList.toggle('active');
      navOverlay.classList.toggle('active');

      document.querySelectorAll('.dropdown').forEach(drop => drop.classList.remove('open'));
    }

    document.addEventListener('DOMContentLoaded', function () {
      const dropdownToggles = document.querySelectorAll('.dropdown-toggle');
      const navOverlay = document.getElementById('navOverlay');

      dropdownToggles.forEach(function (toggle) {
        toggle.addEventListener('click', function (e) {
          e.preventDefault();

          const parent = this.closest('.dropdown');
          const isOpen = parent.classList.contains('open');

          document.querySelectorAll('.dropdown').forEach(drop => drop.classList.remove('open'));
          if (!isOpen) {
            parent.classList.add('open');
          }
        });
      });

      navOverlay.addEventListener('click', function () {
        document.getElementById('navLinks').classList.remove('active');
        this.classList.remove('active');
        document.querySelectorAll('.dropdown').forEach(drop => drop.classList.remove('open'));
      });

      document.querySelectorAll('.dropdown').forEach(function (dropdown) {
        dropdown.addEventListener('mouseenter', function () {
          if (window.innerWidth > 768) {
            dropdown.classList.add('open');
          }
        });
        dropdown.addEventListener('mouseleave', function () {
          if (window.innerWidth > 768) {
            dropdown.classList.remove('open');
          }
        });
      });

      document.querySelectorAll('.nav-links a').forEach(function (link) {
        link.addEventListener('click', function (e) {
          const isDropdownToggle = this.classList.contains('dropdown-toggle');
          const isInDropdown = this.closest('.dropdown-menu');

          if (!isDropdownToggle && !isInDropdown) {
            document.getElementById('navLinks').classList.remove('active');
            document.getElementById('navOverlay').classList.remove('active');
            document.querySelectorAll('.dropdown').forEach(drop => drop.classList.remove('open'));
          }
        });
      });
    });
  </script>




</body>

</html>