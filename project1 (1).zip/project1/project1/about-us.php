<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>About Zodiac Astrology</title>

  <?php include 'header.php'; ?>

  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: url('images/n1.jpg') no-repeat center center/cover;
      color: white;
    }

    .overlay {
      background-color: rgba(0, 0, 0, 0.7);
      min-height: 100vh;
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 80px 20px;
    }

    .about-container {
      display: flex;
      max-width: 1200px;
      width: 100%;
      gap: 40px;
      flex-wrap: wrap;
      align-items: center;
    }

    .about-image {
      flex: 1 1 400px;
      max-width: 500px;
    }

    .about-image img {
      width: 100%;
      border-radius: 12px;
      box-shadow: 0 0 20px rgba(0,0,0,0.5);
      display: block;
    }

    .about-content {
      flex: 1 1 400px;
      color: #ddd;
      font-size: 18px;
    }

    .about-content h1 {
      font-family: 'Playfair Display', serif;
      font-size: 42px;
      margin-bottom: 20px;
      color: #fff;
    }

    .about-content p {
      line-height: 1.8;
      margin-bottom: 20px;
    }

    .about-highlight {
      background-color: #1c1f3f;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 15px rgba(255, 255, 255, 0.05);
      margin-top: 30px;
    }

    .about-highlight h2 {
      margin-bottom: 15px;
      color: #fff;
    }

    .about-highlight ul {
      list-style: none;
      padding: 0;
      font-size: 16px;
    }

    .about-highlight ul li {
      margin-bottom: 10px;
    }

    /* Responsive */
    @media (max-width: 900px) {
      .about-container {
        flex-direction: column;
        padding: 0 10px;
      }

      .about-image,
      .about-content {
        max-width: 100%;
        flex: none;
      }

      .about-content h1 {
        font-size: 32px;
      }

      .about-content p {
        font-size: 16px;
      }
    }
  </style>
</head>
<body>


  <div class="overlay">
    <div class="about-container">
      <div class="about-image">
        <img src="images/np2.jpg" alt="Astrology Illustration" />
      </div>

      <div class="about-content">
        <h1>About Zodiac Astrology</h1>
        <p>
          At Zodiac Astrology, we believe the stars hold the key to understanding ourselves and unlocking our full potential.
          With decades of combined experience, our team of professional astrologers is dedicated to guiding individuals through
          the cosmic wisdom of the universe. Whether you're seeking clarity in love, career, health, or spiritual growth,
          our personalized consultations and forecasts provide deep, actionable insight.
        </p>
        <p>
          Our journey began with a simple yet profound mission: to bring authentic astrology to people worldwide in a way that’s
          modern, meaningful, and accessible. We've helped thousands align with their higher purpose, understand their relationships,
          and make empowered life decisions.
        </p>

        <div class="about-highlight">
          <h2>What Makes Us Unique?</h2>
          <ul>
            <li>✨ Certified and experienced astrologers</li>
            <li>🔮 Personalized birth chart readings</li>
            <li>💖 Accurate love & relationship guidance</li>
            <li>🌙 Ancient Vedic and Western astrology techniques</li>
            <li>🛡️ Energy protection & black magic remedies</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <?php include 'faq.php'; ?>
  <?php include 'testimonials.php'; ?>

  <?php include 'footer.php'; ?>

</body>
</html>
