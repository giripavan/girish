<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Zodiac Astrology</title>


  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: url('images/n1.jpg') no-repeat center center/cover;
      color: #fff;
    }

    .overlay {
      background-color: rgba(0, 0, 0, 0.7); /* dark overlay for readability */
      min-height: 100vh;
      width: 100%;
    }

    .main-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 40px 20px;
    }

    .banner {
      text-align: center;
      padding: 100px 20px 60px;
    }

    .banner h1 {
      font-size: 48px;
      font-family: 'Playfair Display', serif;
      margin-bottom: 20px;
    }

    .banner p {
      font-size: 20px;
      max-width: 600px;
      margin: 0 auto;
    }

    .content-title {
      font-size: 36px;
      font-family: 'Playfair Display', serif;
      margin: 40px 0 20px;
      text-align: center;
    }

    .services-wrapper {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 30px;
      max-width: 1200px;
    }

    .service-card {
      background-color: #1c1f3f;
      padding: 30px 20px;
      border-radius: 12px;
      width: 280px;
      transition: transform 0.3s ease;
      box-shadow: 0 0 10px rgba(255, 255, 255, 0.05);
    }

    .service-card:hover {
      transform: translateY(-5px);
      background-color: #262a5a;
    }

    .service-card h3 {
      font-size: 22px;
      margin-bottom: 10px;
    }

    .service-card p {
      font-size: 15px;
      color: #ccc;
    }

    @media (max-width: 768px) {
      .banner h1 {
        font-size: 32px;
      }

      .banner p {
        font-size: 16px;
      }

      .service-card {
        width: 90%;
      }
    }
  </style>
</head>
<body>

  <?php include 'header.php'; ?>

  <div class="overlay">
    <div class="main-wrapper">
      <div class="banner">
        <h1>Welcome to Zodiac Astrology</h1>
        <p>Discover your true self and unlock your destiny with our expert astrologers and personalized guidance.</p>
      </div>

      <h2 class="content-title">Our Services</h2>
      <div class="services-wrapper">
        
      </div>
    </div>
  </div>
  <?php include 'choose-zodiac.php'; ?>
  <?php include 'why-choose-us.php'; ?>

  <?php include 'services.php'; ?>
  <?php include 'faq.php'; ?>
  <?php include 'testimonials.php'; ?>

  <?php include 'footer.php'; ?>

</body>
</html>
