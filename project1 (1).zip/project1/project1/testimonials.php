<section class="cosmic-testimonials" style="padding: 80px 20px; background: linear-gradient(135deg, #0f0c29, #302b63); position: relative; overflow: hidden;">
  <!-- Cosmic Background Elements -->
  <div class="cosmic-particle" style="position: absolute; top: 20%; left: 10%; width: 3px; height: 3px; background: rgba(255,255,255,0.6); border-radius: 50%; animation: twinkle 3s infinite;"></div>
  <div class="cosmic-particle" style="position: absolute; bottom: 30%; right: 15%; width: 4px; height: 4px; background: rgba(110, 99, 255, 0.8); border-radius: 50%; animation: twinkle 4s infinite 1s;"></div>
  
  <div style="max-width: 1200px; margin: 0 auto; position: relative; z-index: 1;">
    <!-- Section Header -->
    <div class="section-header" style="text-align: center; margin-bottom: 60px;">
      <h2 style="font-size: 2.8rem; color: #eebbc3; margin-bottom: 15px; position: relative; display: inline-block;">
        <span style="background: linear-gradient(45deg, #eebbc3, #9d4edd); -webkit-background-clip: text; background-clip: text; color: transparent;">Celestial Testimonials</span>
        <div style="position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%); width: 80px; height: 3px; background: linear-gradient(90deg, transparent, #6c63ff, transparent);"></div>
      </h2>
      <p style="color: rgba(255,255,255,0.7); max-width: 700px; margin: 0 auto; font-size: 1.1rem; line-height: 1.6;">
        Hear from those who have found guidance and clarity through cosmic wisdom
      </p>
    </div>

    <!-- Testimonials Grid -->
    <div class="testimonials-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
      
      <!-- Testimonial 1 -->
      <div class="cosmic-testimonial" style="background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 20px; padding: 30px; border: 1px solid rgba(110, 99, 255, 0.3); transition: all 0.4s ease; position: relative; overflow: hidden;">
        <div class="quote-icon" style="position: absolute; top: 20px; right: 20px; font-size: 4rem; color: rgba(110, 99, 255, 0.1); z-index: 0;">❝</div>
        <div class="testimonial-content" style="position: relative; z-index: 1;">
          <div class="client-info" style="display: flex; align-items: center; margin-bottom: 20px;">
            <div class="avatar" style="width: 60px; height: 60px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 2px solid #6c63ff;">
              <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Riya Mehta" style="width: 100%; height: 100%; object-fit: cover;">
            </div>
            <div>
              <h3 style="color: #eebbc3; margin: 0; font-size: 1.2rem;">Riya Mehta</h3>
              <p style="color: rgba(255,255,255,0.6); margin: 5px 0 0; font-size: 0.85rem;">Entrepreneur</p>
            </div>
          </div>
          <div class="stars" style="color: #fbb040; margin-bottom: 15px; font-size: 0.9rem;">
            <i class="fas fa-star"></i><i class="fas fa-star"></i>
            <i class="fas fa-star"></i><i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
          </div>
          <p class="testimonial-text" style="color: rgba(255,255,255,0.9); line-height: 1.7; font-size: 0.95rem; margin-bottom: 0;">
            "Astrologer Hanuman's insights completely changed my life path. The reading was accurate beyond expectations and gave me the clarity I needed during a difficult transition."
          </p>
        </div>
        <div class="testimonial-bg" style="position: absolute; bottom: 0; left: 0; width: 100%; height: 5px; background: linear-gradient(90deg, #9d4edd, #6c63ff);"></div>
      </div>

      <!-- Testimonial 2 -->
      <div class="cosmic-testimonial" style="background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 20px; padding: 30px; border: 1px solid rgba(110, 99, 255, 0.3); transition: all 0.4s ease; position: relative; overflow: hidden;">
        <div class="quote-icon" style="position: absolute; top: 20px; right: 20px; font-size: 4rem; color: rgba(110, 99, 255, 0.1); z-index: 0;">❝</div>
        <div class="testimonial-content" style="position: relative; z-index: 1;">
          <div class="client-info" style="display: flex; align-items: center; margin-bottom: 20px;">
            <div class="avatar" style="width: 60px; height: 60px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 2px solid #6c63ff;">
              <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Michael Thomas" style="width: 100%; height: 100%; object-fit: cover;">
            </div>
            <div>
              <h3 style="color: #eebbc3; margin: 0; font-size: 1.2rem;">Michael Thomas</h3>
              <p style="color: rgba(255,255,255,0.6); margin: 5px 0 0; font-size: 0.85rem;">Freelancer</p>
            </div>
          </div>
          <div class="stars" style="color: #fbb040; margin-bottom: 15px; font-size: 0.9rem;">
            <i class="fas fa-star"></i><i class="fas fa-star"></i>
            <i class="fas fa-star"></i><i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
          </div>
          <p class="testimonial-text" style="color: rgba(255,255,255,0.9); line-height: 1.7; font-size: 0.95rem; margin-bottom: 0;">
            "A calm, spiritual approach to my career challenges. The remedies suggested truly work wonders! My business improved within weeks of following the guidance."
          </p>
        </div>
        <div class="testimonial-bg" style="position: absolute; bottom: 0; left: 0; width: 100%; height: 5px; background: linear-gradient(90deg, #9d4edd, #6c63ff);"></div>
      </div>

      <!-- Testimonial 3 -->
      <div class="cosmic-testimonial" style="background: rgba(255,255,255,0.05); backdrop-filter: blur(10px); border-radius: 20px; padding: 30px; border: 1px solid rgba(110, 99, 255, 0.3); transition: all 0.4s ease; position: relative; overflow: hidden;">
        <div class="quote-icon" style="position: absolute; top: 20px; right: 20px; font-size: 4rem; color: rgba(110, 99, 255, 0.1); z-index: 0;">❝</div>
        <div class="testimonial-content" style="position: relative; z-index: 1;">
          <div class="client-info" style="display: flex; align-items: center; margin-bottom: 20px;">
            <div class="avatar" style="width: 60px; height: 60px; border-radius: 50%; overflow: hidden; margin-right: 15px; border: 2px solid #6c63ff;">
              <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="Sneha Kapoor" style="width: 100%; height: 100%; object-fit: cover;">
            </div>
            <div>
              <h3 style="color: #eebbc3; margin: 0; font-size: 1.2rem;">Sneha Kapoor</h3>
              <p style="color: rgba(255,255,255,0.6); margin: 5px 0 0; font-size: 0.85rem;">Designer</p>
            </div>
          </div>
          <div class="stars" style="color: #fbb040; margin-bottom: 15px; font-size: 0.9rem;">
            <i class="fas fa-star"></i><i class="fas fa-star"></i>
            <i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i>
            <i class="far fa-star"></i>
          </div>
          <p class="testimonial-text" style="color: rgba(255,255,255,0.9); line-height: 1.7; font-size: 0.95rem; margin-bottom: 0;">
            "Very intuitive and warm-hearted reading. Helped me understand difficult relationship decisions with cosmic clarity. The timing predictions were remarkably accurate."
          </p>
        </div>
        <div class="testimonial-bg" style="position: absolute; bottom: 0; left: 0; width: 100%; height: 5px; background: linear-gradient(90deg, #9d4edd, #6c63ff);"></div>
      </div>
    </div>

    <!-- Navigation Controls -->
    <div class="testimonial-nav" style="display: flex; justify-content: center; gap: 15px; margin-top: 40px;">
      <button class="nav-dot active" style="width: 12px; height: 12px; border-radius: 50%; border: none; background: #6c63ff; cursor: pointer; padding: 0;"></button>
      <button class="nav-dot" style="width: 12px; height: 12px; border-radius: 50%; border: none; background: rgba(110, 99, 255, 0.3); cursor: pointer; padding: 0;"></button>
      <button class="nav-dot" style="width: 12px; height: 12px; border-radius: 50%; border: none; background: rgba(110, 99, 255, 0.3); cursor: pointer; padding: 0;"></button>
    </div>
  </div>

  <!-- Floating Elements -->
  <div class="floating-symbol" style="position: absolute; top: 10%; right: 10%; font-size: 3rem; color: rgba(110, 99, 255, 0.1); z-index: 0; animation: float 15s infinite ease-in-out;">☯</div>
  <div class="floating-symbol" style="position: absolute; bottom: 15%; left: 8%; font-size: 2rem; color: rgba(238, 187, 195, 0.1); z-index: 0; animation: float 12s infinite ease-in-out reverse;">♆</div>
</section>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />

<style>
  @keyframes twinkle {
    0%, 100% { opacity: 0.3; }
    50% { opacity: 1; }
  }
  
  @keyframes float {
    0%, 100% { transform: translate(0, 0) rotate(0deg); }
    25% { transform: translate(5px, -10px) rotate(2deg); }
    50% { transform: translate(-5px, 5px) rotate(-2deg); }
    75% { transform: translate(8px, 5px) rotate(3deg); }
  }

  .cosmic-testimonial:hover {
    transform: translateY(-5px) !important;
    box-shadow: 0 10px 30px rgba(110, 99, 255, 0.2) !important;
    border-color: rgba(238, 187, 195, 0.5) !important;
  }

  @media (max-width: 768px) {
    .section-header h2 {
      font-size: 2.2rem !important;
    }
    
    .testimonials-grid {
      grid-template-columns: 1fr !important;
    }
  }
</style>

<script>
  // Simple testimonial navigation
  document.querySelectorAll('.nav-dot').forEach((dot, index) => {
    dot.addEventListener('click', () => {
      // Remove active class from all dots
      document.querySelectorAll('.nav-dot').forEach(d => d.classList.remove('active'));
      document.querySelectorAll('.nav-dot').forEach(d => d.style.background = 'rgba(110, 99, 255, 0.3)');
      
      // Add active class to clicked dot
      dot.classList.add('active');
      dot.style.background = '#6c63ff';
      
      // Here you would typically slide to the corresponding testimonial
      // This is just a visual indicator for the demo
    });
  });
</script>