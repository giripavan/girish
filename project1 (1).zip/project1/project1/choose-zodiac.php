<style>
body {
  margin: 0;
  font-family: Arial, sans-serif;
  background-color: #000;
  color: #fff;
}

.zodiac-header {
  text-align: center;
  margin: 20px 0;
}

.zodiac-header h2 {
  font-size: 2rem;
  letter-spacing: 1px;
}

.zodiac-rotation {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  overflow: hidden;
}

.zodiac-container {
  position: relative;
  width: 600px;
  height: 600px;
  max-width: 90vw;
  max-height: 90vw;
}

.zodiac-circle {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 80%;
  height: 80%;
  transform: translate(-50%, -50%);
  animation: rotateZodiac 20s linear infinite;
  z-index: 1;
}

.zodiac-circle img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.zodiac-cards {
  position: absolute;
  top: 96%;
  left: 94.2%;
  width: 108%;
  height: 105%;
  transform: translate(-50%, -50%);
  z-index: 2;
  pointer-events: none;
}

.zodiac-card {
  position: absolute;
  width: 120px;
  text-align: center;
  color: #fff;
  background: rgba(0, 0, 0, 0.8);
  border-radius: 50px;
  padding: 10px;
  font-size: 0.85rem;
  box-shadow: 0 0 8px rgba(255, 255, 255, 0.3);
  transform: rotate(calc(30deg * var(--i))) translate(260px) rotate(calc(-30deg * var(--i)));
  transform-origin: center center;
  pointer-events: auto;
}

.zodiac-card img {
  width: 60px;
  height: 60px;
  margin-bottom: 6px;
}

.zodiac-card small {
  font-size: 0.65rem;
  color: #ccc;
}

@keyframes rotateZodiac {
  from {
    transform: translate(-50%, -50%) rotate(0deg);
  }
  to {
    transform: translate(-50%, -50%) rotate(360deg);
  }
}

@media (max-width: 768px) {
  .zodiac-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 30px;
    width: 100%;
    padding: 20px 0;
    top:-20%;
  }

  .zodiac-cards {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 10px;
    height: 40%;
    width: 100%;
    position: static;
    transform: none !important;
  }
.zodiac-card {
    width: 80px;
    font-size: 0.6rem;
    background: rgba(255, 255, 255, 0.1);
    padding: 8px;
    border-radius: 12px;
    text-align: center;
    transform: none !important;
    position: static !important;
    box-shadow: none;
  }
  .zodiac-cards.top,
.zodiac-cards.bottom {
  margin: 2px 0; 
}

  .zodiac-card img {
    width: 35px;
    height: 35px;
    margin-bottom: 4px;
  }

  .zodiac-card small {
    font-size: 0.55rem;
  }

  .zodiac-circle {
    width: 40vw;
    height: 30vw;
    top: 12%;
    animation: rotateZodiac 20s linear infinite;
    position: relative;
  }
}

</style>

<div class="zodiac-header">
  <h2>Choose Zodiac Sign</h2>
</div>

<section class="zodiac-rotation">
  <div class="zodiac-container">
  <div class="zodiac-rotation-group">

    <!-- Top 6 cards -->
    <div class="zodiac-cards top">
      <div class="zodiac-card" style="--i: 0;">
        <img src="images/aries.png" alt="Aries"> Aries<br><small>Mar 21 - Apr 19</small>
      </div>
      <div class="zodiac-card" style="--i: 1;">
        <img src="images/taurus.png" alt="Taurus"> Taurus<br><small>Apr 20 - May 20</small>
      </div>
      <div class="zodiac-card" style="--i: 2;">
        <img src="images/zodiac/gemini.png" alt="Gemini"> Gemini<br><small>May 21 - Jun 20</small>
      </div>
      <div class="zodiac-card" style="--i: 3;">
        <img src="images/zodiac/cancer.png" alt="Cancer"> Cancer<br><small>Jun 21 - Jul 22</small>
      </div>
      <div class="zodiac-card" style="--i: 4;">
        <img src="images/zodiac/leo.png" alt="Leo"> Leo<br><small>Jul 23 - Aug 22</small>
      </div>
      <div class="zodiac-card" style="--i: 5;">
        <img src="images/zodiac/virgo.png" alt="Virgo"> Virgo<br><small>Aug 23 - Sep 22</small>
      </div>
    </div>

    <!-- Rotating image in center -->
    <div class="zodiac-circle">
      <img src="images/zodiac-circle.png" alt="Zodiac Circle" />
    </div>

    <!-- Bottom 6 cards -->
    <div class="zodiac-cards bottom">
      <div class="zodiac-card" style="--i: 6;">
        <img src="images/zodiac/libra.png" alt="Libra"> Libra<br><small>Sep 23 - Oct 22</small>
      </div>
      <div class="zodiac-card" style="--i: 7;">
        <img src="images/zodiac/scorpio.png" alt="Scorpio"> Scorpio<br><small>Oct 23 - Nov 21</small>
      </div>
      <div class="zodiac-card" style="--i: 8;">
        <img src="images/zodiac/sagittarius.png" alt="Sagittarius"> Sagittarius<br><small>Nov 22 - Dec 21</small>
      </div>
      <div class="zodiac-card" style="--i: 9;">
        <img src="images/zodiac/capricorn.png" alt="Capricorn"> Capricorn<br><small>Dec 22 - Jan 19</small>
      </div>
      <div class="zodiac-card" style="--i: 10;">
        <img src="images/zodiac/aquarius.png" alt="Aquarius"> Aquarius<br><small>Jan 20 - Feb 18</small>
      </div>
      <div class="zodiac-card" style="--i: 11;">
        <img src="images/zodiac/pisces.png" alt="Pisces"> Pisces<br><small>Feb 19 - Mar 20</small>
      </div>
    </div>

  </div>
</div>

</section>

