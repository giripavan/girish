<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <?php include('header.php'); ?>

  <style>
    :root {
      --primary: #FF4D6D;
      --secondary: #FF8FA3;
      --light: #FFF0F3;
      --dark: #590D22;
      --text: #333;
      --text-light: #777;
    }

    body, html {
      margin: 0; padding: 0;
      font-family: 'Arial', sans-serif;
      background-color: var(--light);
      color: var(--text);
      scroll-behavior: smooth;
    }

    /* Background hero section with overlay */
    .astrology-section {
      background: linear-gradient(
          rgba(10, 5, 30, 0.9),
          rgba(10, 5, 30, 0.9)
        ),
        url('https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?ixlib=rb-4.0.3&auto=format&fit=crop&w=1471&q=80')
          no-repeat center center;
      background-size: cover;
      padding: 80px 20px;
      position: relative;
      overflow: hidden;
      color: white;
      text-align: center;
      min-height: 60vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .astrology-section h2 {
      font-size: 3.5rem;
      font-weight: 700;
      margin-bottom: 1rem;
      font-family: 'Playfair Display', serif;
    }

    .astrology-section p {
      font-size: 1.8rem;
      max-width: 700px;
      margin: 0 auto;
      color: #eee;
      line-height: 1.6;
    }

    /* Main content area */
    .love-astrology-main {
      padding: 4rem 2rem;
      background-color: var(--light);
      min-height: 100vh;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
    }

    .love-header {
      text-align: center;
      margin-bottom: 5rem;
      position: relative;
    }

    .love-header h1 {
      font-size: 4.2rem;
      color: var(--dark);
      font-weight: 700;
      margin-bottom: 1.5rem;
      line-height: 1.2;
      display: inline-block;
      font-family: 'Playfair Display', serif;
      position: relative;
    }

    .love-header h1::after {
      content: '';
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
      width: 80px;
      height: 4px;
      background: var(--primary);
      border-radius: 2px;
    }

    .love-header p {
      font-size: 1.8rem;
      color: var(--dark);
      max-width: 700px;
      margin: 0 auto;
      line-height: 1.6;
    }

    .love-content-container {
      background: white;
      border-radius: 12px;
      box-shadow: 0 5px 30px rgba(0, 0, 0, 0.05);
      padding: 4rem;
      margin: 0 auto;
      overflow: hidden;
      position: relative;
    }

    .love-content-container::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 6px;
      height: 100%;
      background: linear-gradient(to bottom, var(--primary), var(--secondary));
      border-radius: 12px 0 0 12px;
    }

    .love-content {
      font-size: 1.8rem;
      line-height: 1.8;
      color: var(--text);
    }

    .love-content p {
      margin-bottom: 2.5rem;
    }

    .quote-card {
      background-color: white;
      border: 1px solid rgba(255, 77, 109, 0.2);
      border-radius: 8px;
      padding: 3rem;
      margin: 3rem 0;
      position: relative;
    }

    .quote-card::before {
      content: '"';
      position: absolute;
      font-size: 8rem;
      color: rgba(255, 77, 109, 0.1);
      top: -1rem;
      left: 1rem;
      line-height: 1;
      font-family: serif;
    }

    .quote-card p {
      font-size: 1.8rem;
      color: var(--dark);
      font-style: italic;
      position: relative;
      z-index: 1;
    }

    .love-features {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 3rem;
      margin: 5rem 0;
    }

    .feature-card {
      background: #FFFECE;
      border-radius: 8px;
      padding: 2.5rem;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.03);
      border: 1px solid rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
      opacity: 0;
      transform: translateY(20px);
    }

    .feature-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 4px;
      background: var(--primary);
    }

    .feature-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 25px rgba(255, 77, 109, 0.1);
      opacity: 1 !important;
    }

    .feature-icon {
      font-size: 3rem;
      color: var(--primary);
      margin-bottom: 1.5rem;
    }

    .feature-card h3 {
      font-size: 2.8rem;
      color: var(--dark);
      margin-bottom: 1.5rem;
      font-weight: 600;
      font-family: 'Playfair Display', serif;
    }

    .feature-card p {
      font-size: 1.75rem;
      margin-bottom: 0;
      color: black;
    }

    .cta-section {
      text-align: center;
      margin-top: 6rem;
      padding: 4rem 2rem;
      background-color: white;
      border-radius: 12px;
      position: relative;
      overflow: hidden;
    }

    .cta-section::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path fill="%23FF4D6D" opacity="0.05" d="M0,0 L100,0 L100,100 L0,100 Z"></path></svg>');
      background-size: cover;
      z-index: 0;
    }

    .cta-section h2 {
      font-size: 2.8rem;
      color: var(--dark);
      margin-bottom: 2rem;
      position: relative;
      z-index: 1;
      font-family: 'Playfair Display', serif;
    }

    .cta-button {
      display: inline-block;
      padding: 1.4rem 3.5rem;
      background-color: var(--primary);
      color: white;
      font-size: 2rem;
      border-radius: 8px;
      text-decoration: none;
      transition: all 0.3s ease;
      position: relative;
      z-index: 1;
      border: none;
      cursor: pointer;
      font-weight: 500;
      font-family: 'Playfair Display', serif;
      line-height: 2.4rem;
    }

    .cta-button:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 15px rgba(255, 77, 109, 0.4);
    }

    /* Responsive adjustments */
    @media (max-width: 1024px) {
      .love-header h1 {
        font-size: 3.5rem;
      }

      .love-header p {
        font-size: 1.6rem;
      }

      .love-content-container {
        padding: 3rem 2rem;
      }

      .love-content, .feature-card p {
        font-size: 1.6rem;
      }

      .feature-card h3 {
        font-size: 2.2rem;
      }

      .feature-icon {
        font-size: 2.5rem;
      }

      .cta-section h2 {
        font-size: 2.4rem;
      }

      .cta-button {
        font-size: 1.8rem;
        padding: 1.2rem 3rem;
      }
    }

    @media (max-width: 600px) {
      .astrology-section {
        padding: 60px 10px;
        min-height: 50vh;
      }

      .astrology-section h2 {
        font-size: 2.8rem;
      }

      .astrology-section p {
        font-size: 1.4rem;
      }

      .love-header h1 {
        font-size: 2.8rem;
      }

      .love-header p {
        font-size: 1.4rem;
      }

      .love-content-container {
        padding: 2rem 1rem;
      }

      .love-content, .feature-card p {
        font-size: 1.4rem;
      }

      .feature-card h3 {
        font-size: 1.8rem;
      }

      .feature-icon {
        font-size: 2rem;
      }

      .cta-section {
        padding: 3rem 1rem;
      }

      .cta-section h2 {
        font-size: 2rem;
      }

      .cta-button {
        font-size: 1.6rem;
        padding: 1rem 2.5rem;
      }
    }
  </style>
</head>
<body>

  <!-- Background hero section -->
  <section class="astrology-section" aria-label="Celestial background section">
    <h2>Celestial Love Guidance</h2>
    <p>Align your heart with the stars for deeper connections and meaningful relationships</p>
  </section>

  <!-- Main Love Astrology Section -->
  <section class="love-astrology-main" aria-label="Love astrology services">
    <div class="container">
      <div class="love-header" aria-labelledby="love-header-title">
        <h1 id="love-header-title">Celestial Love Guidance</h1>
        <p>Align your heart with the stars for deeper connections and meaningful relationships</p>
      </div>

      <div class="love-content-container">
        <div class="love-content">
          <p>In the cosmic dance of relationships, astrology provides the divine rhythm that helps soulmates find each other. When love feels out of balance, Vedic astrological insights can reveal the karmic patterns affecting your journey. Surya Tej, Florida's most trusted Vedic astrologer, offers profound wisdom to illuminate your relationship path.</p>

          <p>Whether you're seeking to attract your destined partner, heal a karmic relationship, or understand soul connections across lifetimes, Vedic astrology provides a sacred map to your love destiny. The positions of Venus (Shukra), Mars (Mangal), and the 7th house in your birth chart reveal your divine romantic blueprint.</p>

          <div class="love-features" id="featureCards">
            <div class="feature-card" tabindex="0">
              <div class="feature-icon" aria-hidden="true">❤️</div>
              <h3>Vedic Compatibility</h3>
              <p>Discover your cosmic compatibility through detailed analysis of Janam Kundali (birth charts) and Gun Milan (36-point matching system).</p>
            </div>
            <div class="feature-card" tabindex="0">
              <div class="feature-icon" aria-hidden="true">🔮</div>
              <h3>Mangal Dosha Solutions</h3>
              <p>Expert remedies and guidance for overcoming challenges posed by Mars afflictions in your birth chart.</p>
            </div>
            <div class="feature-card" tabindex="0">
              <div class="feature-icon" aria-hidden="true">🌿</div>
              <h3>Karmic Healing</h3>
              <p>Powerful Vedic remedies to heal past life relationship wounds and remove obstacles to marital bliss.</p>
            </div>
          </div>

          <p>Beyond conventional relationship advice, Surya Tej's Vedic astrology readings offer timeless wisdom based on your unique birth chart. The Moon (Chandra) reveals your emotional nature, Venus (Shukra) shows your capacity for love, and Mars (Mangal) indicates your passion and drive. When these planetary energies are understood through the lens of Jyotish, relationships transform into sacred journeys of growth.</p>

          <p>For those experiencing persistent relationship challenges, Surya Tej's astrological analysis can reveal if planetary afflictions or past-life karma are creating obstacles. With this divine knowledge, you can align with cosmic rhythms through personalized mantras, yantras, and Vedic remedies.</p>

          <div class="cta-section">
            <h2>Ready to Discover Your Divine Love Blueprint?</h2>
            <a href="contact-us.php" class="cta-button" role="button">Schedule Your Vedic Astrology Reading</a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php include('testimonials.php'); ?>
  <?php include('footer.php'); ?>

  <script>
    // Modern scroll animation implementation
    document.addEventListener('DOMContentLoaded', function () {
      const featureCards = document.querySelectorAll('.feature-card');

      // Intersection Observer for smooth animations
      const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px',
      };

      const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
          if (entry.isIntersecting) {
            setTimeout(() => {
              entry.target.style.opacity = '1';
              entry.target.style.transform = 'translateY(0)';
            }, index * 150);
          }
        });
      }, observerOptions);

      // Set initial styles and observe each card
      featureCards.forEach((card) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
      });

      // Smooth hover effect on CTA button handled via CSS, no need for JS
    });
  </script>
</body>
</html>
