<section class="why-choose-us">
  <h2 class="choose-title">Why Choose Us</h2>
  <p class="choose-desc">
    With decades of experience and countless happy clients, we blend ancient wisdom with modern insight. 
    Let us help you find clarity, peace, and direction in life through astrology.
  </p>

  <div class="stats-grid">
    <div class="stat-box">
      <div class="circle">
        <div class="stat-number" data-count="1500">0</div>
      </div>
      <p>Clients Satisfied</p>
    </div>
    <div class="stat-box">
      <div class="circle">
        <div class="stat-number" data-count="45">0</div>
      </div>
      <p>Palm Reading Branches</p>
    </div>
    <div class="stat-box">
      <div class="circle">
        <div class="stat-number" data-count="980">0</div>
      </div>
      <p>Love Problems Solved</p>
    </div>
    <div class="stat-box">
      <div class="circle">
        <div class="stat-number" data-count="25">0</div>
      </div>
      <p>Years of Experience</p>
    </div>
  </div>
</section>

<style>
.why-choose-us {
  background-color: #0d0d1a;
  color: #fff;
  text-align: center;
  padding: 80px 20px;
}

.choose-title {
  font-size: 36px;
  font-family: 'Playfair Display', serif;
  margin-bottom: 20px;
}

.choose-desc {
  font-size: 18px;
  max-width: 700px;
  margin: 0 auto 50px;
  color: #ccc;
}

.stats-grid {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 40px;
}

.stat-box {
  width: 200px;
}

.circle {
  width: 150px;
  height: 150px;
  margin: auto;
  border-radius: 50%;
  background: radial-gradient(circle at center, #f9d342 0%, #1c1f3f 60%);
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  box-shadow: 0 0 20px 5px #f9d34288;
  animation: glow 2s infinite alternate;
}

@keyframes glow {
  0% {
    box-shadow: 0 0 20px 5px #f9d34288;
  }
  100% {
    box-shadow: 0 0 30px 10px #f9d342aa;
  }
}

.stat-number {
  font-size: 36px;
  color: #fff;
  font-weight: bold;
}

.stat-box p {
  font-size: 16px;
  color: #ccc;
  margin-top: 15px;
}

@media (max-width: 768px) {
  .stat-box {
    width: 90%;
  }

  .choose-title {
    font-size: 28px;
  }

  .choose-desc {
    font-size: 16px;
  }

  .circle {
    width: 120px;
    height: 120px;
  }

  .stat-number {
    font-size: 28px;
  }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const counters = document.querySelectorAll('.stat-number');
  counters.forEach(counter => {
    const updateCount = () => {
      const target = +counter.getAttribute('data-count');
      const count = +counter.innerText;
      const increment = target / 100;

      if (count < target) {
        counter.innerText = Math.ceil(count + increment);
        setTimeout(updateCount, 20);
      } else {
        counter.innerText = target;
      }
    };
    updateCount();
  });
});
</script>
