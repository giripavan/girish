<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <?php include('header.php'); ?>
    
    <style>
        :root {
            --primary: #6C63FF;
            --dark: #121212;
            --light: #f8f9fa;
            --gray: #2d2d2d;
            --form-width: 500px; /* Form width */
        }
        
        body {
            background-color: var(--dark);
            color: var(--light);
            font-family: 'Inter', sans-serif;
        }
        
        
        .contact-section {
            padding: 60px 0;
        }
        
        .section-header {
            text-align: center;
            margin-bottom: 50px;
        }
        
        .section-header h2 {
            font-weight: 700;
            font-size: 4.4rem;
            margin-bottom: 15px;
            background: linear-gradient(90deg, var(--primary), #9D94FF);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-family: 'Playfair Display', serif;
        }
        
        .section-header p {
            color: white;
            max-width: 600px;
            margin: 0 auto;
            font-size: 1.45rem;
            line-height: 1.6;
        }
        
        .contact-container {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            max-width: 1100px;
            margin: 0 auto;
            justify-content: center;
            align-items: stretch;
        }
        
        .contact-form-container {
            width: var(--form-width);
            background: var(--gray);
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            display: flex;
            flex-direction: column;
            border: 2px solid var(--primary); /* Added blue border */
        }
        
        .contact-form-container h3 {
            font-size: 2.6rem; /* Slightly smaller heading */
            margin-bottom: 25px; /* Reduced margin */
            color: white;
            font-family: 'Playfair Display', serif;
        }
        
        .form-group {
            margin-bottom: 18px; /* Reduced spacing */
            position: relative;
            
        }
        
        .form-control {
            width: 100%;
            padding: 12px 12px 12px 40px; /* Adjusted padding */
            background: #1e1e1e;
            border: 1px solid #444;
            border-radius: 8px;
            color: white;
            font-size: 0.95rem; /* Slightly smaller font */
            transition: all 0.3s;
            
        }
        
        /* Form field icons */
        .form-group:before {
            content: '';
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            width: 18px;
            height: 18px;
            background-repeat: no-repeat;
            background-position: center;
            background-size: contain;
            z-index: 2;
            opacity: 0.7;
        }

        /* Update input background when focused (typing) */
        .form-control:focus {
    background-color: black !important;
    color: white;
}

/* Update input background when it has content (after typing) */
.form-control:not(:placeholder-shown) {
    background-color: black !important;
    color: white;
    font-size: 1.3rem;
}

/* Maintain original styling for empty fields */
.form-control {
    background: #1e1e1e; /* Original dark gray */
    transition: background-color 0.3s ease; /* Smooth transition */
}

/* Keep placeholder styling */
.form-control::placeholder {
    font-size: 2.2rem;
    color: #aaa;
    opacity: 1;
}


/* Placeholder text styling */
.form-control::placeholder {
    font-size: 1.4rem; /* Adjust this value as needed */
    color: #aaa;
    opacity: 1;
}

/* Browser-specific placeholder styles */
.form-control::-webkit-input-placeholder { /* Chrome/Edge/Safari */
    font-size: 1.4rem;
    color: #aaa;
}
.form-control::-moz-placeholder { /* Firefox 19+ */
    font-size: 1.4rem;
    color: #aaa;
    opacity: 1;
}
.form-control:-ms-input-placeholder { /* IE 10-11 */
    font-size: 1.4rem;
    color: #aaa;
}
.form-control:-moz-placeholder { /* Firefox 18- */
    font-size: 1.4rem;
    color: #aaa;
    opacity: 1;
}
        
 /* Change all form icons to use --primary color (#6C63FF) */
.name-field:before {
    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%236C63FF"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>');
}

.email-field:before {
    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%236C63FF"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>');
}

.phone-field:before {
    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%236C63FF"><path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56-.35-.12-.74-.03-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z"/></svg>');
}

.service-field:before {
    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%236C63FF"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/></svg>');
}

.message-field:before {
    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%236C63FF"><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/></svg>');
    top: 15px;
}

/* Make icons fully opaque (remove transparency) */
.form-group:before {
    opacity: 1 !important;
}
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.2);
        }
        
        textarea.form-control {
            min-height: 120px; /* Reduced height */
            resize: vertical;
            padding-top: 12px;
        }
        
        /* Select dropdown styling */
        select.form-control {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23ffffff"><path d="M7 10l5 5 5-5z"/></svg>');
            background-repeat: no-repeat;
            background-position: right 12px center;
            background-size: 15px;
        }
        
        .btn-submit {
            background: var(--primary);
            color: white;
            border: none;
            padding: 12px 25px; /* Adjusted padding */
            border-radius: 8px;
            font-weight: 600;
            font-size: 1.8rem;
            cursor: pointer;
            width: 100%;
            transition: all 0.3s;
            margin-top: 5px; /* Reduced margin */
            font-family: 'Playfair Display', serif;
        }
        
        .btn-submit:hover {
            background: #5a52e0;
            transform: translateY(-2px);
        }
        
        .contact-info-container {
            width: var(--form-width);
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .contact-card {
            background: var(--gray);
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            flex: 1;
            display: flex;
            flex-direction: column;
            border: 2px solid var(--primary); /* Added blue border */
        }
        
        .contact-card h4 {
            font-size: 2.4rem;
            margin-bottom: 20px;
            color: white;
            position: relative;
            padding-bottom: 10px;
            font-family: 'Playfair Display', serif;
        }
        
        .contact-card h4:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 3px;
            background: var(--primary);
        }
        
        .contact-detail {
            display: flex;
            align-items: flex-start;
            margin-bottom: 20px;
        }
        
        .contact-icon {
            background: var(--primary);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            flex-shrink: 0;
        }
        
        .contact-text h5 {
            margin: 0 0 5px 0;
            color: #FFEB00;
            font-size: 1.8rem;
            font-family: 'Playfair Display', serif;
        }
        
        .contact-text p, .contact-text a {
            margin: 0;
            color: white;
            text-decoration: none;
        }
        
        .social-links {
            display: flex;
            gap: 15px;
            margin-top: auto;
            padding-top: 20px;
        }
        
        .social-link {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #1e1e1e;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }
        
        .social-link:hover {
            background: var(--primary);
            transform: translateY(-3px);
        }
        
        @media (max-width: 992px) {
            :root {
                --form-width: 100%;
            }
            
            .contact-container {
                flex-direction: column;
            }
            
            .contact-info-container {
                width: 100%;
            }
        }

        /* Add this to your existing CSS */
.form-control::placeholder {
    font-size: 1.5rem; /* Increased to 2rem */
    color: white;
    opacity: 1;
}

/* Browser-specific prefixes */
.form-control::-webkit-input-placeholder { /* Chrome/Edge/Safari */
    font-size: 1.5rem;
    color: white;
}
.form-control::-moz-placeholder { /* Firefox 19+ */
    font-size: 1.5rem;
    color: white;
    opacity: 1;
}
.form-control:-ms-input-placeholder { /* IE 10+ */
    font-size: 1.5rem;
    color: white;
}
.form-control:-moz-placeholder { /* Firefox 18- */
    font-size: 1.5rem;
    color: white;
    opacity: 1;
}

/* Adjust input field padding to accommodate larger placeholder text */
.form-control {
    padding-top: 18px;
    padding-bottom: 18px;
}
    </style>
</head>
<body>
    <section class="contact-section">
        <div class="container">
            <div class="section-header">
                <h2>Get In Touch</h2>
                <p>We're here to help and answer any questions you might have. We look forward to hearing from you.</p>
            </div>
            
            <div class="contact-container">
                <div class="contact-form-container">
                    <h3>Send Us a Message</h3>
                    <form id="contactForm" method="post" >
                        <div class="form-group name-field ">
                            <input type="text" class="form-control" name="name" placeholder="Your Name" required>
                        </div>
                        <div class="form-group email-field">
                            <input type="email" class="form-control" name="email" placeholder="Your Email" required>
                        </div>
                        <div class="form-group phone-field">
                            <input type="tel" class="form-control" name="phone" placeholder="Phone Number">
                        </div>
                        <div class="form-group service-field">
                            <select class="form-control" name="service">
                                <option value="">Select Service</option>
                                <option value="Love Astrology">Love Astrology</option>
                                <option value="Career Guidance">Career Guidance</option>
                                <option value="Marriage Prediction">Marriage Prediction</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="form-group message-field">
                            <textarea class="form-control" name="message" placeholder="Your Message" required></textarea>
                        </div>
                        <button type="submit" class="btn-submit">Send Message</button>
                    </form>
                </div>
                
                <div class="contact-info-container">
                    <div class="contact-card">
                        <h4>Contact Information</h4>
                        
                        <div class="contact-detail">
                            <div class="contact-icon">
                                <i class="fa fa-map-marker"></i>
                            </div>
                            <div class="contact-text">
                                <h5>Address</h5>
                                <p>Florida.</p>
                            </div>
                        </div>
                        
                        <div class="contact-detail">
                            <div class="contact-icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="contact-text">
                                <h5>Phone</h5>
                                <p><a href="tel:+18502640999">+1 (850) 264-0999</a></p>
                            </div>
                        </div>
                        
                        <div class="contact-detail">
                            <div class="contact-icon">
                                <i class="fa fa-envelope"></i>
                            </div>
                            <div class="contact-text">
                                <h5>Email</h5>
                                <p><a href="mailto:suryatejpsychic@gmail.com">suryatejpsychic@gmail.com</a></p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="contact-card">
                        <h4>Working Hours</h4>
                        
                        <div class="contact-detail">
                            <div class="contact-icon">
                                <i class="fa fa-clock-o"></i>
                            </div>
                            <div class="contact-text">
                                <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                                <p>Saturday: 10:00 AM - 3:00 PM</p>
                                <p>Sunday: By Appointment Only</p>
                            </div>
                        </div>
                        
                        <div class="social-links">
                            <a href="#" class="social-link"><i class="fa fa-facebook"></i></a>
                            <a href="#" class="social-link"><i class="fa fa-twitter"></i></a>
                            <a href="#" class="social-link"><i class="fa fa-instagram"></i></a>
                            <a href="#" class="social-link"><i class="fa fa-youtube"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include('footer.php'); ?>
</body>
</html>