<!-- testimonials start -->
<a href="contact-us.php"> <img src="images/ban.jpg" style="width:100%;"> </a>
<section >
<!--
<svg x="0px" y="0px" width="1920px" height="45px" viewBox="0 0 1920 45" preserveAspectRatio="none" style="fill:#f4f4f4;">
            <path d="M1920,0c-82.8,0-108.8,44.4-192,44.4c-78.8,0-116.5-43.7-192-43.7 c-77.1,0-115.9,44.4-192,44.4c-78.2,0-114.6-44.4-192-44.4c-78.4,0-115.3,44.4-192,44.4C883.1,45,841,0.6,768,0.6 C691,0.6,652.8,45,576,45C502.4,45,461.9,0.6,385,0.6C306.5,0.6,267.9,45,191,45C115.1,45,78,0.6,0,0.6V45h1920V0z"></path>
    </svg>
	-->
	<div style="background:#170b0e;margin-top:0px;padding:30px 0px;     background: linear-gradient(to right, #ffffff, #e9e3e6);
">
	<div class="container-fluid"style="padding:20px 0px">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
				<div class="testi-heading">
					<h5 style="color:BLACK;	">Testimonials</h5>
				</div>
					<div id="testimonial-slider" class="owl-carousel">
						<div class="testimonial">
							<div class="pic">
								<img src="images/t4.jpg" alt="williamson">
							</div>
							<p class="description">
								
 He is a genuine astrologer with deep knowledge and understanding of different planets on human life.He has the ability to look deeply into different aspects of the planets and their positions in the horoscope.His advice has changed my life for better.I would highly recommend him for a solution to all problems related to love, wealth, career etc.

							</p>
							<img src="images/google_review.jpg" style="width:30%;">
							<h3 class="title">Somiya
								<span class="post"> - Newyork</span>
							</h3>
							
						
						</div>
						<div class="testimonial">
							<div class="pic">
								<img src="images/t6.jpg" alt="krishna">
							</div>
							<p class="description">
							 His guidance, and support to individuals seeking understanding or direction in their lives. Astrology offers self-discovery by revealing our strengths, weaknesses, and life's purpose through birth charts. It also provides insights into relationships, helps with timing major life decisions, supports emotional well-being, offers career guidance, and promotes mindfulness and perspective.


							</p>
															<img src="images/google_review.jpg" style="width:30%;">
															
															<h3 class="title">Aliza
								<span class="post"> - California</span>
							</h3>
							

						</div>
						<div class="testimonial">
							<div class="pic">
								<img src="images/t9.jpg" alt="sunil">
							</div>
							<p class="description">
			Had a wonderful session with Astrologer ji and it was quite satisfying. He listened to me carefully and answered very patiently. Customer support makes life very comfortable as they are always there to support. 




							</p>
							
															<img src="images/google_review.jpg" style="width:30%;">
															
															<h3 class="title">Nihan
								<span class="post"> - Usa</span>
							</h3>
							

						</div>
						<div class="testimonial">
							<div class="pic">
								<img src="images/williamson.jpg" alt="andeson">
							</div>
							<p class="description">
 I was not getting married and felt depressed. One day I Consulted Pandith ji and  took their live sessions. The astrologer told me about the reason I couldn't get married. I quickly took his advice and worked on getting rid of the dosh and to my surprise after 6 months I found my soulmate on the matrimonial website. Right now, I am happily married.

							</p>
													<img src="images/google_review.jpg" style="width:30%;">

							
							<h3 class="title">Anderson
								<span class="post"> - Newyork</span>
							</h3>
							
						</div>
					</div>
				</div>
				<!--
				<div class="col-md-4 col-sm-4 col-xs-12">
					<div class="testi-img">
						<img src="images/problem-solution.jpg" alt="problems-solution" style="width:100%;border: 2px solid #fefefe;box-shadow: 5px 11px 13px #000;">
					</div>
				</div>
				
				-->
			</div>
		</div>
	</div>
	</div>
	

</section>
<!-- testimonials end -->