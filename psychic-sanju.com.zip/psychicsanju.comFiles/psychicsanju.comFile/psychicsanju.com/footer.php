<!-- footer start -->

<div id="footer">

	<div class="container">
		<div class="row">
		<!--
			<div class="col-md-12 col-sm-12 footer-top">
				<h6 class="animated flash infinite">35 Years Experience Astrologer | Guranteed Result</h6>
				<div class="foot-bottom hidden-xs">
					<ul> 
						<li class="foot-call"> <a href=""><span>Call Support : </span></a><a href="tel:<?php echo $linkphone ?>"><?php echo $phone ?></a> </li>
						<li class="foot-call foot-mail"> <a href="mailto:<?php echo $email ?>"><span>Email Support :<?php echo $email ?> </span></a> </li>
						
					</ul>
				</div>
			</div>
			-->
			<div class="footer-box-section">
			
		
				
						<div class="col-md-3 col-sm-12 footer-box">
					<h6>about us </h6>
				<p style="color:white;">
				 However, all those who can not tolerate your highness and bravery or for some other reasons, People of the day impose black magic on others to harm life. There are varieties of magic, the first is white magic and the second is black magic. Both are exact and evil. They really rely especially on the expert hands of black magic.
				</p>
				</div>
				
				
				<div class="col-md-3 col-sm-12 footer-box">
					<h6>Psychic Services </h6>
					
					<ul>
						<li> <a href="get-love-back.php">Get Your Love Back </a> </li>
						<li> <a href="vashikaran-special.php">Vashikaran Mantra Specialist</a> </li>
						<li> <a href="negitive-energy.php">Negitive energy remove</a> </li>
						<li> <a href="spirtual-healing.php">Spirtual-healing</a> </li>
						<li> <a href="black-magic.php">Black Magic Removal</a> </li>
						<li> <a href="love-marriage.php">Love marriage</a> </li>
					</ul>
					
				</div>
						<div class="col-md-3 col-sm-12 footer-box">
					<h6>Quick Links </h6>
					
					<ul>
						<li> <a href="index.php">Home </a> </li>
						<li> <a href="about-us.php">About Psychic </a> </li>
					
						<li> <a href="contact-us.php">Contact Us </a> </li>
					</ul>
					
					
			
				</div>
				
		
				
				<div class="col-md-3 col-sm-12 footer-box">
					<h6>Contact Us </h6>
					
					<div class="foot-contact">
                    	<img src="images/footer-address-icon.png" alt="footer address">
                        <p><span> Address: </span> 
							 <?php echo $address ?>
						</p>
                    </div>
					
					<div class="foot-contact">
                    	<img src="images/footer-email-icon.png" alt="email-address">
                        <p><span> Email Support:</span> 
							<?php echo $email ?>
						</p>
                    </div>
					
					<div class="foot-contact">
                    	<img src="images/footer-phone-icons.png" alt="phone address">
                        <p><span> Phone No: </span>
							<a href="tel:<?php echo $linkphone ?>"style="color:#ffffff"> 
								<?php echo $phone ?>
							</a>
							<br>
						</p>
                    </div>
					
							<!--<ul class="" style="margin-left: 13px;">
					    
             <a href="https://www.facebook.com/">
                  <img src="images/fbb.png" style="width:30px;    border: 2px solid white;
    border-radius: 51px;">
              </a>
             
                  <a href="https://www.instagram.com/">
                       <img src="images/inn.png" style="width:30px;    border: 2px solid white;
    border-radius: 51px;">
                  </a>
                 
             <a href="https://www.youtube.com/"> <img src="images/ytt.png" style="width:30px;    border: 2px solid white;
    border-radius: 51px;"></a>
            </ul>
			
			-->
				</div>
			
			
			</div>
			
			
			
		</div>
	</div>
</div>


<section id="disclaimer">
    <div class="container-fluid">
        <div class="disclaimer">
            <p><b>Disclaimer:</b>Result May Vary From Person To Person.It May Depends Upon Lot Of Factors</p>
			<span style="color:white;">
		The astrology consultation and service provided by Astrologer Hanuman Ji is purely based on his knowledge of astrology and the severity of your situation. There is absolutely no guarantee about the accuracy of the astrology predictions/analysis and solutions that he provide and cannot be held responsible in any way for any adverse consequences.

			</span>       </div>
    </div>
</section>
<!-- footer end -->
</body>	
	 <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<!-- slider js -->
	<script src="js/jssor.slider-27.5.0.min.js" type="text/javascript"></script>
    <script type="text/javascript">jssor_1_slider_init();</script>
	<!-- End slider js -->
    <!-- Bootsnavs -->
    <script src="js/bootsnav.js"></script>
	<!-- Testimonial js -->
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
	<script>
		$(document).ready(function() {
		$("#news-slider").owlCarousel({
			items:
			3,
			itemsDesktop:[1199,2],
			itemsDesktopSmall:[980,2],
			itemsMobile:[600,1],
			pagination:false,
			navigationText:false,
			autoPlay:true
		});
	});
	</script>
	<script>
	$(document).ready(function(){
    $("#testimonial-slider").owlCarousel({
        items:3,
        itemsDesktop:[1000,1],
        itemsDesktopSmall:[979,1],
        itemsTablet:[768,1],
        pagination:false,
        navigation:true,
        navigationText:["",""],
        autoPlay:true
    });
});
</script>
<!--Start of Tawk.to Script-->

<!--End of Tawk.to Script-->
</html>