	<section class="serv">
	<center> 	<div class="serv-heading visible-xs">
		<h5><?php echo $phone ?></h5>
	</div>
	</center>
	<svg x="0px" y="0px" width="1920px" height="45px" viewBox="0 0 1920 45" preserveAspectRatio="none" style="fill:#f9fbfd;">
            <path d="M1920,0c-82.8,0-108.8,44.4-192,44.4c-78.8,0-116.5-43.7-192-43.7 c-77.1,0-115.9,44.4-192,44.4c-78.2,0-114.6-44.4-192-44.4c-78.4,0-115.3,44.4-192,44.4C883.1,45,841,0.6,768,0.6 C691,0.6,652.8,45,576,45C502.4,45,461.9,0.6,385,0.6C306.5,0.6,267.9,45,191,45C115.1,45,78,0.6,0,0.6V45h1920V0z"></path>
    </svg>
	<div style="background:#f9fbfd;background-size:cover;margin-top:-8px;padding:30px 0px">	  
		<div class="container-fluid">
			<div class="container">
			<div class="testi-heading">
					<h5>Special Pooja Service</h5>
					<p style="color:black;"><strong>disclaimer:</strong>Results may vary from person to person,It depends on lot of factors</p>
				</div>
				
				<div class="row">
				<div class="col-md-12">
					 <div id="news-slider" class="owl-carousel">
                    <div class="post-slide">
                        <div class="post-img">
                            <a href=""><img src="images/l6.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <h3 class="post-title"><a href="chat-reading.php">CHART READING </a></h3>
                            <p>
							A Tarot Card Reading can help guide you through your troubled emotions and clouded thoughts, by offering a reflection of your past, present and possible future and showing you a fresh 
							</p>
                           <a href="chat-reading.php" class="read-more">read more <i class="fas fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>
					
					 <div class="post-slide">
                        <div class="post-img">
                            <a href=""><img src="images/l1.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <h3 class="post-title"><a href="kalimata-pooja.php">KALI MATA POOJA  </a></h3>
                            <p>
							The health and prosperity is preserved throughout the entire life. Lifelong protections awarded for you and your loved ones with blessing religious GODDESS KALIMATHA by our psychic sidhu ji.
							</p>
                           <a href="kalimata-pooja.php" class="read-more">read more <i class="fas fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>
					
					
                    <div class="post-slide">
                        <div class="post-img">
                            <a href=""><img src="images/l2.jpg" alt=""></a>
                        </div>
                       <div class="post-content">
                            <h3 class="post-title"><a href="#">LORD RADHAKRISHNA   </a></h3>
                            <p>
						Krishna Puja is performed to attain love, happiness, finance, business, health and for fulfilling various others desires.feel free to contact astrologer sidhu ji for all god poojas
							</p>
                           <a href="radhakrishna-pooja.php" class="read-more">read more <i class="fas fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>
					<div class="post-slide">
                        <div class="post-img">
                            <a href=""><img src="images/l3.jpg" alt=""></a>
                        </div>
                          <div class="post-content">
                            <h3 class="post-title"><a href="">LORD HANUMAN POOJA    </a></h3>
                            <p>
							Hanuman Puja makes it possible to become successful in attaining your objectives. Hanuman Puja enhances your physical and mental wellbeing radically. Hanuman Puja makes it possible to like 
							</p>
                           <a href="hanuman-pooja.php" class="read-more">read more <i class="fas fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>
                    <div class="post-slide">
                        <div class="post-img">
                            <a href=""><img src="images/l4.jpg" alt=""></a>
                        </div>
                          <div class="post-content">
                            <h3 class="post-title"><a href="kalimata-pooja.php">KALI MATA POOJA   </a></h3>
                            <p>
							The health and prosperity is preserved throughout the entire life. Lifelong protections awarded for you and your loved ones with blessing religious GODDESS contact us today
							</p>
                           <a href="kalimata-pooja.php" class="read-more">read more <i class="fas fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>
					<div class="post-slide">
                        <div class="post-img">
                            <a href=""><img src="images/l5.jpg" alt=""></a>
                        </div>
                          <div class="post-content">
                            <h3 class="post-title"><a href="business-problem.php">BUSINESS PROBLEM    </a></h3>
                            <p>
							You can change the fate of your business with the help of astrology. Consulting the best astrologer might help you in taking your business to the next level. If you are in search of the right
							</p>
                           <a href="business-problem.php" class="read-more">read more <i class="fas fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>
                 
                </div>
				</div>
				</div>
			</div>
		</div> 
		</div>
		
		<svg x="0px" y="0px" width="1920px" height="45px" viewBox="0 0 1920 45" preserveAspectRatio="none" style="fill: #f4f4f4;background:#f4f4f4">
            <path d="M1920,0c-82.8,0-108.8,44.4-192,44.4c-78.8,0-116.5-43.7-192-43.7 c-77.1,0-115.9,44.4-192,44.4c-78.2,0-114.6-44.4-192-44.4c-78.4,0-115.3,44.4-192,44.4C883.1,45,841,0.6,768,0.6 C691,0.6,652.8,45,576,45C502.4,45,461.9,0.6,385,0.6C306.5,0.6,267.9,45,191,45C115.1,45,78,0.6,0,0.6V45h1920V0z"></path>
          </svg>
		  </div>
	</section>
	<!-- about section end -->
	
	
	
	
	
		<div style="background:#f9fbfd;background-size:cover;margin-top:-8px;padding:30px 0px">	 
	<center> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3017.448592043073!2d-73.90138042362588!3d40.86202862841693!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c2f3878de7e093%3A0x34a3cededcdeb511!2s114%20E%20Fordham%20Rd%2C%20Bronx%2C%20NY%2010468%2C%20USA!5e0!3m2!1sen!2sin!4v1711115447597!5m2!1sen!2sin" width="90%" height="250" style="border-radius:50px 0px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
		</center>
		<div class="container-fluid">
			<div class="container">
			<div class="testi-heading">
					<h5>Featured  Service</h5>
					<p style="color:black;"><strong>disclaimer:</strong>Results may vary from person to person,It depends on lot of factors</p>
				</div>
				<div class="row">
				
				<div class="col-md-4">
                    <div class="post-slide">
                        <div class="post-img">
                            <a href=""><img src="images/2.jpg" alt=""></a>
                        </div>
                        <div class="post-content">
                            <h3 class="post-title"><a href="love-marriage.php">LOVE MARRIAGE </a></h3>
                            <p>
							Our Best psychic sanju provides counseling and also a thorough analysis of birth chart that would save your marriage from falling apart. Rituals and experience of our astrologer sorting marriage issues can work wonders for your relationship
							</p>
                           <a href="love-marriage.php" class="read-more">read more <i class="fas fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>                 
                    </div>
					
						<div class="col-md-4">
                    <div class="post-slide">
                        <div class="post-img">
                            <a href="spirtual-healing.php"><img src="images/4.jpg" alt=""></a>
                        </div>
                       <div class="post-content">
                            <h3 class="post-title"><a href="#">SPIRITUAL HEALER  </a></h3>
                            <p>
							Psychic sanju is highly experienced and has helped many of his clients in achieving the best results through spiritual healing. He helps you to process your bad memories and aids you in moving on in life. He heals your traumas and makes you ready to face
							</p>
                           <a href="spirtual-healing.php" class="read-more">read more <i class="fas fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>
                    </div>
					
						<div class="col-md-4">
					<div class="post-slide">
                        <div class="post-img">
                            <a href=""><img src="images/5.jpg" alt=""></a>
                        </div>
                          <div class="post-content">
                            <h3 class="post-title"><a href="#">EXTRA MARITAL AFFAIR  </a></h3>
                            <p>
						Many reasons may responsible for break up or Divorce. Our Best psychic sanju provides counseling and also a thorough analysis of birth chart that would save your marriage from falling apart. Rituals and experience of our astrologer sorting marriage
							</p>
                           <a href="get-love-back.php" class="read-more">read more <i class="fas fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>					
                    </div>
					
						<div class="col-md-4">
                    <div class="post-slide">
                        <div class="post-img">
                            <a href=""><img src="images/img-1.jpg" alt=""></a>
                        </div>
                          <div class="post-content">
                            <h3 class="post-title"><a href="#">FAMILY DISPUTES  </a></h3>
                            <p>
							Forget about all the issues you have and rest assured you can solve all relationship problem with expert’s intervention and guidance.He is expert in solving Family Disputes.
							</p>
                           <a href="couple-disputes.php" class="read-more">read more <i class="fas fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>
                    </div>
					
						<div class="col-md-4">
					<div class="post-slide">
                        <div class="post-img">
                            <a href=""><img src="images/img-2.jpg" alt=""></a>
                        </div>
                          <div class="post-content">
                            <h3 class="post-title"><a href="#">BRING LOVE BACK  </a></h3>
                            <p>
							sanju ji whips up some quick and long-standing astrological hacks to comfort the suffering and bring back happiness into their lives by bringing loved one's back.
							</p>
                           <a href="love-astrologer.php" class="read-more">read more <i class="fas fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>
                    </div>
					
						<div class="col-md-4">
                    <div class="post-slide">
                        <div class="post-img">
                            <a href=""><img src="images/img-3.jpg" alt=""></a>
                        </div>
                           <div class="post-content">
                            <h3 class="post-title"><a href="#">PSYCHIC READING  </a></h3>
                            <p>
							Psychic Reading is one of the services that are extended to people with immense psychic power and understanding to give a perfect solution to solve the problem.
							</p>
                           <a href="chat-reading.php" class="read-more">read more <i class="fas fa-long-arrow-alt-right"></i></a>
                        </div>
                    </div>					
                    </div>
					
                </div>
				</div>
				</div>
			</div>
		</div> 
		</div>
		
							<img src="images/6.gif" style="width:100%;">
