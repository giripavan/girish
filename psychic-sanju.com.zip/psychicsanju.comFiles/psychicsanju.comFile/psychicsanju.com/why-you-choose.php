<!-- why you choose us start -->
	<div class="main-services-shivanand astrology-services-location"style="padding:30px 0px;box-shadow: 9px -2px 17px #000;box-shadow: 9px -2px 17px #0000;">
	<div class="main-content-shivanand">
		<div class="content-para-shivanand">
			<h2> <span> Astrology Services </span> <span>Newyork</span> </h2>
			
			<ul style="list-style-type:none">
			<li> <a href="astrologer-in-bordeaux.php">Astrologer In Newyork </a> </li>
					
                            <li> <a href="astrologer-in-texas.php">Astrologer In Texas </a> </li>
						<li> <a href="astrologer-in-california.php">Astrologer In New York </a> </li>
						<li> <a href="astrologer-in-florida.php">Astrologer In Florida </a> </li>
						<li> <a href="astrologer-in-arizona.php">Astrologer In Arizona </a> </li>
						<li> <a href="astrologer-in-newyork.php">Astrologer In California </a> </li>
						<li> <a href="astrologer-in-illinois.php">Astrologer In illinois </a> </li>
						<li> <a href="astrologer-in-newjersey.php">Astrologer In New Jersey </a> </li>
			</ul>
			
				<ul style="list-style-type:none">
			<li> <a href="astrologer-in-bordeaux.php">Astrologer In Newyork </a> </li>
					
                            <li> <a href="astrologer-in-texas.php">Astrologer In Texas </a> </li>
						<li> <a href="astrologer-in-california.php">Astrologer In New York </a> </li>
						<li> <a href="astrologer-in-florida.php">Astrologer In Florida </a> </li>
						<li> <a href="astrologer-in-arizona.php">Astrologer In Arizona </a> </li>
						<li> <a href="astrologer-in-newyork.php">Astrologer In California </a> </li>
						<li> <a href="astrologer-in-illinois.php">Astrologer In illinois </a> </li>
						<li> <a href="astrologer-in-newjersey.php">Astrologer In New Jersey </a> </li>
			</ul>
			
			
				<ul style="list-style-type:none">
			<li> <a href="astrologer-in-bordeaux.php">Astrologer In Newyork </a> </li>
					
                            <li> <a href="astrologer-in-texas.php">Astrologer In Texas </a> </li>
						<li> <a href="astrologer-in-california.php">Astrologer In New York </a> </li>
						<li> <a href="astrologer-in-florida.php">Astrologer In Florida </a> </li>
						<li> <a href="astrologer-in-arizona.php">Astrologer In Arizona </a> </li>
						<li> <a href="astrologer-in-newyork.php">Astrologer In California </a> </li>
						<li> <a href="astrologer-in-illinois.php">Astrologer In illinois </a> </li>
						<li> <a href="astrologer-in-newjersey.php">Astrologer In New Jersey </a> </li>
			</ul>
			<div class="location-phone">
				<a href="tel:<?php echo $linkphone ?>"> <span> ask question? </span> <?php echo $phone ?></a><br>
			</div>
		</div>
	</div>

</div>
	<!-- why you choose us end -->
<div class="clearfix"></div>	