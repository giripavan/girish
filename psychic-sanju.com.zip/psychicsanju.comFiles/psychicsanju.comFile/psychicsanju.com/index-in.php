	<section class="abt" style="background: linear-gradient(to top, #FF4B2B, #FF416C);
    /* background: li">
		<div class="container-fluid">
			<div class="container">
				<div class="row">
					<div class="about_shiva">
						<!-- <div class="global_heading"> -->
							<!-- <h1>Welcome To Ram baba's Astrology</h1> -->
							<!-- <center><img src="images/underline.png" alt="Underline"></center> -->
							<!-- <!-- <span>Get Famous and Trusted <strong>Astrologers name Ji ’s</strong> Services in <strong>California,</strong> <strong>USA</strong></span></h1> <img src="images/underline.png" alt="Underline"> --> 
						<!-- </div> -->
						<div class="col-md-6 col-sm-8 col-xs-12">
							<div class="about_shiva_box">
							  <div class="about_shiva_cont">
							       <h1 style="color:yellow;">Who is Psychic Sanju? </h1>
								<div class="about_shiva_cont_head" title="LETS TALK ABOUT"> <span style="color:yellow;">No 1 Astrologer in USA</span>
								 
							
                                          
								  <p align="justify">Psychic Sanju is a famous and outstanding astrologer in New York, renowned for his extraordinary skills in astrology. Born into an astrological family, he began his career at a young age. With his exceptional knowledge, he has traveled to many countries and gained a large following of loyal clients. His unique approach to astrology and dedication to serving people set him apart as a distinguished and trusted advisor.


</p>

								</div>
								<div class="about_shiva_c_row" title="Remove Bad Luck IN 48hrs"> <span>REMOVE BAD LUCK IN 48hrs</span>
    								  <p align="justify">Psychic Sanju gives <b>Negative Energy Removal Specialist In Newyork</b> you an answer for
									  all your problems in your life, even if you are moving in an appropriate route without worrying about the life of any body.
									  However, all those who can not tolerate your highness and bravery or for some other reasons, People of the day impose black magic on
									  others to harm life. There are varieties of magic, the first is white magic and the second is black magic. Both are exact and evil. 
									  They really rely especially on the expert hands of black magic.</p>
								</div>
								<div class="about_shiva_c_row" title="HOW TO GET YOUR LOVE BACK IN 9 DAYS"> <span>HOW TO GET YOUR LOVE BACK IN 9 DAYS </span>
								  <p align="justify">Love separation is the cause of distraction from work, avoiding concentration from work and many other problems 
								  can enter in your life. Astrology has the solution of this sensitive love problem. Love problem solution in Newyork astrology is one 
								  of the services of astrology that can make you happy again. If you are going through lost love other love related problems and wants 
								  love problem solutions or lost loved back then you need to take help of specialist astrologer Psychic Sanju ji</p>
								</div>
								<div class="about_shiva_c_row" title="WIN YOUR PARTNER HEART? DON'T CRY or BEG"> <span>WIN YOUR PARTNER HEART? DON'T CRY or BEG</span>
								  <p align="justify">Did you got break up or your partner has left you?Astrologer  will help you repair your relationship and rebuild yourself
								  after a broken relationship.<a href="contact-us.php">CLICK HERE</a></p>
								</div>
							  </div>
							</div>
						</div>
						<div class="col-md-6 col-sm-4 col-xs-12">
						
						<img src="images/about_27.jpg" style="width:100%;border-radius:10px;">
							<?php
							//include('contact-in.php');
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>