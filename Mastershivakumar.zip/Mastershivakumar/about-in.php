<section style="background-color: #0b0623; color: white; padding: 60px 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 30px;">
  
  <!-- Left Column: Moon + Experience -->
  <div style="flex: 1; max-width: 20%; text-align: center;">
    <img src="images/moon.jpg" alt="Moon" style="width: 100px; margin-bottom: 30px;">
    <div style="background-color: #2e2b5f; padding: 20px; border-radius: 8px; width: 120px; margin: 0 auto;">
      <h2 style="margin: 0; font-size: 32px;">16 +</h2>
      <p style="margin: 0;">Year Experience</p>
    </div>
  </div>

  <!-- Center Column: Astro Woman Image -->
  <div style="flex: 1; max-width: 30%; position: relative;">
    <img src="images/imok.png" alt="Astrology Woman" style="width: 100%; border-radius: 12px;">
    <!-- Tarot Card Overlap (Optional) -->
  </div>

  <!-- Right Column: Text Content -->
  <div style="flex: 1; max-width: 40%;">
  <h2 style="color: #f1c40f; font-weight: bold; font-size: 2.9rem;">ABOUT MASTER SHIVAKUMAR</h2>

  <p style="line-height: 1.8; font-size: 16px; margin-bottom: 16px;">
    Master Shivakumar is a renowned astrologer with over 16 years of experience in guiding individuals through life’s toughest challenges. His deep-rooted knowledge in Vedic astrology, palmistry, numerology, and black magic removal has earned him global recognition and the trust of thousands.
  </p>

  <p style="line-height: 1.8; font-size: 16px; margin-bottom: 16px;">
    Whether you're struggling with love issues, family disputes, business setbacks, or health problems, Astrologer Shivakumar provides accurate predictions and personalized remedies rooted in ancient wisdom. His solutions are simple, effective, and designed to bring lasting relief.
  </p>

  <p style="line-height: 1.8; font-size: 16px;">
    Known for his honesty and compassionate nature, Master Shivakumar treats every client with care and confidentiality. His mission is to eliminate negativity, restore balance, and help you achieve happiness, success, and spiritual growth in life.
  </p>
</div>


</section>
<style>
   /* Import Google Font (optional) */
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap');

  /* Apply globally */
  section {
    font-family: 'Poppins', sans-serif;
  }

  /* You can override specific elements if needed */
  section h1,
  section p {
    font-family: 'Poppins', sans-serif;
  }
  @media (max-width: 768px) {
  section {
    flex-direction: column !important;
    align-items: center !important;
  }

  section > div {
    max-width: 100% !important;
    flex: 1 1 100% !important;
    text-align: center !important;
  }

  section h1 {
    font-size: 26px !important;
  }

  section p {
    font-size: 15px !important;
    padding: 0 10px;
  }

  section img {
    width: 100% !important;
    max-width: 300px;
    height: auto;
  }

  /* Change order on mobile: Text first, then center image, then left moon */
  section > div:nth-child(3) {
    order: 1;
  }

  section > div:nth-child(2) {
    order: 2;
  }

  section > div:nth-child(1) {
    order: 3;
  }
}

</style>
<!-- JavaScript Counter Animation -->
<script>
  const counters = document.querySelectorAll('.counter');
  let animated = false;

  function animateCounters() {
    counters.forEach(counter => {
      const updateCount = () => {
        const target = +counter.getAttribute('data-target');
        const count = +counter.innerText;
        const increment = Math.ceil(target / 100); // change speed here

        if (count < target) {
          counter.innerText = count + increment;
          setTimeout(updateCount, 20);
        } else {
          counter.innerText = target + " +";
        }
      };
      updateCount();
    });
  }

  // Trigger on scroll into view
  window.addEventListener('scroll', () => {
    const section = document.getElementById('stats-section');
    const sectionTop = section.getBoundingClientRect().top;
    const windowHeight = window.innerHeight;

    if (sectionTop < windowHeight && !animated) {
      animateCounters();
      animated = true;
    }
  });
</script>
<style>
  @keyframes spin {
    0% { transform: translate(-50%, -50%) rotate(0deg); }
    100% { transform: translate(-50%, -50%) rotate(360deg); }
  }
</style>
<section style="background-color: rgb(52, 3, 50); padding: 60px 20px;">
  <div style="max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 40px;">

    <!-- LEFT COLUMN -->
    <div style="display: flex; flex-direction: column; gap: 40px; flex: 1; min-width: 250px;">
      <div class="card-box" style="background: skyblue;">
        <img src="images/1k.png" alt="Kundli Dosha" class="card-img">
        <h3 style="color:rgb(15, 13, 5);">KUNDLI DOSHA</h3>
        <p>Kundli Dosh can create unexpected hurdles in relationships, career, and health.</p>
      </div>
      <div class="card-box" style="background: skyblue;">
        <img src="images/2b.png" alt="Birth Journal" class="card-img">
        <h3 style="color:rgb(15, 13, 5);">BIRTH JOURNAL</h3>
        <p>A birth journal (Janma Kundli) is created using your birth date, time, and place.</p>
      </div>
    </div>

    <!-- CENTER ROTATING IMAGE -->
    <div style="position: relative; width: 500px; height: 500px; display: flex; align-items: center; justify-content: center;">
      <img src="images/ro12.png" alt="Rotating Image" style="position: absolute; top: 50%; left: 50%; width: 100%; height: 120%; object-fit: contain; animation: spin 20s linear infinite; transform: translate(-50%, -50%); z-index: 1;">
      <img src="images/sop.png" alt="Overlay Image" style="position: absolute; top: 75%; left: 53%; transform: translate(-50%, -50%); max-height: 90%; z-index: 2;">
    </div>

    <!-- RIGHT COLUMN -->
    <div style="display: flex; flex-direction: column; gap: 40px; flex: 1; min-width: 250px;">
      <div class="card-box" style="background: skyblue;">
        <img src="images/3t.png" alt="Tarot Reading" class="card-img">
        <h3 style="color:rgb(15, 13, 5);">TAROT READING</h3>
        <p>Tarot card reading is a powerful tool for gaining clarity on life’s questions.</p>
      </div>
      <div class="card-box" style="background: skyblue;">
        <img src="images/4n.png" alt="Numerology Tips" class="card-img">
        <h3 style="color:rgb(15, 13, 5);">NUMEROLOGY TIPS</h3>
        <p>Numerology reveals how numbers influence your personality and destiny.</p>
      </div>
    </div>

  </div>
</section>

<!-- Style: Card Design + Animation -->
<style>
  .card-box {
    background: white;
    color: black;
    border-radius: 20px;
    padding: 30px;
    text-align: center;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }

  .card-box:hover {
    transform: translateY(-10px) scale(1.03);
    box-shadow: 0 8px 20px rgba(255, 255, 255, 0.2);
  }

  .card-img {
    height: 80px;
    margin-bottom: 20px;
    transition: transform 0.3s ease;
  }

  .card-box:hover .card-img {
    transform: scale(1.1);
  }

  @media (max-width: 768px) {
    .card-img {
      height: 60px !important;
      width: 100px !important;
    }

    .card-box {
      padding: 30px;
    }
  }

  @keyframes spin {
    0% { transform: translate(-50%, -50%) rotate(0deg); }
    100% { transform: translate(-50%, -50%) rotate(360deg); }
  }
</style>




