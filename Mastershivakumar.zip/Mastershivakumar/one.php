<!-- Zodiac Section with Auto-Slider -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />

<section style="padding: 60px 20px; background: #fff; font-family: sans-serif; text-align: center;">
  <!-- Stats -->
  <div style="display: flex; justify-content: center; flex-wrap: wrap; gap: 50px; margin-bottom: 40px;">
    <div><div style="font-size: 40px; font-weight: bold; color: #0a223d;">50+</div><div>Qualified Astrologers</div></div>
    <div><div style="font-size: 40px; font-weight: bold; color: #0a223d;">120+</div><div>Success Horoscope</div></div>
    <div><div style="font-size: 40px; font-weight: bold; color: #0a223d;">60+</div><div>Type Of Horoscopes</div></div>
    <div><div style="font-size: 40px; font-weight: bold; color: #0a223d;">4k</div><div>Happy Clients</div></div>
  </div>

  <h2 style="color: #ff8040; font-size: 32px; font-weight: bold; margin-bottom: 10px;">Choose Your Zodiac Sign</h2>
  <p style="font-size: 16px; color: #444; max-width: 800px; margin: 0 auto 40px;">
    Astrology, type of divination that involves the forecasting of earthly and human events through the observation and interpretation of the fixed stars.
  </p>

  <!-- Swiper -->
  <div class="swiper zodiacSwiper" style="padding: 20px 0;">
    <div class="swiper-wrapper">
  <div class="swiper-slide"><img src="images/pisces.png" alt="Pisces" class="zodiac-img" />Pisces<br><small>21 Feb - 20 Mar</small></div>
  <div class="swiper-slide"><img src="images/z1.png" alt="Aries" class="zodiac-img" />Aries<br><small>21 Mar - 19 Apr</small></div>
  <div class="swiper-slide"><img src="images/taurus.png" alt="Taurus" class="zodiac-img" />Taurus<br><small>20 Apr - 20 May</small></div>
  <div class="swiper-slide"><img src="images/gemini.png" alt="Gemini" class="zodiac-img" />Gemini<br><small>21 May - 20 Jun</small></div>
  <div class="swiper-slide"><img src="images/cancer.png" alt="Cancer" class="zodiac-img" />Cancer<br><small>21 Jun - 22 Jul</small></div>
  <div class="swiper-slide"><img src="images/leo.png" alt="Leo" class="zodiac-img" />Leo<br><small>23 Jul - 22 Aug</small></div>
  <div class="swiper-slide"><img src="images/virgo.png" alt="Virgo" class="zodiac-img" />Virgo<br><small>23 Aug - 22 Sep</small></div>
  <div class="swiper-slide"><img src="images/libra.png" alt="Libra" class="zodiac-img" />Libra<br><small>23 Sep - 22 Oct</small></div>
  <div class="swiper-slide"><img src="images/scorpia.png" alt="Scorpio" class="zodiac-img" />Scorpio<br><small>23 Oct - 21 Nov</small></div>
  <div class="swiper-slide"><img src="images/sagittarius.png" alt="Sagittarius" class="zodiac-img" />Sagittarius<br><small>22 Nov - 21 Dec</small></div>
  <div class="swiper-slide"><img src="images/capricorn.png" alt="Capricorn" class="zodiac-img" />Capricorn<br><small>22 Dec - 19 Jan</small></div>
  <div class="swiper-slide"><img src="images/aquarius.png" alt="Aquarius" class="zodiac-img" />Aquarius<br><small>20 Jan - 18 Feb</small></div>
</div>

  </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
<script>
  new Swiper('.zodiacSwiper', {
    slidesPerView: 4,
    spaceBetween: 30,
    loop: true,
    autoplay: {
      delay: 3000,
      disableOnInteraction: false,
    },
    breakpoints: {
      1024: { slidesPerView: 4 },
      768: { slidesPerView: 2 },
      320: { slidesPerView: 1 },
    },
  });
</script>

<style>
  .swiper-slide {
    background: #fff;
    border-bottom: 5px solid #ff8040;
    border-radius: 10px;
    padding: 30px 20px;
    font-weight: bold;
    color: #0a223d;
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
    font-size: 18px;
  }
  .swiper-slide small {
    display: block;
    margin-top: 8px;
    color: #444;
    font-size: 14px;
    font-weight: normal;
  }
  .zodiac-img {
  width: 60px;
  height: 60px;
  object-fit: contain;
  margin-bottom: 10px;
}
  .swiper-slide:hover {
    transform: scale(1.05);
    transition: transform 0.3s;
  }
  @media (max-width: 768px) {
    .swiper-slide {
      font-size: 16px;
    }
  }
</style>
