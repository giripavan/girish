<!DOCTYPE HTML>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="de">  <!--<![endif]-->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Best Indian Astrologer in Winnipeg</title>

<?php
include('header.php');
?>


<!-- service section about matter -->
<section style="padding: 80px 0; position: relative; overflow: hidden; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);">
  <!-- Animated Stars Background -->
  <div class="stars" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 0;">
    <div style="position: absolute; width: 2px; height: 2px; background: white; border-radius: 50%;" class="star" v-for="n in 100" :key="n" 
         :style="{
           top: Math.random() * 100 + '%',
           left: Math.random() * 100 + '%',
           animation: `twinkle ${Math.random() * 5 + 3}s infinite alternate`
         }"></div>
  </div>
  
  <!-- Floating Planets -->
  <div style="position: absolute; width: 150px; height: 150px; border-radius: 50%; background: radial-gradient(circle, rgba(255,215,0,0.2) 0%, transparent 70%); 
              top: 20%; left: 10%; animation: float 15s ease-in-out infinite;"></div>
  <div style="position: absolute; width: 100px; height: 100px; border-radius: 50%; background: radial-gradient(circle, rgba(138,43,226,0.2) 0%, transparent 70%); 
              bottom: 15%; right: 15%; animation: float 12s ease-in-out infinite reverse;"></div>

  <div class="container-fluid">
    <div class="container">
      <div class="row" style="position: relative; z-index: 2;">
        <div class="col-md-8 col-sm-8 col-xs-12">
          <div style="margin-bottom: 40px;">
            <h2 style="color: #ffd700; font-size: 36px; font-weight: 300; letter-spacing: 1px; margin-bottom: 15px; position: relative; display: inline-block;">
              Best Indian Astrologer In Winnipeg
              <span style="position: absolute; bottom: -10px; left: 0; width: 80px; height: 3px; background: linear-gradient(90deg, #ffd700, transparent);"></span>
            </h2>
          </div>
          
          <div style="color: rgba(255,255,255,0.9); line-height: 1.8; font-size: 16px;">
            <p style="margin-bottom: 25px;">
              Master Shivakumar, the <a href="" style="color: #ffd700; text-decoration: none; font-weight: 600;">Famous astrologer in Winnipeg</a>, offers numerous astrology services including Daily Horoscope, Love Horoscope, Kundli Manufacturing, Horoscope Parties, Vashikaran, Vaastu for the Home, <a href="https://en.wikipedia.org/wiki/Numerology" style="color: #ffd700; text-decoration: none; font-weight: 600;">Numerology</a>, and more. Clients from across the globe (United States, United Kingdom, India, Canada, Australia) trust his astrological guidance.
            </p>
            
            <h3 style="color: #ffd700; font-size: 24px; margin: 30px 0 15px; font-weight: 400;">Master Shivakumar - Indian Astrologer in Canada</h3>
            
            <p style="margin-bottom: 25px;">
              He has blessed thousands with his knowledge, considering astrology a divine gift rather than a profession. A devoted follower of Lord Shiva, he provides his sacred services without fees.
            </p>
            
            <p>
              Meet him personally in Winnipeg to discuss your concerns (by appointment only). Phone consultations are not available.
            </p>
          </div>
        </div>
        
        <div class="col-md-4 col-sm-4 col-xs-12">
          <!-- Contact Form Container with Glow Effect -->
          <div style="background: rgba(26, 26, 46, 0.7); border-radius: 15px; padding: 30px; backdrop-filter: blur(10px); 
                      border: 1px solid rgba(255, 215, 0, 0.3); box-shadow: 0 0 30px rgba(255, 215, 0, 0.1);">
            <h3 style="color: #ffd700; font-size: 22px; margin-bottom: 20px; text-align: center;">Contact in Winnipeg</h3>
            
            <!-- Animated Location Pin -->
            <div style="text-align: center; margin-bottom: 20px; position: relative;">
              <div style="font-size: 40px; color: #ffd700; animation: pulse 2s infinite;">
                📍
              </div>
              <div style="position: absolute; width: 40px; height: 40px; background: rgba(255, 215, 0, 0.3); 
                          border-radius: 50%; top: 50%; left: 50%; transform: translate(-50%, -50%); 
                          animation: ripple 2s infinite;"></div>
            </div>
            
            <!-- Contact Info -->
            <div style="color: white; margin-bottom: 20px;">
              <p style="margin-bottom: 10px;"><i class="fa fa-map-marker" style="color: #ffd700; margin-right: 10px;"></i> Astrology Center, Winnipeg, MB</p>
              <p style="margin-bottom: 10px;"><i class="fa fa-phone" style="color: #ffd700; margin-right: 10px;"></i> +1 (438)-535-3334</p>
              <p><i class="fa fa-envelope" style="color: #ffd700; margin-right: 10px;"></i> mastershivakumar82@gmail.com</p>
            </div>
            
            <!-- Appointment Button -->
            <button style="background: linear-gradient(135deg, #ffd700 0%, #ff8c00 100%); border: none; color: #1a1a2e; 
                        padding: 12px 25px; border-radius: 30px; font-weight: 600; width: 100%; cursor: pointer;
                        transition: all 0.3s; box-shadow: 0 5px 15px rgba(255, 215, 0, 0.3);"
                    onmouseover="this.style.transform='translateY(-3px)'; this.style.boxShadow='0 8px 20px rgba(255, 215, 0, 0.4)'"
                    onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 5px 15px rgba(255, 215, 0, 0.3)'">
              Book Appointment
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <style>
    @keyframes twinkle {
      0% { opacity: 0.2; }
      100% { opacity: 1; }
    }
    @keyframes float {
      0%, 100% { transform: translateY(0) translateX(0); }
      50% { transform: translateY(-20px) translateX(10px); }
    }
    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.1); }
      100% { transform: scale(1); }
    }
    @keyframes ripple {
      0% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
      100% { transform: translate(-50%, -50%) scale(2.5); opacity: 0; }
    }
  </style>
</section>
<section style="padding: 60px 0; background-color: #fff;">
  <div class="container">
    <div class="text-center mb-5">
      <h2 style="color: #062241; font-weight: bold;">Why Choose Us</h2>
      <p style="color: #465168; max-width: 700px; margin: auto;">
        With years of experience and thousands of satisfied clients, we offer deeply personalized astrology and spiritual solutions to help you achieve peace, clarity, and success in life.
      </p>
    </div>

    <div class="row text-center">
      <div class="col-md-4 mb-4">
        <div style="padding: 30px; border: 1px solid #eee; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
          <i class="fas fa-star" style="font-size: 36px; color: #ff7a30;"></i>
          <h5 style="margin-top: 15px; color: #062241;">Trusted Expertise</h5>
          <p style="color: #465168;">Certified astrologer with 15+ years of experience in solving real-life problems through Vedic and modern methods.</p>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div style="padding: 30px; border: 1px solid #eee; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
          <i class="fas fa-hand-holding-heart" style="font-size: 36px; color: #ff7a30;"></i>
          <h5 style="margin-top: 15px; color: #062241;">Personalized Solutions</h5>
          <p style="color: #465168;">Every session is tailored to your birth chart and current planetary conditions for accurate insights and remedies.</p>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div style="padding: 30px; border: 1px solid #eee; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
          <i class="fas fa-comments" style="font-size: 36px; color: #ff7a30;"></i>
          <h5 style="margin-top: 15px; color: #062241;">24/7 Support</h5>
          <p style="color: #465168;">Have a question or emergency? We’re just a message away. Get guidance whenever you need it most.</p>
        </div>
      </div>
    </div>
  </div>
</section>
<?php
include('testimonials.php');
?>

<?php
include('footer.php');
?>
