<!DOCTYPE HTML>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="de">  <!--<![endif]-->
<head>
<!-- Event snippet for Submit lead form conversion page -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">


	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
 <title>Astrologer in Canada</title>
    
<?php
	include('header.php');
	?>
	
 <div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:980px;height:510px;overflow:hidden;visibility:hidden;">
        <!-- Loading Screen -->
        <div data-u="loading" class="jssorl-009-spin" style="position:absolute;top:0px;left:0px;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
            <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="../svg/loading/static-svg/spin.svg" alt="Astrologer in " />
        </div>
        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:510px;overflow:hidden;">
           
<div>
                <img data-u="image" src="images/sb1.jpg" alt="spirtual healer"/>
            </div>
		   <div>
                <img data-u="image" src="images/sb2.jpg" alt="Get love Back"/>
            </div>
            <div>
                <img data-u="image" src="images/sb3.jpg" alt="husband wife disputes"/>
            </div>
            
		
     
        </div>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb053" style="position:absolute;bottom:12px;right:12px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
            <div data-u="prototype" class="i" style="width:16px;height:16px;">
                <svg viewBox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <path class="b" d="M11400,13800H4600c-1320,0-2400-1080-2400-2400V4600c0-1320,1080-2400,2400-2400h6800 c1320,0,2400,1080,2400,2400v6800C13800,12720,12720,13800,11400,13800z"></path>
                </svg>
            </div>
        </div>
        <!-- Arrow Navigator -->
        <div data-u="arrowleft" class="jssora093" style="width:50px;height:50px;top:0px;left:30px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
            <svg viewBox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <circle class="c" cx="8000" cy="8000" r="5920"></circle>
                <polyline class="a" points="7777.8,6080 5857.8,8000 7777.8,9920 "></polyline>
                <line class="a" x1="10142.2" y1="8000" x2="5857.8" y2="8000"></line>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora093" style="width:50px;height:50px;top:0px;right:30px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
            <svg viewBox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <circle class="c" cx="8000" cy="8000" r="5920"></circle>
                <polyline class="a" points="8222.2,6080 10142.2,8000 8222.2,9920 "></polyline>
                <line class="a" x1="5857.8" y1="8000" x2="10142.2" y2="8000"></line>
            </svg>
        </div>
    </div>
	<!-- about section start -->

	
		<?php
	include('index-in.php');
	?>
	
	
	
<section id="services" class="astro-services-section">
  <style>
    .astro-services-section {
      position: relative;
      padding: 80px 20px;
      /* Changed background to a dark gradient instead of image */
      background: linear-gradient(135deg, #1b1b2f 0%, #000000 100%);
      font-family: 'Poppins', sans-serif;
      color: #fff;
    }

    .astro-services-section::before {
      content: "";
      position: absolute;
      top: 0; left: 0;
      width: 100%; height: 100%;
      /* Removed overlay because background is now gradient */
      z-index: 0;
    }

    .astro-services-section .container {
      position: relative;
      z-index: 1;
      max-width: 1200px;
      margin: auto;
    }

    .astro-services-section .section-title {
      text-align: center;
      margin-bottom: 50px;
    }

    .astro-services-section .section-title h5 {
      color: #ffd700;
      text-transform: uppercase;
      letter-spacing: 2px;
      font-weight: 600;
      margin-bottom: 10px;
    }

    .astro-services-section .section-title h2 {
      font-size: 36px;
      font-weight: 800;
      color: #ffffff;
    }

    .astro-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 30px;
    }

    .astro-card {
      position: relative;
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(12px);
      border-radius: 20px;
      padding: 30px 25px;
      text-align: center;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      border: 1px solid rgba(255, 255, 255, 0.2);
      overflow: hidden;
      cursor: pointer;
      user-select: none;
      -webkit-tap-highlight-color: transparent;
      color: #fff;
      z-index: 1;
    }

    /* Card background images */
    .astro-card::before {
      content: "";
      position: absolute;
      inset: 0;
      border-radius: 20px;
      background-size: cover;
      background-position: center center;
      opacity: 0.3;
      z-index: -1;
      transition: opacity 0.3s ease;
      filter: brightness(0.6) saturate(1.1);
    }

    /* Desktop hover */
    @media (hover: hover) and (pointer: fine) {
      .astro-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 25px 40px rgba(255, 255, 255, 0.15);
      }

      .astro-card:hover .astro-icon {
        transform: scale(1.2) rotate(8deg);
        box-shadow: 0 0 15px #ffd700;
      }

      .astro-card:hover::before {
        opacity: 0.5;
      }
    }

    /* Touch devices: tap effect */
    @media (hover: none) {
      .astro-card:active {
        transform: scale(0.97);
        box-shadow: 0 15px 30px rgba(255, 255, 255, 0.2);
      }
      .astro-card:active .astro-icon {
        transform: scale(1.15) rotate(8deg);
        box-shadow: 0 0 12px #ffd700;
      }
    }

    .astro-icon {
      width: 65px;
      height: 65px;
      border-radius: 50%;
      margin: auto 0 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #ffd700, #ff6f61);
      color: #1a1a1a;
      font-size: 28px;
      transition: transform 0.4s ease, box-shadow 0.4s ease;
      animation: popIn 0.6s ease-out forwards;
      z-index: 2;
      position: relative;
    }

    @keyframes popIn {
      0% {
        transform: scale(0);
        opacity: 0;
      }
      100% {
        transform: scale(1);
        opacity: 1;
      }
    }

    .astro-card h4 {
      font-size: 20px;
      margin-bottom: 12px;
      font-weight: 700;
      color: #ffffff;
      position: relative;
      z-index: 2;
    }

    .astro-card p {
      font-size: 15px;
      color: #dcdcdc;
      line-height: 1.6;
      position: relative;
      z-index: 2;
    }

    @media (max-width: 768px) {
      .astro-services-section {
        padding: 60px 15px;
      }
      .astro-services-section .section-title h2 {
        font-size: 28px;
      }
    }

    @media (max-width: 480px) {
      .astro-services-section .section-title h2 {
        font-size: 24px;
      }
      .astro-card {
        padding: 25px 15px;
      }
      .astro-icon {
        width: 55px;
        height: 55px;
        font-size: 24px;
        margin-bottom: 15px;
      }
      .astro-card h4 {
        font-size: 18px;
      }
      .astro-card p {
        font-size: 14px;
      }
    }
  </style>

  <!-- Font Awesome CDN -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

  <!-- AOS Animate On Scroll CDN -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      AOS.init({
        duration: 1000,
        once: true,
      });
    });
  </script>

  <div class="container">
    <div class="section-title">
      <h1 style="color:yellow;">Our Services</h1>
      <h3 style="color:white;">Powerful Astrological Guidance</h3>
    </div>

    <div class="astro-grid">
      <div class="astro-card" data-aos="zoom-in" style="--bg-image: url('images/ss1.jpg');" 
        >
        <div class="astro-icon"><i class="fas fa-heart"></i></div>
        <h4>Love Astrology</h4>
        <p>Empower your love life and find harmony using time-tested astrology methods.</p>
      </div>

      <div class="astro-card" data-aos="zoom-in" data-aos-delay="100" style="--bg-image: url('images/ss2.jpg');">
        <div class="astro-icon"><i class="fas fa-user-shield"></i></div>
        <h4>Black Magic Removal</h4>
        <p>Protect yourself from negative energies and get rid of harmful spiritual forces.</p>
      </div>

      <div class="astro-card" data-aos="zoom-in" data-aos-delay="200" style="--bg-image: url('images/ss3.jpg');">
        <div class="astro-icon"><i class="fas fa-ring"></i></div>
        <h4>Marriage Solutions</h4>
        <p>Fix marital conflicts and find long-lasting relationship compatibility.</p>
      </div>

      <div class="astro-card" data-aos="zoom-in" data-aos-delay="300" style="--bg-image: url('images/ss4.jpg');">
        <div class="astro-icon"><i class="fas fa-eye"></i></div>
        <h4>Palm Reading</h4>
        <p>Unlock secrets of your fate, success, and future with expert palmistry.</p>
      </div>

      <div class="astro-card" data-aos="zoom-in" data-aos-delay="400" style="--bg-image: url('images/ss5.jpg');">
        <div class="astro-icon"><i class="fas fa-star"></i></div>
        <h4>Horoscope Reading</h4>
        <p>Receive personalized insights from your birth chart and planetary positions.</p>
      </div>

      <div class="astro-card" data-aos="zoom-in" data-aos-delay="500" style="--bg-image: url('images/ss6.jpg');">
        <div class="astro-icon"><i class="fas fa-lightbulb"></i></div>
        <h4>Spiritual Healing</h4>
        <p>Realign your energy, cleanse negativity, and restore peace to your soul.</p>
      </div>

      <div class="astro-card" data-aos="zoom-in" data-aos-delay="600" style="--bg-image: url('images/ss7.jpg');">
        <div class="astro-icon"><i class="fas fa-praying-hands"></i></div>
        <h4>Hanuman Pooja</h4>
        <p>Experience divine protection and strength through sacred Hanuman worship.</p>
      </div>

      <div class="astro-card" data-aos="zoom-in" data-aos-delay="700" style="--bg-image: url('images/ss8.jpg');">
        <div class="astro-icon"><i class="fas fa-burn"></i></div>
        <h4>Negative Energy Removal</h4>
        <p>Get rid of dark energies affecting your life and bring positivity back.</p>
      </div>

      <div class="astro-card" data-aos="zoom-in" data-aos-delay="800" style="--bg-image: url('images/ss9.jpg');">
        <div class="astro-icon"><i class="fas fa-brain"></i></div>
        <h4>Psychic Reading</h4>
        <p>Find answers to life's questions and gain clarity through psychic visions.</p>
      </div>
    </div>
  </div>

  <script>
    // Apply background images from CSS variable for each card
    document.querySelectorAll('.astro-card').forEach(card => {
      const bg = card.style.getPropertyValue('--bg-image');
      if (bg) {
        card.style.setProperty('--bg-image', bg);
        card.style.setProperty('background-image', 'none'); // prevent duplicate if any
        card.style.position = 'relative';
        card.style.setProperty('z-index', '1');
        card.style.setProperty('overflow', 'hidden');
      }
    });
  </script>
</section>

<style>
  /* Using the CSS variable to set the background image in ::before */
  .astro-card::before {
    background-image: var(--bg-image);
  }
</style>




	
	

	
	
	
<?php
    include('faq.php');
?>	
	
		
	<?php
	include('testimonials.php');
	?>
	


<?php 
  include('poojaservices.php');
  ?>
	
	
    <?php
     include('one.php');
    ?>
	
	
	

	<div class="clearfix"></div>
	
	


	
	<?php
	include('footer.php');
	?>