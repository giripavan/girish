<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tarot Reading</title>
  <?php include('header.php'); ?>
</head>
<body>

<!-- Banner -->


<!-- Styles -->
<style>
  .love-section {
    position: relative;
    background-color: rgba(6, 1, 44, 0);
    padding: 60px 0;
    overflow: hidden;
  }
  .rotating-bg {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 800px;
    height: 800px;
    background-image: url('images/chakra-orange.png');
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    opacity: 0.5;
    animation: rotate 100s linear infinite;
    transform: translate(-50%, -50%);
    z-index: 0;
  }
  @keyframes rotate {
    from { transform: translate(-50%, -50%) rotate(0deg); }
    to { transform: translate(-50%, -50%) rotate(360deg); }
  }
  .love-content {
    position: relative;
    z-index: 2;
  }
  .love-box {
    background: #fff;
    border: 1px solid #eee;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    margin-bottom: 30px;
  }
  .love-box h4 {
    margin-bottom: 20px;
    color: #062241;
  }
  .order-md-1 { order: 1; }
  .order-md-2 { order: 2; }
  @media (max-width: 767px) {
    .row { display: flex; flex-direction: column; }
    .col-md-8, .col-md-4 { width: 100%; }
    .order-md-1 { order: 2; }
    .order-md-2 { order: 1; }
  }
</style>

<!-- Main Section -->
<section class="love-section">
  <div class="rotating-bg"></div>

  <div class="container love-content">
    <div class="row">
      <!-- Main Content -->
      <div class="col-md-8 col-sm-12 order-md-2">
        <p style="font-size: 18px; line-height: 1.8; text-align: justify; color: black;">
          <span style="float: left; font-size: 60px; line-height: 40px; padding-right: 10px; font-weight: bold; color:rgb(246, 7, 7);">T</span>
          arot Reading is a powerful spiritual tool used to gain insights into your past, present, and future. It helps you understand life's challenges and discover the best path forward.
        </p>

        <p style="font-size: 18px; line-height: 1.8; text-align: justify; color: black;">
          Master Shivakumar uses his deep knowledge of tarot cards to provide accurate and meaningful readings, guiding you toward clarity and empowerment in love, career, and personal growth.
        </p>

        <div class="row" style="margin-top: 20px;">
          <div class="col-md-6 col-sm-6">
            <img src="./images/ta-abt2.jpg" alt="Tarot Reading Cards" style="width: 100%; border-radius: 8px;">
          </div>
          <div class="col-md-6 col-sm-6">
            <img src="./images/nu-abt1.jpg" alt="Tarot Consultation" style="width: 100%; border-radius: 8px;">
          </div>
        </div><br>

        <p style="font-size: 18px; line-height: 1.8; text-align: justify; color: black;">
          Whether you seek answers about love, finances, or spiritual growth, tarot reading can open your mind to new perspectives and possibilities.
        </p>

        <p style="font-size: 18px; line-height: 1.8; text-align: justify; color: black;">
          <strong>Book your tarot reading session today</strong> to unlock the mysteries of your life and move forward with confidence.
        </p>
      </div>

      <!-- Sidebar -->
      <div class="col-md-4 col-sm-12 order-md-1">
        <div class="love-box">
          <h4>Our Services</h4>
          <ul style="list-style: none; padding: 0;">
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="vasthu shastra.php" style="text-decoration: none; color: inherit;">Vasthu Shastra</a></li>
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="palm reading.php" style="text-decoration: none; color: inherit;">Palm Reading</a></li>
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="get-love-back.php" style="text-decoration: none; color: inherit;">Get Love Back</a></li>
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="marriage-problem.php" style="text-decoration: none; color: inherit;">Marriage Problem</a></li>
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="spiritual-healing.php" style="text-decoration: none; color: inherit;">Spiritual Healing</a></li>
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="black-magic-removal.php" style="text-decoration: none; color: inherit;">Black Magic Removal</a></li>
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="tarot-reading.php" style="text-decoration: none; color: inherit;">Tarot Reading</a></li>
            <li style="padding: 10px 0;"><a href="negative-energy.php" style="text-decoration: none; color: inherit;">Negative Energy</a></li>
          </ul>
        </div>

        <div class="love-box">
          <h4>Send a Message</h4>
          <form>
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Your Name *" required>
            </div>
            <div class="form-group">
              <input type="email" class="form-control" placeholder="Your Email *" required>
            </div>
            <div class="form-group">
              <textarea class="form-control" rows="4" placeholder="Your Message *" required></textarea>
            </div>
            <button type="submit" class="btn btn-block" style="background: #ff7a30; color: white; border: none;">Send Message</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include('testimonials.php'); ?>

<section style="padding: 60px 0; background-color: #fff;">
  <div class="container">
    <div class="text-center mb-5">
      <h2 style="color: #062241; font-weight: bold;">Why Choose Us</h2>
      <p style="color: #465168; max-width: 700px; margin: auto;">
        With years of experience and thousands of satisfied clients, we offer deeply personalized astrology and spiritual solutions to help you achieve peace, clarity, and success in life.
      </p>
    </div>

    <div class="row text-center">
      <div class="col-md-4 mb-4">
        <div style="padding: 30px; border: 1px solid #eee; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
          <i class="fas fa-star" style="font-size: 36px; color: #ff7a30;"></i>
          <h5 style="margin-top: 15px; color: #062241;">Trusted Expertise</h5>
          <p style="color: #465168;">Certified astrologer with 15+ years of experience in solving real-life problems through Vedic and modern methods.</p>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div style="padding: 30px; border: 1px solid #eee; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
          <i class="fas fa-hand-holding-heart" style="font-size: 36px; color: #ff7a30;"></i>
          <h5 style="margin-top: 15px; color: #062241;">Personalized Solutions</h5>
          <p style="color: #465168;">Every session is tailored to your birth chart and current planetary conditions for accurate insights and remedies.</p>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div style="padding: 30px; border: 1px solid #eee; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
          <i class="fas fa-comments" style="font-size: 36px; color: #ff7a30;"></i>
          <h5 style="margin-top: 15px; color: #062241;">24/7 Support</h5>
          <p style="color: #465168;">Have a question or emergency? We’re just a message away. Get guidance whenever you need it most.</p>
        </div>
      </div>
    </div>
  </div>
</section>
<?php include('footer.php'); ?>

</body>
</html>
