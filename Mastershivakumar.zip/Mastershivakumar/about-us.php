<!DOCTYPE HTML>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="de">  <!--<![endif]-->
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
	<?php
	include('header.php');
	?>
	<!-- service indicator banner -->
    <!--	<div class="auto-container">
        	<h1>About Astrologer</h1>
            <ul class="page-breadcrumb">
            	<li><a href="index.php">Home</a></li>
                <li>About us</li>
            </ul>
        </div>
        -->
    </section>
	
	<!-- service section about matter -->
	<?php
	include('about-in.php');
	?>
<section style="padding: 60px 0; background-color: #fff;">
  <div class="container">
    <div class="text-center mb-5">
      <h2 style="color: #062241; font-weight: bold;">Why Choose Us</h2>
      <p style="color: #465168; max-width: 700px; margin: auto;">
        With years of experience and thousands of satisfied clients, we offer deeply personalized astrology and spiritual solutions to help you achieve peace, clarity, and success in life.
      </p>
    </div>

    <div class="row text-center">
      <div class="col-md-4 mb-4">
        <div style="padding: 30px; border: 1px solid #eee; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
          <i class="fas fa-star" style="font-size: 36px; color: #ff7a30;"></i>
          <h5 style="margin-top: 15px; color: #062241;">Trusted Expertise</h5>
          <p style="color: #465168;">Certified astrologer with 15+ years of experience in solving real-life problems through Vedic and modern methods.</p>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div style="padding: 30px; border: 1px solid #eee; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
          <i class="fas fa-hand-holding-heart" style="font-size: 36px; color: #ff7a30;"></i>
          <h5 style="margin-top: 15px; color: #062241;">Personalized Solutions</h5>
          <p style="color: #465168;">Every session is tailored to your birth chart and current planetary conditions for accurate insights and remedies.</p>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div style="padding: 30px; border: 1px solid #eee; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
          <i class="fas fa-comments" style="font-size: 36px; color: #ff7a30;"></i>
          <h5 style="margin-top: 15px; color: #062241;">24/7 Support</h5>
          <p style="color: #465168;">Have a question or emergency? We’re just a message away. Get guidance whenever you need it most.</p>
        </div>
      </div>
    </div>
  </div>
</section>

	<?php 
	include('faq.php');
	?>

	<?php
	include('footer.php');
	?>
	
	