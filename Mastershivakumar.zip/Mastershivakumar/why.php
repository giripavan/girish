<section class="bg-black px-12 py-20 flex items-center justify-center min-h-screen relative overflow-hidden">
  <!-- Animated background elements -->
  <div class="absolute inset-0 overflow-hidden">
    <div class="floating-star"></div>
    <div class="floating-star delay-1"></div>
    <div class="floating-star delay-2"></div>
    <div class="floating-star delay-3"></div>
  </div>

  <div class="max-w-7xl w-full flex items-center gap-16 relative z-10">
    <!-- Left Side: Image with animation -->
    <div class="w-1/2 animate__animated animate__fadeInLeft animate__slow">
      <div class="relative group">
        <img src="images/w1.jpg" alt="Cosmic Visual"
             class="w-full h-auto rounded-2xl shadow-2xl object-cover transform transition-all duration-700 group-hover:scale-105">
        
        <!-- Glowing border effect -->
        <div class="absolute inset-0 rounded-2xl border-2 border-transparent group-hover:border-purple-500 group-hover:opacity-70 transition-all duration-500 pointer-events-none"></div>
        
        <!-- Floating cosmic elements overlay -->
        <div class="absolute -inset-4 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
          <div class="cosmic-dot dot-1"></div>
          <div class="cosmic-dot dot-2"></div>
          <div class="cosmic-dot dot-3"></div>
        </div>
      </div>
    </div>

    <!-- Right Side: Content with animation -->
    <div class="w-1/2 text-white animate__animated animate__fadeInRight animate__slow">
      <p class="text-pink-400 text-base font-semibold mb-2 animate__animated animate__fadeInUp animate__delay-1s">
        <span class="inline-block animate__animated animate__pulse animate__infinite animate__slower">✨</span> We Got You!
      </p>
      <h1 class="text-6xl font-extrabold leading-snug mb-6 animate__animated animate__fadeInUp animate__delay-1s">
        Discover Your <span class="text-white cosmic-text">Cosmic Path</span>
      </h1>
      <p class="text-xl text-gray-300 mb-8 leading-relaxed animate__animated animate__fadeInUp animate__delay-2s">
        Unlock personalized insights and find clarity in every star.<br>
        Begin your journey with a free horoscope today.
      </p>
      <a href="#"
         class="inline-flex items-center bg-purple-600 hover:bg-purple-700 text-white text-lg font-semibold px-6 py-3 rounded-lg transition-all duration-300 animate__animated animate__fadeInUp animate__delay-2s hover:shadow-purple-glow">
        Get Started
        <svg class="w-5 h-5 ml-2 arrow-icon" fill="none" stroke="currentColor" stroke-width="2"
             viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"></path>
        </svg>
      </a>
    </div>
  </div>
</section>

<style>
  /* Floating stars background */
  .floating-star {
    position: absolute;
    width: 3px;
    height: 3px;
    background: white;
    border-radius: 50%;
    opacity: 0.7;
    animation: floatStar 15s linear infinite;
  }
  
  .floating-star.delay-1 { animation-delay: 3s; top: 20%; left: 10%; }
  .floating-star.delay-2 { animation-delay: 7s; top: 60%; left: 80%; }
  .floating-star.delay-3 { animation-delay: 12s; top: 30%; left: 50%; }
  
  @keyframes floatStar {
    0% { transform: translateY(0) translateX(0); opacity: 0; }
    50% { opacity: 0.7; }
    100% { transform: translateY(-500px) translateX(100px); opacity: 0; }
  }
  
  /* Cosmic text animation */
  .cosmic-text {
    position: relative;
    display: inline-block;
  }
  
  .cosmic-text::after {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 100%;
    height: 3px;
    background: linear-gradient(90deg, #ec4899, #8b5cf6);
    transform: scaleX(0);
    transform-origin: left;
    animation: cosmicUnderline 3s ease-in-out infinite;
  }
  
  @keyframes cosmicUnderline {
    0%, 100% { transform: scaleX(0); }
    50% { transform: scaleX(1); }
  }
  
  /* Image hover effects */
  .cosmic-dot {
    position: absolute;
    width: 8px;
    height: 8px;
    background: white;
    border-radius: 50%;
    filter: blur(1px);
    animation: cosmicFloat 4s ease-in-out infinite;
  }
  
  .dot-1 { top: 20%; left: 30%; animation-delay: 0s; }
  .dot-2 { top: 60%; left: 70%; animation-delay: 1s; }
  .dot-3 { top: 40%; left: 50%; animation-delay: 2s; }
  
  @keyframes cosmicFloat {
    0%, 100% { transform: translateY(0) translateX(0); opacity: 0.7; }
    50% { transform: translateY(-20px) translateX(10px); opacity: 1; }
  }
  
  /* Button glow effect */
  .hover\:shadow-purple-glow:hover {
    box-shadow: 0 0 15px rgba(168, 85, 247, 0.7);
  }
  
  /* Arrow animation */
  .arrow-icon {
    transition: transform 0.3s ease;
  }
  
  a:hover .arrow-icon {
    transform: translateX(5px);
  }
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.js"></script>
<script>
  document.addEventListener("DOMContentLoaded", function() {
    // Add more floating stars dynamically
    const section = document.querySelector('section');
    for (let i = 0; i < 10; i++) {
      const star = document.createElement('div');
      star.className = 'floating-star';
      star.style.left = Math.random() * 100 + '%';
      star.style.top = Math.random() * 100 + '%';
      star.style.width = Math.random() * 3 + 1 + 'px';
      star.style.height = star.style.width;
      star.style.animationDelay = Math.random() * 15 + 's';
      star.style.animationDuration = Math.random() * 10 + 10 + 's';
      section.appendChild(star);
    }
  });
</script>