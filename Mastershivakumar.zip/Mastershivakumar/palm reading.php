<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Palm Reading</title>
	<?php
	include('header.php');
	?>
	<!-- service indicator banner -->

	
	<!-- service section about matter -->
	<style>
  .love-section {
    position: relative;
    background-color:rgba(200, 161, 248, 0);
    padding: 60px 0;
    overflow: hidden;
  }

  .rotating-bg {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 800px;
    height: 800px;
    background-image: url('images/chakra-orange.png'); /* Replace this */
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    opacity: 0.5;
    animation: rotate 100s linear infinite;
    transform: translate(-50%, -50%);
    z-index: 0;
  }

  @keyframes rotate {
    from {
      transform: translate(-50%, -50%) rotate(0deg);
    }
    to {
      transform: translate(-50%, -50%) rotate(360deg);
    }
  }

  .love-content {
    position: relative;
    z-index: 2;
  }

  .love-box {
    background: #fff;
    border: 1px solid #eee;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    margin-bottom: 30px;
  }

  .love-box h4 {
    margin-bottom: 20px;
    color: #062241;
  }

  .order-md-1 {
    order: 1;
  }

  .order-md-2 {
    order: 2;
  }

  @media (max-width: 767px) {
    .row {
      display: flex;
      flex-direction: column;
    }

    .col-md-8, .col-md-4 {
      width: 100%;
    }

    .order-md-1 {
      order: 2;
    }

    .order-md-2 {
      order: 1;
    }
  }
</style>

<section class="love-section">
  <div class="rotating-bg"></div>

  <div class="container love-content">
    <div class="row">
      <!-- RIGHT: Main Content -->
      <div class="col-md-8 col-sm-12 order-md-2">
        <p style="font-size: 18px; line-height: 1.8; text-align: justify; color: black;">
          <span style="float: left; font-size: 60px; line-height: 40px; padding-right: 10px; font-weight: bold; color:rgb(158, 11, 6);">P</span>
          alm Reading, also known as palmistry, is an ancient practice that interprets the lines, shapes, and mounts on your hands to reveal your personality, future, and destiny. Each line on your palm tells a unique story about your life path, relationships, career, and health.
        </p>

        <p style="font-size: 18px; line-height: 1.8; text-align: justify; color: black;">
          Our expert astrologer, Master Shivakumar, has helped thousands understand themselves better through accurate palm readings. Whether you're curious about love, career direction, or future decisions, your palms hold the clues you seek.
        </p>

        <div class="row" style="margin-top: 20px;">
          <div class="col-md-6 col-sm-6">
            <img src="./images/palm12.jpg" alt="Palm Reading Session" style="width: 100%; border-radius: 8px;">
          </div>
          <div class="col-md-6 col-sm-6">
            <img src="./images/pps1.jpg" alt="Hand Analysis" style="width: 100%; border-radius: 8px;">
          </div>
        </div>
        <br>
        <p style="font-size: 18px; line-height: 1.8; text-align: justify; color: black;">
          <strong>Get an in-depth reading</strong> to understand your fate lines, heart line, head line, and life line. Discover hidden strengths, avoid future obstacles, and align with your true potential.
        </p>

        <p style="font-size: 18px; line-height: 1.8; text-align: justify; color: black;">
          Master Shivakumar uses a blend of traditional wisdom and modern insight to deliver authentic palm readings with clarity and compassion.
        </p>

        <p style="font-size: 18px; line-height: 1.8; text-align: justify; color: black;">
          <strong>Contact us today</strong> to book your personalized palm reading and uncover the secrets written in your hands.
        </p> 
      </div>

      <!-- LEFT: Services + Form -->
      <div class="col-md-4 col-sm-12 order-md-1">
        <div class="love-box">
          <h4>Our Services</h4>
         <ul style="list-style: none; padding: 0;">
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="vasthu shastra.php" style="text-decoration: none; color: inherit;">Vasthu Shastra</a></li>
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="palm reading.php" style="text-decoration: none; color: inherit;">Palm Reading</a></li>
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="get-love-back.php" style="text-decoration: none; color: inherit;">Get Love Back</a></li>
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="marriage-problem.php" style="text-decoration: none; color: inherit;">Marriage Problem</a></li>
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="spiritual-healing.php" style="text-decoration: none; color: inherit;">Spiritual Healing</a></li>
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="black-magic-removal.php" style="text-decoration: none; color: inherit;">Black Magic Removal</a></li>
            <li style="padding: 10px 0; border-bottom: 1px solid #eee;"><a href="tarot-reading.php" style="text-decoration: none; color: inherit;">Tarot Reading</a></li>
            <li style="padding: 10px 0;"><a href="negative-energy.php" style="text-decoration: none; color: inherit;">Negative Energy</a></li>
          </ul>
        </div>

        <div class="love-box">
          <h4>Send a Message</h4>
          <form>
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Your Name *" required>
            </div>
            <div class="form-group">
              <input type="email" class="form-control" placeholder="Your Email *" required>
            </div>
            <div class="form-group">
              <textarea class="form-control" rows="4" placeholder="Your Message *" required></textarea>
            </div>
            <button type="submit" class="btn btn-block" style="background: #ff7a30; color: white; border: none;">Send Message</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
include('testimonials.php');
?>
<section style="padding: 60px 0; background-color: #fff;">
  <div class="container">
    <div class="text-center mb-5">
      <h2 style="color: #062241; font-weight: bold;">Why Choose Us</h2>
      <p style="color: #465168; max-width: 700px; margin: auto;">
        With years of experience and thousands of satisfied clients, we offer deeply personalized astrology and spiritual solutions to help you achieve peace, clarity, and success in life.
      </p>
    </div>

    <div class="row text-center">
      <div class="col-md-4 mb-4">
        <div style="padding: 30px; border: 1px solid #eee; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
          <i class="fas fa-star" style="font-size: 36px; color: #ff7a30;"></i>
          <h5 style="margin-top: 15px; color: #062241;">Trusted Expertise</h5>
          <p style="color: #465168;">Certified astrologer with 15+ years of experience in solving real-life problems through Vedic and modern methods.</p>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div style="padding: 30px; border: 1px solid #eee; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
          <i class="fas fa-hand-holding-heart" style="font-size: 36px; color: #ff7a30;"></i>
          <h5 style="margin-top: 15px; color: #062241;">Personalized Solutions</h5>
          <p style="color: #465168;">Every session is tailored to your birth chart and current planetary conditions for accurate insights and remedies.</p>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div style="padding: 30px; border: 1px solid #eee; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.03);">
          <i class="fas fa-comments" style="font-size: 36px; color: #ff7a30;"></i>
          <h5 style="margin-top: 15px; color: #062241;">24/7 Support</h5>
          <p style="color: #465168;">Have a question or emergency? We’re just a message away. Get guidance whenever you need it most.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include('faq.php'); ?>
<?php
include('footer.php');
?>
