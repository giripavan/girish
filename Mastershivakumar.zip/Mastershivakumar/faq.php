<section class="cosmic-faq-v2" style="padding: 80px 0; background: radial-gradient(ellipse at center,rgb(11, 11, 11) 0%,rgb(83, 7, 169) 100%); position: relative; overflow: hidden; color: #fff; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
    <!-- Cosmic Animated Elements -->
    <div class="shooting-star" style="position: absolute; width: 80px; height: 3px; background: linear-gradient(90deg, rgba(255,255,255,0), #a29bfe); top: 10%; left: -80px; animation: shoot 20s linear infinite;"></div>
    <div class="shooting-star" style="position: absolute; width: 100px; height: 3px; background: linear-gradient(90deg, rgba(255,255,255,0), #f39c12); top: 30%; left: -120px; animation: shoot 18s linear infinite 5s;"></div>
    
    <div class="container">
        <!-- Section Title -->
        <div class="row">
            <div class="col text-center mb-6">
                <h2 class="cosmic-title" style="opacity: 0; animation: fadeInUp 1s 0.3s forwards;">
                    Your Astrology Journey Begins Here
                </h2>
            </div>
        </div>

        <!-- FAQ Section -->
        <div class="row align-items-start">
            <!-- Left Column -->
            <div class="col-md-6 col-lg-4">
                <div class="faq-section">
                    <!-- Question 1 -->
                    <div class="faq-item" style="margin-bottom: 30px;">
                        <div class="faq-question blue" >
                            <h4 style= "color:yellow">How do astrologers help?</h4>
                            <div class="icon">+</div>
                        </div>
                        <div class="faq-answer">
                            <p>Astrologers offer valuable insights, guidance, and support by interpreting celestial patterns, aiding in personal growth, relationships, and life choices.</p>
                        </div>
                    </div>

                    <!-- Question 2 -->
                    <div class="faq-item" style="margin-bottom: 30px;">
                        <div class="faq-question purple" >
                            <h4  style= "color:yellow">Can astrology predict marriage?</h4>
                            <div class="icon">+</div>
                        </div>
                        <div class="faq-answer purple-bg">
                            <p>Astrology helps identify auspicious periods for marriage and assesses compatibility through the analysis of planetary placements in your birth chart.</p>
                        </div>
                    </div>

                    <!-- Question 3 -->
                    <div class="faq-item" style="margin-bottom: 30px;">
                        <div class="faq-question purple" >
                            <h4  style= "color:yellow">Can astrology predict getting love back?</h4>
                            <div class="icon">+</div>
                        </div>
                        <div class="faq-answer purple-bg">
                            <p>Astrology can reveal the cosmic influences affecting your relationship and guide you on the right timing and remedies to bring back lost love with the help of planetary analysis.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cosmic Center Image -->
            <div class="col-md-6 col-lg-4 text-center mb-4 mb-lg-0">
                <div class="cosmic-image-container" style="position: relative; display: inline-block;">
                    <div class="cosmic-image" >
                        <div class="zodiac-symbol">♆</div>
                    </div>
                </div>
            </div>

            <!-- Right Column -->
            <div class="col-md-6 col-lg-4">
                <div class="faq-section">
                    <!-- Question 4 -->
                    <div class="faq-item" style="margin-bottom: 30px;">
                        <div class="faq-question blue" >
                            <h4  style= "color:yellow">How does astrology work?</h4>
                            <div class="icon">+</div>
                        </div>
                        <div class="faq-answer">
                            <p>Astrology interprets the positions and movements of celestial bodies to predict influences on human affairs and natural events.</p>
                        </div>
                    </div>

                    <!-- Question 5 -->
                    <div class="faq-item" style="margin-bottom: 30px;">
                        <div class="faq-question purple" >
                            <h4  style= "color:yellow">What's needed for a reading?</h4>
                            <div class="icon">+</div>
                        </div>
                        <div class="faq-answer purple-bg">
                            <p>Your birth date, time, and location are essential to generate a precise natal chart, enabling accurate astrological readings.</p>
                        </div>
                    </div>

                    <!-- Question 6 -->
                    <div class="faq-item" style="margin-bottom: 30px;">
                        <div class="faq-question purple" >
                            <h4  style= "color:yellow">How Master Shivakumar's Prediction Works?</h4>
                            <div class="icon">+</div>
                        </div>
                        <div class="faq-answer purple-bg">
                            <p>Master helps identify auspicious periods for marriage and assesses compatibility through the analysis of planetary placements in your birth chart.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
    /* Cosmic Animations */
    @keyframes shoot {
        0% { transform: translateX(0); opacity: 1; }
        100% { transform: translateX(100vw); opacity: 0; }
    }

    @keyframes float {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-20px); }
    }

    @keyframes fadeInUp {
        0% { opacity: 0; transform: translateY(20px); }
        100% { opacity: 1; transform: translateY(0); }
    }

    /* Section Title */
    .cosmic-title {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-weight: 800;
        font-size: 3.8rem;
        letter-spacing: 1.2px;
        background: linear-gradient(90deg,rgb(239, 255, 13));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        
    }

    /* FAQ Toggle */
    .faq-question {
        padding: 20px;
        border-radius: 8px;
        cursor: pointer;
        transition: transform 0.3s ease, background 0.3s ease;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-family: 'Poppins', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-weight: 600;
        font-size: 1.3rem;
      
    }

    .faq-question.blue {
        background: rgba(235, 240, 243, 0.2);
        border-left: 5px solid #3498db;
        color: #f1c40f;
    }

    .faq-question.purple {
        background: rgba(17, 2, 23, 0.2);
        border-left: 5px solid #9b59b6;
        color: yellow;
    }

    .faq-question:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    }

    .faq-question.active {
        background: rgba(255, 255, 255, 0.15) !important;
    }

    .faq-question.active .icon {
        transform: rotate(45deg);
    }

    /* FAQ Answer */
    .faq-answer {
        display: none;
        padding: 10px 20px;
        border-radius: 8px;
        font-family: 'Open Sans', Arial, sans-serif;
        font-weight: 400;
        font-size: 1.5rem;
        line-height: 1.7;
        color: white;
        background-color: rgba(4, 2, 33, 0.98);
        margin-top: 8px;
    }

    .faq-answer.purple-bg {
        background-color: rgba(12, 1, 16, 0.98);
    }

    /* Icon + / × */
    .icon {
        font-family: 'Segoe UI Symbol', Arial, sans-serif;
        font-weight: 700;
        font-size: 1.6rem;
        color: inherit; /* inherit from question color */
        text-shadow: 0 0 5px rgba(255, 255, 255, 0.7);
        transition: transform 0.3s ease;
    }

    /* Cosmic center image */
    .cosmic-image {
        width: 250px;
        height: 250px;
        margin: 0 auto;
        background: radial-gradient(circle, #3498db 0%, #9b59b6 70%, transparent 80%);
        border-radius: 50%;
        box-shadow: 0 0 50px rgba(155, 89, 182, 0.5);
        animation: float 6s ease-in-out infinite;
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .zodiac-symbol {
        font-size: 4rem;
        color: #fff;
        opacity: 0.8;
        user-select: none;
        text-shadow: 0 0 10px rgba(255, 255, 255, 0.8);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .cosmic-title {
            font-size: 2.8rem;
        }
        .faq-question {
            font-size: 1.1rem;
        }
        .faq-answer {
            font-size: 1rem;
        }
        .icon {
            font-size: 1.3rem;
        }
        .cosmic-image {
            width: 180px;
            height: 180px;
        }
        .zodiac-symbol {
            font-size: 3rem;
        }
    }
</style>

<script>
    // FAQ Toggle Functionality
    document.querySelectorAll('.faq-question').forEach(question => {
        question.addEventListener('click', () => {
            const answer = question.nextElementSibling;
            const icon = question.querySelector('.icon');
            question.classList.toggle('active');
            if (question.classList.contains('active')) {
                answer.style.display = 'block';
                icon.textContent = '×';
            } else {
                answer.style.display = 'none';
                icon.textContent = '+';
            }
        });
    });
</script>
