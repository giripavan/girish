<section style="padding:30px 0px">
	<div class="container-fluid">
		<div class="container">
		
			<div class="container">
				<div class="row">
					 <div class="col-md-3 col-sm-3 col-xs-12">
						<div class="box">
							<img src="images/spirtual-healing.jpg" alt="spirtual healing">
							<div class="box-content">
								
								<ul class="icon">
									<li><a href="tel: "><i class="fa fa-phone"></i></a></li>
									<li><a href="tel: "><i class="fa fa-envelope"></i></a></li>
								</ul>
							</div>
						</div>
						<div class="ser-content">
						<p>Spiritual healing is a vital scientific technique that helps individuals to remove issues that have their underlay reason in the spiritual region. It is the pristine category of healing known to mankind.</p>
						<a href="spirtual-healing.php"><h5>Readmore</h5></a>
						</div>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-12">
						<div class="box">
							<img src="images/negitive-energy.jpg" alt="negitive energy">
							<div class="box-content">
								
								<ul class="icon">
									<li><a href="tel: "><i class="fa fa-phone"></i></a></li>
									<li><a href="tel: "><i class="fa fa-envelope"></i></a></li>
								</ul>
							</div>
						</div>
						<div class="ser-content">
						<p>Psychic sanju ji gives Negative Energy Removal Specialist In usa you an answer for all your problems in your life, even if you are moving in an appropriate route without worrying about the life of any body.</p>
						<a href="negitive-energy.php"><h5>Readmore</h5></a>
						</div>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-12">
						<div class="box">
							<img src="images/vashikaran-specialist.jpg" alt="vashikaran specialist">
							<div class="box-content">
								
								<ul class="icon">
									<li><a href="tel: "><i class="fa fa-phone"></i></a></li>
									<li><a href="tel: "><i class="fa fa-envelope"></i></a></li>
								</ul>
							</div>
						</div>
						<div class="ser-content">
						<p>
Astrology is always that gives the solution to people about their problems. There are many people those who fed up from the problems that they face into their life. They are trying to find out solution of their problem</p>
						<a href="vashikaran-special.php"><h5>Readmore</h5></a>
						</div>
					</div>
					<div class="col-md-3 col-sm-3 col-xs-12">
						<div class="box">
							<img src="images/love-spells.jpg" alt="love spells">
							<div class="box-content">
								
								<ul class="icon">
									<li><a href="tel: "><i class="fa fa-phone"></i></a></li>
									<li><a href="tel: "><i class="fa fa-envelope"></i></a></li>
								</ul>
							</div>
						</div>
						<div class="ser-content">
						<p>Are you facing despair in your love life? Did you meet the love of your life and lose him/her? Most of the times the universe works in mysterious ways; it always has a reason for whatever happens.</p>
						<a href="love-spells.php"><h5>Readmore</h5></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>	