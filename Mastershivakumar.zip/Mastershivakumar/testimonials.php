<section style="
  background: radial-gradient(circle at center, #121d42 0%, #0a1130 100%);
  padding: 80px 20px;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  color: #eee;
  position: relative;
  overflow: hidden;
  max-width: 1300px;
  margin: auto;
  box-sizing: border-box;
">

  <!-- Zodiac Corner Images -->
  <img src="images/zc1.png" alt="Zodiac Left" style="
    position: absolute;
    top: 15px;
    left: 15px;
    width: 140px;
    opacity: 1.3;
    filter: drop-shadow(0 0 6px #f5c518);
    border-radius: 20px;
    user-select: none;
    pointer-events: none;
  " />
  <img src="images/zc3.png" alt="Zodiac Right" style="
    position: absolute;
    bottom: 15px;
    right: 15px;
    width: 140px;
    opacity: 1.3;
    filter: drop-shadow(0 0 6px #f5c518);
    border-radius: 20px;
    user-select: none;
    pointer-events: none;
  " />

  <!-- Section Title -->
  <h2 style="
    text-align: center;
    font-family: 'Brush Script MT', cursive;
    font-size: 46px;
    margin-bottom: 70px;
    color:rgb(249, 248, 246);
    
  ">
    Client Testimonials
  </h2>

  <!-- Testimonials Grid -->
  <div style="
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 32px;
    padding: 0 10px;
  ">

    <!-- Testimonial Card -->
    <div style="
      background: linear-gradient(145deg, rgba(245,197,24,0.08), rgba(255,255,255,0.05));
      border-radius: 24px;
      padding: 30px 25px;
      box-shadow:
        0 6px 18px rgba(245,197,24,0.25),
        inset 0 0 10px rgba(245,197,24,0.15);
      text-align: center;
      transition: transform 0.4s ease, box-shadow 0.4s ease;
      cursor: default;
      backdrop-filter: blur(12px);
    " onmouseover="this.style.transform='scale(1.06)'; this.style.boxShadow='0 10px 25px rgba(245,197,24,0.6), inset 0 0 20px rgba(245,197,24,0.35)';" onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 6px 18px rgba(245,197,24,0.25), inset 0 0 10px rgba(245,197,24,0.15)';">
      <img src="images/ts2.jpg" alt="Rahul Malhotra" style="
        width: 120px;
        height: 120px;
        border-radius: 50%;
        border: 4px solid #f5c518;
        object-fit: cover;
        margin-bottom: 20px;
        box-shadow:
          0 0 10px #f5c518;
      " />
      <h3 style="
        margin: 0 0 10px;
        font-weight: 800;
        color: #fff6c2;
        
      ">Nancy</h3>
      <div style="color: #f5c518; font-size: 22px; margin-bottom: 18px;">★★★★★</div>
      <p style="
        font-style: italic;
        font-size: 17px;
        line-height: 1.5;
        color: #f0e9cf;
      ">
        "The astrological services provided by them are exceptional in nature. Their prediction for my future was true."
      </p>
    </div>

    <!-- Repeat for other testimonials -->

    <div style="
      background: linear-gradient(145deg, rgba(245,197,24,0.08), rgba(255,255,255,0.05));
      border-radius: 24px;
      padding: 30px 25px;
      box-shadow:
        0 6px 18px rgba(245,197,24,0.25),
        inset 0 0 10px rgba(245,197,24,0.15);
      text-align: center;
      transition: transform 0.4s ease, box-shadow 0.4s ease;
      cursor: default;
      backdrop-filter: blur(12px);
    " onmouseover="this.style.transform='scale(1.06)'; this.style.boxShadow='0 10px 25px rgba(245,197,24,0.6), inset 0 0 20px rgba(245,197,24,0.35)';" onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 6px 18px rgba(245,197,24,0.25), inset 0 0 10px rgba(245,197,24,0.15)';">
      <img src="images/tm1.jpg" alt="Aisha Khan" style="
        width: 120px;
        height: 120px;
        border-radius: 50%;
        border: 4px solid #f5c518;
        object-fit: cover;
        margin-bottom: 20px;
        box-shadow:
          0 0 10px #f5c518;
      " />
      <h3 style="
        margin: 0 0 10px;
        font-weight: 800;
        color: #fff6c2;
     
      ">kate</h3>
      <div style="color: #f5c518; font-size: 22px; margin-bottom: 18px;">★★★★☆</div>
      <p style="
        font-style: italic;
        font-size: 17px;
        line-height: 1.5;
        color: #f0e9cf;
      ">
        "I was amazed by the accuracy of their readings. Their guidance helped me find clarity in my personal and professional life."
      </p>
    </div>

    <div style="
      background: linear-gradient(145deg, rgba(245,197,24,0.08), rgba(255,255,255,0.05));
      border-radius: 24px;
      padding: 30px 25px;
      box-shadow:
        0 6px 18px rgba(245,197,24,0.25),
        inset 0 0 10px rgba(245,197,24,0.15);
      text-align: center;
      transition: transform 0.4s ease, box-shadow 0.4s ease;
      cursor: default;
      backdrop-filter: blur(12px);
    " onmouseover="this.style.transform='scale(1.06)'; this.style.boxShadow='0 10px 25px rgba(245,197,24,0.6), inset 0 0 20px rgba(245,197,24,0.35)';" onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 6px 18px rgba(245,197,24,0.25), inset 0 0 10px rgba(245,197,24,0.15)';">
      <img src="images/tm2.jpg" alt="David Lee" style="
        width: 120px;
        height: 120px;
        border-radius: 50%;
        border: 4px solid #f5c518;
        object-fit: cover;
        margin-bottom: 20px;
        box-shadow:
          0 0 10px #f5c518;
      " />
      <h3 style="
        margin: 0 0 10px;
        font-weight: 800;
        color: #fff6c2;
       
      ">Amelia</h3>
      <div style="color: #f5c518; font-size: 22px; margin-bottom: 18px;">★★★★★</div>
      <p style="
        font-style: italic;
        font-size: 17px;
        line-height: 1.5;
        color: #f0e9cf;
      ">
        "Their intuitive insights were incredibly helpful during a tough period in my life. I highly recommend their spiritual services."
      </p>
    </div>

    <div style="
      background: linear-gradient(145deg, rgba(245,197,24,0.08), rgba(255,255,255,0.05));
      border-radius: 24px;
      padding: 30px 25px;
      box-shadow:
        0 6px 18px rgba(245,197,24,0.25),
        inset 0 0 10px rgba(245,197,24,0.15);
      text-align: center;
      transition: transform 0.4s ease, box-shadow 0.4s ease;
      cursor: default;
      backdrop-filter: blur(12px);
    " onmouseover="this.style.transform='scale(1.06)'; this.style.boxShadow='0 10px 25px rgba(245,197,24,0.6), inset 0 0 20px rgba(245,197,24,0.35)';" onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 6px 18px rgba(245,197,24,0.25), inset 0 0 10px rgba(245,197,24,0.15)';">
      <img src="images/tm3.jpg" alt="Meera Joshi" style="
        width: 120px;
        height: 120px;
        border-radius: 50%;
        border: 4px solid #f5c518;
        object-fit: cover;
        margin-bottom: 20px;
        box-shadow:
          0 0 10px #f5c518;
      " />
      <h3 style="
        margin: 0 0 10px;
        font-weight: 800;
        color: #fff6c2;
        
      ">Henry</h3>
      <div style="color: #f5c518; font-size: 22px; margin-bottom: 18px;">★★★★★</div>
      <p style="
        font-style: italic;
        font-size: 17px;
        line-height: 1.5;
        color: #f0e9cf;
      ">
        "Accurate and compassionate readings. The guidance has brought me peace and clarity."
      </p>
    </div>

    <div style="
      background: linear-gradient(145deg, rgba(245,197,24,0.08), rgba(255,255,255,0.05));
      border-radius: 24px;
      padding: 30px 25px;
      box-shadow:
        0 6px 18px rgba(245,197,24,0.25),
        inset 0 0 10px rgba(245,197,24,0.15);
      text-align: center;
      transition: transform 0.4s ease, box-shadow 0.4s ease;
      cursor: default;
      backdrop-filter: blur(12px);
    " onmouseover="this.style.transform='scale(1.06)'; this.style.boxShadow='0 10px 25px rgba(245,197,24,0.6), inset 0 0 20px rgba(245,197,24,0.35)';" onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 6px 18px rgba(245,197,24,0.25), inset 0 0 10px rgba(245,197,24,0.15)';">
      <img src="images/tm4.jpg" alt="Arjun Patel" style="
        width: 120px;
        height: 120px;
        border-radius: 50%;
        border: 4px solid #f5c518;
        object-fit: cover;
        margin-bottom: 20px;
        box-shadow:
          0 0 10px #f5c518;
      " />
      <h3 style="
        margin: 0 0 10px;
        font-weight: 800;
        color: #fff6c2;
      
      ">Nova</h3>
      <div style="color: #f5c518; font-size: 22px; margin-bottom: 18px;">★★★★☆</div>
      <p style="
        font-style: italic;
        font-size: 17px;
        line-height: 1.5;
        color: #f0e9cf;
      ">
        "A wonderful experience. Their spiritual insights truly helped me find direction."
      </p>
    </div>

    <div style="
      background: linear-gradient(145deg, rgba(245,197,24,0.08), rgba(255,255,255,0.05));
      border-radius: 24px;
      padding: 30px 25px;
      box-shadow:
        0 6px 18px rgba(245,197,24,0.25),
        inset 0 0 10px rgba(245,197,24,0.15);
      text-align: center;
      transition: transform 0.4s ease, box-shadow 0.4s ease;
      cursor: default;
      backdrop-filter: blur(12px);
    " onmouseover="this.style.transform='scale(1.06)'; this.style.boxShadow='0 10px 25px rgba(245,197,24,0.6), inset 0 0 20px rgba(245,197,24,0.35)';" onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 6px 18px rgba(245,197,24,0.25), inset 0 0 10px rgba(245,197,24,0.15)';">
      <img src="images/tm8.jpg" alt="Sneha Verma" style="
        width: 120px;
        height: 120px;
        border-radius: 50%;
        border: 4px solid #f5c518;
        object-fit: cover;
        margin-bottom: 20px;
        box-shadow:
          0 0 10px #f5c518;
      " />
      <h3 style="
        margin: 0 0 10px;
        font-weight: 800;
        color: #fff6c2;
     
      ">Easton</h3>
      <div style="color: #f5c518; font-size: 22px; margin-bottom: 18px;">★★★★★</div>
      <p style="
        font-style: italic;
        font-size: 17px;
        line-height: 1.5;
        color: #f0e9cf;
      ">
        "Professional, empathetic, and truly insightful. Highly recommended."
      </p>
    </div>

  </div>
</section>
