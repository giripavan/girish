<section class="astro-section">
  <div class="astro-content">
    <h2>Know About MASTER SHIVAKUMAR?</h2>
    <p>
     Indian Astrology, also called Vedic Astrology or Jyotish, is an ancient system used to understand how the planets and stars affect our lives. It is based on the date, time, and place of birth. Indian Astrology uses a person’s birth chart, called a Kundli, to study their personality, future events, and life path. It includes 12 zodiac signs, 9 planets, and 27 lunar constellations (Nakshatras). It also focuses on karma and life purpose, helping people make better decisions in love, career, health, and more. Many people follow Indian Astrology for guidance, remedies, and peace of mind.
    </p>
    <p>
  Astrology is the observe of the have an effect on that remote cosmic objects,       generally stars and planets, have on human lives. A entire listing of all       elements of astrology. Includes: planetary phases, signs, constellations and a       way to interpret their meanings
    </p>
    <div class="experience">
      <span class="years">30</span> Years Experience
    </div>
    
  </div>

  <div class="astro-image-container">
    <div class="rotating-bg"></div>
    <img src="images/about-01.jpg" alt="Palm Reading" class="foreground-img" />
  </div>
</section>

<style>
  .astro-section {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 60px;
    position: relative;
    overflow: hidden;
    gap: 40px;
  }

  .astro-content {
    flex: 1;
    max-width: 50%;
  }

  .astro-content h2 {
    color: #ff8040;
    font-size: 36px;
    font-weight: bold;
  }

  .astro-content p {
    font-size: 16px;
    color: #444;
    margin-bottom: 15px;
    line-height: 1.6;
  }

  .experience {
    font-size: 24px;
    font-weight: 600;
    margin-top: 20px;
  }

  .years {
    font-size: 48px;
    font-weight: 800;
    color: #0a223d;
  }

  .signature {
    font-family: 'Brush Script MT', cursive;
    font-size: 28px;
    margin-top: 10px;
  }

  .astro-image-container {
    flex: 1;
    position: relative;
    max-width: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .rotating-bg {
    position: absolute;
    width: 400px;
    height: 400px;
    background-image: url('images/about-03.png');
    background-size: cover;
    background-position: center;
    border-radius: 50%;
    animation: rotate 40s linear infinite;
    z-index: 1;
  }

  .foreground-img {
    width: 300px;
    border-radius: 16px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
    position: relative;
    z-index: 2;
  }

  @keyframes rotate {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }

  /* Responsive: on smaller screens */
  @media (max-width: 768px) {
    .astro-section {
      flex-direction: column;
      padding: 30px 20px;
    }

    /* reorder image first */
    .astro-image-container {
      order: 1;
      max-width: 100%;
      margin-bottom: 30px;
    }

    .astro-content {
      order: 2;
      max-width: 100%;
    }

    .foreground-img {
      width: 100%;
      max-width: 350px;
      height: auto;
    }

    .rotating-bg {
      width: 300px;
      height: 300px;
      margin: 0 auto;
    }
  }
</style>
  <div class="dot" data-index="0"></div>
  <div class="dot" data-index="1"></div>
  <div class="dot" data-index="2"></div>
  <script>
    const testimonialTrack = document.getElementById('testimonialTrack');
    const dots = document.querySelectorAll('.dot');
    let currentIndex = 0;

    function goToSlide(index) {
      currentIndex = index;
      testimonialTrack.style.transform = `translateX(-${index * 100}%)`;
      updateDots();
    }

    function updateDots() {
      dots.forEach((dot, index) => {
        dot.style.backgroundColor = index === currentIndex ? 'white' : 'rgba(255,255,255,0.3)';
      });
    }
    dots.forEach((dot, index) => {
      dot.addEventListener('click', () => {
        goToSlide(index);
      });
    });
    updateDots();
  </script>

      
