<section class="pooja-section">
  <div class="section-heading">
    <h2>Divine Pooja Services</h2>
    <p>Experience spiritual transformation with our sacred rituals performed by expert priests</p>
  </div>
  
  <div class="pooja-slider" id="poojaSlider">
    <!-- Card 1 -->
    <div class="pooja-card">
      <div class="pooja-image">
        <img src="./images/ps5.jpg" alt="Ganapati Pooja">
      </div>
      <div class="pooja-content">
        <h3>Ganapati Pooja</h3>
        <p>Removes obstacles and brings success in new ventures</p>
        <div class="pooja-benefits">
          <ul>
            <li>Success in business</li>
            <li>Removes hurdles</li>
            <li>Improves concentration</li>
          </ul>
        </div>
        <div class="duration">2 hours</div>
                     <a href="contact-us.php" style="text-decoration: none; color: inherit;">
                       <button class="book-btn">Book Now</button>
                     </a>
      </div>
    </div>
    
    <!-- Card 2 -->
    <div class="pooja-card">
      <div class="pooja-image">
        <img src="./images/ps2.jpg" alt="Navagraha Pooja">
      </div>
      <div class="pooja-content">
        <h3>Navagraha Pooja</h3>
        <p>Pacifies all nine planets for overall wellbeing</p>
        <div class="pooja-benefits">
          <ul>
            <li>Balances planetary effects</li>
            <li>Improves health</li>
            <li>Brings peace</li>
          </ul>
        </div>
        <div class="duration">3 hours</div>
                       <a href="contact-us.php" style="text-decoration: none; color: inherit;">
                       <button class="book-btn">Book Now</button>
                     </a>
        </div>
    </div>
    
    <!-- Card 3 -->
    <div class="pooja-card">
      <div class="pooja-image">
        <img src="./images/ps3.jpg" alt="Satyanarayana Pooja">
      </div>
      <div class="pooja-content">
        <h3>Satyanarayana Pooja</h3>
        <p>For prosperity and fulfillment of wishes</p>
        <div class="pooja-benefits">
          <ul>
            <li>Financial stability</li>
            <li>Happy family life</li>
            <li>Wish fulfillment</li>
          </ul>
        </div>
        <div class="duration">4 hours</div>
                  <a href="contact-us.php" style="text-decoration: none; color: inherit;">
                    <button class="book-btn">Book Now</button>
                  </a>
      </div>
    </div>
    
    <!-- Card 4 -->
    <div class="pooja-card">
      <div class="pooja-image">
        <img src="./images/ps4.jpg" alt="Lakshmi Kubera Pooja">
      </div>
      <div class="pooja-content">
        <h3>Lakshmi Kubera Pooja</h3>
        <p>For wealth and financial stability</p>
        <div class="pooja-benefits">
          <ul>
            <li>Wealth growth</li>
            <li>Removes financial blocks</li>
            <li>Prosperity</li>
          </ul>
        </div>
        <div class="duration">2.5 hours</div>
                     <a href="contact-us.php" style="text-decoration: none; color: inherit;">
                       <button class="book-btn">Book Now</button>
                     </a>
      </div>
    </div>
  </div>
  
  <div class="slider-nav">
    <button onclick="scrollSlider(-1)">❮</button>
    <button onclick="scrollSlider(1)">❯</button>
  </div>
</section>

<style>
  .pooja-section {
    padding: 80px 20px;
    background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
    position: relative;
    overflow: hidden;
  }
  
  .section-heading {
    text-align: center;
    margin-bottom: 50px;
    position: relative;
  }
  
  .section-heading h2 {
    font-size: 2.5rem;
    color: #3a3a3a;
    margin-bottom: 15px;
    display: inline-block;
    position: relative;
  }
  
  .section-heading h2:after {
    content: "";
    position: absolute;
    width: 60px;
    height: 4px;
    background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    border-radius: 2px;
  }
  
  .section-heading p {
    color: #666;
    font-size: 1.1rem;
    max-width: 700px;
    margin: 0 auto;
  }
  
  .pooja-slider {
    display: flex;
    gap: 25px;
    padding: 20px 0;
    overflow-x: auto;
    scroll-snap-type: x mandatory;
    scrollbar-width: none;
  }
  
  .pooja-slider::-webkit-scrollbar {
    display: none;
  }
  
  .pooja-card {
    min-width: calc(25% - 20px);
    scroll-snap-align: start;
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
    transition: transform 0.5s ease, box-shadow 0.3s ease;
    animation: slideIn 0.8s ease-out forwards;
    opacity: 0;
    transform: translateY(30px);
  }
  
  @keyframes slideIn {
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  
  .pooja-image {
    height: 300px;
    overflow: hidden;
    position: relative;
  }
  
  .pooja-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.8s ease;
  }
  
  .pooja-card:hover .pooja-image img {
    transform: scale(1.1);
  }
  
  .pooja-content {
    padding: 25px;
  }
  
  .pooja-content h3 {
    margin: 0 0 15px 0;
    color: #3a3a3a;
    font-size: 1.4rem;
    position: relative;
    padding-bottom: 10px;
  }
  
  .pooja-content h3:after {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    width: 40px;
    height: 3px;
    background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  }
  
  .pooja-benefits li {
    margin-bottom: 8px;
    position: relative;
    padding-left: 25px;
    list-style: none;
    line-height: 1.5;
    color: #555;
  }
  
  .pooja-benefits li:before {
    content: "✓";
    color: #4CAF50;
    position: absolute;
    left: 0;
    font-weight: bold;
  }
  
  .duration {
    display: inline-block;
    padding: 6px 12px;
    background: rgba(118, 75, 162, 0.1);
    border-radius: 20px;
    color: #764ba2;
    font-weight: 500;
    margin-bottom: 20px;
    font-size: 0.9rem;
  }
  
  .book-btn {
    width: 100%;
    padding: 12px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    font-size: 1rem;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(118, 75, 162, 0.2);
  }
  
  .book-btn:hover {
    background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(118, 75, 162, 0.3);
  }
  
  .slider-nav {
    display: flex;
    justify-content: center;
    margin-top: 30px;
    gap: 15px;
  }
  
  .slider-nav button {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    border: none;
    background: #764ba2;
    color: white;
    font-size: 1.2rem;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .slider-nav button:hover {
    background: #667eea;
    transform: scale(1.1);
  }
  
  @media (max-width: 1200px) {
    .pooja-card {
      min-width: calc(33.33% - 20px);
    }
  }
  
  @media (max-width: 768px) {
    .pooja-card {
      min-width: calc(50% - 15px);
    }
  }
  
  @media (max-width: 576px) {
    .pooja-card {
      min-width: 85%;
    }
  }
</style>

<script>
  function scrollSlider(direction) {
    const slider = document.getElementById("poojaSlider");
    const scrollAmount = slider.clientWidth * 0.8 * direction;
    slider.scrollBy({ left: scrollAmount, behavior: "smooth" });
  }
  
  // Initialize animations
  document.addEventListener("DOMContentLoaded", function() {
    const cards = document.querySelectorAll(".pooja-card");
    cards.forEach((card, index) => {
      setTimeout(() => {
        card.style.animation = "slideIn 0.6s ease-out forwards";
        card.style.animationDelay = (index * 0.15) + "s";
      }, 100);
    });
  });
</script>