<section class="why-choose-us">
  <h2><span class="highlight">Why</span> Choose Us</h2>
  <p class="subtitle" style="color:white";>
    Our expert has more than 18 years of experience in the field of astrology and has a successful
    practice running globally with clients from individuals to industrialists and like.
  </p>

  <div class="features-grid">
    <div class="feature-box">
      <div class="icon-circle"><i class="fas fa-user-tie"></i></div>
      <p>Renowned Expert Astrologer</p>
    </div>
    <div class="feature-box">
      <div class="icon-circle"><i class="fas fa-phone-alt"></i><span class="mini"></span></div>
      <p>24x7, 365 Days Availability</p>
    </div>
    <div class="feature-box">
      <div class="icon-circle"><i class="fas fa-users"></i></div>
      <p>Instant Access Worldwide</p>
    </div>
    <div class="feature-box">
      <div class="icon-circle"><i class="fas fa-handshake"></i></div>
      <p>Accurate Remedial Solutions</p>
    </div>
    <div class="feature-box">
      <div class="icon-circle"><i class="fas fa-user-lock"></i></div>
      <p>Privacy Guaranteed</p>
    </div>
    <div class="feature-box">
      <div class="icon-circle"><i class="fas fa-user-friends"></i></div>
      <p>Trusted by million clients</p>
    </div>
  </div>
</section>

<!-- Font Awesome CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
  .why-choose-us {
    background-color: rgba(246, 246, 246, 0);
    text-align: center;
    padding: 60px 20px;
    font-family: 'Segoe UI', sans-serif;
  }

  .why-choose-us h2 {
    font-size: 36px;
    font-weight: bold;
    margin-bottom: 10px;
  }

  .why-choose-us .highlight {
    color: #ff6600;
  }

  .why-choose-us .subtitle {
    max-width: 800px;
    margin: 0 auto 40px;
    font-size: 18px;
    color: #555;
    line-height: 1.6;
  }

  .features-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr); /* Always 2 columns */
    gap: 30px;
    justify-items: start; /* Left aligned on desktop */
    max-width: 1000px;
    margin: 0 auto;
  }

  .feature-box {
    display: flex;
    align-items: center;
    background: hsla(0, 0%, 0%, 0.00);
    border-radius: 10px;
    padding: 15px 40px;
    box-shadow: 0 4px 10px hsla(0, 0%, 0%, 0.00);
    transition: 0.3s;
    max-width: 420px;
    width: 100%;
  }

  .feature-box:hover {
    transform: translateY(-5px);
  }

  .icon-circle {
    background-color: #ff6600;
    color: white;
    border-radius: 50%;
    width: 70px;
    height: 70px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 30px;
    margin-right: 20px;
    position: relative;
  }

  .icon-circle .mini {
    font-size: 12px;
    position: absolute;
    bottom: 8px;
    right: 10px;
  }

  .feature-box p {
    margin: 0;
    font-size: 16px;
    text-align: left;
  }

  @media (max-width: 768px) {
    .features-grid {
      grid-template-columns: 1fr; /* 1 column on small screens */
      justify-items: center;
    }

    .feature-box {
      justify-content: flex-start;
    }
  }
</style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">