<link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />

<style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #0d0d2b;
      color: white;
    }

    .contact-section {
      display: flex;
      flex-wrap: wrap;
      padding: 60px 20px;
      max-width: 1200px;
      margin: auto;
      gap: 30px;
    }

    .contact-form {
      flex: 1;
      min-width: 320px;
    }

    .contact-form h2 {
      margin-bottom: 20px;
      color: #ff9900;
    }

    .contact-form input,
    .contact-form select,
    .contact-form textarea {
      width: 100%;
      padding: 12px;
      margin-bottom: 15px;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      background-color: #1f1f3d;
      color: white;
    }

    .contact-form textarea {
      resize: vertical;
      min-height: 120px;
    }

    .contact-form button {
      padding: 12px 30px;
      font-size: 16px;
      border: none;
      background-color: #ff9900;
      color: white;
      border-radius: 6px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .contact-form button:hover {
      background-color: #e68100;
    }

    .map-container {
      flex: 1;
      min-width: 320px;
    }

    .map-container iframe {
      width: 100%;
      height: 100%;
      min-height: 450px;
      border: none;
      border-radius: 10px;
    }

    @media (max-width: 768px) {
      .contact-section {
        flex-direction: column;
      }
    }
  </style>
</head>
<body>

  <section class="contact-section">
    <!-- Left: Contact Form -->
    <div class="contact-form" data-aos="fade-right">
      <h2>Contact Us</h2>
      <form action="#">
        <input type="text" placeholder="Your Name" required />
        <input type="tel" placeholder="Your Phone" required />
        <input type="email" placeholder="Your Email" required />
        <select required>
          <option value="">Select Service</option>
          <option value="love">Love Problem</option>
          <option value="blackmagic">Black Magic Removal</option>
          <option value="marriage">Marriage Solution</option>
          <option value="career">Career Issues</option>
        </select>
        <textarea placeholder="Your Message" required></textarea>
        <button type="submit">Send Message</button>
      </form>
    </div>

    <!-- Right: Map -->
    <div class="map-container" data-aos="fade-up">
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3315.961862361799!2d-84.32584568478266!3d33.818239580670535!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88f506d8490226cb%3A0x38c6d63f16e02e95!2s2190%20Briarcliff%20Rd%20NE%2C%20Atlanta%2C%20GA%2030329%2C%20USA!5e0!3m2!1sen!2sin!4v1717583740902!5m2!1sen!2sin"
        allowfullscreen=""
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade"
      ></iframe>
    </div>
  </section>

  <!-- AOS JS -->
  <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
  <script>
    AOS.init({
      duration: 1000, // Animation duration (ms)
      once: true,     // Animation happens only once while scrolling down
    });
  </script>
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />