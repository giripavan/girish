<section class="section-wrapper">
    <h1>Expert Astrology Services</h1>

    <!-- 1 -->
    <div class="service-box">
      <div class="service-image">
        <img src="./images/love.png" alt="Love Problem" />
      </div>
      <div class="service-content">
        <h2>Love Problem</h2>
        <p>Unlock the secrets of your future with our expert Vedic astrology consultations. From love and relationships our guidance is rooted in ancient wisdom just for you.</p>
        <button class="read-more" onclick="location.href='contact.html'">Read More</button>
      </div>
    </div>

    <!-- 2 -->
    <div class="service-box reverse">
      <div class="service-image">
        <img src="./images/marriage.png" alt="Marriage Compatibility" />
      </div>
      <div class="service-content">
        <h2>Marriage Compatibility</h2>
        <p>Get insights into your marital journey through detailed Kundali matching and astrological analysis. Discover your ideal life partner with ancient Vedic wisdom.</p>
        <button class="read-more" onclick="location.href='contact.html'">Read More</button>
      </div>
    </div>

    <!-- 3 -->
    <div class="service-box">
      <div class="service-image">
        <img src="./images/job.png" alt="Career Guidance" />
      </div>
      <div class="service-content">
        <h2>Career Guidance</h2>
        <p>Let astrology guide your career path. Identify opportunities, overcome obstacles, and align your work with planetary influences for success and satisfaction.</p>
        <button class="read-more" onclick="location.href='contact.html'">Read More</button>
      </div>
    </div>

    <!-- 4 -->
    <div class="service-box reverse">
      <div class="service-image">
        <img src="./images/business.png" alt="Business Solutions" />
      </div>
      <div class="service-content">
        <h2>Business Solutions</h2>
        <p>Explore astrological remedies for business growth, partnership harmony, and financial stability. Consult to align your ventures with auspicious timings.</p>
        <button class="read-more" onclick="location.href='contact.html'">Read More</button>
      </div>
    </div>

    <!-- 5 -->
    <div class="service-box">
      <div class="service-image">
        <img src="./images/blackmagic.png" alt="Black Magic Removal" />
      </div>
      <div class="service-content">
        <h2>Black Magic Removal</h2>
        <p>Protect yourself from negative energies and black magic influences. Our powerful rituals and mantras cleanse and safeguard your spiritual aura.</p>
        <button class="read-more" onclick="location.href='contact.html'">Read More</button>
      </div>
    </div>

    <!-- 6 -->
    <div class="service-box reverse">
      <div class="service-image">
        <img src="./images/health.png" alt="Health Astrology" />
      </div>
      <div class="service-content">
        <h2>Health & Wellness</h2>
        <p>Discover health insights through astrology. Understand the planetary causes of ailments and get remedies to restore balance and vitality in life.</p>
        <button class="read-more" onclick="location.href='contact.html'">Read More</button>
      </div>
    </div>

    <!-- 7 -->
    <div class="service-box">
      <div class="service-image">
        <img src="./images/childbirth.png" alt="Childbirth Solutions" />
      </div>
      <div class="service-content">
        <h2>Childbirth Issues</h2>
        <p>Resolve problems related to childbirth with astrological remedies. We offer spiritual guidance to remove doshas and bring joy into your family.</p>
        <button class="read-more" onclick="location.href='contact.html'">Read More</button>
      </div>
    </div>

    <!-- 8 -->
    <div class="service-box reverse">
      <div class="service-image">
        <img src="./images/vastu.png" alt="Vastu Consultation" />
      </div>
      <div class="service-content">
        <h2>Vastu Consultation</h2>
        <p>Balance the energies of your home or workplace with Vastu. Our experts analyze and correct structural and energetic imbalances for peace and prosperity.</p>
        <button class="read-more" onclick="location.href='contact.html'">Read More</button>
      </div>
    </div>

    <!-- 9 -->
    <div class="service-box">
      <div class="service-image">
        <img src="./images/horoscope.png" alt="Daily Horoscope" />
      </div>
      <div class="service-content">
        <h2>Daily Horoscope</h2>
        <p>Start your day with the guidance of your stars. Our daily horoscope readings help you plan, prepare, and make the most of each moment in alignment with the cosmos.</p>
        <button class="read-more" onclick="location.href='contact.html'">Read More</button>
      </div>
    </div>

</section>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({
      duration: 800,
      once: true
    });
  </script>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({
      duration: 800,
      once: true
    });
  </script>
  
   <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: rgba(28, 28, 60, 1);
      color: white;
    }

    .section-wrapper {
      padding: 30px 15px;
      text-align: center;
    }

    .section-wrapper h1 {
      font-size: 28px;
      color: #ffc107;
      margin-bottom: 25px;
    }

    .service-box {
      display: flex;
      max-width: 750px;
      min-height: 250px;
      background-color: rgba(42, 42, 80, 0.3);
      border-radius: 16px;
      margin: 25px auto;
      overflow: hidden;
      align-items: center;
    }

    .service-box.reverse {
      flex-direction: row-reverse;
    }

    .service-image,
    .service-content {
      flex: 1;
      height: 100%;
    }

    .service-image img {
      width: 300px;
      height:250px;
      object-fit: cover;
      display: block;
    }

    .service-content {
      padding: 20px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      text-align: left;
      box-sizing: border-box;
    }

    .service-content h2 {
      font-size: 20px;
      color: #ffa726;
      margin-bottom: 10px;
    }

    .service-content p {
      font-size: 14px;
      line-height: 1.5;
      color: #e0e0e0;
      margin-bottom: 12px;
      text-align: justify;
    }

    .read-more {
      background-color: #ff9800;
      border: none;
      padding: 7px 14px;
      color: #fff;
      font-weight: bold;
      font-size: 13px;
      border-radius: 6px;
      cursor: pointer;
      transition: background 0.3s;
      align-self: flex-start;
    }

    .read-more:hover {
      background-color: #e68900;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .service-box,
      .service-box.reverse {
        flex-direction: column;
        max-width: 95%;
      }

      .service-image img {
        height: 200px;
      }

      .service-content {
        text-align: center;
        padding: 15px;
      }

      .service-content h2 {
        font-size: 16px;
      }

      .service-content p {
        font-size: 13px;
        text-align: justify;
      }

      .read-more {
        align-self: center;
      }
    }
  </style>

