<section class="hours-section">
    <div class="section-heading">JUST MAKE AN APPOINTMENT & YOU’RE DONE!</div>
    <div class="hours-container">
      <div class="hours-left">
        <img src="images/img1.jpg" alt="" />
        <img src="images/img2.jpg" alt="" />
        <img src="images/img3.jpg" alt="" />
        <div class="quote-box">
          <h2>Life Is Full Of Possibilities.<br />Time To Embrace Them!</h2>
        </div>
      </div>
      <div class="hours-right">
        <h4></h4>
        <h1>Opening Hours</h1>
        <p class="astro-description">
  Known for compassionate listening and powerful solutions, the astrologer has helped countless individuals overcome challenges in love, marriage, career, health, and family matters.
        </p>
        <div class="day-row">
          <i>⏰</i>
          <div>
            <h3>SUNDAY TO SATURDAY</h3>
            <p>11:00 Am - 5:00 Pm</p>
          </div>
        </div> 
      </div>
    </div>
</section> 
<style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
    }

    .hours-section {
      background: linear-gradient(to right, #cc2a66, #e73c7e);
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 80px 0;
      flex-direction: column;
    }

    .section-heading {
      font-size: 32px;
      font-weight: bold;
      text-transform: uppercase;
      margin-bottom: 40px;
    }

    .hours-container {
      display: flex;
      flex-direction: row;
      max-width: 1300px;
      width: 100%;
      padding: 0 30px;
      justify-content: space-between;
      align-items: flex-start;
      gap: 40px;
      flex-wrap: wrap;
    }
    .astro-description {
  text-align: justify;
  font-size: 18px;
  line-height: 1.8;
  color: #ffffff; /* or any preferred color */
  max-width: 800px;
  margin: 0 auto;
  padding: 10px 20px;
  }

    .hours-left {
      position: relative;
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      justify-content: center;
      max-width: 600px;
      margin-left: 170px; /* Shift right on desktop */
    }

    .hours-left img {
      width: 100px;
      height: 250px;
      object-fit: cover;
      margin-top: 40px; /* Push images down on desktop */
    }

    .hours-left .quote-box {
      position: absolute;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
      background-color: #33003d;
      padding: 20px 30px;
      text-align: center;
      z-index: 1;
      width: max-content;
    }

    .hours-left .quote-box h2 {
      margin: 0;
      font-size: 24px;
      line-height: 1.4;
    }

    .hours-right {
      max-width: 600px;
    }

    .hours-right h4 {
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 10px;
    }

    .hours-right h1 {
      font-size: 48px;
      margin: 0 0 20px;
    }

    .hours-right p {
      font-size: 16px;
      line-height: 1.6;
      margin-bottom: 30px;
    }

    .day-row {
      display: flex;
      align-items: center;
      gap: 15px;
      margin-bottom: 20px;
    }

    .day-row i {
      font-size: 24px;
    }

    .day-row div h3 {
      margin: 0;
      font-size: 18px;
      font-weight: bold;
    }

    .day-row div p {
      margin: 0;
      font-size: 15px;
    }

    @media (max-width: 768px) {
      .hours-container {
        flex-direction: column;
        align-items: center;
        text-align: center;
      }

      .hours-right {
        padding-top: 10px;
      }

      .hours-left .quote-box {
        width: 90%;
        padding: 15px 20px;
      }

      .hours-left .quote-box h2 {
        font-size: 18px;
      }

      .hours-left img {
        width: 85px;
        height: 200px;
        margin-top: 0; /* Reset margin-top on mobile */
      }

      .hours-left {
        margin-left: 0; /* Reset margin on mobile */
      }
    }
</style>