 <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Open Sans', sans-serif;
      background-color: #2e003e;
      color: #fff;
      text-align: center;
    }

    .section-heading {
      padding-top: 40px;
    }

    .section-heading span {
      color: #f6246b;
      font-weight: bold;
      text-transform: uppercase;
      font-size: 16px;
    }

    .section-heading h1 {
      font-family: 'Playfair Display', serif;
      font-size: 36px;
      margin: 10px 0;
    }

    .section-heading p {
      font-size: 16px;
      max-width: 600px;
      margin: 0 auto;
      color: #d3c3d3;
    }

    .zodiac-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      margin-top: 50px;
      gap: 40px;
      padding: 0 20px 60px;
    }

    .zodiac-card {
      width: 120px;
    }

    .zodiac-card img {
      width: 100%;
      height: auto;
      filter: brightness(1.2);
    }

    .zodiac-card hr {
      border: none;
      height: 2px;
      background: #fff;
      margin: 10px 0;
      position: relative;
      overflow: hidden;
    }

    .zodiac-card hr::after {
      content: "→";
      position: absolute;
      left: -20px;
      top: -4px;
      color: white;
      font-size: 18px;
      animation: moveArrow 2s linear infinite;
    }

    @keyframes moveArrow {
      0% {
        left: -20px;
        opacity: 0;
      }
      25% {
        opacity: 1;
      }
      100% {
        left: 100%;
        opacity: 0;
      }
    }

    .zodiac-card h3 {
      font-size: 18px;
      margin: 10px 0 5px;
      font-family: 'Playfair Display', serif;
    }

    .zodiac-card p {
      font-size: 14px;
      color: #ccc;
      margin: 0;
    }
  </style>
</head>
<body>

  <section class="section-heading">
    <span>Choose Zodiac Sign</span>
    <h1>The Starry Vault Of Heaven Is In Truth The Open<br>Book Of Cosmic Projection</h1>
    <p>Lorem Ipsum Dolor Sit Amet Consectetur. Auctor Tristique Malesuada Arcu.</p>
  </section>

  <section class="zodiac-container">
    <div class="zodiac-card">
      <img src="https://i.ibb.co/xDTpmsh/aries.png" alt="Aries">
      <hr>
      <h3>Aries</h3>
      <p>Mar 21-Apr 19</p>
    </div>
    <div class="zodiac-card">
      <img src="https://i.ibb.co/JkRDRx9/taurus.png" alt="Taurus">
      <hr>
      <h3>Taurus</h3>
      <p>Apr 20-May 20</p>
    </div>
    <div class="zodiac-card">
      <img src="https://i.ibb.co/2NKJ5Rc/gemini.png" alt="Gemini">
      <hr>
      <h3>Gemini</h3>
      <p>May 21-Jun 20</p>
    </div>
    <div class="zodiac-card">
      <img src="https://i.ibb.co/h1yKbct/cancer.png" alt="Cancer">
      <hr>
      <h3>Cancer</h3>
      <p>Jun 21-Jul 22</p>
    </div>
    <div class="zodiac-card">
      <img src="https://i.ibb.co/VtJjsDx/leo.png" alt="Leo">
      <hr>
      <h3>Leo</h3>
      <p>Jul 23-Aug 22</p>
    </div>
    <div class="zodiac-card">
      <img src="https://i.ibb.co/q5B9rWY/virgo.png" alt="Virgo">
      <hr>
      <h3>Virgo</h3>
      <p>Aug 23-Sep 22</p>
    </div>
    <div class="zodiac-card">
      <img src="https://i.ibb.co/3pPyYB7/libra.png" alt="Libra">
      <hr>
      <h3>Libra</h3>
      <p>Sep 23-Oct 22</p>
    </div>
    <div class="zodiac-card">
      <img src="https://i.ibb.co/NKX9HJj/scorpio.png" alt="Scorpio">
      <hr>
      <h3>Scorpio</h3>
      <p>Oct 23-Nov 21</p>
    </div>
    <div class="zodiac-card">
      <img src="https://i.ibb.co/GM4czBL/sagittarius.png" alt="Sagittarius">
      <hr>
      <h3>Sagittarius</h3>
      <p>Nov 22-Dec 21</p>
    </div>
    <div class="zodiac-card">
      <img src="https://i.ibb.co/vqXZvX5/capricorn.png" alt="Capricorn">
      <hr>
      <h3>Capricorn</h3>
      <p>Dec 22-Jan 19</p>
    </div>
    <div class="zodiac-card">
      <img src="https://i.ibb.co/Z1Rr9x8/aquarius.png" alt="Aquarius">
      <hr>
      <h3>Aquarius</h3>
      <p>Jan 20-Feb 18</p>
    </div>
    <div class="zodiac-card">
      <img src="https://i.ibb.co/Ycw6rfy/pisces.png" alt="Pisces">
      <hr>
      <h3>Pisces</h3>
      <p>Feb 19-Mar 20</p>
    </div>
  </section>