<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Astrologer In Texas</title>
  <?php include 'header.php'; ?>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: url('./images/n4.jpg') no-repeat center center fixed;
      background-size: cover;
    }

    /* Marquee Slider Styles */
    .marquee-slider {
      position: relative;
      width: 100%;
      max-width: 1600px;
      margin: auto;
      overflow: hidden;
      aspect-ratio: 16 / 9; /* Keeps aspect ratio on desktop */
    }

    .marquee-slider img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      position: absolute;
      top: 0;
      left: 0;
      opacity: 0;
      transition: opacity 2s ease-in-out;
    }

    .marquee-slider img.active {
      opacity: 1;
      z-index: 1;
    }

    @media (max-width: 768px) {
      .marquee-slider {
        aspect-ratio: 4 / 3; /* Taller ratio for mobile */
      }
    }
  </style>
</head>
<body>

<!-- Marquee Slider -->
<div class="marquee-slider" id="marqueeSlider">
  <img src="./images/b1.jpg" alt="Banner 1" class="active" />
  <img src="./images/bn2.jpg" alt="Banner 2" />
  <img src="./images/bn3.jpg" alt="Banner 3" />
</div>

<!-- Include Sections -->
<?php include 'zodiac.php'; ?>
<?php include 'why.php'; ?>
<?php include 'services.php'; ?>
<?php include 'one.php'; ?>
<?php include 'testinomials.php'; ?>
<?php include 'two.php'; ?>
<?php include 'footer.php'; ?>

<!-- Slider Script -->
<script>
  const images = document.querySelectorAll('#marqueeSlider img');
  let current = 0;

  setInterval(() => {
    images[current].classList.remove('active');
    current = (current + 1) % images.length;
    images[current].classList.add('active');
  }, 5000); // Change slide every 5 seconds
</script>

</body>
</html>
