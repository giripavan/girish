
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #0d0d2b;
      color: white;
      overflow-x: hidden;
    }

    .testimonial-section {
      display: flex;
      align-items: center;
      position: relative;
      height: 430px;
      overflow: hidden;
      padding: 40px;
    }

    .slider-container {
      width: calc(100% - 340px);
      overflow: hidden;
      position: relative;
      z-index: 1;
    }

    .testimonial-row {
      display: flex;
      gap: 20px;
      animation: slideLeft 30s linear infinite;
    }

    @keyframes slideLeft {
      0% { transform: translateX(0); }
      100% { transform: translateX(-100%); }
    }

    .testimonial-card {
      background-color: #1a1a3d;
      border-radius: 10px;
      padding: 20px;
      width: 300px;
      min-width: 300px;
      box-shadow: 0 0 10px rgba(255, 255, 255, 0.1);
      flex-shrink: 0;
      text-align: center;
    }

    .testimonial-card img {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      object-fit: cover;
      margin-bottom: 10px;
      border: 2px solid #ffd700;
    }

    .testimonial-card h4 {
      margin: 0 0 10px;
      color: #ffd700;
    }

    .testimonial-card p {
      font-size: 14px;
      color: #ccc;
    }

    .right-image {
      position: absolute;
      right: 10px;
      top: 0;
      bottom: 0;
      width: 340px;
      background: url('./images/bb1.jpg') no-repeat center center;
      background-size: cover;
      opacity: 1.2;
      z-index: 0;
      padding-right: 40px;
    }

    @media (max-width: 768px) {
      .testimonial-section {
        flex-direction: column;
        height: auto;
      }

      .slider-container {
        width: 100%;
        margin: 0;
      }

      .right-image {
        display: none;
      }

      .testimonial-row {
        animation: none;
        flex-wrap: wrap;
        justify-content: center;
      }
    }
  </style>
</head>
<body>

<section class="testimonial-section">
  <div class="slider-container">
    <div class="testimonial-row">
      <div class="testimonial-card">
        <img src="https://randomuser.me/api/portraits/men/11.jpg" alt="Ravi Kumar">
        <h4>Ravi Kumar</h4>
        <p>Astrologer Sanju helped me get back on track in life. Amazing predictions!</p>
      </div>
      <div class="testimonial-card">
        <img src="https://randomuser.me/api/portraits/women/12.jpg" alt="Sneha Patil">
        <h4>Sneha Patil</h4>
        <p>Very accurate and insightful! Definitely recommended for love problems.</p>
      </div>
      <div class="testimonial-card">
        <img src="https://randomuser.me/api/portraits/men/22.jpg" alt="Mohammed Asif">
        <h4>Mohammed Asif</h4>
        <p>His remedies actually worked for me. Deeply thankful for his guidance.</p>
      </div>
      <div class="testimonial-card">
        <img src="https://randomuser.me/api/portraits/women/32.jpg" alt="Divya Reddy">
        <h4>Divya Reddy</h4>
        <p>I was facing family issues, and his advice brought peace back home.</p>
      </div>
      <div class="testimonial-card">
        <img src="https://randomuser.me/api/portraits/men/45.jpg" alt="Kiran Sharma">
        <h4>Kiran Sharma</h4>
        <p>Simple, sincere, and powerful predictions that gave me clarity.</p>
      </div>
      <div class="testimonial-card">
        <img src="https://randomuser.me/api/portraits/women/55.jpg" alt="Priya Iyer">
        <h4>Priya Iyer</h4>
        <p>My career path was unclear, but with his help, I made the right decision.</p>
      </div>
    </div>
  </div>

  <div class="right-image"></div>
</section>




<!-- AOS JS -->
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({
    duration: 900,
    once: true,
    easing: 'ease-in-out',
  });
</script>
