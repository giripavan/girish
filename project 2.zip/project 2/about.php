<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>About Us - Celestial Insights</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
  <?php include 'header.php'; ?>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Montserrat', sans-serif;
      background: #0d0d2b;
      color: white;
      line-height: 1.6;
    }
    .hero {
      background: url('https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0') no-repeat center center/cover;
      height: 60vh;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
    }
    .hero h1 {
      font-size: 3rem;
      color: #fff;
      background: rgba(0,0,0,0.6);
      padding: 20px 40px;
      border-radius: 10px;
    }
    .container {
      max-width: 1200px;
      margin: auto;
      padding: 60px 20px;
    }
    .about-section {
      display: flex;
      flex-wrap: wrap;
      gap: 40px;
      align-items: center;
    }
    .about-image {
      flex: 1;
    }
    .about-image img {
      width: 100%;
      border-radius: 20px;
    }
    .about-content {
      flex: 1;
    }
    .about-content h2 {
      font-size: 2.5rem;
      margin-bottom: 20px;
      color: #ff9d00;
    }
    .about-content p {
      font-size: 1.1rem;
      color: #ccc;
    }
    .counters {
      display: flex;
      justify-content: space-around;
      margin-top: 60px;
    }
    .counter-box {
      text-align: center;
    }
    .counter-box h3 {
      font-size: 2rem;
      color: #ff9d00;
    }
    .counter-box p {
      color: #aaa;
    }
    .mission-section {
      display: flex;
      gap: 30px;
      flex-wrap: wrap;
      margin-top: 80px;
    }
    .mission-box {
      background: #1e1e3f;
      flex: 1;
      padding: 30px;
      border-radius: 15px;
      text-align: center;
    }
    .mission-box i {
      font-size: 2rem;
      color: #ff9d00;
      margin-bottom: 15px;
    }
    .mission-box h4 {
      font-size: 1.5rem;
      margin-bottom: 10px;
    }
    .team {
      margin-top: 80px;
    }
    .team h2 {
      text-align: center;
      font-size: 2.5rem;
      margin-bottom: 40px;
      color: #ff9d00;
    }
    .team-members {
      display: flex;
      gap: 30px;
      flex-wrap: wrap;
      justify-content: center;
    }
    .member {
      background: #1a1a3b;
      padding: 20px;
      border-radius: 15px;
      width: 250px;
      text-align: center;
      transition: transform 0.3s;
    }
    .member:hover {
      transform: translateY(-10px);
    }
    .member img {
      width: 100px;
      border-radius: 50%;
      margin-bottom: 15px;
    }
    .member h4 {
      color: #fff;
    }
    .member p {
      color: #aaa;
    }

    @media (max-width: 768px) {
      .about-section,
      .mission-section,
      .counters {
        flex-direction: column;
        text-align: center;
      }
    }
  </style>
</head>
<body>

  <!-- Hero Section -->
  <section class="hero">
    <h1>About Celestial Insights</h1>
  </section>

  <!-- Main Container -->
  <div class="container">

    <!-- About Section -->
    <div class="about-section">
      <div class="about-image">
        <img src="https://images.unsplash.com/photo-1557682224-5b8590cd9ec5" alt="About Us">
      </div>
      <div class="about-content">
        <h2>Who We Are</h2>
        <p>At Celestial Insights, we combine ancient wisdom with modern intuition. With over 18 years of experience, our astrologers have guided thousands across the globe on love, career, spiritual, and personal growth journeys. We believe in clarity, transformation, and purpose-driven living.</p>
      </div>
    </div>

    <!-- Counter Section -->
    <div class="counters">
      <div class="counter-box">
        <h3>18+</h3>
        <p>Years Experience</p>
      </div>
      <div class="counter-box">
        <h3>25K+</h3>
        <p>Clients Served</p>
      </div>
      <div class="counter-box">
        <h3>80+</h3>
        <p>Countries Reached</p>
      </div>
    </div>

    <!-- Mission / Vision -->
    <div class="mission-section">
      <div class="mission-box">
        <i class="fas fa-eye"></i>
        <h4>Our Vision</h4>
        <p>To become a beacon of spiritual clarity and astrological guidance for people worldwide.</p>
      </div>
      <div class="mission-box">
        <i class="fas fa-bullseye"></i>
        <h4>Our Mission</h4>
        <p>To provide accurate, personalized, and transformative astrological solutions for every life concern.</p>
      </div>
    </div>

    <!-- Team Section -->
    <div class="team">
      <h2>Meet Our Experts</h2>
      <div class="team-members">
        <div class="member">
          <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Expert">
          <h4>Pandit Lakshman</h4>
          <p>Chief Astrologer</p>
        </div>
        <div class="member">
          <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Expert">
          <h4>Yamuna Devi</h4>
          <p>Love Specialist</p>
        </div>
        <div class="member">
          <img src="https://randomuser.me/api/portraits/men/58.jpg" alt="Expert">
          <h4>Guru Anand</h4>
          <p>Vastu Consultant</p>
        </div>
      </div>
    </div>

  </div>

  <!-- Font Awesome for icons -->
  <script src="https://kit.fontawesome.com/a2e0f1f0b5.js" crossorigin="anonymous"></script>
</body>
</html>
