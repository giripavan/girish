<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Astrology Locations</title>
  <?php include 'header.php'; ?>
  <style>
    body {
      margin: 0;
      font-family: 'Georgia', serif;
      background: linear-gradient(to bottom, #1c0029, #3a0d52);
      color: white;
      overflow-x: hidden;
    }

    .astro-location-container {
      display: flex;
      flex-wrap: wrap;
      min-height: 100vh;
      align-items: center;
      padding: 60px 30px;
      background: url('https://www.transparenttextures.com/patterns/stardust.png'), radial-gradient(circle at top, #280030, #12001e);
    }

    .astro-text {
      flex: 1;
      min-width: 300px;
      padding: 20px 40px;
    }

    .astro-text h2 {
      font-size: 40px;
      color: #f8d148;
      margin-bottom: 20px;
      text-shadow: 2px 2px #000;
    }

    .astro-text p {
      font-size: 18px;
      line-height: 1.6;
      color: #ddd;
      margin-bottom: 15px;
    }

    .astro-highlight {
      background: rgba(255, 255, 255, 0.08);
      padding: 15px;
      border-left: 5px solid #f8d148;
      border-radius: 8px;
      margin-top: 20px;
    }

    .astro-right {
      flex: 1;
      min-width: 300px;
      padding: 20px;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .astro-right img {
      width: 100%;
      max-width: 500px;
      border-radius: 16px;
      box-shadow: 0 0 30px rgba(248, 209, 72, 0.3);
      transition: transform 0.5s ease;
    }

    .astro-right img:hover {
      transform: scale(1.03);
    }

    @media (max-width: 768px) {
      .astro-location-container {
        flex-direction: column;
        padding: 40px 20px;
      }
    }
  </style>
</head>
<body>

  <section class="astro-location-container">
    <!-- Left Side: Content -->
    <div class="astro-text">
      <h2>Our Sacred Astrology Center in Texas</h2>
      <p>Located in the heart of Houston, our astrology center is a tranquil retreat for the spiritually inclined. We offer deep insights into your life's path through ancient Vedic wisdom.</p>
      <p>Our services include Horoscope Reading, Palmistry, Love & Marriage Guidance, Vastu Shastra, and Black Magic Removal.</p>
      <div class="astro-highlight">
        Address: 2025 Star Vision Street, Houston, TX<br>
        Call: +1 234 567 8900<br>
        Timings: Mon–Sat, 9 AM – 8 PM
      </div>
    </div>

    <!-- Right Side: Image -->
    <div class="astro-right">
      <img src="https://via.placeholder.com/500x400?text=Astrology+Center+Texas" alt="Texas Astrology Center">
    </div>
  </section>
<?php include 'two.php';?>

<?php include 'why.php'; ?>
<?php include 'one.php'; ?>
<?php include 'footer.php'; ?>
</body>
</html>
