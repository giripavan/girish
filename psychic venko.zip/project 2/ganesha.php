<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Ganesha Pooja Services</title>
  <?php include 'header.php'; ?>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background:rgb(61, 6, 67);
    }

    .ganesha-section {
      background: linear-gradient(to right,rgb(107, 28, 107),rgb(91, 6, 95));
      padding: 60px 20px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: center;
    }

    .ganesha-content {
      flex: 1 1 400px;
      max-width: 600px;
      padding: 20px;
    }

    .ganesha-content h2 {
      color:rgb(251, 223, 10);
      font-size: 32px;
      margin-bottom: 20px;
    }

    .ganesha-content p {
      font-size: 18px;
      color: white;
      line-height: 1.6;
    }

    .ganesha-image {
      flex: 1 1 300px;
      max-width: 500px;
      padding: 20px;
      text-align: center;
    }

    .ganesha-image img {
      max-width: 100%;
      height: auto;
      border-radius: 20px;
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    .book-now {
      margin-top: 30px;
      display: inline-block;
      background: #a94442;
      color: white;
      padding: 12px 24px;
      border: none;
      font-size: 16px;
      border-radius: 6px;
      text-decoration: none;
      transition: background 0.3s ease;
    }

    .book-now:hover {
      background: #8b3030;
    }

    /* Cards Section */
    .cards-section {
      background:rgb(107, 28, 107);
      padding: 60px 20px;
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 30px;
      justify-items: center;
    }

    .card {
      background: white;
      border-radius: 50%;
      width: 220px;
      height: 220px;
      box-shadow: 0 8px 20px rgba(169, 68, 66, 0.2);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 20px;
      text-align: center;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
      transform: translateY(-10px);
      box-shadow: 0 14px 30px rgba(169, 68, 66, 0.4);
    }

    .card h3 {
      color: #a94442;
      font-size: 18px;
      margin-bottom: 10px;
    }

    .card p {
      color: #555;
      font-size: 14px;
      line-height: 1.4;
    }

    @media (max-width: 992px) {
      .cards-section {
        grid-template-columns: repeat(2, 1fr);
      }
    }

    @media (max-width: 600px) {
      .cards-section {
        grid-template-columns: 1fr;
      }

      .card {
        width: 180px;
        height: 180px;
        padding: 16px;
      }

      .card h3 {
        font-size: 16px;
      }

      .card p {
        font-size: 13px;
      }
    }
  </style>
</head>
<body>

<section class="ganesha-section">
  <div class="ganesha-image">
    <img src="https://i.imgur.com/yQuY9eP.png" alt="Lord Ganesha" />
  </div>
  <div class="ganesha-content">
    <h2>Ganesha Pooja Services</h2>
    <p>
      Invoke the blessings of Lord Ganesha for wisdom, prosperity, and the removal of obstacles. Our experienced priests perform the pooja with traditional Vedic rituals. Suitable for new beginnings, business openings, and spiritual cleansing.
    </p>
    <a href="#contact" class="book-now">Book Now</a>
  </div>
</section>

<!-- 6 Round Cards in 2 Rows x 3 Columns -->
<section class="cards-section">
  <!-- Types of Pooja -->
  <div class="card">
    <h3>Ganapati Homam</h3>
    <p>Eliminates negativity and invites success in ventures.</p>
  </div>
  <div class="card">
    <h3>Sankatahara Chaturthi</h3>
    <p>Vrat to overcome difficulties and misfortunes.</p>
  </div>
  <div class="card">
    <h3>Vinayaka Chaturthi</h3>
    <p>Special pooja for wisdom and spiritual devotion.</p>
  </div>

  <!-- Benefits / Uses of Pooja -->
  <div class="card">
    <h3>Removes Obstacles</h3>
    <p>Clears path to success in all personal and career efforts.</p>
  </div>
  <div class="card">
    <h3>Brings Prosperity</h3>
    <p>Attracts wealth, harmony, and good fortune into your life.</p>
  </div>
  <div class="card">
    <h3>Spiritual Growth</h3>
    <p>Deepens meditation and purifies your spiritual path.</p>
  </div>
</section>
<?php include 'two.php';?>

<?php include 'why.php'; ?>
<?php include 'one.php'; ?>

<?php include 'footer.php'; ?>

</body>
</html>
