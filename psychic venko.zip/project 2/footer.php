<footer class="fancy-footer">
  <div class="fancy-container">
    <div class="fancy-left">
      <h2 class="fancy-logo">YourBrand</h2>
      <p class="fancy-desc">
        We craft amazing digital experiences. Join our newsletter and stay updated with the latest trends!
      </p>

      <form class="fancy-newsletter" action="#" method="post">
        <input
          type="email"
          placeholder="Enter your email"
          required
          aria-label="Email"
        />
        <button type="submit" aria-label="Subscribe">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
            class="icon-send"
            viewBox="0 0 24 24"
          >
            <line x1="22" y1="2" x2="11" y2="13" />
            <polygon points="22 2 15 22 11 13 2 9 22 2" />
          </svg>
        </button>
      </form>

      <div class="fancy-social">
        <a href="#" aria-label="Facebook" class="social-icon facebook">
          <i class="fab fa-facebook-f"></i>
        </a>
        <a href="#" aria-label="Twitter" class="social-icon twitter">
          <i class="fab fa-twitter"></i>
        </a>
        <a href="#" aria-label="Instagram" class="social-icon instagram">
          <i class="fab fa-instagram"></i>
        </a>
        <a href="#" aria-label="LinkedIn" class="social-icon linkedin">
          <i class="fab fa-linkedin-in"></i>
        </a>
      </div>
    </div>

    <div class="fancy-right">
      <div class="fancy-links">
        <h3>Explore</h3>
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="#">Features</a></li>
          <li><a href="#">Pricing</a></li>
          <li><a href="#">Blog</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
      </div>

      <div class="fancy-contact">
        <h3>Contact</h3>
        <ul>
          <li><i class="fas fa-map-marker-alt"></i> 123 Digital Street, Web City</li>
          <li><i class="fas fa-phone"></i> +1 800 123 4567</li>
          <li><i class="fas fa-envelope"></i> contact@yourbrand.com</li>
        </ul>
      </div>
    </div>
  </div>

  <div class="fancy-bottom">
    <p>© 2025 YourBrand. Crafted with ❤️ by You.</p>
  </div>
</footer>

<!-- FontAwesome CDN for icons -->
<link
  rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
/>

<style>
  /* Reset some basics */
  * {
    box-sizing: border-box;
  }

  /* Fancy Footer */
  

  .fancy-container {
    max-width: 1200px;
    margin: auto;
    display: flex;
    justify-content: space-between;
    gap: 40px;
    flex-wrap: wrap;
  }

  /* Left Side */
  .fancy-left {
    flex: 1 1 380px;
  }

  .fancy-logo {
    font-size: 36px;
    font-weight: 800;
    color: #6366f1; /* Indigo-500 */
    margin-bottom: 15px;
    letter-spacing: 2px;
  }

  .fancy-desc {
    font-size: 16px;
    line-height: 1.6;
    color: #c7d2fe;
    margin-bottom: 30px;
  }

  /* Newsletter */
  .fancy-newsletter {
    display: flex;
    max-width: 400px;
    background: #374151;
    border-radius: 40px;
    overflow: hidden;
    box-shadow: 0 0 15px rgba(99, 102, 241, 0.3);
  }

  .fancy-newsletter input[type='email'] {
    flex-grow: 1;
    padding: 12px 20px;
    font-size: 14px;
    border: none;
    outline: none;
    background: transparent;
    color: #e0e7ff;
    font-weight: 600;
  }

  .fancy-newsletter input::placeholder {
    color: #a5b4fc;
    font-weight: 500;
  }

  .fancy-newsletter button {
    background: #6366f1;
    border: none;
    padding: 0 25px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background-color 0.3s ease;
  }

  .fancy-newsletter button:hover {
    background: #4f46e5;
  }

  .icon-send {
    width: 20px;
    height: 20px;
    stroke: white;
  }

  /* Social Icons */
  .fancy-social {
    margin-top: 30px;
    display: flex;
    gap: 20px;
  }

  .social-icon {
    background: #374151;
    color: #c7d2fe;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
    box-shadow: 0 0 10px transparent;
    font-size: 18px;
  }

  .social-icon:hover {
    color: #fff;
    box-shadow: 0 0 10px #6366f1;
    transform: scale(1.1);
  }

  /* Brand-specific hover colors */
  .facebook:hover {
    box-shadow: 0 0 10px #3b5998;
    background: #3b5998;
  }
  .twitter:hover {
    box-shadow: 0 0 10px #1da1f2;
    background: #1da1f2;
  }
  .instagram:hover {
    box-shadow: 0 0 10px #e4405f;
    background: #e4405f;
  }
  .linkedin:hover {
    box-shadow: 0 0 10px #0077b5;
    background: #0077b5;
  }

  /* Right Side */
  .fancy-right {
    flex: 1 1 380px;
    display: flex;
    justify-content: space-between;
    gap: 40px;
    flex-wrap: wrap;
  }

  .fancy-links,
  .fancy-contact {
    min-width: 180px;
  }

  .fancy-links h3,
  .fancy-contact h3 {
    font-size: 20px;
    margin-bottom: 15px;
    color: #6366f1;
    font-weight: 700;
  }

  .fancy-links ul,
  .fancy-contact ul {
    list-style: none;
    padding: 0;
    margin: 0;
    color: #c7d2fe;
    font-weight: 500;
  }

  .fancy-links ul li,
  .fancy-contact ul li {
    margin-bottom: 12px;
  }

  .fancy-links ul li a {
    text-decoration: none;
    color: #c7d2fe;
    transition: color 0.3s ease;
  }

  .fancy-links ul li a:hover {
    color: #6366f1;
    text-decoration: underline;
  }

  .fancy-contact ul li {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .fancy-contact ul li i {
    color: #6366f1;
    font-size: 18px;
  }

  /* Bottom bar */
  .fancy-bottom {
    text-align: center;
    margin-top: 40px;
    font-size: 14px;
    color: #8b94f7;
    font-weight: 500;
    letter-spacing: 1px;
  }

  /* Responsive */
  @media (max-width: 860px) {
    .fancy-container {
      flex-direction: column;
      gap: 40px;
    }
    .fancy-right {
      justify-content: flex-start;
      gap: 60px;
    }
  }

  @media (max-width: 480px) {
    .fancy-newsletter {
      max-width: 100%;
    }
    .fancy-right {
      flex-direction: column;
      gap: 30px;
    }
  }
</style>
