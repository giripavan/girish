<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>About Us - Celestial Insights</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet" />
  <script src="https://kit.fontawesome.com/a2e0f1f0b5.js" crossorigin="anonymous"></script>
  <?php include 'header.php' ?>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Montserrat', sans-serif;
      background: linear-gradient(to right, #4c0259, #690967);
      color: white;
      overflow-x: hidden;
      line-height: 1.6;
    }
    .hero {
      height: 70vh;
      background: linear-gradient(rgba(77, 6, 81, 0.96), rgba(67, 3, 77, 0.73)),
                  url('images/abb2.jpg') center/cover no-repeat;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
    }
    .hero h1 {
      font-size: 3.5rem;
      background: rgba(255, 255, 255, 0.1);
      padding: 20px 40px;
      border-radius: 15px;
      backdrop-filter: blur(6px);
      color: #fff;
    }
    .container {
      max-width: 1200px;
      margin: auto;
      padding: 60px 20px;
    }
    .about-section {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 50px;
      align-items: center;
    }
    .about-image img {
      width: 100%;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
    }
    .about-content h2 {
      font-size: 2.8rem;
      color: #ff9d00;
      margin-bottom: 20px;
    }
    .about-content p {
      font-size: 1.2rem;
      color: #e0e0e0;
    }
    .counters {
      display: flex;
      justify-content: space-around;
      margin-top: 60px;
      gap: 20px;
      flex-wrap: wrap;
    }
    .counter-box {
      background: #1e1e3f;
      padding: 30px;
      border-radius: 15px;
      width: 30%;
      min-width: 200px;
      text-align: center;
      transition: 0.3s;
    }
    .counter-box:hover {
      transform: translateY(-10px);
    }
    .counter-box h3 {
      font-size: 2.5rem;
      color: #ff9d00;
    }
    .counter-box p {
      color: #ccc;
      font-size: 1rem;
    }
    .mission-section {
      display: flex;
      gap: 30px;
      flex-wrap: wrap;
      margin-top: 80px;
    }
    .mission-box {
      flex: 1;
      min-width: 280px;
      background: #28285a;
      padding: 30px;
      border-radius: 15px;
      text-align: center;
      transition: all 0.3s ease;
    }
    .mission-box i {
      font-size: 2.2rem;
      color: #ff9d00;
      margin-bottom: 20px;
    }
    .mission-box h4 {
      font-size: 1.6rem;
      margin-bottom: 15px;
    }

    /* Team Section */
    .team {
      margin-top: 100px;
      text-align: center;
    }
    .team h2 {
      font-size: 2.8rem;
      margin-bottom: 50px;
      color: #ff9d00;
    }
    .team-grid {
      display: flex;
      justify-content: center;
      gap: 30px;
      flex-wrap: wrap;
    }

    /* Flip Card Styles */
    .flip-card {
      background-color: transparent;
      width: 260px;
      height: 320px;
      perspective: 1000px;
      border-radius: 20px;
    }
    .flip-card-inner {
      position: relative;
      width: 100%;
      height: 100%;
      text-align: center;
      transition: transform 0.8s;
      transform-style: preserve-3d;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.5);
    }
    .flip-card:hover .flip-card-inner {
      transform: rotateY(180deg);
    }
    .flip-card-front, .flip-card-back {
      position: absolute;
      width: 100%;
      height: 100%;
      backface-visibility: hidden;
      border-radius: 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 20px;
      box-sizing: border-box;
    }
    .flip-card-front {
      background: #1a1a3b;
      color: white;
    }
    .flip-card-front img {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      margin-bottom: 15px;
      object-fit: cover;
      border: 3px solid #ff9d00;
    }
    .flip-card-front h4 {
      font-size: 1.2rem;
      margin-bottom: 5px;
      color: #fff;
    }
    .flip-card-front p {
      color: #ccc;
      font-size: 1rem;
    }
    .flip-card-back {
      background: #ff9d00;
      color: #1a1a3b;
      transform: rotateY(180deg);
      font-size: 1rem;
      line-height: 1.4;
      font-weight: 600;
      border-radius: 20px;
    }

    @media (max-width: 992px) {
      .about-section {
        grid-template-columns: 1fr;
        text-align: center;
      }
      .counters {
        flex-direction: column;
        align-items: center;
      }
      .mission-section {
        flex-direction: column;
      }
      .team-grid {
        justify-content: center;
      }
    }
  </style>
</head>
<body>

  <!-- Hero -->
  <section class="hero">
    <h1>About Celestial Insights</h1>
  </section>

  <div class="container">

    <!-- About Section -->
    <div class="about-section">
      <div class="about-image">
        <img src="https://images.unsplash.com/photo-1557682224-5b8590cd9ec5" alt="About Us" />
      </div>
      <div class="about-content">
        <h2>Who We Are</h2>
        <p>At Celestial Insights, we combine ancient wisdom with modern intuition. With over 18 years of experience, our astrologers have guided thousands across the globe on love, career, spiritual, and personal growth journeys. We believe in clarity, transformation, and purpose-driven living.</p>
      </div>
    </div>

    <!-- Counters -->
    <div class="counters">
      <div class="counter-box">
        <h3>18+</h3>
        <p>Years Experience</p>
      </div>
      <div class="counter-box">
        <h3>25K+</h3>
        <p>Clients Served</p>
      </div>
      <div class="counter-box">
        <h3>80+</h3>
        <p>Countries Reached</p>
      </div>
    </div>

    <!-- Mission & Vision -->
    

    <!-- Team Section -->
   <br>

 <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #1e002b;
      color: white;
    }

    .benefits-section {
      display: flex;
      flex-wrap: wrap;
      min-height: 100vh;
    }

    .benefits-left {
      flex: 1;
      background-color: #d42e78;
      padding: 60px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .benefits-left h5 {
      text-transform: uppercase;
      font-weight: bold;
      font-size: 16px;
      margin-bottom: 10px;
    }

    .benefits-left h2 {
      font-size: 40px;
      line-height: 1.2;
      margin-bottom: 20px;
    }

    .benefits-left p {
      font-size: 16px;
      max-width: 500px;
    }

    .benefits-right {
      flex: 1;
      background-color: #1e002b;
      background-image: url('magic-background.png'); /* optional: semi-transparent background image */
      background-size: cover;
      background-position: center;
      padding: 60px 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .benefit-item {
      display: flex;
      align-items: flex-start;
      gap: 20px;
      margin-bottom: 30px;
    }

    .benefit-icon {
      font-size: 32px;
    }

    .benefit-text h4 {
      margin: 0;
      font-size: 18px;
      font-weight: bold;
    }

    .benefit-text p {
      margin: 5px 0 0;
      font-size: 14px;
      color: #ccc;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .benefits-section {
        flex-direction: column;
      }

      .benefits-left, .benefits-right {
        padding: 40px 20px;
      }

      .benefits-left h2 {
        font-size: 28px;
      }

      .benefit-text h4 {
        font-size: 16px;
      }

      .benefit-text p {
        font-size: 13px;
      }
    }
  </style>
</head>
<body>

  <section class="benefits-section">
    <div class="benefits-left">
      <h5>Advantages</h5>
      <h2>Benefits Of<br>Learning Magic</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim.</p>
    </div>

    <div class="benefits-right">
      <div class="benefit-item">
        <div class="benefit-icon">🔮</div>
        <div class="benefit-text">
          <h4>Acts as a Financial Planner</h4>
          <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium</p>
        </div>
      </div>

      <div class="benefit-item">
        <div class="benefit-icon">🧠</div>
        <div class="benefit-text">
          <h4>Makes You Confident and Optimistic</h4>
          <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium</p>
        </div>
      </div>

      <div class="benefit-item">
        <div class="benefit-icon">⚖️</div>
        <div class="benefit-text">
          <h4>Helps in Decision Making</h4>
          <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium</p>
        </div>
      </div>

      <div class="benefit-item">
        <div class="benefit-icon">💘</div>
        <div class="benefit-text">
          <h4>Tells if Your Partner is Rich and Attractive</h4>
          <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium</p>
        </div>
      </div>
    </div>
  </section>

 <link href="https://fonts.googleapis.com/css2?family=Marcellus&display=swap" rel="stylesheet">
<style>
  body {
    margin: 0;
    font-family: 'Marcellus', serif;
    background: linear-gradient(to bottom, #2f0f3f, #4a1d5a);
    color: #fff;
  }

  .services-section {
    text-align: center;
    padding: 80px 20px;
    position: relative;
    overflow: hidden;
  }

  .services-section::before {
    content: '';
    background: url('https://cdn.pixabay.com/photo/2012/11/28/10/40/moon-67672_1280.jpg') no-repeat center;
    background-size: contain;
    position: absolute;
    right: 10%;
    bottom: 0;
    width: 400px;
    height: 400px;
    opacity: 0.2;
    pointer-events: none;
  }

  .services-section h1 {
    color: rgb(239, 57, 114);
    font-size: 36px;
    letter-spacing: 1px;
    margin-bottom: 10px;
  }

  .services-section h2 {
    font-size: 32px;
    margin: 0 0 10px;
  }

  .services-section p {
    max-width: 700px;
    margin: 0 auto 40px;
    font-size: 14px;
    opacity: 0.9;
  }

  .services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 30px;
    max-width: 1100px;
    margin: 0 auto;
  }

  .service-box {
    background: rgba(255, 255, 255, 0.04);
    border: 1px solid #fff;
    padding: 30px 20px;
    border-radius: 50%;
    width: 250px;
    height: 250px;
    margin: 0 auto;
    text-align: center;
    position: relative;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }

  .service-box:hover {
    transform: translateY(-10px);
    box-shadow: 0 0 20px rgba(255, 255, 255, 0.2);
  }

  .service-box img {
    width: 60px;
    height: 60px;
    margin-bottom: 15px;
  }

  .service-box h3 {
    font-size: 16px;
    color: yellow;
    font-weight: bold;
    margin: 0 0 10px;
    text-transform: uppercase;
    margin-bottom: 10px;
  }

  .service-box p {
    font-size: 12px;
    line-height: 1.4;
    color: #ddd;
    padding: 0 10px;
  }

  @media (max-width: 600px) {
    .service-box {
      width: 200px;
      height: 200px;
    }

    .service-box p {
      display: none;
    }
  }
</style>
</head>
<body>

<section class="services-section">
  <h1>OUR SERVICES</h1>
  <h2>Astrology Is Just A Finger Pointing At Reality</h2>
  <p>Lorem Ipsum Dolor Sit Amet Consectetur. Auctor Tristique Malesuada Arcu.</p>

  <div class="services-grid">
    <div class="service-box">
      <img src="./images/gn.png" alt="icon" />
      <h3>General Consultation</h3>
      <p>Astrology helps find the hidden order in life.</p>
    </div>
    <div class="service-box">
      <img src="./images/pl.png" alt="icon" />
      <h3>Personal Life Advice</h3>
      <p>Guiding through confusion with ancient wisdom.</p>
    </div>
    <div class="service-box">
      <img src="./images/af.png" alt="icon" />
      <h3>Annual Forecast</h3>
      <p>Predict what the stars hold for your year ahead.</p>
    </div>
    <div class="service-box">
      <img src="./images/w.png" alt="icon" />
      <h3>Work, Career, Finance</h3>
      <p>Find career direction and financial clarity.</p>
    </div>
    <div class="service-box">
      <img src="./images/fe.png" alt="icon" />
      <h3>Future Events</h3>
      <p>Navigate important moments with cosmic insight.</p>
    </div>
    <div class="service-box">
      <img src="./images/cl.png" alt="icon" />
      <h3>Life Situations</h3>
      <p>Decode challenges and uncover purpose.</p>
    </div>
  </div>
</section>

<?php include 'testinomials.php'; ?>
    
<?php include 'why.php';?>
<?Php include 'two.php';?>

   <?php include 'footer.php'; ?>

  </div>
</body>
</html>
