<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>Testimonials - Astrologer Sanju</title>
  <meta name="description" content="Read genuine testimonials from clients who have benefited from Astrologer Sanju's guidance and astrology services.">
  <meta name="keywords" content="Astrologer Testimonials, Client Reviews, Astrology Feedback, Astrologer Sanju Reviews">
  <meta name="author" content="Astrologer Sanju" />

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Segoe+UI:wght@400;600&display=swap" rel="stylesheet">

  <!-- Favicon -->
  <link rel="icon" href="favicon.ico" type="image/x-icon" />

  <!-- AOS CSS -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />

  <!-- Custom CSS -->
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #0d0d2b;
      color: white;
      overflow-x: hidden;
    }

    .testimonial-section {
      display: flex;
      flex-direction: column;
      align-items: center;
      position: relative;
      padding: 40px 20px;
    }

    .testimonial-heading {
      font-size: 36px;
      color: #ffd700;
      text-align: center;
      margin-bottom: 40px;
      font-weight: bold;
      text-transform: uppercase;
      position: relative;
    }

    .testimonial-heading::after {
      content: "";
      width: 80px;
      height: 4px;
      background-color: #ffd700;
      display: block;
      margin: 10px auto 0;
      border-radius: 2px;
    }

    .testimonial-slider-area {
      display: flex;
      align-items: center;
      width: 100%;
      max-width: 1440px;
      height: 430px;
      overflow: hidden;
      position: relative;
    }

    .slider-container {
      width: calc(100% - 340px);
      overflow: hidden;
      position: relative;
      z-index: 1;
    }

    .testimonial-row {
      display: flex;
      gap: 20px;
      animation: slideLeft 30s linear infinite;
    }

    @keyframes slideLeft {
      0% { transform: translateX(0); }
      100% { transform: translateX(-100%); }
    }

    .testimonial-card {
      background-color: #1a1a3d;
      border-radius: 10px;
      padding: 20px;
      width: 300px;
      min-width: 300px;
      box-shadow: 0 0 10px rgba(255, 255, 255, 0.1);
      flex-shrink: 0;
      text-align: center;
    }

    .testimonial-card img {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      object-fit: cover;
      margin-bottom: 10px;
      border: 2px solid #ffd700;
    }

    .testimonial-card h4 {
      margin: 0 0 10px;
      color: #ffd700;
    }

    .testimonial-card p {
      font-size: 14px;
      color: #ccc;
    }

    .right-image {
      position: absolute;
      right: 10px;
      top: 0;
      bottom: 0;
      width: 340px;
      background: url('./images/bb1.jpg') no-repeat center center;
      background-size: cover;
      opacity: 1.2;
      z-index: 0;
      padding-right: 40px;
    }

    @media (max-width: 768px) {
      .testimonial-slider-area {
        flex-direction: column;
        height: auto;
      }

      .slider-container {
        width: 100%;
        margin: 0;
      }

      .right-image {
        display: none;
      }

      .testimonial-row {
        animation: none;
        flex-wrap: wrap;
        justify-content: center;
      }

      .testimonial-heading {
        font-size: 28px;
      }
    }
  </style>
</head>
<body>

<section class="testimonial-section">
  <h2 class="testimonial-heading">Testimonials</h2>

  <div class="testimonial-slider-area">
    <div class="slider-container">
      <div class="testimonial-row">
        <div class="testimonial-card" data-aos="fade-up">
          <img src="https://randomuser.me/api/portraits/men/11.jpg" alt="Ravi Kumar">
          <h4>Ravi Kumar</h4>
          <p>Astrologer Sanju helped me get back on track in life. Amazing predictions!</p>
        </div>
        <div class="testimonial-card" data-aos="fade-up">
          <img src="https://randomuser.me/api/portraits/women/12.jpg" alt="Sneha Patil">
          <h4>Sneha Patil</h4>
          <p>Very accurate and insightful! Definitely recommended for love problems.</p>
        </div>
        <div class="testimonial-card" data-aos="fade-up">
          <img src="https://randomuser.me/api/portraits/men/22.jpg" alt="Mohammed Asif">
          <h4>Mohammed Asif</h4>
          <p>His remedies actually worked for me. Deeply thankful for his guidance.</p>
        </div>
        <div class="testimonial-card" data-aos="fade-up">
          <img src="https://randomuser.me/api/portraits/women/32.jpg" alt="Divya Reddy">
          <h4>Divya Reddy</h4>
          <p>I was facing family issues, and his advice brought peace back home.</p>
        </div>
        <div class="testimonial-card" data-aos="fade-up">
          <img src="https://randomuser.me/api/portraits/men/45.jpg" alt="Kiran Sharma">
          <h4>Kiran Sharma</h4>
          <p>Simple, sincere, and powerful predictions that gave me clarity.</p>
        </div>
        <div class="testimonial-card" data-aos="fade-up">
          <img src="https://randomuser.me/api/portraits/women/55.jpg" alt="Priya Iyer">
          <h4>Priya Iyer</h4>
          <p>My career path was unclear, but with his help, I made the right decision.</p>
        </div>
      </div>
    </div>
    <div class="right-image"></div>
  </div>
</section>

<!-- AOS JS -->
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({
    duration: 900,
    once: true,
    easing: 'ease-in-out',
  });
</script>


</body>
</html>
