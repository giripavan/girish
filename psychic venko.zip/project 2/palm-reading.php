<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Psychic Venkojirav - Palm Reading</title>
  <?php include 'header.php'; ?>
  <style>
    body {
      margin: 0;
      font-family: 'Open Sans', sans-serif;
      background:rgb(78, 4, 90);
      color: #fff;
    }

    .palm-wrapper {
      padding: 80px 20px;
      background: linear-gradient(135deg,rgba(41, 0, 51, 0),rgba(17, 0, 26, 0));
      display: flex;
      align-items: center;
      gap: 50px;
      max-width: 1200px;
      margin: 0 auto;
      position: relative;
      overflow: hidden;
      z-index: 0;
    }

    /* Starry animated background */
    .palm-wrapper::before {
      content: "";
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      background: transparent;
      background: radial-gradient(ellipse at center,rgba(41, 0, 51, 0) 0%,rgba(17, 0, 26, 0) 100%);
      z-index: -2;
    }

    .palm-wrapper::after {
      content: "";
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      pointer-events: none;
      background: transparent;
      z-index: -1;
      box-shadow:
        0 0 1px 1px #fff,
        100px 50px 1px 1px #fff,
        200px 120px 1px 1px #fff,
        300px 200px 1px 1px #fff,
        400px 90px 1px 1px #fff,
        500px 180px 1px 1px #fff,
        600px 30px 1px 1px #fff,
        700px 170px 1px 1px #fff,
        800px 110px 1px 1px #fff,
        900px 70px 1px 1px #fff;
      animation: starTwinkle 15s linear infinite;
    }

    @keyframes starTwinkle {
      0%, 100% {
        box-shadow:
          0 0 1px 1px #fff,
          100px 50px 1px 1px #fff,
          200px 120px 1px 1px #fff,
          300px 200px 1px 1px #fff,
          400px 90px 1px 1px #fff,
          500px 180px 1px 1px #fff,
          600px 30px 1px 1px #fff,
          700px 170px 1px 1px #fff,
          800px 110px 1px 1px #fff,
          900px 70px 1px 1px #fff;
      }
      50% {
        box-shadow:
          0 0 3px 3px #ffd700,
          100px 50px 2px 2px #ffd700,
          200px 120px 3px 3px #ffd700,
          300px 200px 2px 2px #ffd700,
          400px 90px 1px 1px #ffd700,
          500px 180px 3px 3px #ffd700,
          600px 30px 2px 2px #ffd700,
          700px 170px 1px 1px #ffd700,
          800px 110px 2px 2px #ffd700,
          900px 70px 1px 1px #ffd700;
      }
    }

    /* Left side image */
    .palm-image {
      flex: 1 1 400px;
      max-width: 450px;
      border-radius: 20px;
      box-shadow: 0 0 40px #ffd700;
      overflow: hidden;
      aspect-ratio: 4 / 5;
    }

    .palm-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    /* Right side content */
    .palm-content {
      flex: 1 1 550px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      gap: 20px;
    }

    .palm-title {
      color: #ffd700;
      font-size: 44px;
      margin: 0;
      text-shadow: 0 0 10px #ffd700;
    }

    .palm-subtitle {
      font-size: 18px;
      color: #ccc;
      max-width: 100%;
      line-height: 1.6;
    }

    /* Round service boxes container */
    .service-grid {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 40px;
      margin-top: 40px;
    }

    /* Round service boxes */
    .service-item {
      background: rgba(20, 18, 18, 0.39);
      border: 1px solid rgba(255, 215, 0, 0.1);
      border-radius: 50%;
      width: 280px;
      height: 280px;
      padding: 30px;
      text-align: center;
      position: relative;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      transition: transform 0.4s ease, box-shadow 0.4s ease;
      box-sizing: border-box;
    }

    .service-item:hover {
      transform: translateY(-10px);
      box-shadow: 0 0 25px rgba(255, 215, 0, 0.3);
    }

    .service-icon {
      width: 100px;
      height: 100px;
      margin-bottom: 20px;
      border-radius: 50%;
      background: radial-gradient(circle at center, #ffd700 0%, #a17700 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 40px;
      color: #140022;
      box-shadow: 0 0 20px rgba(255, 215, 0, 0.4);
    }

    .service-item h3 {
      font-size: 20px;
      color: #ffd700;
      margin-bottom: 10px;
    }

    .service-item p {
      font-size: 14px;
      color: #ddd;
      line-height: 1.4;
      padding: 0 10px;
    }

    .cta-box {
      text-align: center;
      margin-top: 60px;
    }

    .cta-box a {
      background: #ffd700;
      color: #1a0028;
      text-decoration: none;
      padding: 14px 30px;
      font-size: 16px;
      font-weight: bold;
      border-radius: 30px;
      transition: background 0.3s ease;
      display: inline-block;
    }

    .cta-box a:hover {
      background: #e6c200;
    }

    @media (max-width: 1024px) {
      .palm-wrapper {
        flex-direction: column;
        padding: 40px 20px;
      }
      .palm-image {
        max-width: 100%;
        width: 100%;
        aspect-ratio: auto;
        height: 300px;
        margin-bottom: 40px;
      }
      .palm-content {
        width: 100%;
      }
      .service-grid {
        justify-content: center;
      }
    }

    @media (max-width: 480px) {
      .palm-title {
        font-size: 28px;
      }
      .service-item {
        width: 220px;
        height: 220px;
        padding: 20px;
      }
      .service-icon {
        width: 80px;
        height: 80px;
        font-size: 30px;
        margin-bottom: 15px;
      }
      .service-item h3 {
        font-size: 18px;
      }
      .service-item p {
        font-size: 13px;
      }
    }
  </style>
</head>
<body>

<section class="palm-wrapper">
  <div class="palm-image">
    <img src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80" alt="Palm Reading Image" />
  </div>

  <div class="palm-content">
    <h2 class="palm-title">Palm Reading by Psychic Venkojirav</h2>
    <p class="palm-subtitle">
      Your hands hold the divine map of your destiny. Explore your life's secrets with Psychic Venkojirav's insightful palmistry—revealing love, fate, spirit, and power through the ancient art of hand reading.
    </p>

    <div class="service-grid">
      <div class="service-item">
        <div class="service-icon">🖐️</div>
        <h3>Life Line</h3>
        <p>Uncover your vitality and key turning points. The life line reflects health, energy, and the journey of your soul.</p>
      </div>

      <div class="service-item">
        <div class="service-icon">❤️</div>
        <h3>Heart Line</h3>
        <p>Reveal your emotional patterns, romantic depth, and how you connect in love and relationships.</p>
      </div>

      <div class="service-item">
        <div class="service-icon">💼</div>
        <h3>Fate & Career</h3>
        <p>Discover your path, ambition, and direction. The fate line shows career patterns and purpose in life.</p>
      </div>

      <div class="service-item">
        <div class="service-icon">👨‍👩‍👧</div>
        <h3>Marriage & Children</h3>
        <p>Explore palm signs that predict marriage prospects, relationship timing, and children’s future energy.</p>
      </div>

      <div class="service-item">
        <div class="service-icon">✨</div>
        <h3>Spiritual Signs</h3>
        <p>Identify psychic marks and mystic signs—triangles, crosses, and stars that show spiritual gifts and intuition.</p>
      </div>
    </div>

    <div class="cta-box">
      <a href="#contact">Book Your Palm Reading Now</a>
    </div>
  </div>
</section>
<?php include 'two.php';?>

<?php include 'why.php'; ?>
<?php include 'one.php'; ?>
<?php include 'footer.php'; ?>
</body>
</html>
