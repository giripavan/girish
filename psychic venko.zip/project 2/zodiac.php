<style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Open Sans', sans-serif;
      background-color:rgb(175, 25, 225);
      color: #fff;
      text-align: center;
    }

    .section-heading {
      padding-top: 40px;
    }

    .section-heading span {
      color: #f6246b;
      font-weight: bold;
      text-transform: uppercase;
      font-size: 16px;
    }

    .section-heading h1 {
      font-family: 'Playfair Display', serif;
      font-size: 36px;
      margin: 10px 0;
    }

    .section-heading p {
      font-size: 16px;
      max-width: 600px;
      margin: 0 auto;
      color: #d3c3d3;
    }

    .zodiac-container {
      display: grid;
      grid-template-columns: repeat(6, 1fr);
      gap: 40px;
      justify-items: center;
      margin-top: 50px;
      padding: 0 20px 60px;
    }

    @media (max-width: 768px) {
      .zodiac-container {
        grid-template-columns: repeat(2, 1fr);
        gap: 30px;
      }
    }

    .zodiac-card {
      width: 140px;
      height: 220px;
      background: rgba(255, 255, 255, 0);
      padding: 10px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: space-between;
      position: relative;
    }

    .zodiac-card img {
      width: 80px;
      height: 80px;
      object-fit: contain;
      margin-top: 10px;
      filter: brightness(2.2);
    }

    .zodiac-card h3 {
      font-size: 18px;
      margin: 5px 0;
      font-family: 'Playfair Display', serif;
      position: relative;
    }

    .arrow-under-name {
      position: relative;
      width: 60px;
      height: 20px;
      margin-top: 5px;
      overflow: hidden;
    }

    .arrow-under-name::before {
      content: "→";
      position: absolute;
      left: -30px;
      top: 0;
      font-size: 24px;
      color: #fff;
      animation: arrowMove 5s linear infinite;
    }

    @keyframes arrowMove {
      0% {
        left: -30px;
        opacity: 0;
      }
      20% {
        opacity: 1;
      }
      100% {
        left: 30px;
        opacity: 0;
      }
    }

    .zodiac-card p {
      font-size: 14px;
      color: #ccc;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>

  <section class="section-heading">
    <span>Choose Zodiac Sign</span>
    <h1>The Starry Vault Of Heaven Is In Truth The Open<br>Book Of Cosmic Projection</h1>
  </section>

  <section class="zodiac-container">
    <div class="zodiac-card">
      <img src="./images/aries.png" alt="Aries">
      <h3>Aries</h3>
      <div class="arrow-under-name"></div>
      <p>Mar 21-Apr 19</p>
    </div>
    <div class="zodiac-card">
      <img src="./images/taurus.png" alt="Taurus">
      <h3>Taurus</h3>
      <div class="arrow-under-name"></div>
      <p>Apr 20-May 20</p>
    </div>
    <div class="zodiac-card">
      <img src="./images/gemini.png" alt="Gemini">
      <h3>Gemini</h3>
      <div class="arrow-under-name"></div>
      <p>May 21-Jun 20</p>
    </div>
    <div class="zodiac-card">
      <img src="./images/cancer.png" alt="Cancer">
      <h3>Cancer</h3>
      <div class="arrow-under-name"></div>
      <p>Jun 21-Jul 22</p>
    </div>
    <div class="zodiac-card">
      <img src="./images/leo.png" alt="Leo">
      <h3>Leo</h3>
      <div class="arrow-under-name"></div>
      <p>Jul 23-Aug 22</p>
    </div>
    <div class="zodiac-card">
      <img src="./images/virgo.png" alt="Virgo">
      <h3>Virgo</h3>
      <div class="arrow-under-name"></div>
      <p>Aug 23-Sep 22</p>
    </div>
    <div class="zodiac-card">
      <img src="./images/libra.png" alt="Libra">
      <h3>Libra</h3>
      <div class="arrow-under-name"></div>
      <p>Sep 23-Oct 22</p>
    </div>
    <div class="zodiac-card">
      <img src="./images/scorpio.png" alt="Scorpio">
      <h3>Scorpio</h3>
      <div class="arrow-under-name"></div>
      <p>Oct 23-Nov 21</p>
    </div>
    <div class="zodiac-card">
      <img src="./images/sagittarius.png" alt="Sagittarius">
      <h3>Sagittarius</h3>
      <div class="arrow-under-name"></div>
      <p>Nov 22-Dec 21</p>
    </div>
    <div class="zodiac-card">
      <img src="./images/capricorn.png" alt="Capricorn">
      <h3>Capricorn</h3>
      <div class="arrow-under-name"></div>
      <p>Dec 22-Jan 19</p>
    </div>
    <div class="zodiac-card">
      <img src="./images/aquarius.png" alt="Aquarius">
      <h3>Aquarius</h3>
      <div class="arrow-under-name"></div>
      <p>Jan 20-Feb 18</p>
    </div>
    <div class="zodiac-card">
      <img src="./images/pisces.png" alt="Pisces">
      <h3>Pisces</h3>
      <div class="arrow-under-name"></div>
      <p>Feb 19-Mar 20</p>
    </div>
  </section>