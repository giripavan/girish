<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Astrologer In Texas</title>
  <?php include 'header.php'; ?>
  <style>
    :root {
      --main-bg: rgb(76, 13, 99);
      --card-bg: rgba(150, 0, 200, 0.15);
      --text-light: #ffffff;
      --highlight: #f6246b;
    }

    body {
      margin: 0;
      padding: 0;
      font-family: 'Open Sans', sans-serif;
      background-color: var(--main-bg);
      color: var(--text-light);
      text-align: center;
    }

    /* Marquee Slider Styles */
    .marquee-slider {
      position: relative;
      width: 100%;
      max-width: 1600px;
      margin: auto;
      overflow: hidden;
      aspect-ratio: 16 / 9;
    }

    .marquee-slider img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      position: absolute;
      top: 0;
      left: 0;
      opacity: 0;
      transition: opacity 2s ease-in-out;
    }

    .marquee-slider img.active {
      opacity: 1;
      z-index: 1;
    }

    @media (max-width: 768px) {
      .marquee-slider {
        aspect-ratio: 4 / 3;
      }
    }

    /* Apply purple background to section containers globally */
    section, .section, .container, .wrapper {
      background-color: var(--main-bg) !important;
    }

    /* Optional: Cards, Feature Boxes, Testimonials, etc. */
    .card, .feature-box, .zodiac-card, .service-box, .testimonial-box {
      background-color: var(--card-bg) !important;
      border-radius: 10px;
      color: var(--text-light);
    }

    /* Headings and highlights */
    h1, h2, h3, h4, h5 {
      color: var(--text-light);
    }

    .highlight {
      color: var(--highlight);
    }
  </style>
</head>
<body>

<!-- Marquee Slider -->
<div class="marquee-slider" id="marqueeSlider">
  <img src="./images/b1.jpg" alt="Banner 1" class="active" />
  <!-- Add more images as needed -->
</div>

<!-- Include Sections -->
<?php include 'zodiac.php'; ?>
<?php include 'why.php'; ?>
<?php include 'services.php'; ?>
<?php include 'one.php'; ?>
<?php include 'testinomials.php'; ?>
<?php include 'two.php'; ?>
<?php include 'footer.php'; ?>

<!-- Slider Script -->
<script>
  const images = document.querySelectorAll('#marqueeSlider img');
  let current = 0;

  setInterval(() => {
    images[current].classList.remove('active');
    current = (current + 1) % images.length;
    images[current].classList.add('active');
  }, 5000);
</script>

</body>
</html>
