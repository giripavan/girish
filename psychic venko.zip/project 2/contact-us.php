<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact Page</title>
  <?php include 'header.php'; ?>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #330038;
      color: #fff;
    }

    .contact-section {
      padding: 50px 20px;
    }

    .contact-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
    }

    .form-section {
      flex: 1;
      min-width: 300px;
      max-width: 500px;
      padding-right: 30px;
    }

    .form-section h5 {
      color: #ff4b8b;
      margin: 0;
      text-transform: uppercase;
      font-size: 14px;
    }

    .form-section h2 {
      font-size: 32px;
      margin: 10px 0 20px;
    }

    .form-section form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    input, textarea {
      padding: 12px;
      border: 1px solid #ff4b8b;
      background-color: transparent;
      color: white;
      border-radius: 3px;
      outline: none;
      font-size: 15px;
    }

    input::placeholder, textarea::placeholder {
      color: #ccc;
    }

    textarea {
      resize: vertical;
      min-height: 100px;
    }

    button {
      padding: 12px;
      background-color: #ff4b8b;
      border: none;
      color: white;
      cursor: pointer;
      width: 100px;
      font-weight: bold;
      border-radius: 3px;
    }

    .map-section {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 20px;
    }

    .map-circle {
      width: 300px;
      height: 300px;
      border-radius: 50%;
      overflow: hidden;
      border: 2px dashed #ff4b8b;
      position: relative;
      box-shadow: 0 0 15px rgba(255, 75, 139, 0.5);
    }

    .map-circle iframe {
      width: 100%;
      height: 100%;
      border: 0;
    }

    .footer-cards {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      margin-top: 50px;
      gap: 20px;
    }

    .card {
      background-color: #3b0045;
      padding: 20px;
      width: 220px;
      text-align: center;
      border: 1px solid #6a006e;
      transition: transform 0.3s ease;
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 0 10px #ff4b8b;
    }

    .card h3 {
      margin: 0 0 10px;
      font-size: 18px;
      color: #fff;
    }

    .card p {
      font-size: 14px;
      color: #ccc;
      line-height: 1.6;
    }

    @media (max-width: 768px) {
      .contact-container {
        flex-direction: column;
        align-items: flex-start;
      }

      .map-section {
        margin-top: 40px;
      }

      .form-section {
        padding-right: 0;
      }

      .map-circle {
        width: 250px;
        height: 250px;
      }
    }
  </style>
</head>
<body>

  <section class="contact-section">
    <div class="contact-container">
      <!-- Contact Form -->
      <div class="form-section">
        <h5>CONTACT US</h5>
        <h2>Get In Touch</h2>
        <form>
          <label>Name</label>
          <input type="text" placeholder="Enter Your First Name" />

          <label>Your Email <span>*</span></label>
          <input type="email" placeholder="Youremail@Domain.Com" />

          <label>Message</label>
          <textarea placeholder="Enter your message here..."></textarea>

          <button type="submit">★ Submit</button>
        </form>
      </div>

      <!-- Map -->
      <div class="map-section">
        <div class="map-circle">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d241317.11609913297!2d72.74109995!3d19.0821978!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTnCsDA0JzU2LjAiTiA3MsKwNDUnMjguOCJF!5e0!3m2!1sen!2sin!4v1633097496790!5m2!1sen!2sin"
            loading="lazy"
            allowfullscreen>
          </iframe>
        </div>
      </div>
    </div>

    <!-- Bottom Contact Cards -->
    <div class="footer-cards">
      <div class="card">
        <h3>PERSONAL</h3>
        <p>+ (977) 22000-214-988<br>AstroAlwa@Info.Com<br>14 Main Road, New York 1002</p>
      </div>
      <div class="card">
        <h3>BUSINESS</h3>
        <p>+ (977) 22000-214-988<br>AstroAlwa@Info.Com<br>14 Main Road, New York 1002</p>
      </div>
      <div class="card">
        <h3>LOVE PROBLEM</h3>
        <p>+ (977) 22000-214-988<br>AstroAlwa@Info.Com<br>14 Main Road, New York 1002</p>
      </div>
      <div class="card">
        <h3>GUIDANCE</h3>
        <p>+ (977) 22000-214-988<br>AstroAlwa@Info.Com<br>14 Main Road, New York 1002</p>
      </div>
    </div>
  </section>

<?php include 'one.php'; ?>
<?php include 'footer.php'; ?>

</body>
</html>
